# Public sources and third-party materials

- Python timeit: https://docs.python.org/3.14/library/timeit.html
  Python documentation: PSF terms.
- The Python Profilers: https://docs.python.org/3.14/library/profile.html
  Python documentation: PSF terms.
- NumPy Broadcasting: https://numpy.org/doc/stable/user/basics.broadcasting.html
  NumPy: BSD-3-Clause; official documentation.
- Python tracemalloc: https://docs.python.org/3.14/library/tracemalloc.html
  Python documentation: PSF terms.
- Gene M. Amdahl (1967), Validity of the single processor approach to achieving large scale computing capabilities: https://doi.org/10.1145/1465482.1465560
  Scientific historical citation.
