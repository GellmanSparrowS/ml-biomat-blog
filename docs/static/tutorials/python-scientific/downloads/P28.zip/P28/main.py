"""Compare equal neighbor-pair calculations using measured time and memory.

Coordinates are generated teaching data in a 10 um square. Timing samples are
local measurements; memory formulas describe named buffers rather than RSS.
"""
from pathlib import Path
import argparse
import cProfile
import io
import json
import platform
import pstats
import timeit
import tracemalloc
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager



def available_plot_fonts():
    """Choose installed fonts; keep a Latin fallback on every platform."""
    choices = ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]



def pair_count_loop(points, radius):
    count=0;limit=radius*radius
    for i in range(len(points)):
        for j in range(i+1,len(points)):
            dx=points[i,0]-points[j,0];dy=points[i,1]-points[j,1]
            if dx*dx+dy*dy < limit:count+=1
    return count


def pair_count_full(points,radius):
    delta=points[:,None,:]-points[None,:,:]
    squared=np.einsum('ijk,ijk->ij',delta,delta)
    return int(np.count_nonzero(np.triu(squared < radius*radius,k=1)))


def pair_count_blocked(points,radius,block=64):
    count=0;n=len(points);columns=np.arange(n)[None,:]
    for start in range(0,n,block):
        stop=min(start+block,n)
        delta=points[start:stop,None,:]-points[None,:,:]
        squared=np.einsum('ijk,ijk->ij',delta,delta)
        rows=np.arange(start,stop)[:,None]
        count+=int(np.count_nonzero((squared < radius*radius)&(columns>rows)))
        del delta,squared
    return count


def measured_peak(function):
    tracemalloc.start()
    result=function()
    _,peak=tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return result,int(peak)


def analyze_frame(points,radius):
    """A small scientific workload for function-level profiling."""
    center=points.mean(axis=0)
    centered=points-center
    pairs=pair_count_loop(centered,radius)
    radial=np.sqrt(np.einsum('ij,ij->i',centered,centered))
    return {'center':center.tolist(),'pairs':pairs,'mean_radius_um':float(radial.mean())}


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--language',choices=['zh','en'],default='en')
    ap.add_argument('--timing-input',type=Path,help='Reuse an explicitly saved benchmark for an alternative-language figure')
    args=ap.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True);zh=args.language=='zh';tr=lambda a,b:a if zh else b
    sizes=[100,200,400,800];blocks=[16,32,64,128];radius=1.0
    points=np.random.default_rng(2819).uniform(0,10,size=(max(sizes),2))
    hand=np.array([[0.,0.],[1.,0.],[0.,1.],[3.,3.]])
    assert pair_count_loop(hand,1.1)==pair_count_full(hand,1.1)==pair_count_blocked(hand,1.1,2)==2
    if args.timing_input:
        benchmark=json.loads(args.timing_input.read_text(encoding='utf8'))
        assert benchmark['seed']==2819 and benchmark['sizes']==sizes
        records=benchmark['records']
    else:
        records=[]
        for n in sizes:
            x=points[:n];reference=pair_count_loop(x,radius)
            methods=[('loop',0,lambda x=x:pair_count_loop(x,radius)),('full',n,lambda x=x:pair_count_full(x,radius))]
            methods += [('blocked',b,lambda x=x,b=b:pair_count_blocked(x,radius,b)) for b in blocks]
            for method,block,fn in methods:
                assert fn()==reference
                samples=timeit.repeat(fn,number=1,repeat=7)
                result,peak=measured_peak(fn)
                assert result==reference
                records.append({'n':n,'method':method,'block':block,'pairs':result,'seconds':samples,
                                'median_seconds':float(np.median(samples)),'minimum_seconds':min(samples),
                                'traced_peak_bytes':peak,'named_float_buffers_bytes':0 if method=='loop' else 24*n*min(block,n)})
        benchmark={'seed':2819,'sizes':sizes,'radius_um':radius,'python':platform.python_version(),
                   'numpy':np.__version__,'timing_definition':'seven independent timeit runs, one call per run',
                   'memory_definition':'separate tracemalloc peak; named buffers are float64 delta and squared distances',
                   'records':records}
    # Every run still independently checks the saved reference computations.
    for n in sizes:
        expected=next(r['pairs'] for r in records if r['n']==n)
        assert pair_count_full(points[:n],radius)==pair_count_blocked(points[:n],radius,64)==expected
    (out/'benchmark.json').write_text(json.dumps(benchmark,indent=2),encoding='utf8')
    profile=cProfile.Profile();profile_result=profile.runcall(analyze_frame,points[:400],radius)
    assert profile_result['pairs']==next(r['pairs'] for r in records if r['n']==400)
    stream=io.StringIO();pstats.Stats(profile,stream=stream).strip_dirs().sort_stats('cumulative').print_stats(8)
    (out/'profile.txt').write_text(stream.getvalue(),encoding='utf8')
    largest=[r for r in records if r['n']==800]
    summary={'hand_checked_pairs':2,'sizes':sizes,'pair_counts':{str(n):next(r['pairs'] for r in records if r['n']==n) for n in sizes},
             'all_methods_agree':True,'repeats':7,'largest_full_named_buffers_bytes':24*800*800,
             'largest_block64_named_buffers_bytes':24*800*64,'amdahl_p08_s10':1/(.2+.8/10)}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    (out/'lab-data.json').write_text(json.dumps({'points':points.tolist(),'radius':radius,'records':records}),encoding='utf8')
    plt.rcParams.update({'font.family':available_plot_fonts(),'font.size':12,'svg.fonttype':'none','figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','axes.spines.top':False,'axes.spines.right':False})
    colors={'loop':'#b4482e','full':'#205b8c','blocked':'#2b7c73'}
    def save(fig,name):
        fig.savefig(out/f'{name}-{args.language}.svg',metadata={'Date':None});fig.savefig(out/f'{name}-{args.language}.png',dpi=150);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(12.4,5.3),layout='constrained',gridspec_kw={'width_ratios':[1.1,1]})
    for method in ['loop','full','blocked']:
        selected=[r for r in records if r['method']==method and (method!='blocked' or r['block']==64)]
        label=tr({'loop':'Python 双循环','full':'完整广播','blocked':'64 行分块'}[method],{'loop':'Python loops','full':'Full broadcast','blocked':'64-row blocks'}[method])
        axs[0].plot([r['n'] for r in selected],[r['median_seconds']*1000 for r in selected],'-o',color=colors[method],label=label)
        r=next(r for r in selected if r['n']==800);i=['loop','full','blocked'].index(method)
        axs[1].scatter(np.full(7,i)+np.linspace(-.1,.1,7),np.array(r['seconds'])*1000,color=colors[method],s=35)
        axs[1].hlines(r['median_seconds']*1000,i-.24,i+.24,color=colors[method],lw=3)
    axs[0].set(xscale='log',yscale='log',xlabel=tr('点数 N','Point count N'),ylabel=tr('单次中位时间 / ms','Median time per call / ms'))
    axs[0].set_xticks(sizes,[str(n) for n in sizes]);axs[0].xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    axs[0].legend(frameon=False,fontsize=11);axs[0].set_title(tr('A  相同输入与计数定义','A  Equal inputs and counting definitions'),loc='left')
    axs[1].set_yscale('log');axs[1].set_xticks(range(3),tr(['双循环','完整广播','64 行分块'],['Loops','Full','Block 64']))
    axs[1].set_ylabel(tr('单次时间 / ms（7 次）','Time per call / ms (7 runs)'));axs[1].set_title(tr('B  N = 800 的实际重复测量','B  Actual repeated timings at N = 800'),loc='left')
    for ax in axs:ax.grid(axis='y',alpha=.2)
    save(fig,'measured-timings')
    fig,axs=plt.subplots(1,2,figsize=(12.4,5.2),layout='constrained');nn=np.array(sizes)
    axs[0].plot(nn,24*nn**2/2**20,'-o',color=colors['full'],label=tr('完整浮点数组','Full floating-point buffers'))
    axs[0].plot(nn,24*nn*64/2**20,'-o',color=colors['blocked'],label=tr('64 行浮点分块','64-row floating-point buffers'))
    axs[0].set(xlabel=tr('点数 N','Point count N'),ylabel=tr('命名浮点数组大小 / MiB','Named floating-point buffers / MiB'));axs[0].legend(frameon=False,fontsize=10)
    rows=[r for r in largest if r['method']=='full' or (r['method']=='blocked' and r['block'] in [16,64,128])]
    x=np.arange(len(rows));axs[1].bar(x-.17,[r['named_float_buffers_bytes']/2**20 for r in rows],width=.34,color='#a5bfce',label=tr('两个命名数组','Two named arrays'))
    axs[1].bar(x+.17,[r['traced_peak_bytes']/2**20 for r in rows],width=.34,color='#205b8c',label=tr('tracemalloc 峰值','tracemalloc peak'))
    axs[1].set_xticks(x,[('Full' if r['method']=='full' else f"B={r['block']}") for r in rows]);axs[1].set_ylabel(tr('追踪/计算内存 / MiB','Traced/calculated memory / MiB'));axs[1].legend(frameon=False,fontsize=10)
    axs[0].set_title(tr('A  保存形状决定增长规律','A  Stored shapes determine growth'),loc='left');axs[1].set_title(tr('B  N = 800：数组与实际峰值','B  N = 800: arrays and measured peaks'),loc='left')
    save(fig,'memory-growth')
    fig,axs=plt.subplots(1,2,figsize=(12.4,5.2),layout='constrained');accelerations=np.linspace(1,50,250)
    for p,color in [(.5,'#205b8c'),(.8,'#b4482e'),(.95,'#2b7c73')]:
        axs[0].plot(accelerations,1/((1-p)+p/accelerations),color=color,label=f'p = {p}')
    axs[0].set(xlabel=tr('目标部分的加速倍数 s','Speedup s of the selected part'),ylabel=tr('整体加速倍数 S','Overall speedup S'));axs[0].legend(frameon=False)
    axs[0].set_title(tr('A  Amdahl（1967）的时间分解思想','A  Amdahl (1967): decompose elapsed time'),loc='left',fontsize=13)
    axs[1].barh([1,0],[20,20],color='#9db5c3',label=tr('保持不变的部分','Unchanged work'))
    axs[1].barh([1,0],[80,8],left=[20,20],color='#b4482e',label=tr('加速的部分','Accelerated work'))
    axs[1].set_yticks([1,0],tr(['原流程','局部加速 10 倍'],['Original','Local 10× speedup']))
    axs[1].set_xlabel(tr('教学时间预算 / s','Illustrative time budget / s'));axs[1].legend(frameon=False,loc='lower right',fontsize=10)
    axs[1].text(29,0,'100 / 28 ≈ 3.57',va='center',fontsize=13);axs[1].set_title(tr('B  80% 工作加速后的整体变化','B  Accelerating 80% of the original work'),loc='left',fontsize=13)
    save(fig,'amdahl-budget')
    print(json.dumps(summary))


if __name__=='__main__':main()
