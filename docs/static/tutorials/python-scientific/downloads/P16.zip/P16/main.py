"""Compose scientific figures from explicitly defined teaching depletion curves."""
from pathlib import Path
import argparse, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import Normalize, LogNorm

BLUE, RED, INK = '#28658c', '#b64a35', '#20313e'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--language', choices=['zh', 'en'], default='en')
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    zh = args.language == 'zh'
    def tr(a, b): return a if zh else b
    def save(fig, name):
        fig.savefig(args.output/f'{name}-{args.language}.svg')
        fig.savefig(args.output/f'{name}-{args.language}.png', dpi=160)
        plt.close(fig)
    plt.rcParams.update({'font.family':[name for name in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if name in {f.name for f in font_manager.fontManager.ttflist}], 'font.size':12,
                         'svg.fonttype':'none', 'axes.spines.top':False,
                         'axes.spines.right':False, 'axes.labelcolor':INK,
                         'axes.titleweight':'bold', 'savefig.facecolor':'white'})
    t = np.linspace(0, 12, 241)
    taus = np.array([1., 2., 4., 8.])
    mass = 4 * np.exp(-t[None, :] / taus[:, None])
    np.savetxt(args.output/'curves.csv', np.column_stack([t, mass.T]), delimiter=',',
               header='time_min,mass_tau1_mg,mass_tau2_mg,mass_tau4_mg,mass_tau8_mg', comments='')
    norm = Normalize(0, 4)
    fig, ax = plt.subplot_mosaic([['map','map'],['linear','log']], figsize=(12,9),
                                 layout='constrained', gridspec_kw={'height_ratios':[1.05,1]})
    # Rows represent four discrete models; row labels retain physical relaxation times.
    image = ax['map'].imshow(mass, extent=[-.025,12.025,3.5,-.5], aspect='auto',
                             interpolation='nearest', cmap='viridis', norm=norm)
    ax['map'].set(xlim=(0,12), yticks=range(4), yticklabels=['1','2','4','8'], xlabel=tr('时间 / min','Time / min'),
                  ylabel=tr('时间常数 / min','Time constant / min'), title=tr('A  总览：相同质量色标','A  Overview: one mass scale'))
    fig.colorbar(image, ax=ax['map'], label=tr('剩余质量 / mg','Remaining mass / mg'), shrink=.9)
    colors=plt.colormaps['viridis'](np.linspace(.15,.8,4))
    for tau, row, color in zip(taus, mass, colors):
        for key in ['linear','log']:
            ax[key].plot(t,row,color=color,lw=2,label=f'τ = {tau:g} min')
        ax['linear'].scatter([tau*np.log(2)],[2],color=color,s=28,zorder=5)
    ax['linear'].axhline(2,color='#71808b',ls=':',lw=1)
    ax['linear'].set(xlabel=tr('时间 / min','Time / min'),ylabel=tr('剩余质量 / mg','Remaining mass / mg'),
                     ylim=(0,4.2),title=tr('B  线性轴：比较绝对差值','B  Linear axis: absolute differences'))
    ax['log'].set_yscale('log'); ax['log'].set(xlabel=tr('时间 / min','Time / min'),
        ylabel=tr('剩余质量 / mg（对数刻度）','Remaining mass / mg (log scale)'),
        title=tr('C  对数轴：比较倍数与速率','C  Log axis: ratios and rates'))
    for key in ['linear','log']:
        ax[key].set_xlim(0,12); ax[key].grid(alpha=.15); ax[key].legend(fontsize=10,frameon=False)
    save(fig, 'composition')

    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    z=np.array([[.01,.1,1.,4.]])
    for ax, n, title in [(axes[0,0],Normalize(0,4),tr('A  线性颜色：差值相等','A  Linear color: equal differences')),
                          (axes[0,1],LogNorm(.01,4),tr('B  对数颜色：倍数相等','B  Log color: equal ratios'))]:
        im=ax.imshow(z,aspect='auto',norm=n,cmap='viridis'); ax.set(yticks=[],xticks=range(4),
            xticklabels=['0.01','0.1','1','4'],xlabel=tr('选取的质量值 / mg','Selected mass values / mg'),title=title)
        fig.colorbar(im,ax=ax,label=tr('质量 / mg','Mass / mg'),orientation='horizontal',pad=.18)
    a=4*np.exp(-t/4); b=np.exp(-t/4)
    for ax, normalized in [(axes[1,0],False),(axes[1,1],True)]:
        ax.plot(t,a/4 if normalized else a,color=BLUE,lw=2,label=tr('样品 A，初始 4 mg','Sample A, initially 4 mg'))
        ax.plot(t,b if normalized else b,color=RED,lw=2,ls='--',label=tr('样品 B，初始 1 mg','Sample B, initially 1 mg'))
        ax.set(xlabel=tr('时间 / min','Time / min'),ylabel=tr('剩余比例','Remaining fraction') if normalized else tr('质量 / mg','Mass / mg'),
               title=tr('D  除以各自初值：曲线重合','D  Divide by each initial value: overlap') if normalized else tr('C  原始量：A 是 B 的 4 倍','C  Raw quantity: a factor of four'))
        ax.legend(frameon=False,fontsize=10); ax.grid(alpha=.15)
    save(fig, 'mapping')

    fig=plt.figure(figsize=(12,5.2),layout='constrained');axes=fig.subplots(1,2,gridspec_kw={'width_ratios':[.8,1.2]})
    axes[0].axis('off')
    values=np.column_stack([np.arange(0,13,3),4*np.exp(-np.arange(0,13,3)/2),4*np.exp(-np.arange(0,13,3)/8)])
    table=axes[0].table(cellText=[[f'{r[0]:.0f}',f'{r[1]:.2f}',f'{r[2]:.2f}'] for r in values],
        colLabels=[tr('时间/min','Time/min'),'τ=2 min','τ=8 min'],cellLoc='center',loc='center')
    table.auto_set_font_size(False);table.set_fontsize(12);table.scale(1,2.2)
    axes[0].set_title(tr('数字：逐项读取','Numbers: read item by item'),loc='left')
    axes[1].plot(values[:,0],values[:,1],'o-',color=BLUE,label='τ=2 min')
    axes[1].plot(values[:,0],values[:,2],'s-',color=RED,label='τ=8 min')
    axes[1].set(xlabel=tr('时间 / min','Time / min'),ylabel=tr('剩余质量 / mg','Remaining mass / mg'),
                title=tr('共同坐标：同时比较过程','Common coordinates: compare processes'))
    axes[1].legend(frameon=False);axes[1].grid(alpha=.15)
    fig.suptitle(tr('从 Playfair 1786 年图表传统到可复现科学图','From Playfair’s 1786 chart tradition to reproducible figures'),fontsize=15)
    save(fig, 'history')
    summary={'versions':{'numpy':np.__version__,'matplotlib':matplotlib.__version__},
             'initial_mg':float(mass[2,0]),'tau4_t4_mg':float(4/np.e),
             'half_times_min':(taus*np.log(2)).tolist(),'half_mass_mg':2.,
             'linear_color_1mg':float(norm(1)), 'log_color_1mg':float(LogNorm(.01,4)(1)),
             'raw_mass_ratio':4.,'normalized_difference_max':float(np.max(np.abs(a/4-b)))}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False))


if __name__=='__main__': main()
