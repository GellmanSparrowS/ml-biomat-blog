# Public sources and third-party materials

- Matplotlib: constrained layout: https://matplotlib.org/3.10.9/users/explain/axes/constrainedlayout_guide.html
  Matplotlib license; original teaching code and figures
- Matplotlib: subplot mosaic: https://matplotlib.org/3.10.9/users/explain/axes/mosaic.html
  Matplotlib license; original teaching code and figures
- Matplotlib: colormap normalization: https://matplotlib.org/3.10.9/users/explain/colors/colormapnorms.html
  Matplotlib license; original teaching code and figures
- Matplotlib: choosing colormaps: https://matplotlib.org/3.10.9/users/explain/colors/colormaps.html
  Matplotlib license; original teaching code and figures
- Playfair, The Commercial and Political Atlas (1786), Wellcome Collection: https://wellcomecollection.org/works/kau5c9ny
  Historical bibliographic reference; no image or text reproduction
