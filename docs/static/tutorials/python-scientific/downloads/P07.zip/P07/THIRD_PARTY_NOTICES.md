# Public sources and third-party materials

- NumPy: the absolute basics for beginners: https://numpy.org/doc/stable/user/absolute_beginners.html
  NumPy code and documentation: BSD-3-Clause; teaching narrative and figures here are independently written.
- numpy.mean: https://numpy.org/doc/stable/reference/generated/numpy.mean.html
  BSD-3-Clause documentation.
- numpy.std: https://numpy.org/doc/stable/reference/generated/numpy.std.html
  BSD-3-Clause documentation.
- Harris et al. — Array programming with NumPy (2020): https://doi.org/10.1038/s41586-020-2649-2
  Scientific attribution; original concept figures, no publisher artwork reproduced.
