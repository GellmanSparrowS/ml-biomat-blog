"""Represent repeated thickness measurements as an array and inspect both axes."""
from pathlib import Path
import argparse
import csv
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import patches, font_manager

TIME = np.array([0, 10, 20, 40, 60], dtype=float)
SPECIMENS = ["A", "B", "C"]
THICKNESS = np.array([
    [1.00, 1.08, 1.14, 1.18, 1.20],
    [1.02, 1.09, 1.16, 1.21, 1.24],
    [0.98, 1.05, 1.11, 1.15, 1.18],
], dtype=np.float64)
COLORS = ["#28648a", "#b85336", "#467a62"]
INK = "#172b36"

def style():
    available = {font.name for font in font_manager.fontManager.ttflist}
    family = next((name for name in ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"] if name in available), "DejaVu Sans")
    plt.rcParams.update({"font.family": family, "font.size": 12, "axes.labelsize": 13,
        "axes.titlesize": 14, "axes.titleweight": "bold", "axes.spines.top": False,
        "axes.spines.right": False, "axes.edgecolor": INK, "axes.labelcolor": INK,
        "text.color": INK, "xtick.color": INK, "ytick.color": INK,
        "figure.facecolor": "#fbfaf6", "axes.facecolor": "#fbfaf6", "savefig.facecolor": "#fbfaf6",
        "svg.fonttype": "none", "pdf.fonttype": 42, "axes.unicode_minus": False})

def label(zh, en, language):
    return zh if language == "zh" else en

def save(fig, output, name, language):
    fig.savefig(output / f"{name}-{language}.svg", bbox_inches="tight", pad_inches=0.22)
    fig.savefig(output / f"{name}-{language}.png", dpi=170, bbox_inches="tight", pad_inches=0.22)
    plt.close(fig)

def figures(output, language, mean_time, mean_specimen, spread):
    t = lambda zh, en: label(zh, en, language)
    fig = plt.figure(figsize=(12.5, 6.8), layout="constrained")
    grid = fig.add_gridspec(2, 2, width_ratios=[1.4, 1], height_ratios=[1, 0.27])
    ax = fig.add_subplot(grid[0, 0])
    im = ax.imshow(THICKNESS, cmap="cividis", vmin=0.95, vmax=1.25, aspect="auto")
    for i in range(3):
        for j in range(5):
            ax.text(j, i, f"{THICKNESS[i,j]:.2f}", ha="center", va="center", fontsize=16,
                    color="white" if THICKNESS[i,j] < 1.09 else INK)
    ax.add_patch(patches.Rectangle((1.5, .5), 1, 1, fill=False, lw=3.5, ec="#e4a321"))
    ax.set_xticks(range(5), [f"{int(v)}" for v in TIME]); ax.set_yticks(range(3), SPECIMENS)
    ax.set_xlabel(t("时间 / min（第1轴）", "Time / min (axis 1)")); ax.set_ylabel(t("样品（第0轴）", "Specimen (axis 0)"))
    ax.set_title(t("a  同一张表，两个索引", "a  One table, two indices"), loc="left", pad=16)
    cbar = fig.colorbar(im, ax=ax, shrink=.8, pad=.04)
    cbar.set_label(t("厚度 / mm", "Thickness / mm"))
    ax = fig.add_subplot(grid[0, 1])
    for i, color in enumerate(COLORS):
        ax.plot(TIME, THICKNESS[i], "o-", color=color, lw=2.2, ms=6, label=SPECIMENS[i])
    ax.scatter([20], [1.16], s=180, facecolor="none", edgecolor="#e4a321", lw=2.5, zorder=5)
    ax.annotate("h[1, 2] = 1.16 mm", xy=(20, 1.16), xytext=(25, 1.045),
                arrowprops={"arrowstyle":"->", "color": INK}, fontsize=12)
    ax.set(xlabel=t("时间 / min", "Time / min"), ylabel=t("厚度 / mm", "Thickness / mm"), ylim=(.95,1.27))
    ax.legend(title=t("样品", "Specimen"), frameon=False, ncol=3, loc="upper left")
    ax.set_title(t("b  行身份成为曲线身份", "b  Rows become individual curves"), loc="left", pad=16)
    ax = fig.add_subplot(grid[1, :]); ax.axis("off")
    lines = [t("shape = (3, 5)：3个样品 × 5个时刻", "shape = (3, 5): 3 specimens × 5 times"),
             t("ndim = 2：两个索引；size = 15：十五个数", "ndim = 2: two indices; size = 15: fifteen values"),
             t("教学构造数据；颜色与数字表示同一厚度。", "Constructed teaching data; color and number encode the same thickness.")]
    for y, text in zip([.82,.44,.06], lines): ax.text(.01,y,text,fontsize=13,transform=ax.transAxes)
    save(fig,output,"array-anatomy",language)

    fig = plt.figure(figsize=(12.5, 7.8), layout="constrained")
    grid = fig.add_gridspec(2, 2, width_ratios=[1.45,1], height_ratios=[1,.8])
    ax = fig.add_subplot(grid[:, 0])
    for i, color in enumerate(COLORS): ax.plot(TIME, THICKNESS[i], "o-", color=color, lw=1.5, alpha=.75, label=SPECIMENS[i])
    ax.errorbar(TIME, mean_time, yerr=spread, fmt="D-", color=INK, lw=2.7, ms=6, capsize=5,
                label=t("均值 ± 样本标准差", "Mean ± sample SD"))
    ax.set(xlabel=t("时间 / min", "Time / min"), ylabel=t("厚度 / mm", "Thickness / mm"), ylim=(.94,1.28))
    ax.set_title(t("a  axis=0：每个时刻，汇总三个样品", "a  axis=0: combine specimens at each time"),loc="left",pad=16)
    ax.legend(frameon=False,loc="upper left",fontsize=11)
    ax.text(.04,.03,t("结果形状 (5,)；保留时间顺序", "Output shape (5,); time order is retained"),transform=ax.transAxes,fontsize=12)
    ax = fig.add_subplot(grid[0,1])
    ax.barh(SPECIMENS, mean_specimen, color=COLORS, height=.5)
    for i, value in enumerate(mean_specimen): ax.text(value+.015,i,f"{value:.3f}",va="center",fontsize=13)
    ax.set(xlabel=t("五个观测时刻的等权平均 / mm", "Equally weighted mean of five observations / mm"), xlim=(0,1.35))
    ax.invert_yaxis(); ax.set_title(t("b  axis=1：每个样品，汇总五个时刻", "b  axis=1: combine times within each specimen"),loc="left",pad=16)
    ax = fig.add_subplot(grid[1,1]); ax.axis("off")
    values=[t("留下什么？", "What remains?"),t("axis=0  →  时间，5个数", "axis=0  →  time, five values"),t("axis=1  →  样品，3个数", "axis=1  →  specimen, three values"),t("axis=None  →  全表，1个数", "axis=None  →  the whole table, one value"),t("时间间隔不等：行平均是观测平均。", "Unequal time gaps: row means average observations."),t("它与按持续时间加权的平均不同。", "A duration-weighted average answers another question.")]
    for y, text in zip([.92,.72,.54,.36,.14,.0], values): ax.text(.02,y,text,fontsize=12.5 if y<.9 else 14,weight="bold" if y>.9 else "normal")
    save(fig,output,"axis-reductions",language)

    fig, axes=plt.subplots(3,1,figsize=(12.5,7.8),gridspec_kw={"height_ratios":[1,.8,1]},layout="constrained")
    for ax in axes: ax.axis("off");ax.set_xlim(0,15);ax.set_ylim(0,1)
    ax=axes[0]
    ax.text(0,.97,t("a  一致的数据对象：数值 + 形状 + 类型", "a  One array object: values + shape + type"),weight="bold",fontsize=15)
    flat=THICKNESS.ravel()
    for k, value in enumerate(flat):
        ax.add_patch(patches.Rectangle((k+.03,.18),.92,.42,facecolor=COLORS[k//5],alpha=.17,edgecolor=COLORS[k//5]))
        ax.text(k+.49,.39,f"{value:.2f}",ha="center",va="center",fontsize=11)
    ax.text(.1,.03,t("连续存储示意；行优先排列", "Contiguous-storage schematic; row-major order"),fontsize=12)
    ax=axes[1]
    ax.text(0,.92,t("b  同一个计算规则，可以作用于整组数", "b  The same numerical rule acts on a group of values"),weight="bold",fontsize=15)
    ax.text(.25,.4,"(1.14 + 1.16 + 1.11) / 3",fontsize=20,color=INK)
    ax.annotate("",xy=(8.4,.45),xytext=(6.4,.45),arrowprops={"arrowstyle":"->","lw":2,"color":INK})
    ax.text(8.6,.4,"h.mean(axis=0)[2]",fontsize=20,color=COLORS[0])
    ax=axes[2]
    ax.text(0,.97,t("c  科学需求推动共同的数组接口", "c  Scientific needs motivate a common array interface"),weight="bold",fontsize=15)
    boxes=[(0,4.2,"Numeric",t("1990年代：Python中的数值数组", "1990s: numerical arrays in Python")),(5.1,4.2,"Numarray",t("大幅天文图像与灵活索引", "Large astronomical images and flexible indexing")),(10.2,4.6,"NumPy",t("2005：整合既有数组工作的方向", "2005: a shared direction for earlier array work"))]
    for x,w,name,description in boxes:
        ax.add_patch(patches.Rectangle((x,.15),w,.52,facecolor="#e8e6dc",edgecolor="none"))
        ax.text(x+.18,.48,name,fontsize=17,weight="bold")
        ax.text(x+.18,.27,description,fontsize=10.4)
    save(fig,output,"array-history",language)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=Path("output"))
    parser.add_argument("--language",choices=["zh","en"],default="zh")
    args=parser.parse_args(); args.output.mkdir(parents=True,exist_ok=True);style()
    mean_time=THICKNESS.mean(axis=0)
    mean_specimen=THICKNESS.mean(axis=1)
    spread=THICKNESS.std(axis=0,ddof=1)
    manual_columns=np.array([sum(THICKNESS[i,j] for i in range(3))/3 for j in range(5)])
    np.testing.assert_allclose(mean_time,manual_columns,rtol=0,atol=1e-14)
    np.save(args.output/"thickness.npy",THICKNESS)
    np.savetxt(args.output/"thickness.csv",THICKNESS,delimiter=",",fmt="%.2f")
    recovered=np.load(args.output/"thickness.npy")
    np.testing.assert_array_equal(recovered,THICKNESS)
    np.testing.assert_allclose(np.loadtxt(args.output/"thickness.csv",delimiter=","),THICKNESS,rtol=0,atol=1e-14)
    summary={"data_kind":"constructed teaching data","specimens":SPECIMENS,"time_min":TIME.tolist(),
             "thickness_mm":THICKNESS.tolist(),"shape":list(THICKNESS.shape),"ndim":THICKNESS.ndim,
             "size":THICKNESS.size,"dtype":str(THICKNESS.dtype),"nbytes":THICKNESS.nbytes,
             "mean_over_specimens_mm":mean_time.tolist(),"mean_over_observed_times_mm":mean_specimen.tolist(),
             "sample_sd_over_specimens_mm":spread.tolist(),"overall_mean_mm":float(THICKNESS.mean()),
             "npy_roundtrip_exact":bool(np.array_equal(recovered,THICKNESS))}
    (args.output/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    figures(args.output,args.language,mean_time,mean_specimen,spread)
    print(json.dumps({"shape":summary["shape"],"mean_over_specimens_mm":summary["mean_over_specimens_mm"]}))

if __name__=="__main__":main()
