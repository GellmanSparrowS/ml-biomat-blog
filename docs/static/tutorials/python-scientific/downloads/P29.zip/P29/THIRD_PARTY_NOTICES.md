# Public sources and third-party materials

- NIST StRD: Misra1a: https://www.itl.nist.gov/div898/strd/nls/data/misra1a.shtml
  NIST Standard Reference Database 140; free SRD with NIST SRD terms and source attribution.
- NIST SRD copyright and licensing: https://www.nist.gov/open/copyright-fair-use-and-licensing-statements-srd-data-software-and-technical-series-publications
  NIST official SRD terms; SRD is a distinct category under 15 USC 290e.
- SciPy curve_fit: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html
  SciPy BSD-3-Clause; original chapter implementation.
- Langmuir (1918), The Adsorption of Gases on Plane Surfaces of Glass, Mica and Platinum: https://pubs.acs.org/jacsat/article/40/9/1361/430014/THE-ADSORPTION-OF-GASES-ON-PLANE-SURFACES-OF-GLASS
  Scientific historical citation; original explanatory diagram.
- NIST StRD background: https://www.nist.gov/itl/sed/statistical-reference-datasets/strd-background-information
  Official NIST information.
