"""Analyze the observed NIST Misra1a adsorption data and fitting range."""
from pathlib import Path
from io import StringIO
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.stats import t
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Circle, Rectangle



def available_plot_fonts():
    """Choose installed fonts; keep a Latin fallback on every platform."""
    choices = ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]



def exponential(pressure, capacity, scale):
    return -capacity * np.expm1(-scale * pressure)


def langmuir(pressure, capacity, scale):
    return capacity * scale * pressure / (1 + scale * pressure)


def jacobian(pressure, capacity, scale, model):
    if model == 'exponential':
        return np.column_stack((-np.expm1(-scale * pressure),
                                capacity * pressure * np.exp(-scale * pressure)))
    denominator = 1 + scale * pressure
    return np.column_stack((scale * pressure / denominator,
                            capacity * pressure / denominator**2))


def load_data(path):
    raw = path.read_bytes()
    text = raw.decode('ascii')
    # The first Data heading describes variables; the second starts the numbers.
    numeric = text.split('Data:   y               x', 1)[1]
    frame = pd.read_csv(StringIO(numeric), sep=r'\s+', names=['volume', 'pressure'])
    if len(frame) != 14 or not np.isfinite(frame.to_numpy()).all():
        raise ValueError('Expected 14 finite observations')
    if frame.pressure.duplicated().any() or (frame <= 0).any().any():
        raise ValueError('Expected positive values and unique pressures')
    return frame.sort_values('pressure').reset_index(drop=True), hashlib.sha256(raw).hexdigest()


def fit(frame, count, model, grid):
    pressure = frame.pressure.to_numpy(dtype=float)
    volume = frame.volume.to_numpy(dtype=float)
    function = exponential if model == 'exponential' else langmuir
    parameters, covariance = curve_fit(
        function, pressure[:count], volume[:count], p0=[250, .0005],
        jac=lambda x, a, k: jacobian(x, a, k, model), bounds=(0, np.inf),
        x_scale=[250, .0005], ftol=1e-13, xtol=1e-13, gtol=1e-13,
        max_nfev=10000)
    residuals = volume - function(pressure, *parameters)
    rss = float(residuals[:count] @ residuals[:count])
    gradient = jacobian(grid, *parameters, model)
    variance = np.einsum('ij,jk,ik->i', gradient, covariance, gradient)
    half_width = t.ppf(.975, count - 2) * np.sqrt(np.maximum(0, variance))
    standard_error = np.sqrt(np.diag(covariance))
    return {'model': model, 'count': count, 'max_pressure': float(pressure[count-1]),
            'capacity': float(parameters[0]), 'scale': float(parameters[1]),
            'standard_errors': standard_error.tolist(),
            'correlation': float(covariance[0, 1] / np.prod(standard_error)),
            'rss': rss, 'residual_sd': float(np.sqrt(rss / (count-2))),
            'residuals': residuals.tolist(), 'prediction': function(grid, *parameters).tolist(),
            'mean_ci_half_width': half_width.tolist()}


def figures(frame, states, grid, output, language):
    zh = language == 'zh'
    tr = lambda a, b: a if zh else b
    plt.rcParams.update({'font.family': available_plot_fonts(),
                         'font.size': 13, 'axes.spines.top': False,
                         'axes.spines.right': False, 'svg.fonttype': 'none',
                         'axes.unicode_minus': False})
    blue, orange, green = '#205b8c', '#bd5535', '#2b7c73'
    p, v = frame.pressure.to_numpy(), frame.volume.to_numpy()
    full = next(s for s in states if s['count'] == 14 and s['model'] == 'exponential')
    other = next(s for s in states if s['count'] == 14 and s['model'] == 'langmuir')
    xlabel = tr('压力 / 原记录压力单位', 'Pressure / recorded pressure unit')
    ylabel = tr('体积 / 原记录体积单位', 'Volume / recorded volume unit')

    def save(fig, name):
        for suffix in ['svg', 'png']:
            fig.savefig(output / f'{name}-{language}.{suffix}', dpi=160,
                        facecolor='#faf9f5', bbox_inches='tight')
        plt.close(fig)

    fig, axes = plt.subplots(2, 1, figsize=(12, 8), sharex=True,
                             gridspec_kw={'height_ratios': [2.2, 1]}, layout='constrained')
    selected = grid <= 800
    prediction, half = np.array(full['prediction']), np.array(full['mean_ci_half_width'])
    axes[0].fill_between(grid[selected], (prediction-half)[selected],
                         (prediction+half)[selected], color=blue, alpha=.2,
                         label=tr('均值曲线的近似95%区间', 'Approximate 95% interval for the mean curve'))
    axes[0].plot(grid[selected], prediction[selected], color=blue, lw=2.5,
                 label=tr('指数模型拟合', 'Exponential model fit'))
    axes[0].scatter(p, v, s=56, facecolor='#faf9f5', edgecolor=orange,
                    linewidth=2, zorder=3, label=tr('14个观测值', '14 observed values'))
    axes[0].set(ylabel=ylabel, title=tr('观测与曲线：体积增加逐渐放缓',
                                      'Observations and curve: volume increases more slowly'))
    axes[0].legend(loc='upper left', fontsize=12)
    axes[1].axhline(0, color='#667782', lw=1)
    axes[1].stem(p, full['residuals'], linefmt=blue, markerfmt='o', basefmt=' ')
    axes[1].set(xlabel=xlabel, ylabel=tr('残差 / 体积单位', 'Residual / volume unit'),
                title=f"RSS = {full['rss']:.8f};  " + tr('自由度 = 12', 'degrees of freedom = 12'))
    save(fig, 'fit-and-residuals')

    fig = plt.figure(figsize=(13, 8), layout='constrained')
    gs = fig.add_gridspec(2, 2, width_ratios=[1.35, 1])
    ax = fig.add_subplot(gs[:, 0]); top = fig.add_subplot(gs[0, 1]); bottom = fig.add_subplot(gs[1, 1])
    capacities = np.linspace(210, 270, 180)
    scales = np.linspace(.000475, .00064, 180)
    aa, kk = np.meshgrid(capacities, scales)
    rss = np.sum((v[:, None, None] - exponential(p[:, None, None], aa, kk))**2, axis=0)
    filled = ax.contourf(aa, kk*1000, np.log10(rss/full['rss']),
                         levels=np.linspace(0, 4, 17), cmap='cividis', extend='max')
    ax.plot(full['capacity'], full['scale']*1000, '*', color=orange, ms=16)
    ax.set(xlabel=tr('容量参数 A / 体积单位', 'Capacity parameter A / volume unit'),
           ylabel=tr('尺度参数 k / 10⁻³ 压力单位⁻¹', 'Scale parameter k / 10⁻³ pressure unit⁻¹'),
           title=tr('同一批数据形成狭长的参数谷', 'A narrow parameter valley for the same data'))
    fig.colorbar(filled, ax=ax, label='log₁₀(RSS / RSSmin)', shrink=.7)
    subset = [s for s in states if s['model'] == 'exponential']
    for axis, key, index, factor, label in [(top, 'capacity', 0, 1, 'A'),
                                            (bottom, 'scale', 1, 1000, 'k × 1000')]:
        axis.errorbar([s['max_pressure'] for s in subset],
                       [s[key]*factor for s in subset],
                       yerr=[s['standard_errors'][index]*factor for s in subset],
                       color=blue, marker='o', capsize=3)
        axis.axhline(full[key]*factor, color=orange, ls='--')
        axis.set(ylabel=(tr('A / 体积单位','A / volume unit') if key=='capacity'
                         else tr('k / 10⁻³ 压力单位⁻¹','k / 10⁻³ pressure unit⁻¹')))
    top.set_title(tr('逐步纳入高压力观测\n误差棒为1 SE',
                     'Include higher-pressure observations\nBars show 1 SE'), fontsize=13)
    bottom.set_xlabel(tr('拟合范围的最大压力 / 原单位',
                         'Maximum fitted pressure / recorded unit'))
    save(fig, 'parameter-coverage')

    fig = plt.figure(figsize=(13, 8), layout='constrained')
    gs = fig.add_gridspec(2, 2, height_ratios=[.85, 1.35], width_ratios=[1, 1])
    surface = fig.add_subplot(gs[0, 0]); explanation = fig.add_subplot(gs[0, 1])
    curve = fig.add_subplot(gs[1, :])
    for axis in [surface, explanation]:
        axis.set(xlim=(0, 10), ylim=(0, 4)); axis.axis('off')
    surface.add_patch(Rectangle((.4, .5), 9, .65, facecolor='#ccd5d8'))
    occupied = {0, 2, 3, 6, 8}
    for i in range(9):
        surface.add_patch(Rectangle((.6+i, 1.15), .65, .12, color=blue))
        if i in occupied:
            surface.add_patch(Circle((.925+i, 1.65), .32, facecolor=orange))
    surface.annotate('', xy=(1.925, 1.5), xytext=(1.925, 3.3),
                     arrowprops={'arrowstyle': '->', 'lw': 2, 'color': blue})
    surface.annotate('', xy=(6.925, 3.3), xytext=(6.925, 2.1),
                     arrowprops={'arrowstyle': '->', 'lw': 2, 'color': orange})
    surface.text(.4, 3.75, tr('有限位点：空位吸附，已占位点脱附',
                             'Finite sites: adsorption and desorption'), fontsize=14)
    surface.text(.4, .05, tr('位点占据示意：5个占据，4个空位',
                            'Site occupancy: five occupied, four vacant'), fontsize=12)
    explanation.text(.2, 3.5, 'Langmuir, 1918', fontsize=19, weight='bold')
    explanation.text(.2, 2.55, tr('单层、等价位点、动态平衡',
                                 'Monolayer, equivalent sites, dynamic balance'), fontsize=14)
    explanation.text(.2, 1.55, r'$V=A K P/(1+K P)$', fontsize=21, color=green)
    explanation.text(.2, .3, tr('指数曲线采用另一种函数形状；分别检验',
                               'The exponential curve has a different shape'), fontsize=13)
    curve.axvspan(0, p.max(), color='#d8e2e7', alpha=.7,
                   label=tr('观测覆盖范围', 'Observed pressure coverage'))
    curve.plot(grid, full['prediction'], color=blue, lw=2.5,
                label=tr('指数模型', 'Exponential') + f"; RSS={full['rss']:.3f}")
    curve.plot(grid, other['prediction'], color=green, lw=2.5, ls='--',
                label=f"Langmuir; RSS={other['rss']:.3f}")
    curve.scatter(p, v, color=orange, s=25, zorder=3)
    curve.set(xlabel=xlabel, ylabel=ylabel, xlim=(0, grid.max()),
                title=tr('越过观测区间，模型形状的差别逐渐放大',
                         'Model shapes diverge beyond the observations'))
    curve.legend(loc='lower right', fontsize=12)
    save(fig, 'surface-and-extrapolation')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path('results'))
    parser.add_argument('--language', choices=['zh', 'en'], default='en')
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    frame, checksum = load_data(Path(__file__).resolve().parent / 'data' / 'Misra1a.dat')
    grid = np.linspace(0, 4000, 401)
    states = [fit(frame, count, model, grid) for model in ['exponential', 'langmuir']
              for count in range(6, 15)]
    full = next(s for s in states if s['model'] == 'exponential' and s['count'] == 14)
    assert np.allclose([full['capacity'], full['scale']],
                       [238.94212918, .00055015643181], rtol=2e-8, atol=0)
    assert abs(full['rss'] - .12455138894) < 1e-10
    frame['fitted_volume'] = exponential(frame.pressure.to_numpy(), full['capacity'], full['scale'])
    frame['residual'] = frame.volume - frame.fitted_volume
    frame.to_csv(args.output / 'observations-and-fit.csv', index=False)
    data = {'pressure': frame.pressure.tolist(), 'volume': frame.volume.tolist(),
            'grid': grid.tolist(), 'states': states}
    (args.output / 'lab-data.json').write_text(json.dumps(data), encoding='utf8')
    summary = {'observations': len(frame), 'data_sha256': checksum,
               'units': {'pressure': 'recorded pressure unit, SI identity unspecified',
                         'volume': 'recorded volume unit, SI identity unspecified'},
               'exponential': {k: v for k, v in full.items()
                               if k not in ['prediction', 'mean_ci_half_width', 'residuals']},
               'langmuir_rss': states[-1]['rss'],
               'first_residual': float(frame.residual.iloc[0]),
               'observed_fraction_of_capacity': float(frame.volume.max()/full['capacity']),
               'states': len(states)}
    (args.output / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf8')
    figures(frame, states, grid, args.output, args.language)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
