"""Run scientific tests and compare deliberately changed implementations."""
from pathlib import Path
import argparse
import json
import math
import os
import re
import subprocess
import sys
import textwrap
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import ListedColormap
from measurement import mask_area

HERE=Path(__file__).resolve().parent



def available_plot_fonts():
    """Choose installed fonts; keep a Latin fallback on every platform."""
    choices = ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]



def changed_area(mask,spacing,mode):
    """Teaching mutations: each intentionally changes one scientific rule."""
    if mode=='correct':return mask_area(mask,spacing)
    if mode=='no_validation':return float(np.count_nonzero(mask)*spacing[0]*spacing[1])
    mask_area(mask,spacing)  # These two mutations retain the input checks.
    if mode=='one_scale':return float(np.count_nonzero(mask)*spacing[0])
    if mode=='whole_grid':return float(mask.size*spacing[0]*spacing[1])
    raise ValueError(mode)


def cases():
    rectangle=np.zeros((8,10),bool);rectangle[2:5,1:5]=True
    return [
        ('unit_square',np.ones((2,2),bool),(1.,1.),4.),
        ('rectangle',rectangle,(.2,.3),.72),
        ('empty',np.zeros((8,10),bool),(.2,.3),0.),
        ('doubled',rectangle,(.4,.6),2.88),
        ('negative',rectangle,(-.2,.3),'ValueError'),
        ('nonfinite',rectangle,(.2,float('nan')),'ValueError'),
        ('volume',np.ones((2,3,4),bool),(.2,.3),'ValueError'),
        ('intensity',np.array([[0,120],[80,255]]),(.2,.3),'TypeError')]


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--language',choices=['zh','en'],default='en');args=ap.parse_args()
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=True);zh=args.language=='zh';tr=lambda a,b:a if zh else b
    environment=os.environ.copy();environment['PYTHONDONTWRITEBYTECODE']='1'
    environment['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
    command=[sys.executable,'-m','pytest',str(HERE/'test_measurement.py'),'-q','--rootdir',str(HERE),'-p','no:cacheprovider']
    completed=subprocess.run(command,cwd=HERE,text=True,capture_output=True,env=environment)
    (out/'pytest-output.txt').write_text(completed.stdout+completed.stderr,encoding='utf8')
    if completed.returncode:raise RuntimeError('Scientific tests failed; see pytest-output.txt')
    negative=subprocess.run([sys.executable,'-m','pytest','failure_demo.py','-q','--tb=short','-p','no:cacheprovider'],cwd=HERE,text=True,capture_output=True,env=environment)
    if negative.returncode!=1:raise RuntimeError('The deliberate missing-scale example must fail its assertion')
    (out/'failure-example.txt').write_text(negative.stdout+negative.stderr,encoding='utf8')
    modes=['correct','one_scale','whole_grid','no_validation'];records=[]
    for name,mask,spacing,expected in cases():
        for mode in modes:
            try:
                value=changed_area(mask,spacing,mode)
                observed=value if math.isfinite(value) else 'NaN'
            except (ValueError,TypeError) as error:observed=type(error).__name__
            passed=(observed==expected if isinstance(expected,str) else isinstance(observed,(int,float)) and math.isclose(observed,expected,rel_tol=1e-12,abs_tol=1e-12))
            records.append({'case':name,'mode':mode,'expected':expected,'observed':observed,'passed':bool(passed)})
    passes={m:sum(r['passed'] for r in records if r['mode']==m) for m in modes}
    passed_count=int(re.search(r'(\d+) passed',completed.stdout).group(1))
    summary={'pytest_exit_code':completed.returncode,'pytest_passed':passed_count,'deliberate_failure_exit':negative.returncode,'cases':8,'modes':4,'pass_counts':passes,
             'rectangle_area_um2':mask_area(cases()[1][1],(.2,.3)),'mutation_results':records}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    inputs={name:{'shape':list(mask.shape),'dtype':str(mask.dtype),'mask':mask.tolist(),
                  'spacing':[v if math.isfinite(v) else 'NaN' for v in spacing]}
            for name,mask,spacing,expected in cases()}
    (out/'lab-data.json').write_text(json.dumps({'records':records,'modes':modes,'cases':[c[0] for c in cases()],'inputs':inputs}),encoding='utf8')
    plt.rcParams.update({'font.family':available_plot_fonts(),'font.size':12,'svg.fonttype':'none','figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','axes.spines.top':False,'axes.spines.right':False})
    def save(fig,name):
        fig.savefig(out/f'{name}-{args.language}.svg',metadata={'Date':None});fig.savefig(out/f'{name}-{args.language}.png',dpi=150);plt.close(fig)
    mask=cases()[1][1];fig,ax=plt.subplots(figsize=(9,5.3),layout='constrained')
    ax.imshow(mask,cmap=ListedColormap(['#f0f2f3','#205b8c']),extent=(0,3,1.6,0),interpolation='nearest')
    ax.vlines(np.arange(0,3.01,.3),0,1.6,color='white',lw=1.2)
    ax.hlines(np.arange(0,1.61,.2),0,3,color='white',lw=1.2)
    ax.set(xlabel=tr('水平位置 / μm','Horizontal position / μm'),ylabel=tr('垂直位置 / μm','Vertical position / μm'))
    ax.text(1.8,.65,tr('选中 4 列 × 3 行\n宽 1.2 μm，高 0.6 μm\n独立几何面积 = 0.72 μm²','4 columns × 3 rows selected\nWidth 1.2 μm, height 0.6 μm\nGeometric area = 0.72 μm²'),fontsize=12,linespacing=1.8)
    ax.set_title(tr('一个能在纸上独立算出答案的测试对象','A test object with an independently calculable answer'),loc='left')
    save(fig,'known-geometry')
    grid=np.array([[int(next(r['passed'] for r in records if r['case']==case[0] and r['mode']==m)) for m in modes] for case in cases()])
    fig,ax=plt.subplots(figsize=(12.4,6.4),layout='constrained');ax.imshow(grid,cmap=ListedColormap(['#f1d7cb','#deebe6']),vmin=0,vmax=1,aspect='auto')
    names=tr(['单位方格','有背景的矩形','空区域','双向尺度加倍','负标定','非有限标定','误传三维数组','误传灰度数组'],['Unit square','Rectangle with background','Empty region','Both lengths doubled','Negative calibration','Nonfinite calibration','3D input','Intensity input'])
    ax.set_xticks(range(4),tr(['正确实现','漏乘一个尺度','误数整个网格','省略输入检查'],['Correct','One scale missing','Whole grid counted','No input validation']))
    ax.set_yticks(range(8),names)
    for y in range(8):
        for x in range(4):ax.text(x,y,'PASS' if grid[y,x] else 'FAIL',ha='center',va='center',color='#205b55' if grid[y,x] else '#9b3e21',fontsize=13)
    ax.set_title(tr('测试诊断矩阵：不同科学条件发现不同错误','Diagnostic test matrix: different conditions detect different errors'),loc='left',pad=18)
    save(fig,'test-matrix')
    fig=plt.figure(figsize=(13.2,7.3));gs=fig.add_gridspec(2,2,width_ratios=[1,1.6],height_ratios=[1.3,1],left=.06,right=.97,bottom=.15,top=.88,hspace=.23,wspace=.18)
    geom=fig.add_subplot(gs[0,0]);geom.imshow(mask,cmap=ListedColormap(['#edf1f3','#205b8c']),extent=(0,3,1.6,0),interpolation='nearest')
    geom.vlines(np.arange(0,3.01,.3),0,1.6,color='white',lw=1);geom.hlines(np.arange(0,1.61,.2),0,3,color='white',lw=1)
    geom.set(xlabel=tr('横坐标 / μm','Horizontal position / μm'),ylabel=tr('纵坐标 / μm','Vertical position / μm'))
    geom.set_title(tr('A  同一个 12 像素矩形','A  The same 12-pixel rectangle'),loc='left',fontsize=14)
    calculation=fig.add_subplot(gs[1,0]);calculation.axis('off')
    calculation.text(0,.97,tr('独立几何期望','Independent geometry'),fontsize=14,color='#205b8c',va='top')
    calculation.text(0,.73,'(4 × 0.3) × (3 × 0.2)\n= 0.72 μm²',fontsize=17,va='top',linespacing=1.6)
    calculation.text(0,.16,tr('漏乘列间隔：12 × 0.2 = 2.4\n恢复列间隔：2.4 × 0.3 = 0.72','Missing column spacing: 12 × 0.2 = 2.4\nRestore it: 2.4 × 0.3 = 0.72'),fontsize=12,va='top',linespacing=1.6)
    failure=fig.add_subplot(gs[0,1]);failure.axis('off');failure.set_title(tr('B  pytest 的实际失败片段','B  Actual pytest failure excerpt'),loc='left',fontsize=14,color='#9b3e21')
    excerpt=[line for line in negative.stdout.splitlines() if line.startswith('E ') or 'failure_demo.py:' in line]
    # Keep actual diagnostic text; wrap long lines for display.
    visible=[]
    for line in excerpt[:7]:visible.extend(textwrap.wrap(line,width=64,replace_whitespace=False,drop_whitespace=False) or [''])
    failure.text(0,.94,'\n'.join(visible),va='top',family='DejaVu Sans Mono',fontsize=12,linespacing=1.45,
                 bbox={'facecolor':'#f5e8e1','edgecolor':'#d7b5a5','pad':12})
    success=fig.add_subplot(gs[1,1]);success.axis('off');success.set_title(tr('C  正确函数通过独立测试集','C  Correct function passes the independent suite'),loc='left',fontsize=14,color='#205b55')
    success.text(0,.85,'assert area == pytest.approx(\n    0.72, rel=1e-12, abs=1e-12\n)',va='top',family='DejaVu Sans Mono',fontsize=12.5,linespacing=1.5)
    actual_pass=next(line for line in completed.stdout.splitlines() if re.search(r'\d+ passed',line))
    success.text(0,.15,actual_pass,fontsize=14,color='#205b55',bbox={'facecolor':'#e1eee7','edgecolor':'none','pad':9})
    fig.suptitle(tr('把一次真实失败读回面积定义','Read an actual failure back into the area definition'),x=.06,ha='left',fontsize=18)
    fig.text(.06,.035,tr('测试传统：Python unittest 受 JUnit 启发；可重复输入、独立期望与执行报告保留在一起。','Testing tradition: Python unittest was inspired by JUnit; retain repeatable inputs, independent expectations, and execution reports.'),fontsize=12)
    save(fig,'test-structure')
    print(json.dumps({k:v for k,v in summary.items() if k!='mutation_results'}))


if __name__=='__main__':main()
