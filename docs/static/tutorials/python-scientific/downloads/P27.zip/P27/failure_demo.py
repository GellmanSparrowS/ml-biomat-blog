"""One intentional failure, selected explicitly for reading a failure report."""
import numpy as np
import pytest
from main import changed_area


def test_missing_column_spacing():
    mask = np.zeros((8, 10), dtype=bool)
    mask[2:5, 1:5] = True
    observed = changed_area(mask, (.2, .3), mode="one_scale")
    assert observed == pytest.approx(.72, rel=1e-12, abs=1e-12)
