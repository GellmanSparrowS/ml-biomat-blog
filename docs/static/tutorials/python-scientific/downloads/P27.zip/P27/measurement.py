"""A small scientific function with an explicit input and unit contract."""
import numpy as np


def mask_area(mask, spacing):
    """Return selected 2D area in um^2 for (row, column) spacing in um.

    A Boolean mask defines membership. Empty selections have area zero.
    Both physical spacings must be finite and strictly positive.
    """
    mask = np.asarray(mask)
    if mask.ndim != 2:
        raise ValueError("mask must have exactly two spatial dimensions")
    if mask.dtype != np.bool_:
        raise TypeError("mask must contain Boolean membership values")
    scale = np.asarray(spacing, dtype=float)
    if scale.shape != (2,) or not np.all(np.isfinite(scale)) or np.any(scale <= 0):
        raise ValueError("spacing must contain two finite positive lengths")
    return float(np.count_nonzero(mask) * scale[0] * scale[1])
