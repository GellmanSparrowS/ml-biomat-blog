"""Expected values come from geometry and input definitions."""
import numpy as np
import pytest
from measurement import mask_area


@pytest.fixture
def rectangle():
    mask = np.zeros((8, 10), dtype=bool)
    mask[2:5, 1:5] = True
    return mask


def test_rectangle_geometry(rectangle):
    # Four columns × 0.3 um = 1.2 um; three rows × 0.2 um = 0.6 um.
    assert mask_area(rectangle, (.2, .3)) == pytest.approx(.72, rel=1e-12, abs=1e-12)


def test_empty_region():
    assert mask_area(np.zeros((4, 7), dtype=bool), (.2, .3)) == 0


def test_doubling_both_lengths_quadruples_area(rectangle):
    assert mask_area(rectangle, (.4, .6)) == pytest.approx(2.88, rel=1e-12, abs=1e-12)


def test_transpose_with_swapped_spacing(rectangle):
    assert mask_area(rectangle.T, (.3, .2)) == pytest.approx(.72, rel=1e-12, abs=1e-12)


@pytest.mark.parametrize("spacing", [(0, .3), (-.2, .3), (.2, float('nan')),
                                    (.2, float('inf')), (.2,), (.2, .3, .4)])
def test_reject_invalid_calibration(rectangle, spacing):
    with pytest.raises(ValueError):
        mask_area(rectangle, spacing)


@pytest.mark.parametrize("mask", [np.ones(5,dtype=bool), np.ones((2,3,4),dtype=bool)])
def test_reject_wrong_dimension(mask):
    with pytest.raises(ValueError):
        mask_area(mask, (.2, .3))


def test_reject_numeric_intensities():
    with pytest.raises(TypeError):
        mask_area(np.array([[0, 120], [80, 255]]), (.2, .3))
