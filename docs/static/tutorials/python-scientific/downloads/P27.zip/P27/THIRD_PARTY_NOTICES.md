# Public sources and third-party materials

- pytest: Get Started: https://docs.pytest.org/en/stable/getting-started.html
  pytest code and documentation: MIT.
- pytest: Parametrizing fixtures and test functions: https://docs.pytest.org/en/stable/how-to/parametrize.html
  MIT.
- Python unittest: https://docs.python.org/3/library/unittest.html
  Python documentation: PSF terms; historical and technical reference.
- pytest.approx: https://docs.pytest.org/en/stable/reference/reference.html#pytest-approx
  MIT.
