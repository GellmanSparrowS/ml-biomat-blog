# Public sources and third-party materials

- xarray quick overview: https://docs.xarray.dev/en/stable/getting-started-guide/quick-overview.html
  xarray Apache-2.0; original chapter implementation.
- xarray indexing and selecting data: https://docs.xarray.dev/en/stable/user-guide/indexing.html
  xarray Apache-2.0.
- h5py datasets: https://docs.h5py.org/en/stable/high/dataset.html
  h5py BSD-3-Clause.
- h5py dimension scales: https://docs.h5py.org/en/stable/high/dims.html
  h5py BSD-3-Clause.
- The HDF Group: Balancing Performance and Preservation (2010): https://docs.hdfgroup.org/archive/support/pubs/papers/HDFandpreservation_NIST_2010_paper_Folk.pdf
  Historical factual citation; original file-structure and chunk diagrams.
- Hoyer and Hamman (2017), xarray: N-D labeled Arrays and Datasets in Python: https://doi.org/10.5334/jors.148
  Open research software paper; scientific citation.
