"""Labeled analytic diffusion fields, missing regions, and HDF5 chunk layouts."""
from pathlib import Path
import argparse
import base64
import json
import numpy as np
import xarray as xr
import h5py
from scipy.special import erf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle

BASE=293.15  # K
AMPLITUDE=80.0  # K
SX0,SY0=1.8,1.2  # mm
X0,Y0=1.1,-.5  # mm
DIMS=('diffusivity','time','y','x')
LAYOUTS={'snapshot':(1,1,20,20),'time_series':(1,10,10,10)}



def available_plot_fonts():
    """Choose installed fonts; keep a Latin fallback on every platform."""
    choices = ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]



def make_dataset():
    coords={'diffusivity':[.2,.5],'time':np.arange(61,dtype=float),
            'y':-5.9+.2*np.arange(60),'x':-7.9+.2*np.arange(80)}
    alpha,time,y,x=np.meshgrid(*(coords[d] for d in DIMS),indexing='ij')
    sx2=SX0**2+2*alpha*time;sy2=SY0**2+2*alpha*time
    values=BASE+AMPLITUDE*SX0*SY0/np.sqrt(sx2*sy2)*np.exp(-.5*((x-X0)**2/sx2+(y-Y0)**2/sy2))
    field=xr.DataArray(values,dims=DIMS,coords=coords,name='temperature',
                       attrs={'units':'K','model':'analytic Gaussian diffusion on an infinite plane'})
    for name,unit in [('diffusivity','mm^2/s'),('time','s'),('y','mm'),('x','mm')]:field.coords[name].attrs['units']=unit
    mask=(field.time>=20)&(field.x>=0)&(field.x<3)&(field.y>=-2)&(field.y<1)
    dataset=xr.Dataset({'temperature':field,'sensor_view':field.where(~mask)},
                        attrs={'data_identity':'analytic teaching fields; sensor_view includes a constructed missing rectangle',
                               'baseline_K':BASE,'initial_amplitude_K':AMPLITUDE,'center_x_mm':X0,'center_y_mm':Y0})
    return dataset


def save_hdf(dataset,path,chunks):
    with h5py.File(path,'w') as f:
        for key,value in dataset.attrs.items():f.attrs[key]=value
        coordinates=f.create_group('coordinates');fields=f.create_group('fields')
        for dim in DIMS:
            scale=coordinates.create_dataset(dim,data=dataset.coords[dim].values)
            scale.make_scale(dim);scale.attrs['units']=dataset.coords[dim].attrs['units']
        for name in dataset.data_vars:
            array=fields.create_dataset(name,data=dataset[name].values,chunks=chunks,
                                         compression='gzip',compression_opts=4,shuffle=True)
            array.attrs['units']='K';array.attrs['dimension_order']=json.dumps(DIMS)
            for axis,dim in enumerate(DIMS):
                array.dims[axis].label=dim
                array.dims[axis].attach_scale(coordinates[dim])


def read_hdf(path):
    with h5py.File(path,'r') as f:
        coords={dim:xr.DataArray(f['coordinates'][dim][:],dims=dim,
                                 attrs={'units':f['coordinates'][dim].attrs['units']}) for dim in DIMS}
        variables={}
        for name,array in f['fields'].items():
            dims=tuple(array.dims[i].label for i in range(array.ndim))
            if dims!=DIMS or any(len(array.dims[i])!=1 for i in range(4)):
                raise ValueError('Expected one named coordinate scale per axis')
            variables[name]=xr.DataArray(array[:],dims=dims,coords=coords,attrs={'units':array.attrs['units']})
        return xr.Dataset(variables,attrs=dict(f.attrs))


def touched_chunks(shape,chunks,selection):
    total=1
    for length,chunk,part in zip(shape,chunks,selection):
        if isinstance(part,int):count=1
        else:
            start,stop,step=part.indices(length)
            if step!=1:raise ValueError('This example counts contiguous slices')
            count=0 if stop<=start else (stop-1)//chunk-start//chunk+1
        total*=count
    return total


def exact_window_integral(alpha,time):
    sx=np.sqrt(SX0**2+2*alpha*time);sy=np.sqrt(SY0**2+2*alpha*time)
    fraction_x=.5*(erf((8-X0)/(np.sqrt(2)*sx))-erf((-8-X0)/(np.sqrt(2)*sx)))
    fraction_y=.5*(erf((6-Y0)/(np.sqrt(2)*sy))-erf((-6-Y0)/(np.sqrt(2)*sy)))
    return AMPLITUDE*2*np.pi*SX0*SY0*fraction_x*fraction_y


def figures(dataset,summary,output,language):
    zh=language=='zh';tr=lambda z,e:z if zh else e
    plt.rcParams.update({'font.family':available_plot_fonts() if zh else ['DejaVu Sans'],
                         'font.size':13,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'svg.fonttype':'none'})
    def save(fig,name):
        for ext in ['svg','png']:fig.savefig(output/f'{name}-{language}.{ext}',dpi=160,bbox_inches='tight',facecolor='#faf9f5')
        plt.close(fig)
    fig,axes=plt.subplots(2,3,figsize=(13,6.6),layout='constrained',sharex=True,sharey=True)
    for i,alpha in enumerate([.2,.5]):
        for j,time in enumerate([0,10,40]):
            field=dataset.temperature.sel(diffusivity=alpha,time=time)
            im=axes[i,j].pcolormesh(field.x,field.y,field-273.15,cmap='inferno',vmin=20,vmax=100,shading='nearest',rasterized=True)
            axes[i,j].set_aspect('equal');axes[i,j].set_title(f'α={alpha} mm²/s; t={time} s',fontsize=13)
            if i==1:axes[i,j].set_xlabel('x / mm')
            if j==0:axes[i,j].set_ylabel('y / mm')
    fig.colorbar(im,ax=axes,label=tr('温度 / °C（全部面板同一色标）','Temperature / °C (one scale for all panels)'),shrink=.75)
    save(fig,'labeled-diffusion')
    fig=plt.figure(figsize=(13,8),layout='constrained');gs=fig.add_gridspec(2,2)
    for j,name in enumerate(['temperature','sensor_view']):
        ax=fig.add_subplot(gs[0,j]);field=dataset[name].sel(diffusivity=.2,time=20)
        cmap=plt.get_cmap('inferno').copy();cmap.set_bad('#dbe3e6')
        im=ax.pcolormesh(field.x,field.y,field-273.15,vmin=20,vmax=40,cmap=cmap,shading='nearest',rasterized=True)
        ax.set_aspect('equal');ax.set(xlabel='x / mm',ylabel='y / mm',title=tr('完整解析场','Complete analytical field') if j==0 else tr('构造的缺失区域；α=0.2, t=20 s','Constructed missing region; α=0.2, t=20 s'))
        fig.colorbar(im,ax=ax,label=tr('温度 / °C','Temperature / °C'),shrink=.8)
    ax=fig.add_subplot(gs[1,0]);other=fig.add_subplot(gs[1,1])
    for alpha,color in [(.2,'#205b8c'),(.5,'#bd5535')]:
        full=dataset.temperature.sel(diffusivity=alpha).mean(['y','x'])-273.15
        observed=dataset.sensor_view.sel(diffusivity=alpha).mean(['y','x'],skipna=True)-273.15
        ax.plot(dataset.time,full,color=color,lw=2.5,label=f'α={alpha}: '+tr('完整','complete'))
        ax.plot(dataset.time,observed,color=color,ls='--',lw=2,label=f'α={alpha}: '+tr('有效像素均值','valid-cell mean'))
    ax.set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('空间均值 / °C','Spatial mean / °C'));ax.legend(fontsize=11)
    snapshot=dataset.temperature.sel(diffusivity=.2,time=0,y=Y0,method='nearest')
    reversed_snapshot=snapshot.isel(x=slice(None,None,-1))
    positional=snapshot.values-reversed_snapshot.values
    labeled=snapshot-reversed_snapshot
    other.plot(snapshot.x,positional,color='#bd5535',label=tr('按数组位置','By array position'))
    other.plot(labeled.x,labeled,color='#205b8c',lw=3,label=tr('按x坐标对齐','Aligned by x'))
    other.set(xlabel='x / mm',ylabel=tr('温差 / K','Temperature difference / K'),title=tr('同一条剖面，把x顺序倒转','Reverse x order in the same profile'));other.legend(fontsize=12,loc='upper left')
    save(fig,'mask-and-alignment')
    fig=plt.figure(figsize=(13,8.5),layout='constrained');gs=fig.add_gridspec(2,3,width_ratios=[1.2,1,1],height_ratios=[1.25,1])
    info=fig.add_subplot(gs[:,0]);info.axis('off')
    lines=['HDF5','/coordinates','  diffusivity  [0.2, 0.5]  mm²/s','  time          [0 … 60]  s',tr('  y             60个单元中心  mm','  y             60 cell centers  mm'),tr('  x             80个单元中心  mm','  x             80 cell centers  mm'),'/fields','  temperature  (2, 61, 60, 80)','  sensor_view   (2, 61, 60, 80)','  units = K',tr('  维度 → 关联的坐标尺度','  dimensions → attached scales')]
    for i,line in enumerate(lines):info.text(0,1-i*.065,line,fontsize=12.5 if i else 19,transform=info.transAxes,color='#172534',weight='bold' if i in [0,1,6] else 'normal')
    info.text(0,.18,tr('1988：HDF公开发布\n1998：HDF5首次发布\n2017：xarray命名数组论文','1988: HDF public release\n1998: first HDF5 release\n2017: xarray labeled-array paper'),fontsize=13,linespacing=1.8,transform=info.transAxes)
    for j,(name,chunks) in enumerate(LAYOUTS.items()):
        ax=fig.add_subplot(gs[0,j+1]);cy,cx=chunks[-2:]
        for y in range(0,60,cy):
            for x in range(0,80,cx):
                selected=x<=45<x+cx and y<=27<y+cy
                ax.add_patch(Rectangle((x,y),cx,cy,facecolor='#d5e1e7' if not selected else '#d38d58',edgecolor='white',lw=1.4))
        ax.plot(45,27,'o',color='#172534',ms=6);ax.set(xlim=(0,80),ylim=(0,60),xlabel=tr('x单元索引','x cell index'),ylabel=tr('y单元索引','y cell index'),title=f'{chunks}\n'+tr('α、t、y、x方向块尺寸','chunk shape: α, t, y, x'));ax.set_aspect('equal')
    bars=fig.add_subplot(gs[1,1:]);x=np.arange(2);width=.34
    for j,name in enumerate(LAYOUTS):
        values=[summary['storage'][name]['snapshot_chunks'],summary['storage'][name]['trace_chunks']]
        bars.bar(x+(j-.5)*width,values,width,label=name,color=['#205b8c','#bd5535'][j])
        for k,value in enumerate(values):bars.text(x[k]+(j-.5)*width,value+1,str(value),ha='center',fontsize=13)
    bars.set(xticks=x,xticklabels=[tr('一张完整快照','One complete snapshot'),tr('一个点的61时刻','61 times at one point')],ylabel=tr('请求触及的块数','Chunks touched by the request'),ylim=(0,75));bars.legend(fontsize=12)
    save(fig,'coordinates-and-chunks')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,default=Path('results'));parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    dataset=make_dataset();storage={};shape=dataset.temperature.shape
    snapshot_request=(0,20,slice(None),slice(None));trace_request=(0,slice(None),27,45)
    for name,chunks in LAYOUTS.items():
        path=args.output/f'{name}.h5';save_hdf(dataset,path,chunks);restored=read_hdf(path)
        xr.testing.assert_allclose(restored.temperature,dataset.temperature)
        xr.testing.assert_allclose(restored.sensor_view,dataset.sensor_view)
        with h5py.File(path,'r') as f:
            assert np.array_equal(f['fields/temperature'][snapshot_request],dataset.temperature.values[snapshot_request])
            assert np.array_equal(f['fields/temperature'][trace_request],dataset.temperature.values[trace_request])
        storage[name]={'chunks':list(chunks),'file_bytes':path.stat().st_size,
                        'snapshot_chunks':touched_chunks(shape,chunks,snapshot_request),
                        'trace_chunks':touched_chunks(shape,chunks,trace_request)}
    initial=dataset.temperature.sel(diffusivity=.2,time=0)
    reverse=initial.isel(x=slice(None,None,-1))
    labeled=float(abs(initial-reverse).max());positional=float(abs(initial.values-reverse.values).max())
    numeric=float((initial-BASE).sum()*.2*.2);exact=float(exact_window_integral(.2,0))
    assert labeled==0 and positional>40 and abs(numeric/exact-1)<1e-4
    summary={'shape':list(shape),'dimensions':list(DIMS),'initial_peak_K':float(initial.max()),
              'labeled_reversal_difference_K':labeled,'positional_reversal_difference_K':positional,
              'initial_window_integral_K_mm2':numeric,'analytic_window_integral_K_mm2':exact,
              'valid_cells_t20':int(dataset.sensor_view.sel(diffusivity=.2,time=20).count()),
              'full_cells':60*80,'full_mean_t20_K':float(dataset.temperature.sel(diffusivity=.2,time=20).mean()),
              'valid_mean_t20_K':float(dataset.sensor_view.sel(diffusivity=.2,time=20).mean()),'storage':storage}
    states=[];frames=[]
    for alpha in [.2,.5]:
        for time in range(0,61,5):
            full=dataset.temperature.sel(diffusivity=alpha,time=time);masked=dataset.sensor_view.sel(diffusivity=alpha,time=time)
            frames.append(full.values)
            states.append({'diffusivity':alpha,'time':time,'full_mean_K':float(full.mean()),
                           'valid_mean_K':float(masked.mean()),'valid_cells':int(masked.count()),'peak_K':float(full.max())})
    arrays=np.asarray(frames,dtype='<f8')
    data={'x':dataset.x.values.tolist(),'y':dataset.y.values.tolist(),'states':states,
          'shape':list(arrays.shape),'field_f64_le':base64.b64encode(arrays.tobytes()).decode('ascii'),
          'colormap_rgb':(plt.get_cmap('inferno')(np.linspace(0,1,256))[:,:3]*255).astype(int).tolist(),
          'storage':storage,'missing_region':{'from_time':20,'xmin':0,'xmax':3,'ymin':-2,'ymax':1}}
    (args.output/'lab-data.json').write_text(json.dumps(data),encoding='utf8')
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    dataset.temperature.mean(['y','x']).to_dataframe(name='mean_temperature_K').to_csv(args.output/'spatial-means.csv')
    figures(dataset,summary,args.output,args.language);print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
