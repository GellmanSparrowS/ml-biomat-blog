"""Measure the largest bright region in a public quantitative-phase cell image.

Data: skimage.data.cell, CC0, Mueller et al. (2018),
https://doi.org/10.1364/OE.26.010729 . Pixel spacing: 0.107 micrometres.
The calibrated disk is an analytic teaching object, separate from the image.
"""
from pathlib import Path
import argparse
import base64
import hashlib
import json
import math

import numpy as np
from scipy import ndimage
from skimage import io, filters, measure
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

HERE = Path(__file__).resolve().parent
SPACING = 0.107
THRESHOLDS = np.arange(80, 201, 2)



def available_plot_fonts():
    """Choose installed fonts; keep a Latin fallback on every platform."""
    choices = ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]



def region_mask(image, threshold, fill):
    """Select the largest 8-connected region strictly brighter than threshold."""
    labels = measure.label(image > threshold, connectivity=2)
    sizes = np.bincount(labels.ravel())
    sizes[0] = 0
    mask = labels == int(sizes.argmax()) if sizes.max() else np.zeros_like(image, bool)
    return ndimage.binary_fill_holes(mask) if fill else mask


def metrics(mask):
    pixels = int(np.count_nonzero(mask))
    area = pixels * SPACING ** 2
    return {"pixels": pixels, "area_um2": area,
            "equivalent_diameter_um": 2 * math.sqrt(area / math.pi)}


def otsu_curve(image):
    """Between-class variance for every integer uint8 threshold."""
    counts = np.bincount(image.ravel(), minlength=256)
    p = counts / counts.sum()
    weights = np.cumsum(p)
    first_moment = np.cumsum(p * np.arange(256))
    total_mean = first_moment[-1]
    score = np.zeros(256)
    valid = (weights > 0) & (weights < 1)
    score[valid] = (total_mean * weights[valid] - first_moment[valid]) ** 2 / (
        weights[valid] * (1 - weights[valid]))
    return counts, weights, score


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--language", choices=("zh", "en"), default="en")
    args = parser.parse_args()
    out = args.output; out.mkdir(parents=True, exist_ok=True)
    zh = args.language == "zh"
    text = lambda a, b: a if zh else b
    path = HERE / "data/cell.png"
    image = io.imread(path)
    assert image.shape == (660, 550) and image.dtype == np.uint8
    threshold = int(filters.threshold_otsu(image))
    mask = region_mask(image, threshold, True)
    base = metrics(mask)
    counts, weights, score = otsu_curve(image)
    assert int(score.argmax()) == threshold
    states = []
    for t in THRESHOLDS:
        for fill in (False, True):
            current = region_mask(image, int(t), fill)
            contours = measure.find_contours(current.astype(float), .5)
            # Simplification affects display geometry, never the measured area.
            outlines = [np.round(measure.approximate_polygon(c, tolerance=1.0)[:, ::-1], 1).tolist()
                        for c in contours if len(c) > 8]
            states.append({"threshold": int(t), "fill": fill, **metrics(current), "contours": outlines})
    # An independent analytic area check at known spatial sampling.
    yy, xx = np.mgrid[-15:15:SPACING, -15:15:SPACING]
    radius = 8.0
    disk = xx ** 2 + yy ** 2 <= radius ** 2
    disk_area = float(disk.sum() * SPACING ** 2)
    analytic_area = math.pi * radius ** 2
    assert abs(disk_area / analytic_area - 1) < .01
    summary = {"dataset": "skimage.data.cell", "data_license": "CC0", "shape": list(image.shape),
               "spacing_um": SPACING, "threshold_otsu": threshold, "fill_holes": True,
               "connectivity": 8, "comparison": "image > threshold", **base,
               "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
               "disk_check": {"radius_um": radius, "pixel_area_um2": disk_area,
                              "analytic_area_um2": analytic_area,
                              "relative_error": disk_area / analytic_area - 1}}
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (out / "lab-data.json").write_text(json.dumps({"width": 550, "height": 660, "spacing": SPACING,
        "otsu": threshold, "states": states, "histogram": counts.tolist(),
        "image": "data:image/png;base64," + base64.b64encode(path.read_bytes()).decode()}, separators=(",", ":")), encoding="utf-8")
    np.savetxt(out / "threshold-sensitivity.csv", np.array([[s['threshold'],int(s['fill']),s['pixels'],s['area_um2'],s['equivalent_diameter_um']] for s in states]), delimiter=",", header="threshold,fill_holes,pixels,area_um2,equivalent_diameter_um", comments="")
    plt.rcParams.update({"font.family": available_plot_fonts(), "font.size": 12,
                         "axes.spines.top": False, "axes.spines.right": False, "svg.fonttype": "none",
                         "axes.labelcolor": "#172534", "text.color": "#172534", "axes.edgecolor": "#81939d",
                         "figure.facecolor": "#faf9f5", "axes.facecolor": "#faf9f5"})
    blue, orange = "#205b8c", "#ba5231"
    def save(fig, name):
        fig.savefig(out / f"{name}-{args.language}.svg", metadata={"Date": None})
        fig.savefig(out / f"{name}-{args.language}.png", dpi=150)
        plt.close(fig)
    # Spatial views share physical coordinates, including the zoomed boundary.
    fig = plt.figure(figsize=(12.4, 7.2), layout="constrained")
    gs = fig.add_gridspec(2, 2, width_ratios=[1, 1.2], height_ratios=[1, .7])
    ax = fig.add_subplot(gs[:, 0]); zoom = fig.add_subplot(gs[0, 1]); profile = fig.add_subplot(gs[1, 1])
    for a in (ax, zoom):
        a.imshow(image, cmap="gray", vmin=0, vmax=255, extent=(0, 550*SPACING,660*SPACING,0))
        for c in measure.find_contours(mask.astype(float), .5):
            a.plot((c[:,1]+.5)*SPACING,(c[:,0]+.5)*SPACING,color="#ffcb66",lw=1.5)
        a.set(xlabel=text("水平位置 / μm", "Horizontal position / μm"),ylabel=text("垂直位置 / μm", "Vertical position / μm"))
    ax.set_title(text("A  原始相位图与测量边界", "A  Phase image and measured boundary"),loc="left")
    zoom.set(xlim=(34,55),ylim=(49,29));zoom.set_title(text("B  边界附近的真实灰度", "B  Original intensities near the boundary"),loc="left")
    row=370; ax.axhline((row+.5)*SPACING,color="#74d9db",ls="--",lw=1)
    profile.plot((np.arange(550)+.5)*SPACING,image[row],color=blue,lw=1.3)
    profile.axhline(threshold,color=orange,ls="--",label=f"T = {threshold}")
    profile.set(xlabel=text("水平位置 / μm", "Horizontal position / μm"),ylabel=text("灰度值", "Intensity"),ylim=(0,270))
    profile.set_title(text("C  水平剖面（第 370 行）", "C  Horizontal profile (row 370)"),loc="left");profile.legend(frameon=False)
    save(fig,"measured-cell")
    fig, axs=plt.subplots(1,2,figsize=(12.4,4.8),layout="constrained")
    for fill,color,ls in [(False,blue,"-"),(True,orange,"--")]:
        ss=[s for s in states if s['fill']==fill]
        for a,key in zip(axs,['area_um2','equivalent_diameter_um']):
            a.plot([s['threshold'] for s in ss],[s[key] for s in ss],color=color,ls=ls,lw=2,label=text("填充孔洞" if fill else "保留孔洞","Holes filled" if fill else "Holes retained"))
    for a,key in zip(axs,['area_um2','equivalent_diameter_um']):
        a.axvline(threshold,color="#7a8a94",ls=":");a.scatter([threshold],[base[key]],color=orange,zorder=3)
        a.set_xlabel(text("灰度阈值 T", "Intensity threshold T"));a.grid(axis='y',alpha=.18)
    axs[0].set_ylabel(text("投影区域面积 / μm²", "Projected region area / μm²"));axs[1].set_ylabel(text("等效圆直径 / μm", "Equivalent-circle diameter / μm"))
    axs[0].set_title(text("A  边界选择改变测量面积", "A  Boundary choice changes measured area"),loc="left")
    axs[1].set_title(text("B  相同面积换算成直径", "B  The same area expressed as a diameter"),loc="left");axs[0].legend(frameon=False)
    save(fig,"threshold-sensitivity")
    fig=plt.figure(figsize=(12.4,6.2),layout="constrained");gs=fig.add_gridspec(2,2,width_ratios=[1.25,1])
    hist=fig.add_subplot(gs[:,0]);criterion=fig.add_subplot(gs[0,1]);weight=fig.add_subplot(gs[1,1])
    hist.bar(np.arange(256),counts,width=1,color=np.where(np.arange(256)>threshold,orange,blue),rasterized=True)
    hist.axvline(threshold,color="#172534",ls="--");hist.set_yscale('log')
    hist.set(xlabel=text("灰度值", "Intensity"),ylabel=text("像素数（对数坐标）", "Pixel count (log scale)"),xlim=(0,255),ylim=(1,counts.max()*2))
    hist.set_title(text("A  按灰度把像素分成两类", "A  Split pixels into two intensity classes"),loc="left")
    criterion.plot(np.arange(256),score,color=blue);criterion.axvline(threshold,color=orange,ls="--")
    criterion.set(xlabel=text("候选阈值", "Candidate threshold"),ylabel=text("类间方差 / 灰度²", "Between-class variance / intensity²"));criterion.set_title(text("B  Otsu（1979）：比较所有分割", "B  Otsu (1979): compare all splits"),loc="left")
    weight.plot(np.arange(256),weights,color=blue,label=text("暗侧比例", "Dark-class fraction"));weight.plot(np.arange(256),1-weights,color=orange,label=text("亮侧比例", "Bright-class fraction"))
    weight.set(xlabel=text("候选阈值", "Candidate threshold"),ylabel=text("像素比例", "Pixel fraction"),ylim=(0,1));weight.legend(frameon=False,fontsize=10)
    save(fig,"otsu-separation")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
