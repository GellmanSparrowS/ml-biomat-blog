# Public sources and third-party materials

- scikit-image tutorials: Images are arrays: https://scikit-image.org/skimage-tutorials/lectures/00_images_are_arrays.html
  Tutorial materials CC0, per repository README.
- scikit-image tutorials: Image segmentation: https://scikit-image.org/skimage-tutorials/lectures/4_segmentation.html
  Tutorial materials CC0, per repository README.
- scikit-image: cell image: https://scikit-image.org/docs/stable/api/skimage.data.html#skimage.data.cell
  Image: CC0, as documented by scikit-image.
- Mueller et al. (2018), Optics Express 26, 10729: https://doi.org/10.1364/OE.26.010729
  Scientific citation; supplied image separately released under CC0.
- Otsu (1979), A Threshold Selection Method from Gray-Level Histograms: https://doi.org/10.1109/TSMC.1979.4310076
  Bibliographic reference; original plots generated for this chapter.
- scikit-image: Measure region properties: https://scikit-image.org/docs/stable/auto_examples/segmentation/plot_regionprops.html
  Technical reference; example implementation authored for this chapter.
