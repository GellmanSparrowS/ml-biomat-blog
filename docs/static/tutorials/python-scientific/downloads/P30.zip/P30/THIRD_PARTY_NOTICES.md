# Public sources and third-party materials

- pandas merge_asof: https://pandas.pydata.org/docs/reference/api/pandas.merge_asof.html
  pandas BSD-3-Clause; official documentation.
- LAMMPS fix nve: https://docs.lammps.org/fix_nve.html
  Official technical reference.
- LAMMPS: How a timestep works: https://docs.lammps.org/Developer_flow.html
  Official technical reference.
- Swope et al. (1982), A computer simulation method for the calculation of equilibrium constants for the formation of physical clusters of molecules: https://doi.org/10.1063/1.442716
  Scientific historical citation; diagrams and teaching simulations are original.
