"""Generate, read, align, and compare harmonic-oscillator simulation outputs."""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import NullLocator

MASS = 1.0             # kg
SPRING = 1.0           # N/m
INITIAL_POSITION = 1.0 # m
FINAL_TIME = 20.0      # s
STEPS = [.025, .05, .1, .2]



def available_plot_fonts():
    """Choose installed fonts; keep a Latin fallback on every platform."""
    choices = ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]



def simulate(method, dt):
    count = round(FINAL_TIME / dt)
    if not np.isclose(count * dt, FINAL_TIME):
        raise ValueError('Final time must be an integer number of steps')
    x, v = np.empty(count+1), np.empty(count+1)
    x[0], v[0] = INITIAL_POSITION, 0.0
    for i in range(count):
        acceleration = -SPRING * x[i] / MASS
        if method == 'euler':
            x[i+1] = x[i] + dt*v[i]
            v[i+1] = v[i] + dt*acceleration
        elif method == 'verlet':
            half_velocity = v[i] + .5*dt*acceleration
            x[i+1] = x[i] + dt*half_velocity
            next_acceleration = -SPRING*x[i+1]/MASS
            v[i+1] = half_velocity + .5*dt*next_acceleration
        else:
            raise ValueError('Unknown integrator')
    return pd.DataFrame({'step': np.arange(count+1),
                         'time_s': np.arange(count+1)*dt,
                         'position_m': x, 'velocity_m_s': v})


def read_and_compare(path, common):
    frame = pd.read_csv(path)
    if frame.time_s.duplicated().any() or not frame.time_s.is_monotonic_increasing:
        raise ValueError('Times must be unique and increasing')
    if not np.isfinite(frame.to_numpy()).all():
        raise ValueError('All values must be finite')
    frame['energy_J'] = .5*MASS*frame.velocity_m_s**2 + .5*SPRING*frame.position_m**2
    frame['relative_energy_error'] = frame.energy_J / (.5*SPRING*INITIAL_POSITION**2) - 1
    # Retain both time columns so the alignment can be inspected explicitly.
    aligned = pd.merge_asof(common, frame.rename(columns={'time_s':'matched_time_s'}),
                            left_on='time_s', right_on='matched_time_s',
                            direction='nearest', tolerance=1e-9)
    if aligned.matched_time_s.isna().any():
        raise ValueError('A requested physical time has no matching sample')
    omega = np.sqrt(SPRING/MASS)
    aligned['exact_position_m'] = INITIAL_POSITION*np.cos(omega*aligned.time_s)
    aligned['position_error_m'] = aligned.position_m-aligned.exact_position_m
    return frame, aligned


def figures(runs, summary, output, language):
    zh = language == 'zh'; tr=lambda z,e:z if zh else e
    plt.rcParams.update({'font.family':available_plot_fonts(),'font.size':13,
                         'axes.spines.top':False,'axes.spines.right':False,
                         'axes.unicode_minus':False,'svg.fonttype':'none'})
    colors={'verlet':'#205b8c','euler':'#bd5535'}
    names={'verlet':'Velocity Verlet','euler':tr('显式Euler','Forward Euler')}
    def save(fig,name):
        for ext in ['svg','png']:
            fig.savefig(output/f'{name}-{language}.{ext}',dpi=160,bbox_inches='tight',facecolor='#faf9f5')
        plt.close(fig)
    fig=plt.figure(figsize=(12.5,10),layout='constrained')
    grid=fig.add_gridspec(3,2)
    axes=[fig.add_subplot(grid[0,:]),fig.add_subplot(grid[1,:]),fig.add_subplot(grid[2,0])]
    exact_time=np.linspace(0,FINAL_TIME,1001)
    axes[0].plot(exact_time,np.cos(exact_time),color='#73828b',lw=3,alpha=.6,label=tr('解析解','Exact'))
    for method in ['euler','verlet']:
        r=next(r for r in runs if r['method']==method and r['dt']==.1)
        axes[0].plot(r['time'],r['position'],color=colors[method],lw=1.7,label=names[method])
        axes[1].plot(r['common_time'],r['common_error'],color=colors[method],lw=2)
        axes[2].plot(r['time'],np.array(r['energy'])/.5,color=colors[method],lw=2)
    axes[0].set(ylabel=tr('位置 / m','Position / m'),title=tr('步长均为0.1 s；比较相同20 s物理过程','Both steps are 0.1 s; compare the same 20 s physical interval'));axes[0].legend(ncol=3,fontsize=12)
    axes[1].set(ylabel=tr('位置误差 / m','Position error / m'),title=tr('误差在101个共同物理时刻计算','Errors evaluated at 101 shared physical times'))
    axes[2].axhline(1,color='#73828b',ls='--');axes[2].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('能量 / 初始能量','Energy / initial energy'),yscale='log')
    inset=fig.add_subplot(grid[2,1])
    vr=next(r for r in runs if r['method']=='verlet' and r['dt']==.1)
    inset.plot(vr['time'],(np.array(vr['energy'])/.5-1)*100,color=colors['verlet'],lw=1.7)
    inset.set_title(tr('Verlet相对能量误差 / %','Verlet relative energy error / %'),fontsize=13)
    inset.set(xlabel=tr('时间 / s','Time / s'));inset.set_xticks([0,10,20]);inset.set_yticks([-.25,0])
    axes[0].tick_params(labelbottom=False);axes[1].tick_params(labelbottom=False)
    save(fig,'trajectory-comparison')
    fig,axes=plt.subplots(1,2,figsize=(13,6),layout='constrained')
    for method in ['euler','verlet']:
        r=[s for s in summary['runs'] if s['method']==method]
        axes[0].loglog([s['dt'] for s in r],[s['rms_position_error_m'] for s in r],'o-',color=colors[method],lw=2,label=names[method])
        axes[1].loglog([s['steps'] for s in r],[s['rms_position_error_m'] for s in r],'o-',color=colors[method],lw=2,label=names[method])
    r=[s for s in summary['runs'] if s['method']=='verlet'];factor=r[0]['rms_position_error_m']/.025**2
    axes[0].loglog(STEPS,factor*np.array(STEPS)**2,ls=':',color='#73828b',label=tr('二阶斜率参考','Second-order slope guide'))
    axes[0].set(xlabel=tr('时间步长 / s','Time step / s'),ylabel=tr('位置均方根误差 / m','RMS position error / m'),title=tr('同一时间网格上的精度','Accuracy on one shared time grid'))
    axes[1].set(xlabel=tr('20 s内的积分步数','Integration steps over 20 s'),ylabel=tr('位置均方根误差 / m','RMS position error / m'),title=tr('精度与工作量；步数不是实测耗时','Accuracy and work; steps are not measured runtime'))
    for ax in axes:ax.legend(fontsize=11);ax.grid(alpha=.2,which='both')
    axes[0].set_xticks(STEPS,[str(s) for s in STEPS]);axes[0].xaxis.set_minor_locator(NullLocator())
    axes[1].set_xticks([100,200,400,800],['100','200','400','800']);axes[1].xaxis.set_minor_locator(NullLocator())
    save(fig,'step-convergence')
    fig=plt.figure(figsize=(13,8),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1,1])
    phase=fig.add_subplot(gs[:,0]);detail=fig.add_subplot(gs[0,1]);note=fig.add_subplot(gs[1,1]);note.axis('off')
    phase.plot(np.cos(exact_time),-np.sin(exact_time),color='#73828b',lw=3,label=tr('解析轨道','Exact orbit'))
    for method in ['euler','verlet']:
        r=next(r for r in runs if r['method']==method and r['dt']==.1)
        phase.plot(r['position'],r['velocity'],color=colors[method],lw=1.6,label=names[method])
    phase.set(xlabel=tr('位置 / m','Position / m'),ylabel=tr('速度 / (m/s)','Velocity / (m/s)'),title=tr('同一运动的相空间表示','The same motion in phase space'));phase.set_aspect('equal');phase.legend(loc='upper left',fontsize=11)
    pts=np.array([[1,0],[1,-.05],[.995,-.05],[.995,-.09975]])
    for i in range(3):
        detail.annotate('',xy=pts[i+1],xytext=pts[i],arrowprops={'arrowstyle':'->','color':colors['verlet'],'lw':2.5})
    detail.plot(pts[:,0],pts[:,1],'o',color=colors['verlet'])
    detail.text(1.0003,-.025,tr('半步速度','Half velocity step'),fontsize=12)
    detail.text(.9975,-.043,tr('整步位置','Full position step'),fontsize=12,ha='center')
    detail.text(.9947,-.078,tr('半步速度','Half velocity step'),fontsize=12,ha='right')
    detail.set(xlim=(.990,1.005),ylim=(-.115,.015),xlabel=tr('位置 / m','Position / m'),ylabel=tr('速度 / (m/s)','Velocity / (m/s)'),title=tr('首步：0 → 0.1 s','First step: 0 → 0.1 s'));detail.ticklabel_format(axis='x',style='plain',useOffset=False)
    note.text(0,.94,'Swope et al., 1982',fontsize=19,weight='bold',transform=note.transAxes)
    note.text(0,.69,tr('速度形式的Verlet积分\n半步 → 整步 → 半步','Velocity form of Verlet integration\nHalf step → full step → half step'),fontsize=15,linespacing=1.7,transform=note.transAxes)
    note.text(0,.34,'x₁ = 0.995 m\nv₁ = −0.09975 m/s\nE₁ = 0.49998753125 J',fontsize=15,linespacing=1.7,color=colors['verlet'],transform=note.transAxes)
    save(fig,'phase-and-verlet')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path('results'))
    parser.add_argument('--language',choices=['zh','en'],default='en')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    raw=args.output/'trajectories';raw.mkdir(exist_ok=True)
    common=pd.DataFrame({'time_s':np.arange(101)*.2})
    records=[];runs=[]
    for method in ['euler','verlet']:
        for dt in STEPS:
            name=f'{method}-{dt:g}';path=raw/f'{name}.csv'
            simulate(method,dt).to_csv(path,index=False)
            frame,aligned=read_and_compare(path,common)
            aligned.to_csv(args.output/f'{name}-aligned.csv',index=False)
            records.append({'method':method,'dt':dt,'steps':len(frame)-1,
                            'common_samples':len(aligned),
                            'rms_position_error_m':float(np.sqrt(np.mean(aligned.position_error_m**2))),
                            'max_relative_energy_error':float(frame.relative_energy_error.abs().max()),
                            'final_energy_J':float(frame.energy_J.iloc[-1]),
                            'max_time_mismatch_s':float((aligned.time_s-aligned.matched_time_s).abs().max())})
            runs.append({'method':method,'dt':dt,'time':frame.time_s.tolist(),
                         'position':frame.position_m.tolist(),'velocity':frame.velocity_m_s.tolist(),
                         'energy':frame.energy_J.tolist(),'common_time':aligned.time_s.tolist(),
                         'common_error':aligned.position_error_m.tolist()})
    first=simulate('verlet',.1).iloc[1]
    assert np.allclose([first.position_m,first.velocity_m_s],[.995,-.09975],atol=1e-14,rtol=0)
    euler=next(r for r in records if r['method']=='euler' and r['dt']==.1)
    analytic_euler_energy=.5*(1+.1**2)**200
    assert abs(euler['final_energy_J']-analytic_euler_energy)<1e-12
    summary={'model':'deterministic harmonic oscillator teaching simulation',
             'mass_kg':MASS,'spring_N_m':SPRING,'initial_energy_J':.5,
             'final_time_s':FINAL_TIME,'common_samples':len(common),
             'first_verlet_x_m':float(first.position_m),'first_verlet_v_m_s':float(first.velocity_m_s),
             'euler_h01_analytic_final_energy_J':analytic_euler_energy,'runs':records}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    (args.output/'lab-data.json').write_text(json.dumps({'runs':runs,'summary':summary}),encoding='utf8')
    pd.DataFrame(records).to_csv(args.output/'comparison.csv',index=False)
    figures(runs,summary,args.output,args.language)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
