"""Read three cooling CSV files with explicit per-file time units."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, FancyArrowPatch


def read_run(path, specification):
    """Return typed observations in seconds and degrees Celsius."""
    factors = {'s': 1.0, 'min': 60.0}
    factor = factors[specification['time_unit']]
    rows = []
    with path.open('r', encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != ['time', 'temperature', 'note']:
            raise ValueError(f'{path.name}: expected time,temperature,note')
        for record_index, row in enumerate(reader, start=1):
            if None in row or any(value is None for value in row.values()):
                raise ValueError(f'{path.name}, record {record_index}: field count differs')
            try:
                time_raw = float(row['time'])
                temperature_text = row['temperature'].strip()
                temperature = float(temperature_text) if temperature_text else None
            except ValueError as error:
                raise ValueError(f'{path.name}, record {record_index}: invalid numeric field; {error}') from error
            if not math.isfinite(time_raw) or time_raw < 0:
                raise ValueError(f'{path.name}, record {record_index}: invalid time')
            if temperature is not None and not math.isfinite(temperature):
                raise ValueError(f'{path.name}, record {record_index}: invalid temperature')
            rows.append({'run_id': specification['run_id'], 'source_file': path.name,
                         'source_record': record_index, 'time_raw': time_raw,
                         'time_unit': specification['time_unit'], 'time_s': time_raw * factor,
                         'temperature_C': temperature, 'note': row['note']})
    rows.sort(key=lambda row: row['time_s'])
    times = [row['time_s'] for row in rows]
    if len(set(times)) != len(times):
        raise ValueError(f'{path.name}: repeated times need an explicit replicate rule')
    return rows


def summarize_run(rows):
    valid = [row for row in rows if row['temperature_C'] is not None]
    if len(valid) < 2:
        return {'record_count':len(rows), 'valid_count':len(valid), 'mean_rate_C_per_s':None}
    first, last = valid[0], valid[-1]
    duration = last['time_s'] - first['time_s']
    change = last['temperature_C'] - first['temperature_C']
    return {'record_count':len(rows), 'valid_count':len(valid),
            'start_time_s':first['time_s'], 'end_time_s':last['time_s'],
            'temperature_change_C':change, 'duration_s':duration,
            'mean_rate_C_per_s':change / duration}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=Path('output'))
    parser.add_argument('--language',choices=['zh','en'],default='en')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    data_dir=Path(__file__).resolve().parent/'data'
    manifest=json.loads((data_dir/'manifest.json').read_text(encoding='utf-8'))
    if manifest['temperature_unit']!='degC':
        raise ValueError('This example expects temperatures in degrees Celsius')
    paths=sorted(data_dir.glob('run_*.csv'))
    if {path.name for path in paths}!=set(manifest['runs']):
        raise ValueError('Discovered files and manifest entries differ')
    observations=[];runs={};hashes={'manifest.json':hashlib.sha256((data_dir/'manifest.json').read_bytes()).hexdigest()}
    for path in paths:
        spec=manifest['runs'][path.name]
        rows=read_run(path,spec)
        observations.extend(rows)
        runs[spec['run_id']]={'specification':spec,'rows':rows,'summary':summarize_run(rows)}
        hashes[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
    columns=['run_id','source_file','source_record','time_raw','time_unit','time_s','temperature_C','note']
    with (args.output/'combined.csv').open('w',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=columns);writer.writeheader();writer.writerows(observations)
    with (args.output/'combined.csv').open(encoding='utf-8',newline='') as stream:
        reread=list(csv.DictReader(stream))
    assert len(reread)==18
    assert reread[0]['note']=='start, open vessel'
    assert sum(row['temperature_C']=='' for row in reread)==1
    assert math.isclose(runs['R02']['summary']['mean_rate_C_per_s'],-.15)
    zh=args.language=='zh'
    def tr(z,e):return z if zh else e
    fonts={f.name for f in font_manager.fontManager.ttflist}
    family=next((f for f in ['Noto Sans CJK SC','Microsoft YaHei','DejaVu Sans'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[family,'DejaVu Sans'] if zh else ['DejaVu Sans','Arial'],'font.size':12,'axes.titlesize':15,'axes.titleweight':'bold','svg.fonttype':'none','figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','text.color':'#172b36','axes.labelcolor':'#172b36','axes.spines.top':False,'axes.spines.right':False})
    blue,red,green='#28648a','#b85336','#467a62';colors=[blue,red,green]
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg',bbox_inches='tight')
        fig.savefig(args.output/f'{name}-{args.language}.png',dpi=180,bbox_inches='tight');plt.close(fig)

    fig=plt.figure(figsize=(12,8),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1,.9])
    ax=fig.add_subplot(gs[0,0]);ax.axis('off');ax.set_title(tr('a  CSV保存文本字段','a  CSV stores text fields'),loc='left')
    text='run_02.csv\n'+(data_dir/'run_02.csv').read_text(encoding='utf-8').strip()
    ax.text(.02,.93,text,va='top',fontsize=14,linespacing=1.55,transform=ax.transAxes)
    ax=fig.add_subplot(gs[0,1]);ax.axis('off');ax.set_title(tr('b  清单补上测量含义','b  A manifest supplies meaning'),loc='left')
    for i,(k,v) in enumerate([('run_id','R02'),('time_unit','min'),('temperature_unit','degC'),('ambient_temperature_C','20.0')]):
        y=.84-i*.18;ax.text(.02,y,k,fontsize=13,transform=ax.transAxes);ax.text(.88,y,v,color=red,ha='right',fontsize=15,transform=ax.transAxes)
    ax.text(.02,.07,tr('空字段 → None\n时间字段 × 60 → 秒','Empty field → None\nTime field × 60 → seconds'),fontsize=15,color=blue,transform=ax.transAxes)
    ax=fig.add_subplot(gs[1,:]);ax.axis('off');ax.set_xlim(0,12);ax.set_ylim(0,4)
    ax.text(.1,3.65,tr('c  转换后的记录保留身份与原始数值','c  Typed records retain identity and original values'),fontsize=16,weight='bold')
    xs=[.15,1.4,3.4,5.6,7.6,9.4];heads=['run_id','source_record','time_raw','time_unit','time_s','temperature_C']
    for x,h in zip(xs,heads):ax.text(x,2.9,h,fontsize=12,weight='bold')
    for j,r in enumerate(runs['R02']['rows'][1:4]):
        y=2.2-j*.7;ax.add_patch(Rectangle((.1,y-.14),11.5,.55,color=red if r['temperature_C'] is None else blue,alpha=.07))
        values=[r['run_id'],r['source_record'],r['time_raw'],r['time_unit'],r['time_s'],'None' if r['temperature_C'] is None else r['temperature_C']]
        for x,value in zip(xs,values):ax.text(x,y,str(value),fontsize=13)
    save(fig,'file-to-record')

    fig=plt.figure(figsize=(12,7.8),layout='constrained');gs=fig.add_gridspec(2,2,width_ratios=[1.4,1],height_ratios=[1,.26])
    ax=fig.add_subplot(gs[0,0])
    for (rid,run),col in zip(runs.items(),colors):
        rr=run['rows'];ax.plot([r['time_s'] for r in rr],[r['temperature_C'] if r['temperature_C'] is not None else math.nan for r in rr],'-o',color=col,label=rid,lw=2,ms=6)
    ax.axhline(manifest['ambient_temperature_C'],color='#76837c',ls='--',lw=1,label=tr('环境20°C','Ambient 20°C'))
    ax.set(xlabel=tr('统一时间 / s','Common time / s'),ylabel=tr('温度 / °C','Temperature / °C'),title=tr('a  三次独立冷却记录','a  Three independent cooling records'),ylim=(16,85),xlim=(-10,310),xticks=[0,60,120,180,240,300]);ax.legend(frameon=False,ncols=2);ax.grid(alpha=.15)
    ax=fig.add_subplot(gs[1,0]);ax.set_xlim(-10,310);ax.set_ylim(-.6,2.6)
    for i,(rid,run) in enumerate(runs.items()):
        for r in run['rows']:ax.scatter(r['time_s'],i,marker='x' if r['temperature_C'] is None else 's',color=red if r['temperature_C'] is None else '#a4b6b5',s=65)
    ax.set(yticks=[0,1,2],yticklabels=list(runs),xticks=[0,60,120,180,240,300],xlabel=tr('采样位置 / s；×为缺失','Sampling positions / s; × marks missing'));ax.invert_yaxis();ax.spines[['left','bottom']].set_visible(False)
    ax=fig.add_subplot(gs[:,1]);rates=[r['summary']['mean_rate_C_per_s'] for r in runs.values()]
    ax.barh(list(runs),rates,color=colors,height=.5);ax.axvline(0,color='#172b36',lw=1)
    for i,v in enumerate(rates):ax.text(v-.008,i,f'{v:.4f}',ha='right',va='center',fontsize=13)
    ax.set(xlim=(-.25,.01),xlabel=tr('首末有效点平均速率 / °C·s⁻¹','Endpoint mean rate / °C·s⁻¹'),title=tr('b  相同300 s窗口比较','b  Compare the same 300 s window'));ax.invert_yaxis();ax.grid(axis='x',alpha=.15)
    save(fig,'cooling-results')

    fig=plt.figure(figsize=(12,7.3),layout='constrained');gs=fig.add_gridspec(2,2,width_ratios=[1,1.2],height_ratios=[1,.5])
    pixels=[[0,0,1,0],[0,2,8,1],[1,4,6,0],[0,1,0,0]]
    ax=fig.add_subplot(gs[0,0]);im=ax.imshow(pixels,cmap='cividis',vmin=0,vmax=8,origin='lower')
    for i,row in enumerate(pixels):
        for j,v in enumerate(row):ax.text(j,i,str(v),ha='center',va='center',fontsize=15,color='white' if v<4 else '#172b36')
    ax.set(xticks=range(4),yticks=range(4),xlabel=tr('列索引','Column index'),ylabel=tr('行索引','Row index'),title=tr('a  数组本身：16个数值','a  An array: sixteen values'))
    ax=fig.add_subplot(gs[0,1]);ax.axis('off');ax.set_title(tr('b  描述信息让接收者读懂数组','b  Description makes the array interpretable'),loc='left')
    items=[(tr('尺寸','Dimensions'),'4 × 4'),(tr('数值含义','Value meaning'),tr('示意计数','Illustrative counts')),(tr('方向','Orientation'),tr('原点在左下','Origin at lower left')),(tr('坐标尺度','Coordinate scale'),tr('每像素0.4角秒','0.4 arcsec per pixel'))]
    for i,(k,v) in enumerate(items):
        y=.85-i*.22;ax.text(.01,y,k,fontsize=14,transform=ax.transAxes,color=blue);ax.text(.43,y,v,fontsize=14,transform=ax.transAxes)
    ax=fig.add_subplot(gs[1,:]);ax.axis('off');ax.text(.01,.79,tr('FITS：把数据的组织方式与数值一起交换','FITS: exchange the organization of data together with its values'),fontsize=18,weight='bold',transform=ax.transAxes)
    ax.text(.01,.46,tr('1979 年跨系统交换 → 1981 年发表基本定义','Cross-system exchange in 1979 → basic definition published in 1981'),fontsize=14,transform=ax.transAxes)
    ax.text(.01,.1,tr('本章中的同类问题：CSV的时间值 + JSON中的单位 → 可比较的冷却曲线','The corresponding issue here: CSV time values + JSON units → comparable cooling curves'),fontsize=14,color=red,transform=ax.transAxes)
    save(fig,'metadata-history')
    r02_valid=[r for r in runs['R02']['rows'] if r['temperature_C'] is not None]
    incorrect_rate=(r02_valid[-1]['temperature_C']-r02_valid[0]['temperature_C'])/(r02_valid[-1]['time_raw']-r02_valid[0]['time_raw'])
    summary={'dataset':manifest['description'],'file_count':len(paths),'record_count':len(observations),'valid_count':sum(r['temperature_C'] is not None for r in observations),'input_sha256':hashes,'runs':{rid:run['summary'] for rid,run in runs.items()},'unit_error_R02_rate_if_minutes_read_as_seconds':incorrect_rate,'roundtrip_record_count':len(reread),'quoted_note_roundtrip':reread[0]['note']}
    (args.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    (args.output/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:summary[k] for k in ['file_count','record_count','valid_count','runs']},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
