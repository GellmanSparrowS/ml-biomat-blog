Original constructed teaching data for P05.
Each CSV row is one time/temperature observation in one independent run.
The manifest supplies time units and the common temperature unit.
An empty temperature field means an absent reading; it is not zero.
Labels describe the chosen numerical trajectories and do not encode a tested material effect.
Data may be reused under CC0 1.0: https://creativecommons.org/publicdomain/zero/1.0/
