# Public sources and third-party materials

- Software Carpentry — Looping Over Data Sets: https://swcarpentry.github.io/python-novice-gapminder/14-looping-data-sets.html
  CC BY 4.0, https://creativecommons.org/licenses/by/4.0/; original prose, code and figures.
- Python 3.14 — csv: https://docs.python.org/3.14/library/csv.html
  PSF documentation license
- Python 3.14 — pathlib: https://docs.python.org/3.14/library/pathlib.html
  PSF documentation license
- Python 3.14 — json: https://docs.python.org/3.14/library/json.html
  PSF documentation license
- NASA FITS — The First Agreement: https://fits.gsfc.nasa.gov/users_guide/users_guide/node9.html
  NASA institutional historical reference; original diagram, no reused image.
- NASA Science Data Portal — FITS: https://science.data.nasa.gov/fits
  NASA factual technical reference
