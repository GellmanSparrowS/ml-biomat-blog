"""Create and independently read back a calibrated microscopy workbook.

Input pixel counts are measurements of the CC0 skimage.data.cell image using
the S01 threshold/connected-region pipeline. Rows vary processing parameters
on the same image; they are not independent biological replicates.
"""
from pathlib import Path
import argparse
import csv
import json
import math
import zipfile
import numpy as np
import xlsxwriter
import openpyxl
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

HERE = Path(__file__).resolve().parent



def available_plot_fonts():
    """Choose installed fonts; keep a Latin fallback on every platform."""
    choices = ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]



def create_workbook(rows, output, spacing):
    path = output / "microscopy-report.xlsx"
    with xlsxwriter.Workbook(path) as workbook:
        inputs = workbook.add_worksheet("Parameters")
        data = workbook.add_worksheet("Measurements")
        notes = workbook.add_worksheet("Readme")
        number = workbook.add_format({"num_format": "0.000", "font_color": "#172534"})
        parameter = workbook.add_format({"num_format": "0.000", "bg_color": "#e7f1f6", "border": 1})
        header = workbook.add_format({"bold": True, "font_color": "#205b8c", "text_wrap": True})
        inputs.write_row(0,0,["Parameter", "Value", "Unit"],header)
        inputs.write(1,0,"Square-pixel side length");inputs.write_number(1,1,spacing,parameter);inputs.write(1,2,"um / pixel")
        inputs.data_validation("B2",{"validate":"decimal","criteria":">","value":0,
                                     "input_title":"Calibration", "input_message":"Positive micrometres per pixel",
                                     "error_type":"stop","error_message":"Use a positive pixel spacing."})
        inputs.set_column("A:A",32);inputs.set_column("B:C",19);inputs.freeze_panes(1,0)
        headers=["Threshold","Fill holes","Pixels","Area / um^2","Equivalent diameter / um"]
        for i,row in enumerate(rows,start=1):
            excel=i+1
            data.write_number(i,0,row['threshold']);data.write_boolean(i,1,row['fill_holes'])
            data.write_number(i,2,row['pixels'])
            data.write_formula(i,3,f"=C{excel}*Parameters!$B$2^2",number,row['area_um2'])
            data.write_formula(i,4,f"=2*SQRT(D{excel}/PI())",number,row['diameter_um'])
        data.add_table(0,0,len(rows),4,{"name":"RegionMeasurements","style":"Table Style Medium 2",
                                                  "columns":[{"header":h} for h in headers]})
        data.freeze_panes(1,3);data.set_column("A:C",16);data.set_column("D:E",29)
        chart=workbook.add_chart({"type":"scatter","subtype":"straight_with_markers"})
        # Interleaved filled/unfilled rows are written to separate linked columns.
        inputs.write_row(4,0,["Threshold","Area, holes filled / um^2"],header)
        filled=[(i,r) for i,r in enumerate(rows,start=2) if r['fill_holes']]
        for j,(excel,r) in enumerate(filled,start=5):
            inputs.write_number(j,0,r['threshold'])
            inputs.write_formula(j,1,f"=Measurements!D{excel}",number,r['area_um2'])
        chart.add_series({"name":"Same image; holes filled","categories":["Parameters",5,0,4+len(filled),0],
                          "values":["Parameters",5,1,4+len(filled),1],"line":{"color":"#205b8c"},
                          "marker":{"type":"circle","size":5}})
        chart.set_title({"name":"Threshold sensitivity"});chart.set_x_axis({"name":"Intensity threshold"})
        chart.set_y_axis({"name":"Projected area / um^2"});chart.set_legend({"none":True})
        data.insert_chart("G2",chart,{"x_scale":1.2,"y_scale":1.15})
        messages=["Image: skimage.data.cell; data license CC0; Mueller et al. 2018, doi:10.1364/OE.26.010729.",
                  "Each row is one processing condition on the same image, not a biological replicate.",
                  "Pixels: largest eight-connected region with intensity strictly above threshold.",
                  "Fill holes: fill enclosed background after selecting the largest component.",
                  "Area = pixel count * square-pixel spacing squared; diameter = 2*sqrt(area/pi).",
                  "Formulas include cached values independently calculated in Python.",
                  "Editing Parameters!B2 updates dependent cells when a spreadsheet engine recalculates.",
                  "openpyxl reads formula text or cached results; it does not calculate formulas.",
                  "Original measurement workflow: S01, Measuring Structure in Microscopy Images."]
        notes.set_column("A:A",115)
        for i,message in enumerate(messages):notes.write(i,0,message)
    return path


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--language",choices=("zh","en"),default="en")
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    zh=args.language=='zh';tr=lambda a,b:a if zh else b;spacing=.107
    with (HERE/'data/region-measurements.csv').open(encoding='utf-8',newline='') as f:
        rows=[{'threshold':int(r['threshold']),'fill_holes':bool(int(r['fill_holes'])),'pixels':int(r['pixels'])} for r in csv.DictReader(f)]
    for r in rows:
        r['area_um2']=r['pixels']*spacing**2;r['diameter_um']=2*math.sqrt(r['area_um2']/math.pi)
    path=create_workbook(rows,args.output,spacing)
    formulas=openpyxl.load_workbook(path,data_only=False,read_only=True)
    cached=openpyxl.load_workbook(path,data_only=True,read_only=True)
    for i,r in enumerate(rows,start=2):
        assert formulas['Measurements'][f'D{i}'].value==f'=C{i}*Parameters!$B$2^2'
        assert math.isclose(cached['Measurements'][f'D{i}'].value,r['area_um2'],abs_tol=1e-10)
        assert math.isclose(cached['Measurements'][f'E{i}'].value,r['diameter_um'],abs_tol=1e-10)
    assert formulas['Measurements']['B2'].data_type=='b'
    sheetnames=formulas.sheetnames;formulas.close();cached.close()
    with zipfile.ZipFile(path) as z:assert 'xl/worksheets/sheet2.xml' in z.namelist()
    selected=next(r for r in rows if r['threshold']==122 and r['fill_holes'])
    summary={'rows':len(rows),'spacing_um':spacing,'sheet_names':sheetnames,'formula_count':len(rows)*2+7,
             'readback_rows_checked':len(rows),'selected':selected,'calculation_engine':'Python cached values; Excel-compatible formulas'}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    (args.output/'lab-data.json').write_text(json.dumps({'rows':rows,'spacing_um':spacing}),encoding='utf8')
    plt.rcParams.update({'font.family':available_plot_fonts(),'font.size':12,'svg.fonttype':'none',
                         'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','axes.spines.top':False,'axes.spines.right':False})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg',metadata={'Date':None})
        fig.savefig(args.output/f'{name}-{args.language}.png',dpi=150);plt.close(fig)
    fig,ax=plt.subplots(figsize=(12.4,5.1),layout='constrained');ax.axis('off')
    header=[tr('阈值','Threshold'),tr('填孔','Fill holes'),tr('像素数','Pixels'),tr('面积 / μm²','Area / μm²'),tr('直径 / μm','Diameter / μm')]
    show=[r for r in rows if r['fill_holes']]
    table=ax.table(cellText=[[r['threshold'],tr('是','Yes'),r['pixels'],f"{r['area_um2']:.3f}",f"{r['diameter_um']:.3f}"] for r in show],colLabels=header,cellLoc='right',loc='center',colWidths=[.13,.13,.18,.27,.27])
    table.auto_set_font_size(False);table.set_fontsize(13);table.scale(1,2)
    for (r,c),cell in table.get_celld().items():
        cell.set_edgecolor('#dce3e6');cell.set_facecolor('#205b8c' if r==0 else ('#e7f1f6' if r==3 else '#ffffff'))
        if r==0:cell.get_text().set_color('white')
    ax.set_title(tr('同一图像的处理条件表 · 原始计数与可追踪的计算列','Processing conditions for one image · counts and traceable calculations'),loc='left',pad=15)
    save(fig,'workbook-values')
    fig,axs=plt.subplots(1,2,figsize=(12.4,4.5),layout='constrained');ss=np.linspace(.07,.15,200);n=selected['pixels']
    axs[0].plot(ss,n*ss**2,color='#205b8c',lw=2);axs[1].plot(ss,2*np.sqrt(n*ss**2/np.pi),color='#b4482e',lw=2)
    for ax,value in zip(axs,[selected['area_um2'],selected['diameter_um']]):
        ax.axvline(spacing,color='#7e8d95',ls='--');ax.scatter([spacing],[value],color='#172534',zorder=4);ax.set_xlabel(tr('像素边长 / μm','Pixel side length / μm'));ax.grid(alpha=.15)
    axs[0].set(ylabel=tr('面积 / μm²','Area / μm²'),title=tr('A  面积随标定的平方改变','A  Area scales with calibration squared'))
    axs[1].set(ylabel=tr('等效圆直径 / μm','Equivalent-circle diameter / μm'),title=tr('B  长度随标定线性改变','B  Diameter scales linearly with calibration'))
    save(fig,'calibration-dependence')
    fig,ax=plt.subplots(figsize=(12.4,4.9),layout='constrained');ax.set(xlim=(0,12),ylim=(0,5));ax.axis('off')
    boxes=[(0.2,3.3,3.1,1.0,'Parameters!B2',tr('标定：0.107 μm/像素','Calibration: 0.107 μm/pixel')),(0.2,.8,3.1,1.0,'Measurements!C7','11746 pixels'),(4.6,2,3.1,1.2,'Measurements!D7','134.479954 μm²'),(8.7,2,3.1,1.2,'Measurements!E7','13.085305 μm')]
    for x,y,w,h,title,value in boxes:
        ax.add_patch(plt.Rectangle((x,y),w,h,facecolor='#e7f1f6' if title.startswith('Parameters') else '#fff',edgecolor='#8da5b4'))
        ax.text(x+.15,y+h-.30,title,fontsize=11,color='#205b8c');ax.text(x+.15,y+.25,value,fontsize=12)
    for start,end in [((3.3,3.8),(4.6,2.9)),((3.3,1.3),(4.6,2.3)),((7.7,2.6),(8.7,2.6))]:ax.annotate('',xy=end,xytext=start,arrowprops={'arrowstyle':'->','color':'#8da5b4','lw':2})
    ax.text(4.6,1.5,'=C7*Parameters!$B$2^2',fontsize=12,parse_math=False);ax.text(8.7,1.5,'=2*SQRT(D7/PI())',fontsize=12,parse_math=False)
    ax.set_title(tr('从 VisiCalc（1979）到科学工作簿：保留单元格之间的依赖','From VisiCalc (1979) to a scientific workbook: preserve cell dependencies'),loc='left',fontsize=15)
    save(fig,'cell-dependencies')
    print(json.dumps(summary))


if __name__=='__main__':main()
