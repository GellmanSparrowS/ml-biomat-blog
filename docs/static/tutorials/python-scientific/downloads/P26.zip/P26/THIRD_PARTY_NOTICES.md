# Public sources and third-party materials

- XlsxWriter: Tutorial 1: https://xlsxwriter.readthedocs.io/tutorial01.html
  Software: BSD-2-Clause; original tutorial adaptation.
- XlsxWriter: Working with Formulas: https://xlsxwriter.readthedocs.io/working_with_formulas.html
  Official technical documentation.
- openpyxl Tutorial: https://openpyxl.readthedocs.io/en/stable/tutorial.html
  Software: MIT; official documentation reference.
- Computer History Museum: Software, Putting PCs to Work: https://www.computerhistory.org/revolution/personal-computers/17/305
  Historical reference; original dependency diagram.
- scikit-image cell image: https://scikit-image.org/docs/stable/api/skimage.data.html#skimage.data.cell
  Original image CC0; numerical derivative measurements supplied with the example.
