"""Read four public PDB entry records, validate their identities, and plot metadata.

Default execution reads the bundled JSON snapshots.  --refresh retrieves current
records with Requests and places the new snapshots inside the output directory.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import platform
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
import requests

IDS = ("1UBQ", "4HHB", "1BNA", "1D3Z")
BASE_URL = "https://data.rcsb.org/rest/v1/core/entry/"
HERE = Path(__file__).resolve().parent



def available_plot_fonts():
    """Choose installed fonts; keep a Latin fallback on every platform."""
    choices = ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]



def fetch_record(session, pdb_id, destination):
    """Download one identified entry. A failed request never replaces a cache."""
    response = session.get(BASE_URL + pdb_id, timeout=(10, 60))
    response.raise_for_status()
    value = response.json()
    validate_record(value, pdb_id)
    destination.write_bytes(response.content)
    return value


def validate_record(record, requested_id):
    if record.get("rcsb_id") != requested_id:
        raise ValueError("The response identifier differs from the requested entry")
    methods = record.get("exptl", [])
    if not methods or not all(isinstance(x.get("method"), str) for x in methods):
        raise ValueError("The entry has no readable experimental method")
    info = record.get("rcsb_entry_info", {})
    atom_count = info.get("deposited_atom_count")
    if not isinstance(atom_count, int) or atom_count <= 0:
        raise ValueError("The deposited atom count must be a positive integer")


def select_fields(record, raw):
    info = record["rcsb_entry_info"]
    resolutions = info.get("resolution_combined", [])
    return {
        "pdb_id": record["rcsb_id"],
        "title": record["struct"]["title"],
        "method": "; ".join(x["method"] for x in record["exptl"]),
        "deposited_atoms": info["deposited_atom_count"],
        "polymer_entities": info["polymer_entity_count"],
        "resolution_angstrom": float(resolutions[0]) if resolutions else None,
        "response_bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def figures(rows, records, output, language):
    zh = language == "zh"
    plt.rcParams.update({"font.family": available_plot_fonts(),
        "font.size": 12, "axes.spines.top": False, "axes.spines.right": False,
        "svg.fonttype": "none", "axes.unicode_minus": False, "figure.facecolor": "#faf9f5",
        "axes.facecolor": "#faf9f5", "text.color": "#172534", "axes.labelcolor": "#172534"})
    blue, orange, grey = "#205b8c", "#b4482e", "#6a7782"
    fig = plt.figure(figsize=(12.2, 7.5), layout="constrained")
    grid = fig.add_gridspec(2, 2, width_ratios=[1.35, 1])
    ax = fig.add_subplot(grid[:, 0])
    positions = np.arange(len(rows))
    colours = [orange if "NMR" in r["method"] else blue for r in rows]
    ax.hlines(positions, 0, [r["deposited_atoms"] for r in rows], color=colours, lw=3)
    ax.scatter([r["deposited_atoms"] for r in rows], positions, c=colours, s=80, zorder=3)
    ax.set_yticks(positions, [r["pdb_id"] for r in rows]); ax.invert_yaxis()
    ax.set_xlim(0, max(r["deposited_atoms"] for r in rows) * 1.24)
    ax.set_xlabel("条目报告的存档原子数" if zh else "Deposited atom count reported by the entry")
    ax.set_title("A  同一字段，四个结构条目" if zh else "A  One field across four structure entries", loc="left", pad=22)
    for i, r in enumerate(rows):
        ax.text(r["deposited_atoms"] + 100, i, f'{r["deposited_atoms"]:,}', va="center", fontsize=12)
    ax.grid(axis="x", color="#dde1e3", lw=.6); ax.set_axisbelow(True)
    bx = fig.add_subplot(grid[0, 1])
    valid = [r for r in rows if r["resolution_angstrom"] is not None]
    bx.scatter([r["resolution_angstrom"] for r in valid], np.arange(len(valid)), color=blue, s=75)
    bx.set_yticks(np.arange(len(valid)), [r["pdb_id"] for r in valid]); bx.invert_yaxis()
    bx.set_xlabel("报告的分辨率 / Å" if zh else "Reported resolution / Å")
    bx.set_xlim(0, max(r["resolution_angstrom"] for r in valid) * 1.25)
    bx.set_title("B  有该字段的X射线条目" if zh else "B  X-ray entries with this field", loc="left")
    bx.grid(axis="x", color="#dde1e3", lw=.6)
    cx = fig.add_subplot(grid[1, 1]); cx.axis("off")
    txt = ("实验方法是解释数字的前提\n\n蓝：X-RAY DIFFRACTION\n橙：SOLUTION NMR\n\n1D3Z 的分辨率字段缺失，\n保留为 null；不填成 0 Å。" if zh else
           "Read the experimental method first\n\nBlue: X-RAY DIFFRACTION\nOrange: SOLUTION NMR\n\nThe resolution field for 1D3Z is absent.\nKeep null; do not substitute 0 Å.")
    cx.text(.02, .95, txt, va="top", linespacing=1.7, fontsize=12)
    fig.savefig(output / f"entry-comparison-{language}.svg", metadata={"Date": None}); plt.close(fig)
    fig, axes = plt.subplots(2, 3, figsize=(14, 7.2), gridspec_kw={"width_ratios":[1.4,1,1.45],"height_ratios":[2.5,1]}, layout="constrained")
    for axis in axes.ravel(): axis.axis("off")
    info = records[0]["rcsb_entry_info"]
    source_fields = {"rcsb_id":records[0]["rcsb_id"],"rcsb_entry_info":{key:info[key] for key in ["deposited_atom_count","polymer_entity_count","resolution_combined"]}}
    axes[0,0].set_title("A  真实响应中的选定字段" if zh else "A  Selected fields in the actual response",loc="left",fontsize=13)
    axes[0,0].text(.02,.9,json.dumps(source_fields,indent=2),va="top",family="DejaVu Sans Mono",fontsize=13,linespacing=1.45,
                   bbox={"facecolor":"#edf2f4","edgecolor":"#cad5dc","pad":14})
    axes[0,1].set_title("B  从嵌套路径到结果列" if zh else "B  Nested paths become result columns",loc="left",fontsize=13)
    for y,key,name,value,color in [(.83,'deposited_atom_count','deposited_atoms',rows[0]['deposited_atoms'],blue),
                                   (.53,'polymer_entity_count','polymer_entities',rows[0]['polymer_entities'],'#277a78'),
                                   (.23,'resolution_combined[0]','resolution_angstrom',rows[0]['resolution_angstrom'],orange)]:
        axes[0,1].text(0,y,'rcsb_entry_info.\n'+key,va='top',fontsize=12.5,color=color,linespacing=1.4)
        axes[0,1].text(0,y-.17,'→ '+name+' = '+str(value),fontsize=12,color=color)
    axes[0,2].set_title("C  同一路径用于四条记录" if zh else "C  Apply the same path to all four records",loc="left",fontsize=13)
    labels=['编号','原子数','实体数','Å'] if zh else ['ID','Atoms','Entities','Å']
    table=axes[0,2].table(cellText=[[r['pdb_id'],r['deposited_atoms'],r['polymer_entities'],r['resolution_angstrom'] if r['resolution_angstrom'] is not None else 'null'] for r in rows],colLabels=labels,cellLoc='center',bbox=[0,.14,1,.72],colWidths=[.23,.27,.25,.25])
    table.auto_set_font_size(False);table.set_fontsize(13)
    for (r,c),cell in table.get_celld().items():
        cell.set_edgecolor('#cbd7dd');cell.set_facecolor('#e7eef3' if r==1 else '#ffffff')
        if r==0:cell.set_facecolor(['#172534',blue,'#277a78',orange][c]);cell.get_text().set_color('white')
        if r==4 and c==3:cell.set_facecolor('#f3e5df');cell.get_text().set_color(orange)
    nmr=next(record for record in records if record['rcsb_id']=='1D3Z')
    missing='resolution_combined' not in nmr['rcsb_entry_info']
    axes[1,0].text(.02,.9,'1D3Z · '+nmr['exptl'][0]['method'],color=orange,fontsize=14,va='top')
    axes[1,0].text(.02,.55,('rcsb_entry_info 中没有\nresolution_combined 字段' if zh else 'resolution_combined is absent\nfrom rcsb_entry_info') if missing else 'resolution_combined is present',fontsize=12,va='top',linespacing=1.5)
    axes[1,1].text(0,.9,'→ Python: None\n→ JSON: null\n→ CSV: '+('空单元格' if zh else 'empty cell'),fontsize=13,va='top',linespacing=1.6,color=orange)
    axes[1,2].text(0,.9,'1D3Z'+(' 保留身份与实验方法\n分辨率图不放置数值点\n缺失状态随记录保存' if zh else ' keeps its identity and method\nNo point on the resolution axis\nMissing state remains in the record'),fontsize=12,va='top',linespacing=1.7)
    fig.savefig(output / f"response-to-table-{language}.svg", metadata={"Date": None})
    fig.savefig(output / f"response-to-table-{language}.png", dpi=150); plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--language", choices=["zh", "en"], default="zh")
    parser.add_argument("--refresh", action="store_true")
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    data_dir = HERE / "data"
    if args.refresh:
        data_dir = args.output / "refreshed-data"; data_dir.mkdir(exist_ok=True)
        with requests.Session() as session:
            session.headers["User-Agent"] = "ScientificPythonCourse/1.0"
            for pdb_id in IDS:
                fetch_record(session, pdb_id, data_dir / f"{pdb_id}.json")
                time.sleep(.2)
    rows = []; records = []
    for pdb_id in IDS:
        raw = (data_dir / f"{pdb_id}.json").read_bytes()
        record = json.loads(raw); validate_record(record, pdb_id)
        records.append(record)
        rows.append(select_fields(record, raw))
    with (args.output / "entries.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    summary = {"source": "RCSB PDB core entry API", "entry_count": len(rows), "rows": rows,
               "resolution_present": sum(r["resolution_angstrom"] is not None for r in rows),
               "missing_resolution_ids": [r["pdb_id"] for r in rows if r["resolution_angstrom"] is None]}
    (args.output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    figures(rows, records, args.output, args.language)
    print(json.dumps({"entry_count": len(rows), "resolution_present": summary["resolution_present"]}))


if __name__ == "__main__":
    main()
