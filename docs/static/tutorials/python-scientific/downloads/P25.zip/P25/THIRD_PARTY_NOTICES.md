# Public sources and third-party materials

- RCSB PDB Data API: https://data.rcsb.org/
  Technical documentation; original teaching prose and implementation.
- Requests: Quickstart: https://requests.readthedocs.io/en/latest/user/quickstart/
  Technical reference; no tutorial text reproduced.
- RCSB PDB Policies: https://www.rcsb.org/pages/policies
  PDB core archive data: CC0; site documentation: CC BY 4.0.
- The Protein Data Bank: a computer-based archival file for macromolecular structures (1977): https://doi.org/10.1016/S0022-2836(77)80200-3
  Bibliographic reference; no text or figures reproduced.
- 1UBQ · Structure of ubiquitin refined at 1.8 A resolution. (1987): https://doi.org/10.1016/0022-2836(87)90679-6
  Bibliographic reference; the bundled core archive record is CC0.
- 4HHB · The crystal structure of human deoxyhaemoglobin at 1.74 A resolution (1984): https://doi.org/10.1016/0022-2836(84)90472-8
  Bibliographic reference; the bundled core archive record is CC0.
- 1BNA · Structure of a B-DNA dodecamer: conformation and dynamics. (1981): https://doi.org/10.1073/pnas.78.4.2179
  Bibliographic reference; the bundled core archive record is CC0.
- 1D3Z · Validation of Protein Structure from Anisotropic Carbonyl Chemical Shifts in a Dilute Liquid Crystalline Phase (1998): https://doi.org/10.1021/ja9812610
  Bibliographic reference; the bundled core archive record is CC0.
