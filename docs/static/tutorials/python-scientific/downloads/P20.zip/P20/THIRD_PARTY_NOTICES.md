# Public sources and third-party materials

- SciPy: signal processing tutorial: https://docs.scipy.org/doc/scipy/tutorial/signal.html
  SciPy BSD-3-Clause; original teaching data and figures
- SciPy: Savitzky–Golay filter: https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.savgol_filter.html
  SciPy BSD-3-Clause; original teaching data and figures
- SciPy: Savitzky–Golay coefficients: https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.savgol_coeffs.html
  SciPy BSD-3-Clause; original teaching data and figures
- SciPy: find_peaks: https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.find_peaks.html
  SciPy BSD-3-Clause; original teaching data and figures
- SciPy: periodogram: https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.periodogram.html
  SciPy BSD-3-Clause; original teaching data and figures
- Savitzky & Golay (1964), Smoothing and Differentiation of Data by Simplified Least Squares Procedures: https://doi.org/10.1021/ac60214a047
  Historical and technical reference; no reproduced passage or figure
