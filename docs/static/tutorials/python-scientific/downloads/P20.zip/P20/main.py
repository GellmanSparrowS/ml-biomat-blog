"""Inspect smoothing, peak finding, and frequency response on a defined teaching signal."""
from pathlib import Path
import argparse,json
import numpy as np
import scipy
from scipy import signal,ndimage
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

DT=.02
BLUE,RED,INK,GRAY='#28658c','#b64a35','#20313e','#71808b'


def data():
    t=np.arange(501)*DT
    clean=.1+.02*t+1.2*np.exp(-.5*((t-3)/.25)**2)+.8*np.exp(-.5*((t-7)/.5)**2)
    interference=.12*np.sin(2*np.pi*9*t)+.035*np.cos(2*np.pi*17*t)
    return t,clean,clean+interference


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
    def tr(a,b):return a if zh else b
    available={font.name for font in font_manager.fontManager.ttflist}
    font_names=[name for name in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if name in available]
    plt.rcParams.update({'font.family':font_names,
        'font.size':12,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'grid.alpha':.15})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg');fig.savefig(args.output/f'{name}-{args.language}.png',dpi=160);plt.close(fig)
    t,clean,observed=data();results={}
    for method in ['savgol','mean']:
        for window in [5,11,21,41]:
            coefficients=signal.savgol_coeffs(window,2) if method=='savgol' else np.ones(window)/window
            smoothed=signal.savgol_filter(observed,window,2,mode='mirror') if method=='savgol' else ndimage.uniform_filter1d(observed,window,mode='mirror')
            peaks,properties=signal.find_peaks(smoothed,prominence=.3,distance=100)
            # A centered symmetric filter has a real frequency response.
            offsets=np.arange(window)-window//2
            gain9=float(abs(np.sum(coefficients*np.cos(2*np.pi*9*DT*offsets))))
            results[f'{method}_{window}']={'rmse_mV':float(np.sqrt(np.mean((smoothed-clean)**2))),
                'value_at3s_mV':float(smoothed[150]),'gain9':gain9,
                'peak_times_s':t[peaks].tolist(),'peak_values_mV':smoothed[peaks].tolist(),
                'prominences_mV':properties['prominences'].tolist(),'coefficient_sum':float(coefficients.sum())}
    smooth=signal.savgol_filter(observed,21,2,mode='mirror');peaks,properties=signal.find_peaks(smooth,prominence=.3,distance=100)
    np.savetxt(args.output/'signal.csv',np.column_stack([t,clean,observed,smooth]),delimiter=',',comments='',
        header='time_s,clean_model_mV,with_interference_mV,savgol21_mV')
    fig,axes=plt.subplots(2,1,figsize=(12,8),layout='constrained',gridspec_kw={'height_ratios':[1.4,1]})
    axes[0].plot(t,observed,color='#bdc9d0',lw=1,label=tr('含规定干扰','Defined interference added'))
    axes[0].plot(t,clean,color=INK,lw=1.5,ls='--',label=tr('已知平滑模型','Known smooth model'))
    axes[0].plot(t,smooth,color=BLUE,lw=2,label=tr('Savitzky–Golay：21点，二次','Savitzky–Golay: 21 points, degree 2'))
    axes[0].scatter(t[peaks],smooth[peaks],color=RED,zorder=5)
    for i in peaks:axes[0].annotate(f'{t[i]:.2f} s',(t[i],smooth[i]),xytext=(8,13),textcoords='offset points',color=RED)
    axes[0].set(ylabel=tr('信号 / mV','Signal / mV'),title=tr('A  平滑与局部峰定位','A  Smoothing and local peak locations'));axes[0].legend(frameon=False,fontsize=10)
    for window,color in zip([5,21,41],[GRAY,BLUE,RED]):
        y=signal.savgol_filter(observed,window,2,mode='mirror');axes[1].plot(t,y-clean,color=color,label=tr(f'{window}点',f'{window} points'))
    axes[1].axhline(0,color=INK,lw=.8);axes[1].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('平滑结果 − 已知模型 / mV','Smoothed − known model / mV'),title=tr('B  误差同时包含残留干扰与峰形改变','B  Error includes residual interference and shape change'))
    for a in axes:a.grid();a.set_xlim(0,10)
    axes[1].legend(frameon=False,loc='lower center',bbox_to_anchor=(.5,1.02),ncol=3);axes[1].set_title(tr('B  误差同时包含残留干扰与峰形改变','B  Error includes residual interference and shape change'),pad=38);save(fig,'smoothing')
    fig,axes=plt.subplots(1,2,figsize=(12,5.6),layout='constrained')
    k=np.arange(-2,3,dtype=float);values=k*k;dense=np.linspace(-2,2,200)
    axes[0].plot(dense,dense*dense,color=BLUE,lw=2,label=tr('局部二次曲线','Local quadratic'))
    axes[0].scatter(k,values,color=INK,zorder=4,label=tr('五个样本值','Five sampled values'))
    axes[0].axhline(values.mean(),color=RED,ls='--',label=tr('移动平均的中心输出 = 2','Moving-mean center output = 2'))
    axes[0].scatter([0],[0],s=80,facecolors='white',edgecolors=BLUE,zorder=5,label=tr('二次拟合的中心输出 = 0','Quadratic-fit center output = 0'))
    axes[0].set(xlabel=tr('相对样本位置 k','Relative sample offset k'),ylabel=tr('教学数值 / mV','Teaching value / mV'),title=tr('保留局部曲率','Preserve local curvature'));axes[0].legend(frameon=False,fontsize=9)
    coefficients=signal.savgol_coeffs(5,2)
    axes[1].bar(k-.14,np.ones(5)/5,width=.28,color=RED,label=tr('移动平均','Moving mean'))
    axes[1].bar(k+.14,coefficients,width=.28,color=BLUE,label='Savitzky–Golay')
    axes[1].axhline(0,color=INK,lw=1);axes[1].set(xlabel=tr('相对样本位置 k','Relative sample offset k'),ylabel=tr('权重，无量纲','Weight, dimensionless'),xticks=k,title=tr('固定权重实现局部最小二乘','Fixed weights implement local least squares'));axes[1].legend(frameon=False,fontsize=10)
    fig.suptitle(tr('Savitzky与Golay（1964）：把局部拟合变成重复加权','Savitzky and Golay (1964): local fitting as repeated weighting'),fontsize=15)
    save(fig,'history')
    fig,axes=plt.subplots(1,2,figsize=(12,5.8),layout='constrained')
    for y,color,label in [(observed,GRAY,tr('含干扰','With interference')),(smooth,BLUE,'SG21')]:
        freq,psd=signal.periodogram(y,fs=1/DT,window='hann',detrend='linear',scaling='density')
        axes[0].semilogy(freq,psd,color=color,lw=1.5,label=label)
    axes[0].set(xlabel=tr('频率 / Hz','Frequency / Hz'),ylabel='PSD / mV²·Hz⁻¹',xlim=(0,25),ylim=(1e-12,1),title=tr('频域：9 Hz与17 Hz干扰','Frequency view: 9 Hz and 17 Hz interference'));axes[0].legend(frameon=False)
    freq=np.linspace(0,25,501)
    for window,color in zip([5,21,41],[GRAY,BLUE,RED]):
        c=signal.savgol_coeffs(window,2);k=np.arange(window)-window//2;gain=np.abs(np.cos(2*np.pi*freq[:,None]*DT*k[None,:])@c)
        axes[1].plot(freq,gain,color=color,label=tr(f'{window}点',f'{window} points'))
    axes[1].axvline(9,color=INK,ls=':',lw=1);axes[1].set(xlabel=tr('频率 / Hz','Frequency / Hz'),ylabel=tr('幅值增益，无量纲','Amplitude gain, dimensionless'),title=tr('窗口决定保留哪些变化速度','The window selects rates of variation'),xlim=(0,25));axes[1].legend(frameon=False)
    for a in axes:a.grid()
    save(fig,'frequency')
    summary={'versions':{'numpy':np.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__},
        'sampling_interval_s':DT,'sampling_frequency_Hz':1/DT,'n':len(t),'cases':results,
        'sg5_coefficients':coefficients.tolist(),'quadratic_sg_center':float(coefficients@values),
        'quadratic_mean_center':float(values.mean())}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))


if __name__=='__main__':main()
