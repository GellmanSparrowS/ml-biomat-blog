"""Fit an explicitly defined relaxation dataset and inspect residuals and profiles."""
from pathlib import Path
import argparse
import json
import numpy as np
import scipy
from scipy.optimize import curve_fit, minimize_scalar
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

BLUE, RED, INK, GRAY = "#28658c", "#b64a35", "#202e39", "#71808b"


def relaxation(t, amplitude, tau, baseline):
    return amplitude * np.exp(-np.asarray(t) / tau) + baseline


def profile(t, observed, tau):
    """Solve the two linear coefficients at a fixed positive time scale."""
    design = np.column_stack((np.exp(-t / tau), np.ones_like(t)))
    amplitude, baseline = np.linalg.lstsq(design, observed, rcond=None)[0]
    residual = observed - design @ np.array([amplitude, baseline])
    return float(residual @ residual), float(amplitude), float(baseline)


def main(output, language):
    output.mkdir(parents=True, exist_ok=True)
    zh = language == "zh"
    def tr(a, b): return a if zh else b
    plt.rcParams.update({"font.family": [name for name in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if name in {f.name for f in font_manager.fontManager.ttflist}],
        "font.size": 11, "axes.labelsize": 12, "axes.titlesize": 13,
        "axes.titleweight": "bold", "axes.spines.top": False,
        "axes.spines.right": False, "text.color": INK, "svg.fonttype": "none",
        "svg.hashsalt": "P19", "savefig.facecolor": "white"})
    t = np.arange(25, dtype=float) / 2
    noise = np.array([.04,-.03,.02,-.05,.01,.03,-.02,.04,-.01,-.03,
                     .02,-.04,.03,0,-.02,.01,.03,-.01,-.03,.02,-.01,.03,-.02,.01,-.02])
    truth = np.array([2.4, 3., .4])
    y = relaxation(t, *truth) + noise
    popt, pcov = curve_fit(relaxation, t, y, p0=[2., 2., .3],
        bounds=([0., .1, 0.], [10., 20., 3.]), xtol=1e-12, ftol=1e-12, gtol=1e-12)
    def zero_baseline(time, amplitude, tau): return relaxation(time, amplitude, tau, 0.)
    pzero, _ = curve_fit(zero_baseline, t, y, p0=[2., 3.],
        bounds=([0., .1], [10., 20.]), xtol=1e-12, ftol=1e-12, gtol=1e-12)
    residual = y - relaxation(t, *popt)
    residual_zero = y - zero_baseline(t, *pzero)
    tau_grid = np.linspace(1., 7., 301)
    profiles = {}
    for end in (3., 6., 12.):
        use = t <= end
        solution = minimize_scalar(lambda tau: profile(t[use], y[use], tau)[0],
                                   bounds=(1., 7.), method="bounded",
                                   options={"xatol": 1e-12})
        loss, amp, base = profile(t[use], y[use], solution.x)
        profiles[str(int(end))] = {"n": int(use.sum()), "tau_s": float(solution.x),
            "amplitude_kPa": amp, "baseline_kPa": base, "sse_kPa2": loss,
            "curve": [profile(t[use], y[use], q)[0] for q in tau_grid]}
    clean, _ = curve_fit(relaxation, t, relaxation(t, *truth), p0=[2., 2., .3],
                        bounds=([0., .1, 0.], [10., 20., 3.]),
                        xtol=1e-12, ftol=1e-12, gtol=1e-12)
    assert np.max(np.abs(clean-truth)) < 1e-8
    assert abs(profiles["12"]["tau_s"] - popt[1]) < 1e-5
    assert residual @ residual < residual_zero @ residual_zero
    dense = np.linspace(0, 12, 400)
    def save(fig, name):
        fig.savefig(output / f"{name}-{language}.svg", metadata={"Date": None})
        fig.savefig(output / f"{name}-{language}.png", dpi=180)
        plt.close(fig)
    fig, ax = plt.subplots(figsize=(11.5, 5.5), layout="constrained")
    ax.plot(dense, relaxation(dense, *truth), color=BLUE, lw=2.5)
    ax.axhline(.4, color=GRAY, ls="--", lw=1)
    ax.vlines(3, 0, relaxation(3, *truth), color=RED, ls="--")
    ax.scatter([0,3], relaxation(np.array([0,3]), *truth), color=RED, zorder=4)
    ax.annotate("A + b = 2.8 kPa", (0,2.8), xytext=(1.3,2.65),
                arrowprops={"arrowstyle":"->", "color":GRAY})
    ax.annotate(tr("t = τ：超出平台的部分剩下约36.8%", "t = τ: 36.8% of the initial excess remains"),
                (3,relaxation(3,*truth)), xytext=(4.4,1.75),
                arrowprops={"arrowstyle":"->", "color":RED}, color=RED)
    ax.text(8,.23,"b = 0.4 kPa",color=GRAY)
    ax.set(xlim=(-.2,12),ylim=(0,3.1),xlabel=tr("时间 / s","Time / s"),
           ylabel=tr("应力 / kPa","Stress / kPa"),
           title=tr("参数把曲线拆成高度、时间尺度和平台", "Parameters separate amplitude, time scale, and plateau"))
    save(fig,"parameters")
    fig, axes = plt.subplots(2,2,figsize=(12.3,8.2),sharex=True,sharey="row",
                             gridspec_kw={"height_ratios":[2.1,1]},layout="constrained")
    for j,(parameters,errors,title) in enumerate([(popt,residual,tr("带平台的指数模型","Exponential with a plateau")),
         (np.r_[pzero,0.],residual_zero,tr("强制平台为零","Plateau fixed to zero"))]):
        axes[0,j].scatter(t,y,s=27,color=INK,label=tr("教学数据","Teaching data"),zorder=3)
        axes[0,j].plot(dense,relaxation(dense,*parameters),color=BLUE if j==0 else RED,lw=2,
                       label=tr("拟合曲线","Fitted curve"))
        axes[0,j].set_title(title,loc="left")
        axes[0,j].legend(frameon=False,fontsize=10)
        axes[0,j].set_ylim(0,3.05)
        axes[1,j].axhline(0,color=GRAY,lw=1)
        axes[1,j].vlines(t,0,errors,color=BLUE if j==0 else RED,lw=1.5)
        axes[1,j].scatter(t,errors,color=BLUE if j==0 else RED,s=20)
        axes[1,j].set(xlabel=tr("时间 / s","Time / s"),ylim=(-.3,.3))
        axes[1,j].text(.96,.94,f"SSE = {errors @ errors:.5f} kPa²",transform=axes[1,j].transAxes,
                        va="top",ha="right",bbox={"fc":"white","ec":"none","alpha":.9},fontsize=10)
    axes[0,0].set_ylabel(tr("应力 / kPa","Stress / kPa"))
    axes[1,0].set_ylabel(tr("观测 − 拟合 / kPa","Observed − fitted / kPa"))
    save(fig,"residuals")
    fig, axes = plt.subplots(1,2,figsize=(12.3,5.7),layout="constrained")
    colors=[RED,GRAY,BLUE]
    for end,color in zip((3,6,12),colors):
        p=profiles[str(end)]
        axes[0].plot(tau_grid,np.asarray(p["curve"])-p["sse_kPa2"],color=color,lw=2,
                     label=f"0–{end} s; n={p['n']}")
        axes[0].scatter([p["tau_s"]],[0],color=color,s=35,zorder=4)
    axes[0].set(xlabel=tr("固定的时间尺度 τ / s","Fixed time scale τ / s"),
        ylabel=tr("相对最小值增加的SSE / kPa²","SSE above its minimum / kPa²"),ylim=(-.015,.6),
        title=tr("观测窗口决定谷底有多清楚","The observation window shapes the valley"))
    axes[0].legend(frameon=False)
    axes[1].scatter(t,y,color=INK,s=25,zorder=4)
    for tau,color in zip((2.,3.,5.),(RED,BLUE,GRAY)):
        _,amplitude,baseline=profile(t[t<=3],y[t<=3],tau)
        axes[1].plot(dense,relaxation(dense,amplitude,tau,baseline),color=color,lw=2,label=f"τ = {tau:g} s")
    axes[1].axvspan(0,3,color="#eaf1f5",zorder=0)
    axes[1].set(xlabel=tr("时间 / s","Time / s"),ylabel=tr("应力 / kPa","Stress / kPa"),
                title=tr("只用前3秒拟合，向后外推","Fit the first 3 seconds, then extrapolate"),ylim=(-.6,3.1))
    axes[1].legend(frameon=False)
    save(fig,"profiles")
    fig,axes=plt.subplot_mosaic([['curves','curves'],['residuals','objective']],
                                figsize=(12.3,9),layout='constrained')
    axes['curves'].scatter(t,y,color=INK,s=24,zorder=5,label=tr('25个教学观测值','25 teaching observations'))
    candidate_sse=[]
    for tau,color in zip((2.,3.,5.),(RED,BLUE,GRAY)):
        loss,amp,base=profile(t,y,tau);candidate_sse.append(loss)
        axes['curves'].plot(dense,relaxation(dense,amp,tau,base),color=color,lw=2,
                            label=f'τ={tau:g} s; A={amp:.3f} kPa; b={base:.3f} kPa')
        axes['residuals'].plot(t,y-relaxation(t,amp,tau,base),'o-',color=color,ms=3,
                               lw=1.3,label=f'τ={tau:g} s')
    axes['curves'].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('应力 / kPa','Stress / kPa'),
                       title=tr('A  函数接口：每个候选τ都生成一条完整曲线','A  Function interface: each candidate τ generates a complete curve'))
    axes['curves'].legend(frameon=False,fontsize=10,ncols=2)
    axes['residuals'].axhline(0,color=INK,lw=1)
    axes['residuals'].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('观测 − 模型 / kPa','Observed − model / kPa'),
                          title=tr('B  数组相减：逐点计算残差','B  Array subtraction: pointwise residuals'))
    axes['residuals'].legend(frameon=False)
    axes['objective'].plot(tau_grid,profiles['12']['curve'],color=INK,lw=1.7)
    axes['objective'].scatter([2,3,5],candidate_sse,c=[RED,BLUE,GRAY],s=55,zorder=5)
    axes['objective'].scatter([popt[1]],[residual@residual],marker='*',color='#d19a24',s=150,zorder=6,
                              label=tr('有边界curve_fit结果','Bounded curve_fit result'))
    axes['objective'].set(xlabel=tr('固定的τ / s','Fixed τ / s'),ylabel='SSE / kPa²',
                          title=tr('C  数值搜索：定位平方和的低处','C  Numerical search: locate a lower sum of squares'))
    axes['objective'].legend(frameon=False,fontsize=10)
    for a in axes.values():a.grid(alpha=.14)
    fig.suptitle(tr('SciPy：数组、模型函数与数值求解在同一问题中相接',
                     'SciPy: arrays, model functions, and numerical solvers meet'),fontsize=16)
    save(fig,"history")
    np.savetxt(output/"relaxation.csv",np.c_[t,y,noise],delimiter=",",comments="",
               header="time_s,stress_kPa,teaching_perturbation_kPa",fmt="%.12g")
    summary={"data_kind":"defined teaching model plus explicit perturbations", "n":len(t),
        "truth":{"amplitude_kPa":2.4,"tau_s":3.,"baseline_kPa":.4},
        "fit":{"amplitude_kPa":float(popt[0]),"tau_s":float(popt[1]),"baseline_kPa":float(popt[2]),
               "sse_kPa2":float(residual@residual),"residual_sd_kPa":float(np.sqrt(residual@residual/(len(t)-3))),
               "local_parameter_std":np.sqrt(np.diag(pcov)).tolist()},
        "zero_baseline":{"amplitude_kPa":float(pzero[0]),"tau_s":float(pzero[1]),
                         "sse_kPa2":float(residual_zero@residual_zero)},
        "profiles":{k:{q:v for q,v in p.items() if q!="curve"} for k,p in profiles.items()},
        "noise_free_max_abs_error":float(np.max(np.abs(clean-truth))),
        "profile_native_tau_difference_s":float(abs(profiles["12"]["tau_s"]-popt[1])),
        "versions":{"numpy":np.__version__,"scipy":scipy.__version__,"matplotlib":matplotlib.__version__}}
    (output/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    (output/"profile-data.json").write_text(json.dumps({"tau_s":tau_grid.tolist(),"profiles":profiles}),encoding="utf-8")


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=Path("output"))
    parser.add_argument("--language",choices=["zh","en"],default="en")
    args=parser.parse_args()
    main(args.output,args.language)
