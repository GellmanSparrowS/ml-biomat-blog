# Public sources and third-party materials

- SciPy: curve_fit: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html
  SciPy BSD-3 documentation; original teaching dataset and explanations
- SciPy: Optimization tutorial: https://docs.scipy.org/doc/scipy/tutorial/optimize.html
  SciPy BSD-3 documentation
- NIST/SEMATECH: Least Squares: https://www.itl.nist.gov/div898/handbook/pmd/section4/pmd431.htm
  Technical reference; no source text or image reproduced
- Virtanen et al. (2020), SciPy 1.0: https://arxiv.org/abs/1907.10121
  CC BY 4.0; facts paraphrased, original diagram
