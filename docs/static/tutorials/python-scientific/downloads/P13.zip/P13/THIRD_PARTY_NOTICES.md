# Public sources and third-party materials

- pandas: How to combine data from multiple tables: https://pandas.pydata.org/docs/getting_started/intro_tutorials/08_combine_dataframes.html
  pandas BSD-3; original case and figures
- pandas: Merge, join, concatenate and compare: https://pandas.pydata.org/docs/user_guide/merging.html
  pandas BSD-3 documentation
- IBM: The relational database: https://www.ibm.com/history/relational-database
  Historical facts paraphrased; no source image or text reproduced
