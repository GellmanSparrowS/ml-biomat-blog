"""Join defined teaching tables and inspect record identity and statistical weight."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyArrowPatch,Rectangle

BLUE,RED,INK,GRAY='#28658c','#b64a35','#202e39','#71808b'


def make_tables():
    measurements=pd.DataFrame({'record':['R01','R02','R03','R04','R05','R06'],
        'sample':['S01','S01','S02','S03','S03','S04'],
        'stress_kPa':[12.,14.,18.,21.,23.,16.]})
    specimens=pd.DataFrame({'sample':['S03','S01','S05','S02'],
                            'formulation':['A','A','B','B']})
    return measurements,specimens


def main(output,language):
    output.mkdir(parents=True,exist_ok=True)
    def tr(a,b):return a if language=='zh' else b
    plt.rcParams.update({'font.family':[name for name in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if name in {f.name for f in font_manager.fontManager.ttflist}],'font.size':11,
        'axes.labelsize':12,'axes.titlesize':13,'axes.titleweight':'bold','axes.spines.top':False,
        'axes.spines.right':False,'text.color':INK,'svg.fonttype':'none','svg.hashsalt':'P13'})
    measurements,specimens=make_tables()
    duplicated=pd.concat([specimens,specimens.loc[specimens['sample'].eq('S03')]],ignore_index=True)
    measurements.to_csv(output/'measurements.csv',index=False)
    specimens.to_csv(output/'specimens.csv',index=False)
    duplicated.to_csv(output/'specimens-duplicate.csv',index=False)
    summary={'data_kind':'explicitly defined teaching tables','cases':{}}
    results={}
    for duplicate,metadata in [(False,specimens),(True,duplicated)]:
        for how in ['inner','left','outer']:
            name=f'{how}-'+('duplicate' if duplicate else 'unique')
            result=measurements.merge(metadata,on='sample',how=how,indicator=True,sort=True)
            result.to_csv(output/f'{name}.csv',index=False)
            counts=result['_merge'].value_counts().to_dict()
            group=result.groupby('formulation')['stress_kPa'].agg(['count','mean'])
            summary['cases'][name]={'rows':len(result),'unique_observations':int(result['record'].nunique()),
                'matched':int(counts.get('both',0)),'left_only':int(counts.get('left_only',0)),
                'right_only':int(counts.get('right_only',0)),
                'A_count':int(group.loc['A','count']),'A_mean_kPa':float(group.loc['A','mean'])}
            results[name]=result
    validated=measurements.merge(specimens,on='sample',how='left',validate='m:1',indicator=True)
    try:
        measurements.merge(duplicated,on='sample',how='left',validate='m:1')
    except pd.errors.MergeError:
        summary['duplicate_contract_rejected']=True
    else:
        raise AssertionError('A duplicated right key must fail m:1 validation')
    extra=pd.DataFrame({'record':['R07','R08'],'sample':['S02','S03'],'stress_kPa':[20.,22.]})
    appended=pd.concat([measurements,extra],ignore_index=True)
    assert appended['record'].is_unique
    appended.to_csv(output/'appended-measurements.csv',index=False)
    summary['appended_rows']=len(appended)
    batch_measurements=pd.DataFrame({'batch':['B01','B02'],'sample':['S01','S01'],
                                      'stress_kPa':[10.,30.]})
    batch_metadata=pd.DataFrame({'batch':['B02','B01'],'sample':['S01','S01'],
                                'formulation':['B','A']})
    composite=batch_measurements.merge(batch_metadata,on=['batch','sample'],validate='m:1')
    ambiguous=batch_measurements.merge(batch_metadata,on='sample')
    composite.to_csv(output/'composite-key.csv',index=False)
    summary['composite_key_rows']=len(composite)
    summary['sample_only_rows']=len(ambiguous)
    assert composite['formulation'].tolist()==['A','B']
    assert len(validated)==6
    assert summary['cases']['left-duplicate']['rows']==8
    assert summary['cases']['left-unique']['A_mean_kPa']==17.5
    assert summary['cases']['left-duplicate']['A_mean_kPa']==19.
    def save(fig,name):
        fig.savefig(output/f'{name}-{language}.svg',metadata={'Date':None})
        fig.savefig(output/f'{name}-{language}.png',dpi=180)
        plt.close(fig)
    fig=plt.figure(figsize=(12,6.5));ax=fig.add_axes([.03,.1,.94,.75]);ax.set_axis_off();ax.set(xlim=(0,1),ylim=(0,1))
    fig.text(.06,.94,tr('记录靠身份对应，不依赖当前行号','Records match by identity, independently of row order'),fontsize=16,weight='bold')
    ax.text(.04,1,tr('测量表：一行一次测量','Measurements: one row per observation'),fontsize=12,weight='bold')
    ax.text(.65,1,tr('样品表：一行一个样品','Metadata: one row per sample'),fontsize=12,weight='bold')
    colors={'S01':BLUE,'S02':'#886a29','S03':RED,'S04':GRAY,'S05':GRAY}
    for i,row in measurements.iterrows():
        y=.86-i*.135
        ax.add_patch(Rectangle((.035,y-.045),.39,.09,fc='#f2f6f8',ec='none'))
        ax.text(.055,y,f"{row['record']}   {row['sample']}   {row['stress_kPa']:.0f} kPa",va='center',fontsize=12,color=colors[row['sample']])
        for j,target in specimens.iterrows():
            if row['sample']==target['sample']:
                ax.add_patch(FancyArrowPatch((.44,y),(.64,.82-j*.20),arrowstyle='->',mutation_scale=11,color=colors[row['sample']],alpha=.65))
    for j,row in specimens.iterrows():
        y=.82-j*.2
        ax.add_patch(Rectangle((.65,y-.055),.30,.11,fc='#f2f6f8',ec='none'))
        ax.text(.67,y,f"{row['sample']}   →   {row['formulation']}",va='center',fontsize=12,color=colors[row['sample']])
    fig.text(.06,.035,tr('关系数据思想：用字段值表达对应关系；物理存放次序可以改变。','Relational idea: field values specify correspondence while storage order can change.'),fontsize=11,color=GRAY)
    save(fig,'identity')
    fig,axes=plt.subplots(1,2,figsize=(12,5.8),layout='constrained',sharey=True)
    for ax,suffix,title in zip(axes,['unique','duplicate'],[tr('样品键唯一','Unique sample keys'),tr('S03在样品表出现两次','S03 appears twice in metadata')]):
        bottom=np.zeros(3)
        for field,color,label in [('matched',BLUE,tr('成功对应','Matched')),('left_only',RED,tr('只有测量','Measurement only')),('right_only',GRAY,tr('只有样品信息','Metadata only'))]:
            values=np.array([summary['cases'][f'{how}-{suffix}'][field] for how in ['inner','left','outer']])
            ax.bar(np.arange(3),values,bottom=bottom,color=color,width=.55,label=label)
            for x,y,b in zip(np.arange(3),values,bottom):
                if y:ax.text(x,b+y/2,str(y),ha='center',va='center',color='white',weight='bold')
            bottom+=values
        ax.set(xticks=np.arange(3),xticklabels=['inner','left','outer'],ylim=(0,11),title=title)
        ax.legend(frameon=False,loc='upper left',fontsize=10)
    axes[0].set_ylabel(tr('合并结果行数','Rows in the merged result'))
    save(fig,'join-counts')
    fig,axes=plt.subplots(1,2,figsize=(12,5.8),gridspec_kw={'width_ratios':[1.3,1]},layout='constrained')
    left=results['left-unique'];dup=results['left-duplicate'];labels=['R01','R02','R04','R05']
    values=np.array([12,14,21,23])
    counts=[int(dup['record'].eq(label).sum()) for label in labels]
    for i,(record,value,count) in enumerate(zip(labels,values,counts)):
        axes[0].scatter([0],[value],s=55,color=BLUE)
        axes[0].scatter([.9+ .14*j for j in range(count)],[value]*count,s=55,color=RED)
        axes[0].annotate(record,(0,value),xytext=(-28,3),textcoords='offset points',ha='right',fontsize=10)
    axes[0].hlines([17.5,19],[-.15,.75],[.15,1.2],colors=[BLUE,RED],lw=3)
    axes[0].set(xticks=[0,1],xticklabels=[tr('键唯一','Unique keys'),tr('S03重复','Duplicate S03')],
                xlim=(-.45,1.35),ylim=(9,25),ylabel=tr('配方A的应力记录 / kPa','Stress records in formulation A / kPa'),
                title=tr('同一条记录被重复计入','The same observation enters twice'))
    axes[1].bar([0,1],[17.5,19],color=[BLUE,RED],width=.55)
    axes[1].set(xticks=[0,1],xticklabels=[tr('4条结果行','4 result rows'),tr('6条结果行','6 result rows')],
                ylim=(0,24),ylabel=tr('按结果行计算的均值 / kPa','Mean across result rows / kPa'),
                title=tr('重复匹配改变了统计权重','Repeated matches change statistical weight'))
    for i,v in enumerate([17.5,19]):axes[1].text(i,v+.6,f'{v:g}',ha='center',fontsize=13)
    save(fig,'weights')
    summary['versions']={'pandas':pd.__version__,'numpy':np.__version__,'matplotlib':matplotlib.__version__}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path('output'))
    parser.add_argument('--language',choices=['zh','en'],default='en')
    args=parser.parse_args();main(args.output,args.language)
