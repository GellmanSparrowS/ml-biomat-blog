"""Show distributions and distinguish specimens from repeated instrument readings."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import scipy
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import MaxNLocator
import seaborn as sns

VALUES={'A':[8,8,9,9,10,10,10,10,11,11,12,12],
        'B':[6,6,7,8,9,10,10,11,12,13,14,14]}
COLORS={'A':'#28658c','B':'#b64a35'}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
    def tr(a,b):return a if zh else b
    sns.set_theme(style='whitegrid',font='DejaVu Sans',font_scale=1.1)
    plt.rcParams.update({'font.family':[name for name in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if name in {f.name for f in font_manager.fontManager.ttflist}],'svg.fonttype':'none',
                        'axes.spines.top':False,'axes.spines.right':False,'grid.alpha':.18})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg');fig.savefig(args.output/f'{name}-{args.language}.png',dpi=160);plt.close(fig)
    readings=pd.DataFrame([{'group':group,'specimen':f'{group}{i+1:02}',
        'repeat':j+1,'modulus_kPa':value+offset} for group,values in VALUES.items()
        for i,value in enumerate(values) for j,offset in enumerate([-.2,0,.2])])
    specimens=readings.groupby(['group','specimen'],as_index=False)['modulus_kPa'].mean()
    readings.to_csv(args.output/'readings.csv',index=False);specimens.to_csv(args.output/'specimens.csv',index=False)
    summary={'versions':{'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,
                         'seaborn':sns.__version__,'matplotlib':matplotlib.__version__},'groups':{}}
    for group in VALUES:
        v=specimens.loc[specimens.group==group,'modulus_kPa'].to_numpy();raw=readings.loc[readings.group==group,'modulus_kPa'].to_numpy()
        n=len(v);mean=float(v.mean());sd=float(v.std(ddof=1));se=float(stats.sem(v));critical=float(stats.t.ppf(.975,n-1))
        summary['groups'][group]={'n_specimens':n,'n_readings':len(raw),'mean_kPa':mean,'sd_kPa':sd,
             'sem_kPa':se,'t_critical':critical,'ci95_kPa':[mean-critical*se,mean+critical*se],
             'naive_reading_sem_kPa':float(stats.sem(raw)),'sum_squared_deviations_kPa2':float(np.sum((v-mean)**2)),
             'quantiles_kPa':np.quantile(v,[.25,.5,.75]).tolist(),
             'count_at_or_below_10':int(np.count_nonzero(v<=10))}
    fig,axes=plt.subplots(1,2,figsize=(12,5.5),layout='constrained')
    sns.barplot(data=specimens,x='group',y='modulus_kPa',hue='group',palette=COLORS,errorbar=None,legend=False,ax=axes[0])
    axes[0].set(title=tr('A  均值相同：两根柱子都是10','A  Same mean: both bars equal 10'),xlabel=tr('组别','Group'),ylabel=tr('平均模量 / kPa','Mean modulus / kPa'),ylim=(0,15))
    sns.swarmplot(data=specimens,x='group',y='modulus_kPa',hue='group',palette=COLORS,legend=False,size=6,ax=axes[1])
    axes[1].axhline(10,color='#71808b',ls='--',lw=1)
    axes[1].set(title=tr('B  保留样品：分布范围不同','B  Keep specimens: different distributions'),xlabel=tr('组别，每组12个样品','Group, 12 specimens each'),ylabel=tr('样品平均模量 / kPa','Specimen-mean modulus / kPa'),ylim=(0,15))
    fig.suptitle(tr('Anscombe 1973：看图能发现数值摘要隐藏的结构','Anscombe 1973: graphs reveal structure beyond summaries'),fontsize=15)
    save(fig,'history')
    fig,axes=plt.subplots(2,2,figsize=(12,9),layout='constrained')
    for ax,width in zip(axes[0],[1,4]):
        sns.histplot(data=specimens,x='modulus_kPa',hue='group',palette=COLORS,
            bins=np.arange(5.5,17.5+width,width),element='step',fill=False,common_bins=True,stat='count',ax=ax)
        ax.set(title=tr(f'箱宽 {width} kPa',f'Bin width {width} kPa'),xlabel=tr('模量 / kPa','Modulus / kPa'),ylabel=tr('样品数','Specimen count'),xlim=(5,18))
        ax.yaxis.set_major_locator(MaxNLocator(integer=True))
        ax.get_legend().set_title(tr('组别','Group'))
    sns.ecdfplot(data=specimens,x='modulus_kPa',hue='group',palette=COLORS,ax=axes[1,0])
    axes[1,0].get_legend().set_title(tr('组别','Group'))
    axes[1,0].set(title=tr('经验累积分布：逐个累计样品','Empirical CDF: accumulate specimens'),xlabel=tr('模量 / kPa','Modulus / kPa'),ylabel=tr('不超过横轴值的比例','Fraction at or below x'),xlim=(5,16))
    sns.boxplot(data=specimens,x='group',y='modulus_kPa',hue='group',palette=COLORS,legend=False,width=.45,showfliers=False,ax=axes[1,1])
    sns.swarmplot(data=specimens,x='group',y='modulus_kPa',color='#20313e',size=4,ax=axes[1,1])
    axes[1,1].set(title=tr('箱线图与全部样品','Box summaries with every specimen'),xlabel=tr('组别','Group'),ylabel=tr('模量 / kPa','Modulus / kPa'))
    save(fig,'distributions')
    fig,axes=plt.subplots(1,2,figsize=(12,6),layout='constrained')
    for j,group in enumerate(VALUES):
        d=summary['groups'][group]
        for i,(label,half) in enumerate([('SD',d['sd_kPa']),('SEM',d['sem_kPa']),('95% t CI',d['ci95_kPa'][1]-10)]):
            axes[0].errorbar(10,i+j*.18,xerr=half,fmt='o',capsize=5,color=COLORS[group],label=group if i==0 else None)
        axes[1].plot([0,1],[d['sem_kPa'],d['naive_reading_sem_kPa']],'o-',color=COLORS[group],lw=2,label=group)
    axes[0].set(yticks=[.09,1.09,2.09],yticklabels=[tr('均值 ± SD','mean ± SD'),tr('均值 ± SEM','mean ± SEM'),'95% t CI'],
        xlabel=tr('模量 / kPa','Modulus / kPa'),title=tr('同一均值，三种区间含义','One mean, three interval meanings'),xlim=(6,14));axes[0].legend(frameon=False)
    axes[1].set(xticks=[0,1],xticklabels=[tr('12个独立样品','12 independent\nspecimens'),tr('36条读数\n直接计算','Treat 36 readings\nas independent')],
        ylabel=tr('计算得到的SEM / kPa','Calculated SEM / kPa'),title=tr('独立单位决定SEM的分母','Independent units determine the SEM denominator'),ylim=(0,1))
    axes[1].tick_params(axis='x',labelsize=11);axes[1].legend(frameon=False)
    save(fig,'intervals')
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))


if __name__=='__main__':main()
