# Public sources and third-party materials

- Seaborn: visualizing distributions: https://seaborn.pydata.org/tutorial/distributions.html
  BSD-3-Clause; seaborn LICENSE.md
- Seaborn: statistical estimation and error bars: https://seaborn.pydata.org/tutorial/error_bars.html
  BSD-3-Clause
- Waskom (2021), seaborn: statistical data visualization: https://joss.theoj.org/papers/10.21105/joss.03021
  CC BY4.0 paper, BSD3 software
- Anscombe (1973), Graphs in Statistical Analysis: https://www.tandfonline.com/doi/abs/10.1080/00031305.1973.10478966
  Historical attribution; no reproduced figures or passages
- SciPy: standard error of the mean: https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.sem.html
  SciPy BSD3
- SciPy: Student t distribution: https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.t.html
  SciPy BSD3
