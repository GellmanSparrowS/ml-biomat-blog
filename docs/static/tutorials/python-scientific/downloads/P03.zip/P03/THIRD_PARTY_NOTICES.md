# Public sources and third-party materials

- Software Carpentry — Lists: https://swcarpentry.github.io/python-novice-gapminder/11-lists.html
  CC BY4.0, https://creativecommons.org/licenses/by/4.0/; original prose, code and figures.
- Python 3.14 — Data Structures: https://docs.python.org/3.14/tutorial/datastructures.html
  PSF documentation license; https://docs.python.org/3.14/license.html
- Python 3.14 — Built-in Types: https://docs.python.org/3.14/library/stdtypes.html#dict
  PSF documentation license
- E. F. Codd — A Relational Model of Data for Large Shared Data Banks (1970): https://research.ibm.com/publications/a-relational-model-of-data-for-large-shared-data-banks
  Historical factual reference to IBM publication record; no reproduced article text or figure.
