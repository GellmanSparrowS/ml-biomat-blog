"""Keep specimen identity attached to values while organizing records."""
from pathlib import Path
import argparse
import json
import math
import copy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, FancyArrowPatch


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,default=Path("output"))
    parser.add_argument("--language",choices=["zh","en"],default="en")
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    zh=args.language=='zh'
    def tr(a,b):return a if zh else b
    # Net specimen masses in grams; constructed teaching records.
    records=[
        {"id":"A01","bath":"water","dry_g":1.2,"wet_g":4.8,"temperature_C":25.0},
        {"id":"A02","bath":"water","dry_g":1.0,"wet_g":3.4,"temperature_C":25.0},
        {"id":"A03","bath":"water","dry_g":0.8,"wet_g":2.8,"temperature_C":25.0},
        {"id":"B01","bath":"saline","dry_g":1.2,"wet_g":3.6,"temperature_C":25.0},
        {"id":"B02","bath":"saline","dry_g":1.0,"wet_g":None,"temperature_C":25.0},
        {"id":"B03","bath":"saline","dry_g":0.8,"wet_g":2.32,"temperature_C":25.0},
    ]
    ids=[record['id'] for record in records]
    if len(set(ids))!=len(ids):raise ValueError("Specimen identifiers must be unique.")
    by_id={record['id']:record for record in records}
    processed=[]
    for record in records:
        if record['dry_g']<=0:raise ValueError("Dry mass must be positive.")
        item=record.copy()
        if record['wet_g'] is None:
            item['uptake_g_per_g']=None
        else:
            if record['wet_g']<record['dry_g']:raise ValueError("Check uptake mass accounting.")
            item['uptake_g_per_g']=(record['wet_g']-record['dry_g'])/record['dry_g']
        processed.append(item)
    groups={}
    for bath in ['water','saline']:
        all_rows=[r for r in processed if r['bath']==bath]
        values=[r['uptake_g_per_g'] for r in all_rows if r['uptake_g_per_g'] is not None]
        groups[bath]={'record_count':len(all_rows),'valid_count':len(values),'mean_uptake':math.fsum(values)/len(values) if values else None}
    ordered=sorted(records,key=lambda row:row['dry_g'])
    ordered_lookup={record['id']:record for record in ordered}
    assert ordered_lookup['A01']==by_id['A01']
    # Assignment shares an object; deepcopy provides independent nested records.
    alias=records
    independent=copy.deepcopy(records)
    independent[0]['dry_g']=9.0
    assert records[0]['dry_g']==1.2 and alias is records

    fonts={f.name for f in font_manager.fontManager.ttflist}
    family=next((f for f in ['Noto Sans CJK SC','Microsoft YaHei','DejaVu Sans'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[family,'DejaVu Sans'] if zh else ['DejaVu Sans'],'font.size':12,'axes.titlesize':15,'axes.titleweight':'bold','svg.fonttype':'none','figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','text.color':'#172b36','axes.labelcolor':'#172b36','axes.spines.top':False,'axes.spines.right':False})
    ink,blue,red,green='#172b36','#28648a','#b85336','#467a62'
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg',bbox_inches='tight')
        fig.savefig(args.output/f'{name}-{args.language}.png',dpi=180,bbox_inches='tight');plt.close(fig)

    fig=plt.figure(figsize=(12,7),layout='constrained');ax=fig.add_subplot();ax.axis('off');ax.set_xlim(0,12);ax.set_ylim(0,7)
    ax.text(.1,6.6,tr('a  列表保留记录顺序，字典保留字段名称','a  A list orders records; dictionaries name their fields'),fontsize=17,weight='bold')
    cols=[.2,1.4,3.3,5.1,7.1,9.3]; widths=[1,1.7,1.6,1.7,1.9,2.4]
    headers=[tr('位置','Position'),'id','bath','dry_g','wet_g','temperature_C']
    for x,label in zip(cols,headers):ax.text(x,5.95,label,fontsize=13,weight='bold')
    for i,r in enumerate(records):
        y=5.05-i*.62
        vals=[str(i),r['id'],r['bath'],f"{r['dry_g']:.2f}",'None' if r['wet_g'] is None else f"{r['wet_g']:.2f}",f"{r['temperature_C']:.1f}"]
        for j,(x,w,val) in enumerate(zip(cols,widths,vals)):
            ax.add_patch(Rectangle((x-.05,y-.13),w,.5,facecolor=red if i==1 else blue,alpha=.13 if i==1 else .045,edgecolor='#cad2d0',lw=.6))
            ax.text(x+.05,y+.03,val,fontsize=13,color=red if val=='None' else ink)
    ax.text(.2,.85,'records[1]["wet_g"] → 3.40 g',fontsize=19,color=red)
    ax.text(6.0,.85,'by_id["A02"]["wet_g"] → 3.40 g',fontsize=17,color=blue)
    ax.text(.2,.2,tr('None表示缺少该次称量；0.00表示称量值为零。两者参与计算的规则不同。','None marks an absent weighing; 0.00 is a numerical reading. They require different calculations.'),fontsize=12)
    save(fig,'record-anatomy')

    fig=plt.figure(figsize=(12,8),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1.1,1.2])
    for panel,wrong in enumerate([False,True]):
        ax=fig.add_subplot(gs[0,panel]);ax.axis('off');ax.set_xlim(0,1);ax.set_ylim(0,1)
        ax.set_title(tr('a  排序整条记录：身份保持','a  Sort whole records: preserve identity') if not wrong else tr('b  单独排序一列：配对改变','b  Sort one column alone: change pairing'),loc='left')
        order=[2,1,0] if not wrong else [0,1,2]
        left=['A01 | 1.20 g','A02 | 1.00 g','A03 | 0.80 g']; right=['A03 | 2.80 g','A02 | 3.40 g','A01 | 4.80 g']
        for i in range(3):
            y=.78-i*.28;ax.text(.02,y,left[i],fontsize=13);ax.text(.67,y,right[i],fontsize=13)
            dest=2-i if not wrong else i
            ax.add_patch(FancyArrowPatch((.36,y+.02),(.65,.78-dest*.28+.02),arrowstyle='->',mutation_scale=16,color=[blue,green,red][i],lw=1.7))
        ax.text(.02,.96,tr('干质量及身份','Dry mass + identity'),fontsize=11);ax.text(.67,.96,tr('湿质量及身份','Wet mass + identity'),fontsize=11)
    ax=fig.add_subplot(gs[1,0]);correct=[3,2.4,2.5];wrong=[(2.8-1.2)/1.2,(3.4-1)/1,(4.8-.8)/.8]
    for i,(c,w) in enumerate(zip(correct,wrong)):
        ax.plot([c,w],[i,i],color='#acb8b8',lw=2);ax.scatter([c],[i],color=blue,s=80,zorder=3);ax.scatter([w],[i],color=red,s=70,marker='x',zorder=3)
    ax.set(yticks=[0,1,2],yticklabels=['A01','A02','A03'],xlabel=tr('按干质量归一化的吸液量 / g·g⁻¹','Dry-basis liquid uptake / g·g⁻¹'),title=tr('c  相同数字，错误关联改变结果','c  The same numbers give different results'))
    ax.grid(axis='x',alpha=.15);ax.scatter([],[],color=blue,s=60,label=tr('正确配对','Correct pairing'));ax.scatter([],[],color=red,s=60,marker='x',label=tr('错配','Mismatched'));ax.legend(frameon=False)
    ax=fig.add_subplot(gs[1,1]);ax.axis('off');ax.set_title(tr('d  从存储位置转向数据含义','d  Separate position from meaning'),loc='left')
    ax.text(.02,.78,'E. F. Codd · 1970',fontsize=20,color=ink,transform=ax.transAxes)
    ax.text(.02,.54,tr('关系数据模型关注：\n改变存储安排时，数据关系保持清楚。','Relational data modeling asks how\nmeaning can survive changes\nin storage arrangement.'),fontsize=15,transform=ax.transAxes)
    ax.text(.02,.15,tr('本例中的做法：\n把样品ID、条件与测量值放在同一记录中。','In this example:\nkeep specimen ID, conditions,\nand measurements in one record.'),fontsize=14,transform=ax.transAxes)
    save(fig,'identity-history')

    fig=plt.figure(figsize=(12,6),layout='constrained');gs=fig.add_gridspec(1,2,width_ratios=[1.4,1])
    ax=fig.add_subplot(gs[0]);
    for i,r in enumerate(processed):
        color=blue if r['bath']=='water' else red;q=r['uptake_g_per_g']
        if q is None:ax.text(.08,i,tr('未称量','Not weighed'),va='center',color='#6b7779',fontsize=12)
        else:ax.hlines(i,0,q,color=color,alpha=.4,lw=2);ax.scatter([q],[i],s=80,color=color);ax.text(q+.08,i,f'{q:.2f}',va='center',fontsize=12)
    ax.set(yticks=range(6),yticklabels=ids,xlim=(0,3.7),xlabel=tr('吸液量 / g·g⁻¹','Liquid uptake / g·g⁻¹'),title=tr('a  每个点保留样品身份','a  Keep each specimen visible'));ax.set_ylim(-.5,len(processed)-.5);ax.invert_yaxis();ax.grid(axis='x',alpha=.15)
    ax=fig.add_subplot(gs[1]);
    for i,bath in enumerate(['water','saline']):
        vals=[r['uptake_g_per_g'] for r in processed if r['bath']==bath and r['uptake_g_per_g'] is not None];col=blue if i==0 else red
        ax.scatter([i+(.1*(j-(len(vals)-1)/2)) for j in range(len(vals))],vals,color=col,s=70,alpha=.8)
        avg=groups[bath]['mean_uptake'];ax.text(i,3.3,tr(f"有效 {len(vals)} / 3",f"{len(vals)} of 3 valid"),ha='center',fontsize=14)
        if avg is not None:
            ax.hlines(avg,i-.25,i+.25,color=ink,lw=3)
            label=tr(f'均值 {avg:.4f}',f'Mean {avg:.4f}')
        else:
            label=tr('无有效称量','No valid weighing')
        ax.text(i,.4,label,ha='center',fontsize=13,color=col)
    ax.set(xticks=[0,1],xticklabels=[tr('水浴','Water'),tr('盐水浴','Saline')],ylabel=tr('吸液量 / g·g⁻¹','Liquid uptake / g·g⁻¹'),ylim=(0,3.6),xlim=(-.55,1.55),title=tr('b  汇总同时说明有效计数','b  Summaries retain valid counts'));ax.grid(axis='y',alpha=.15)
    save(fig,'specimen-results')
    summary={'dataset':'Constructed six-record liquid-uptake example','record_count':len(records),'valid_count':sum(r['uptake_g_per_g'] is not None for r in processed),'missing_ids':[r['id'] for r in processed if r['uptake_g_per_g'] is None],'groups':groups,'uptake_by_id':{r['id']:r['uptake_g_per_g'] for r in processed},'lookup_A01_after_sort':ordered_lookup['A01'],'independent_copy_original_dry_g':records[0]['dry_g'],'wrong_pairing_A_uptake':wrong}
    for name,data in [('records.json',records),('processed.json',processed),('summary.json',summary)]:
        (args.output/name).write_text(json.dumps(data,indent=2),encoding='utf8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
