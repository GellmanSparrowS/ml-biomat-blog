# Public sources and third-party materials

- NumPy: numpy.linalg.lstsq: https://numpy.org/doc/2.4/reference/generated/numpy.linalg.lstsq.html
  BSD-3-Clause documentation; original example here
- NumPy: numpy.matmul: https://numpy.org/doc/2.4/reference/generated/numpy.matmul.html
  BSD-3-Clause documentation
- NumPy: numpy.linalg.norm: https://numpy.org/doc/2.4/reference/generated/numpy.linalg.norm.html
  BSD-3-Clause documentation
- PEP 465: matrix multiplication operator: https://peps.python.org/pep-0465/
  Public domain PEP; factual reference
- Legendre, Nouvelles méthodes, 1805: https://doi.org/10.3931/e-rara-35115
  Public Domain Mark, ETH Library; no scans reproduced
