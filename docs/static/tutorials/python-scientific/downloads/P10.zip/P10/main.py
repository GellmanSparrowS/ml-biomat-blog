"""Calibrate a constructed microscope scale and rotate planar coordinates."""
from pathlib import Path
import argparse
import json
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Polygon

LENGTH = np.array([0, 2, 4, 6, 8, 10], dtype=float)  # mm
PIXEL = np.array([1, 42, 80, 120, 162, 201], dtype=float)  # px
OUTLINE = np.array([[0, 0], [200, 0], [200, 80], [0, 80]], dtype=float)
BLUE, RED, GREEN = '#246989', '#b95235', '#42816b'


def rotation(degrees):
    theta = np.deg2rad(degrees)
    return np.array([[np.cos(theta), -np.sin(theta)],
                     [np.sin(theta), np.cos(theta)]])


def scalar_fit(x, y):
    """Independent centered-sum line fit, used as an arithmetic check."""
    xbar = math.fsum(map(float, x)) / len(x)
    ybar = math.fsum(map(float, y)) / len(y)
    numerator = math.fsum((float(u)-xbar)*(float(v)-ybar) for u, v in zip(x, y))
    denominator = math.fsum((float(u)-xbar)**2 for u in x)
    slope = numerator / denominator
    return slope, ybar - slope*xbar


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path('output'))
    parser.add_argument('--language', choices=['zh', 'en'], default='en')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    design = np.column_stack([LENGTH, np.ones_like(LENGTH)])
    coefficients, returned_sse, rank, singular = np.linalg.lstsq(design, PIXEL, rcond=None)
    slope, intercept = coefficients
    predicted = design @ coefficients
    residual = PIXEL - predicted
    sse = float(residual @ residual)
    R = rotation(30)
    physical = OUTLINE / slope  # displacement from a chosen image origin, in mm
    rotated = physical @ R.T
    radii = np.linalg.norm(physical, axis=1)
    rotated_radii = np.linalg.norm(rotated, axis=1)
    point90 = rotation(90) @ np.array([2., 1.])
    constrained_slope = float(LENGTH @ PIXEL / (LENGTH @ LENGTH))
    constrained_residual = PIXEL - constrained_slope * LENGTH
    assert np.allclose(coefficients, [20, 1])
    assert np.allclose(coefficients, scalar_fit(LENGTH, PIXEL))
    assert np.allclose(residual, [0, 1, -1, -1, 1, 0]) and np.isclose(sse, 4)
    assert np.allclose(point90, [-1, 2])
    assert np.allclose(R.T @ R, np.eye(2))
    assert np.allclose(radii, rotated_radii)
    assert np.allclose(rotated, [[u*math.cos(math.pi/6)-v*math.sin(math.pi/6),
                                 u*math.sin(math.pi/6)+v*math.cos(math.pi/6)] for u, v in physical])
    zh = args.language == 'zh'
    tr = lambda z, e: z if zh else e
    fonts = {f.name for f in font_manager.fontManager.ttflist}
    family = [f for f in ['Noto Sans CJK SC', 'Noto Sans SC', 'Microsoft YaHei', 'DejaVu Sans'] if f in fonts]
    plt.rcParams.update({'font.family': family if zh else ['DejaVu Sans', 'Arial'],
                         'font.size': 12, 'axes.titlesize': 14, 'axes.titleweight': 'bold',
                         'axes.spines.top': False, 'axes.spines.right': False, 'svg.fonttype': 'none',
                         'figure.facecolor': '#fbfaf6', 'axes.facecolor': '#fbfaf6', 'text.color': '#172b36'})
    def save(fig, name):
        fig.savefig(args.output / f'{name}-{args.language}.svg', bbox_inches='tight')
        fig.savefig(args.output / f'{name}-{args.language}.png', dpi=170, bbox_inches='tight')
        plt.close(fig)

    fig = plt.figure(figsize=(12.4, 7.7), layout='constrained')
    gs = fig.add_gridspec(2, 2, width_ratios=[1.2, 1])
    ax = fig.add_subplot(gs[:, 0])
    for points, color, label in [(physical, BLUE, tr('标定后','Calibrated')), (rotated, RED, tr('逆时针30°','30° counterclockwise'))]:
        ax.add_patch(Polygon(points, facecolor=color, edgecolor=color, alpha=.15, lw=2))
        closed = np.vstack([points, points[0]])
        ax.plot(closed[:, 0], closed[:, 1], 'o-', color=color, lw=2, label=label)
    for i, (x, y) in enumerate(rotated):
        ax.annotate(str(i), (x, y), xytext=(6, 7), textcoords='offset points', color=RED, weight='bold')
    ax.axhline(0, color='#83949a', lw=.8); ax.axvline(0, color='#83949a', lw=.8)
    ax.set(xlim=(-4, 12), ylim=(-3, 11), aspect='equal', xlabel='x / mm', ylabel='y / mm', title=tr('a  长度不变，坐标改变','a  Coordinates change; lengths do not'))
    ax.legend(loc='upper left', fontsize=11); ax.grid(alpha=.15)
    ax = fig.add_subplot(gs[0, 1])
    basis = rotation(30)
    for v, color, label in [(np.array([1, 0]), BLUE, '(1, 0)'), (np.array([0, 1]), BLUE, '(0, 1)'), (basis[:, 0], RED, '(0.866, 0.500)'), (basis[:, 1], GREEN, '(-0.500, 0.866)')]:
        ax.annotate('', xy=v, xytext=(0, 0), arrowprops={'arrowstyle': '-|>', 'color': color, 'lw': 2})
        ax.text(v[0]*1.08, v[1]*1.08, label, color=color, fontsize=10, ha='center')
    ax.set(xlim=(-.8, 1.45), ylim=(-.2, 1.35), aspect='equal', title=tr('b  矩阵的两列：单位方向转到哪里','b  Matrix columns: rotated unit directions'))
    ax.set_xlabel(tr('无量纲方向分量','Dimensionless direction components')); ax.grid(alpha=.15)
    ax = fig.add_subplot(gs[1, 1])
    pos = np.arange(4)
    ax.bar(pos-.17, radii, .34, color=BLUE, label=tr('旋转前','Before'))
    ax.bar(pos+.17, rotated_radii, .34, color=RED, alpha=.75, label=tr('旋转后','After'))
    ax.set(xticks=pos, xlabel=tr('顶点编号','Vertex index'), ylabel=tr('到原点距离 / mm','Distance to origin / mm'), title=tr('c  按行计算向量长度','c  Vector norms computed row by row'))
    ax.legend(); ax.grid(axis='y', alpha=.15)
    save(fig, 'coordinate-rotation')

    fig = plt.figure(figsize=(12.4, 8), layout='constrained')
    gs = fig.add_gridspec(2, 2, height_ratios=[1.5, 1], width_ratios=[1.5, 1])
    ax = fig.add_subplot(gs[0, 0])
    xx = np.linspace(0, 10, 101)
    ax.plot(xx, slope*xx+intercept, color=BLUE, lw=2, label='p = 20s + 1')
    ax.scatter(LENGTH, PIXEL, color=RED, s=65, zorder=3, label=tr('构造的标定记录','Constructed calibration records'))
    ax.set(xlabel=tr('已知长度 s / mm','Known length s / mm'), ylabel='p / px', title=tr('a  像素读数：六条记录确定比例与零点','a  Six records determine scale and offset'))
    ax.legend(); ax.grid(alpha=.15)
    ax = fig.add_subplot(gs[1, 0])
    ax.axhline(0, color='#83949a', lw=1)
    ax.vlines(LENGTH, 0, residual, color=BLUE, lw=3); ax.scatter(LENGTH, residual, color=BLUE, s=55)
    ax.set(xlabel=tr('已知长度 / mm','Known length / mm'), ylabel=tr('观测 − 拟合 / px','Observed − fitted / px'), ylim=(-1.7, 1.7), yticks=[-1,0,1], title=tr('b  残差放大后，1 px清楚可见','b  Residual view reveals 1 px differences'))
    ax.grid(alpha=.15)
    ax = fig.add_subplot(gs[:, 1]); ax.axis('off')
    table = ax.table(cellText=[[f'{s:.0f}', '1', f'{p:.0f}', str(round(float(r)))] for s,p,r in zip(LENGTH,PIXEL,residual)],
                     colLabels=['s / mm', '1', 'p / px', 'r / px'], loc='center', cellLoc='center', bbox=[.02,.22,.96,.60])
    table.auto_set_font_size(False); table.set_fontsize(13)
    for (i,j), cell in table.get_celld().items():
        cell.set_edgecolor('#d3dcdb'); cell.set_facecolor('#e6efee' if i==0 else '#fbfaf6')
    ax.text(.02,.94,tr('c  设计矩阵的每一行都对应一条记录','c  One design-matrix row per record'),fontsize=14,weight='bold')
    ax.text(.02,.10,tr('a = 20 px/mm；b = 1 px\n残差平方和 = 4 px²；rank = 2','a = 20 px/mm; b = 1 px\nSquared residual sum = 4 px²; rank = 2'),fontsize=14,linespacing=1.7)
    save(fig, 'calibration-residuals')

    fig = plt.figure(figsize=(12.4, 7.5), layout='constrained')
    gs = fig.add_gridspec(2, 2, height_ratios=[.2, 1], width_ratios=[1.2, 1])
    ax = fig.add_subplot(gs[0, :]); ax.axis('off')
    ax.text(0,.75,tr('1805：把互不完全吻合的观测，变成一个共同的求解问题','1805: reconciling observations through one shared objective'),fontsize=18,weight='bold')
    ax.text(0,.05,tr('勒让德的最小二乘思想，用本章构造的显微标定记录展示。','Legendre’s least-squares principle, illustrated with this chapter’s constructed calibration records.'),fontsize=12)
    ax = fig.add_subplot(gs[1, 0])
    aa, bb = np.meshgrid(np.linspace(19,21,301), np.linspace(-4,6,301))
    costs = np.sum((PIXEL[:,None,None] - aa[None]*LENGTH[:,None,None]-bb[None])**2, axis=0)
    contours = ax.contour(aa, bb, costs, levels=[5,10,20,40,80,160,320], cmap='viridis', linewidths=1.5)
    ax.clabel(contours, inline=True, fontsize=10, fmt='%g')
    ax.axhline(0, color=RED, linestyle=':', linewidth=1.2, alpha=.6)
    ax.scatter([slope,constrained_slope],[intercept,0],color=[BLUE,RED],s=[80,65],zorder=4)
    ax.annotate(tr('自由零点：(20, 1)','Free offset: (20, 1)'),(20,1),xytext=(19.05,4.5),arrowprops={'arrowstyle':'->','color':BLUE},color=BLUE)
    ax.annotate(tr('强制 b = 0','Force b = 0'),(constrained_slope,0),xytext=(20.25,-3),arrowprops={'arrowstyle':'->','color':RED},color=RED)
    ax.set(xlabel=tr('斜率 a / (px/mm)','Slope a / (px/mm)'), ylabel=tr('截距 b / px','Intercept b / px'), title=tr('a  等高线数字：残差平方和 / px²','a  Contour labels: squared residual sum / px²'))
    ax = fig.add_subplot(gs[1, 1])
    ax.plot(LENGTH,residual,'o-',color=BLUE,label=tr('自由零点','Free offset'))
    ax.plot(LENGTH,constrained_residual,'s--',color=RED,label=tr('强制零点','Forced zero'))
    ax.axhline(0,color='#83949a',lw=1)
    ax.set(xlabel=tr('已知长度 / mm','Known length / mm'),ylabel=tr('残差 / px','Residual / px'),ylim=(-1.8,1.8),title=tr('b  改变模型，残差也随之改变','b  Changing the model changes the residuals'))
    ax.legend();ax.grid(alpha=.15)
    save(fig,'least-squares-history')
    summary = {'dataset':'Constructed microscope calibration', 'length_mm':LENGTH.tolist(),'pixel_px':PIXEL.tolist(),
               'slope_px_per_mm':float(slope),'intercept_px':float(intercept),'residual_px':residual.tolist(),'sse_px2':sse,
               'rank':int(rank),'singular_values':singular.tolist(),'returned_sse_px2':returned_sse.tolist(),
               'rotation_30':R.tolist(),'physical_vertices_mm':physical.tolist(),'rotated_vertices_mm':rotated.tolist(),
               'radii_before_mm':radii.tolist(),'radii_after_mm':rotated_radii.tolist(),'point_90_mm':point90.tolist(),
               'constrained_slope_px_per_mm':constrained_slope,'constrained_sse_px2':float(constrained_residual@constrained_residual)}
    (args.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
