# Public sources and third-party materials

- MDAnalysis: trajectories: https://userguide.mdanalysis.org/stable/trajectories/trajectories.html
  MDAnalysis User Guide repository: LGPL-2.1; methodological reference.
- MDAnalysis: RMSF tutorial: https://userguide.mdanalysis.org/stable/examples/analysis/alignment_and_rms/rmsf.html
  MDAnalysis User Guide repository: LGPL-2.1; methodological reference.
- MDAnalysis 2.11: RMS quantities: https://docs.mdanalysis.org/stable/documentation_pages/analysis/rms.html
  MDAnalysis package LGPL-3.0-or-later; component terms retained.
- MDAnalysis 2.11: alignment: https://docs.mdanalysis.org/stable/documentation_pages/analysis/align.html
  MDAnalysis package LGPL-3.0-or-later; API reference.
- MDAnalysis 2.11: atom groups: https://docs.mdanalysis.org/stable/documentation_pages/core/groups.html
  MDAnalysis package LGPL-3.0-or-later; API reference.
- McCammon, Gelin & Karplus (1977), Dynamics of folded proteins: https://doi.org/10.1038/267585a0
  Primary scientific reference; publisher copyright.
- PDB 1UBQ: ubiquitin: https://www.rcsb.org/structure/1UBQ
  PDB archive data: CC0 1.0; https://www.rcsb.org/pages/policies
- Vijay-Kumar, Bugg & Cook (1987), Structure of ubiquitin refined at 1.8 Å resolution: https://doi.org/10.1016/0022-2836(87)90679-6
  Primary scientific reference; publisher copyright.
- GROMACS introductory tutorial: https://tutorials.gromacs.org/docs/md-intro-tutorial.html
  Public tutorial; consult its stated terms for reuse.
- MDAnalysis licensing: https://github.com/MDAnalysis/mdanalysis/blob/develop/LICENSE
  LGPL-3.0-or-later package; component licenses as listed.
