"""Read a real ubiquitin trajectory; separate rigid-body motion and fluctuations."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import shutil
import numpy as np
import MDAnalysis as mda
from MDAnalysis.analysis import align, rms
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.collections import LineCollection

BLUE, ORANGE, GREEN = '#176480', '#bd5b28', '#2e8071'
MODES = ('raw', 'centered', 'fitted')
WINDOWS = {'all': (0, 1000), 'early': (0, 200), 'late': (800, 1000)}


def available_plot_fonts():
    choices = ['Noto Sans CJK SC', 'Noto Sans SC', 'Microsoft YaHei',
               'SimHei', 'DejaVu Sans']
    installed = {f.name for f in font_manager.fontManager.ttflist}
    return [x for x in choices if x in installed]


def rigid_fit_svd(mobile, reference):
    """Independent equal-weight proper rotation, using row-vector coordinates."""
    x = mobile - mobile.mean(axis=0)
    y = reference - reference.mean(axis=0)
    left, _, right = np.linalg.svd(x.T @ y)
    correction = np.eye(3)
    correction[-1, -1] = np.linalg.det(left @ right)
    fitted = x @ (left @ correction @ right) + reference.mean(axis=0)
    return fitted


def analyze(output):
    source = Path(__file__).resolve().parent / 'data'
    # XTC readers save an offset index next to the trajectory. Keep it in output.
    cache = output / 'trajectory-cache'
    cache.mkdir(exist_ok=True)
    trajectory = cache / 'ubiquitin-5ps.xtc'
    shutil.copyfile(source / trajectory.name, trajectory)
    u = mda.Universe(str(source / 'reference.tpr'), str(trajectory))
    protein = u.select_atoms('protein')
    ca = u.select_atoms('protein and name CA')
    assert len(u.atoms) == 18869 and len(protein) == 1231 and len(ca) == 76
    assert np.array_equal(ca.resids, np.arange(1, 77))
    times, coordinates, rg, rg_direct = [], [], [], []
    masses = protein.masses.astype(float)
    for ts in u.trajectory:
        times.append(float(ts.time))
        coordinates.append(ca.positions.astype(float).copy() / 10)
        rg.append(float(protein.radius_of_gyration()) / 10)
        xyz = protein.positions.astype(float) / 10
        com = np.average(xyz, axis=0, weights=masses)
        rg_direct.append(float(np.sqrt(np.average(
            np.sum((xyz - com) ** 2, axis=1), weights=masses))))
    times = np.asarray(times)
    raw = np.asarray(coordinates)
    assert np.allclose(times, np.arange(201) * 5, atol=1e-6)
    reference = raw[0]
    centered = raw - raw.mean(axis=1, keepdims=True) + reference.mean(axis=0)
    # A small in-memory Universe has the same 76 atom identities and 201 frames.
    mobile = mda.Merge(ca)
    mobile.load_new((raw * 10).astype(np.float32), order='fac', dt=5)
    ref = mda.Merge(ca)
    ref.atoms.positions = reference * 10
    align.AlignTraj(mobile, ref, select='all', weights=None,
                    in_memory=True).run()
    fitted = np.array([mobile.atoms.positions.copy().astype(float) / 10
                       for _ in mobile.trajectory])
    xyz_by_mode = {'raw': raw, 'centered': centered, 'fitted': fitted}
    rmsd = {key: np.sqrt(np.mean(np.sum((a-reference)**2, axis=2), axis=1))
            for key, a in xyz_by_mode.items()}
    qcp = np.array([rms.rmsd(x, reference, center=True, superposition=True)
                    for x in raw])
    independent = np.array([rigid_fit_svd(x, reference) for x in raw])
    svd_rmsd = np.sqrt(np.mean(np.sum((independent-reference)**2, axis=2), axis=1))
    # The exact identity frame can give a tiny QCP roundoff, so compare at 1e-6 nm.
    assert np.max(np.abs(qcp-svd_rmsd)) < 1e-6
    assert np.max(np.abs(rmsd['fitted']-svd_rmsd)) < 1e-6
    assert np.max(np.abs(np.array(rg)-rg_direct)) < 1e-12
    windows, rmsf_error = {}, []
    for key, (start, end) in WINDOWS.items():
        indices = np.flatnonzero((times >= start) & (times <= end))
        record = {'start_ps': start, 'end_ps': end, 'frames': len(indices),
                  'rmsf_nm': {}, 'mean_nm': {}, 'rg_mean_nm': float(np.mean(np.array(rg)[indices]))}
        for mode, xyz in xyz_by_mode.items():
            mem = mda.Merge(ca)
            mem.load_new((xyz*10).astype(np.float32), order='fac', dt=5)
            result = rms.RMSF(mem.atoms).run(start=int(indices[0]), stop=int(indices[-1])+1)
            fluct = result.results.rmsf / 10
            direct = np.sqrt(np.mean(np.sum((xyz[indices]-xyz[indices].mean(axis=0))**2,
                                           axis=2), axis=0))
            rmsf_error.append(float(np.max(np.abs(fluct-direct))))
            record['rmsf_nm'][mode] = fluct.tolist()
            record['mean_nm'][mode] = xyz[indices].mean(axis=0).tolist()
        windows[key] = record
    assert max(rmsf_error) < 1e-6
    summary = {
        'frames': len(times), 'atoms': len(u.atoms), 'protein_atoms': len(protein),
        'CA_atoms': len(ca), 'sampling_ps': 5, 'duration_ps': float(times[-1]-times[0]),
        'protein_mass_u': float(masses.sum()),
        'rg_mean_nm': float(np.mean(rg)), 'rg_first_nm': rg[0],
        'rmsd_last_nm': {key: float(v[-1]) for key,v in rmsd.items()},
        'rmsd_mean_nm': {key: float(np.mean(v)) for key,v in rmsd.items()},
        'rmsf_76_nm': {key: value['rmsf_nm']['fitted'][75] for key,value in windows.items()},
        'rmsf_peak_residue': int(np.argmax(windows['all']['rmsf_nm']['fitted'])+1),
        'checks': {'QCP_SVD_max_nm': float(np.max(np.abs(qcp-svd_rmsd))),
                   'AlignTraj_SVD_max_nm': float(np.max(np.abs(rmsd['fitted']-svd_rmsd))),
                   'Rg_max_nm': float(np.max(np.abs(np.array(rg)-rg_direct))),
                   'RMSF_max_nm': max(rmsf_error)},
        'versions': {'MDAnalysis': mda.__version__, 'numpy': np.__version__,
                     'matplotlib': matplotlib.__version__},
        'input_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in (source/'reference.tpr', source/'ubiquitin-5ps.xtc')}
    }
    lab = {'times_ps': times.tolist(), 'resids': ca.resids.tolist(),
           'resnames': ca.resnames.tolist(), 'xyz_nm': {k:v.tolist() for k,v in xyz_by_mode.items()},
           'rmsd_nm': {k:v.tolist() for k,v in rmsd.items()}, 'rg_nm': rg,
           'windows': windows, 'reference_nm': reference.tolist()}
    for name, obj in [('summary',summary),('lab-data',lab)]:
        (output/f'{name}.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    with (output/'timeseries.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['time_ps','RMSD_raw_nm','RMSD_centered_nm','RMSD_fitted_nm','Rg_nm'])
        w.writerows(zip(times,*[rmsd[k] for k in MODES],rg))
    with (output/'rmsf.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['window','mode','resid','resname','RMSF_nm'])
        for window, record in windows.items():
            for mode in MODES:
                w.writerows((window,mode,int(i),str(n),float(v)) for i,n,v in
                            zip(ca.resids,ca.resnames,record['rmsf_nm'][mode]))
    return lab, summary


def plot_figures(d, summary, output, language):
    zh = language == 'zh'
    def t(a,b): return a if zh else b
    plt.rcParams.update({'font.family':available_plot_fonts() if zh else ['DejaVu Sans'],
        'font.size':13,'axes.titlesize':16,'axes.labelsize':13,'xtick.labelsize':12,
        'ytick.labelsize':12,'axes.spines.top':False,'axes.spines.right':False,
        'svg.fonttype':'none','figure.facecolor':'#fffefb','axes.facecolor':'#fffefb'})
    time=np.array(d['times_ps']); ref=np.array(d['reference_nm']); ref-=ref.mean(axis=0)
    raw=np.array(d['xyz_nm']['raw']); fit=np.array(d['xyz_nm']['fitted'])
    labels=[t('未配准','Unfitted'),t('去平移','Translation removed'),t('去平移与旋转','Rigid-body fitted')]
    colors=[ORANGE,'#887494',BLUE]
    def save(fig,name):
        fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight')
        fig.savefig(output/f'{name}-{language}.png',dpi=150,bbox_inches='tight'); plt.close(fig)
    def clean(ax): ax.grid(alpha=.16); ax.set_axisbelow(True)
    fig=plt.figure(figsize=(14,8.5),layout='constrained')
    grid=fig.add_gridspec(2,2,height_ratios=[1.3,1])
    a=fig.add_subplot(grid[0,:]); b=fig.add_subplot(grid[1,0]); c=fig.add_subplot(grid[1,1])
    for mode,label,color in zip(MODES,labels,colors): a.plot(time,d['rmsd_nm'][mode],color=color,lw=1.8,label=label)
    a.set(xlabel=t('时间 / ps','Time / ps'),ylabel=t('Cα RMSD / nm','Cα RMSD / nm'),
          title=t('A  同一个第一帧参考，三种坐标处理','A  One first-frame reference, three coordinate treatments'))
    a.legend(loc='upper left',ncol=3,fontsize=12); a.set_ylim(bottom=0); clean(a)
    b.plot(time,d['rg_nm'],color=GREEN,lw=1.5); b.set(xlabel=t('时间 / ps','Time / ps'),ylabel='Rg / nm',
          title=t('B  1231个蛋白质原子的质量分布','B  Mass distribution of 1231 protein atoms')); clean(b)
    c.plot(ref[:,0],ref[:,2],color='#a6acaf',lw=2,label=t('第一帧','First frame'))
    for arr,color,label in [(raw[-1]-np.array(d['reference_nm']).mean(axis=0),ORANGE,t('1000 ps：未配准','1000 ps: unfitted')),
                             (fit[-1]-np.array(d['reference_nm']).mean(axis=0),BLUE,t('1000 ps：配准后','1000 ps: fitted'))]:
        c.plot(arr[:,0],arr[:,2],color=color,lw=1.5,alpha=.85,label=label)
    c.set(xlabel='x / nm',ylabel='z / nm',title=t('C  固定视角的Cα链迹','C  Cα traces in one fixed projection'))
    c.set_aspect('equal'); clean(c)
    save(fig,'global-motion')
    fig=plt.figure(figsize=(14,9),layout='constrained'); g=fig.add_gridspec(2,2,width_ratios=[1.25,1])
    a=fig.add_subplot(g[0,0]); b=fig.add_subplot(g[1,0]); c=fig.add_subplot(g[:,1]); res=np.arange(1,77)
    for key,col in [('all',BLUE),('early',GREEN),('late',ORANGE)]:
        r=d['windows'][key]; a.plot(res,r['rmsf_nm']['fitted'],lw=2,color=col,label=f"{r['start_ps']}–{r['end_ps']} ps ({r['frames']})")
    a.set(title=t('A  固定配准后，时间窗决定平均位置','A  A fixed alignment, different averaging windows'),xlabel=t('残基编号','Residue number'),ylabel='Cα RMSF / nm'); a.legend(fontsize=11);clean(a)
    for mode,col,label in [('raw',ORANGE,labels[0]),('fitted',BLUE,labels[2])]:
        b.plot(res,d['windows']['all']['rmsf_nm'][mode],color=col,lw=2,label=label)
    b.set(title=t('B  0–1000 ps：整体转动也会增大坐标波动','B  Global rotation also enlarges positional fluctuations'),xlabel=t('残基编号','Residue number'),ylabel='Cα RMSF / nm');b.legend(fontsize=11);clean(b)
    mean=np.array(d['windows']['all']['mean_nm']['fitted']); mean-=mean.mean(axis=0)
    fluct=np.array(d['windows']['all']['rmsf_nm']['fitted']); pts=mean[:,[0,2]]
    lc=LineCollection(np.stack([pts[:-1],pts[1:]],axis=1),cmap='viridis',norm=plt.Normalize(0,.55),linewidth=4)
    lc.set_array((fluct[:-1]+fluct[1:])/2); c.add_collection(lc);c.scatter(pts[:,0],pts[:,1],c=fluct,cmap='viridis',vmin=0,vmax=.55,s=24,zorder=3)
    for i,offset in [(0,(-20,-24)),(75,(8,8))]: c.annotate(f'{i+1} {d["resnames"][i]}',pts[i],xytext=offset,textcoords='offset points',fontsize=12)
    c.annotate('9 THR',pts[8],xytext=(1.05,1.15),textcoords='data',fontsize=12,
               arrowprops={'arrowstyle':'-','color':'#666'},bbox={'facecolor':'#fffefb','edgecolor':'none','pad':2})
    c.autoscale(); c.margins(.2);c.set_aspect('equal');c.set(xlabel='x / nm',ylabel='z / nm',title=t('C  全窗口平均构象及局部波动','C  Full-window mean and local fluctuations'))
    fig.colorbar(lc,ax=c,orientation='horizontal',pad=.09,label='Cα RMSF / nm',ticks=[0,.1,.2,.3,.4,.5]);clean(c)
    save(fig,'local-fluctuations')
    fig=plt.figure(figsize=(14,8.5),layout='constrained');g=fig.add_gridspec(2,3,height_ratios=[1.4,1])
    for j,frame in enumerate([0,100,200]):
        ax=fig.add_subplot(g[0,j]);p=fit[frame]-np.array(d['reference_nm']).mean(axis=0)
        ax.plot(ref[:,0],ref[:,2],color='#b5b8b9',lw=2,label=t('0 ps','0 ps'))
        ax.plot(p[:,0],p[:,2],color=BLUE,lw=2);ax.scatter(*p[75,[0,2]],color=ORANGE,s=65,zorder=4)
        ax.annotate('Gly76',p[75,[0,2]],xytext=(8,6),textcoords='offset points',fontsize=12)
        ax.set(xlabel='x / nm',ylabel='z / nm',title=f'{time[frame]:.0f} ps',xlim=(-2.2,2.2),ylim=(-2,2.8));ax.set_aspect('equal');clean(ax)
    a=fig.add_subplot(g[1,:2]); mean=np.array(d['windows']['all']['mean_nm']['fitted'])
    for idx,col in [(22,BLUE),(75,ORANGE)]:
        a.plot(time,np.linalg.norm(fit[:,idx]-mean[idx],axis=1),color=col,lw=1.7,label=f'{d["resnames"][idx]}{idx+1}')
    a.set(xlabel=t('时间 / ps','Time / ps'),ylabel=t('距自身平均位置 / nm','Distance from own mean / nm'),title=t('局部波动：相同时间里，两个位置怎样移动','Local fluctuations at two positions over the same time'));a.legend(ncol=2,fontsize=12);clean(a)
    b=fig.add_subplot(g[1,2]); b.axis('off')
    b.text(0,1,t('从折叠结构到原子运动','From folded structure\nto atomic motion'),va='top',fontsize=17,color=BLUE)
    b.text(0,.70,t('1977 · McCammon、Gelin、Karplus\nBPTI的经验势能与运动方程\n追踪平均结构周围的波动。\n\n上方：本例泛素的201帧子集\n灰色参考保持不动，\n橙色端点显示Gly76的位置。',
        '1977 · McCammon, Gelin, Karplus\nAn empirical potential and equations\nof motion for BPTI revealed\nfluctuations about an average.\n\nAbove: the present ubiquitin subset\nThe gray reference stays fixed;\norange tracks the position of Gly76.'),va='top',fontsize=13,linespacing=1.6)
    save(fig,'fluctuation-history')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path('results'))
    parser.add_argument('--language',choices=['zh','en'],default='en')
    args=parser.parse_args(); args.output.mkdir(parents=True,exist_ok=True)
    data,summary=analyze(args.output)
    plot_figures(data,summary,args.output,args.language)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
