Ubiquitin trajectory subset / 泛素轨迹子集

Starting protein: PDB 1UBQ (76-residue ubiquitin).
https://www.rcsb.org/structure/1UBQ
Vijay-Kumar S, Bugg CE, Cook WJ (1987), J Mol Biol 194, 531–544.
https://doi.org/10.1016/0022-2836(87)90679-6
PDB archive data: CC0 1.0, https://www.rcsb.org/pages/policies

Simulation: GROMACS 2026.4; AMBER99SB-ILDN protein parameters; TIP3P water;
5868 water molecules and 17 each of sodium and chloride ions; 300 K and 1 bar
control targets; 2 fs integration step. Whole molecules reconstructed and
protein centered before sampling. Coordinates are a molecular dynamics model.

reference.tpr: original topology, masses, connectivity, and minimized coordinates.
ubiquitin-5ps.xtc: every fifth frame of the original 1 ps output; 201 frames,
0–1000 ps inclusive, 18869 atoms per frame. Protein: 1231 atoms, 76 Cα atoms.
This chapter uses the FIRST TRAJECTORY FRAME as its fitting reference.
Subsampling preserved all selected coordinates exactly after XTC readback.
MDAnalysis reads lengths in angstroms and times in ps; main.py converts to nm.

SHA-256
reference.tpr: f93a8e01fd3720fa984d6cdd678365529e260dd94093e05e3ef97fd16756efb2
ubiquitin-5ps.xtc: 9eb5246411648e7653402f004f871bacdc75518519b6b133524f141415e13a2a

Trajectory preparation and teaching adaptations: Yunhao Yang, CC BY 4.0.
https://creativecommons.org/licenses/by/4.0/
This subset adapts the openly shareable ubiquitin motion dataset by retaining
one frame every 5 ps. Original scientific molecular identity and attribution
are preserved. Molecular software and force-field components retain their
respective licenses. GROMACS workflow references:
https://tutorials.gromacs.org/docs/md-intro-tutorial.html
https://github.com/jalemkul/gmx_tutorials_livecoms
MDAnalysis package: LGPLv3+, component terms in
https://github.com/MDAnalysis/mdanalysis/blob/develop/LICENSE
