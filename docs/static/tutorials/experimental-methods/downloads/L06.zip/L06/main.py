"""Offline ELISA calibration, matrix effects and dilution experiment."""
from pathlib import Path
import argparse,csv,json
import numpy as np
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Ellipse
from PIL import Image
BLUE='#186e83';AMBER='#cd803f';GREEN='#3c8a6a';PURPLE='#8160a1'
PARAMS=(.05,2.05,100.,1.2)
def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def fourpl(c,a=.05,d=2.05,m=100.,b=1.2):
    c=np.asarray(c,dtype=float);return a+(d-a)*c**b/(m**b+c**b)
def inverse(y,a=.05,d=2.05,m=100.,b=1.2):
    y=np.asarray(y,dtype=float)
    with np.errstate(invalid='ignore',divide='ignore'):return m*((y-a)/(d-y))**(1/b)
def main(output,language='zh'):
    out=Path(output);out.mkdir(parents=True,exist_ok=True);zh=language=='zh'
    def T(a,b):return a if zh else _label(b)
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5'})
    def save(fig,name):fig.savefig(out/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    rng=np.random.default_rng(606);levels=np.array([0,6.25,12.5,25,50,100,200,400,800,1600]);x=np.repeat(levels,3)
    sigma=.006+.008*fourpl(x);raw=fourpl(x)+rng.normal(0,sigma)
    fit,cov=curve_fit(fourpl,x,raw,p0=PARAMS,sigma=sigma,absolute_sigma=True,bounds=([0,1,1,.3],[.3,4,1000,3]),maxfev=10000)
    with (out/'standards.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['concentration_pg_ml','replicate','absorbance','constructed_noise_sd']);w.writerows(zip(x,np.tile([1,2,3],len(levels)),raw,sigma))
    dilutions=np.array([1,2,4,8,16,32]);original=800.;effective=original/dilutions*(1-.4/dilutions)
    sample_signal=fourpl(effective);sample_raw=sample_signal[:,None]+rng.normal(0,.01,(len(dilutions),3));back=inverse(sample_raw,*fit)*dilutions[:,None]
    with (out/'dilutions.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['dilution','replicate','true_original_pg_ml','matrix_fraction','absorbance','estimated_original_pg_ml'])
        for i,dil in enumerate(dilutions):
            for j in range(3):w.writerow([dil,j+1,original,1-.4/dil,sample_raw[i,j],back[i,j]])
    fig,ax=plt.subplots(figsize=(11,5));ax.set(xlim=(0,12),ylim=(0,6));ax.axis('off')
    for x0,stage in [(1.5,0),(5.5,1),(9.5,2)]:
        ax.add_patch(Rectangle((x0-1,1),2,.15,fc=BLUE));ax.plot([x0,x0,x0-.5,x0,x0+.5],[1.1,2,2.5,2,2.5],color=BLUE,lw=4)
        if stage>=1:ax.add_patch(Ellipse((x0,2.65),1,.6,fc=AMBER))
        if stage>=2:
            ax.plot([x0,x0,x0-.4,x0,x0+.4],[2.95,3.5,4,3.5,4],color=PURPLE,lw=4);ax.add_patch(Ellipse((x0+.55,4.2),.8,.55,fc=GREEN));ax.text(x0+.55,4.2,'E',ha='center',va='center',color='white')
            ax.scatter([x0+.4,x0+.8,x0+1.2],[4.9,5.2,4.8],color='#d7ac3f',s=70)
    for a,b in [(2.8,4.1),(6.8,8.1)]:ax.annotate('',xy=(b,2.5),xytext=(a,2.5),arrowprops={'arrowstyle':'->','lw':1.5})
    for x0,label in [(1.5,T('固定捕获抗体','Immobilized capture')),(5.5,T('结合样品中的靶标','Bind sample target')),(9.5,T('检测抗体、酶与产物','Detector, enzyme and product'))]:ax.text(x0,.45,label,ha='center',fontsize=10)
    fig.text(.5,.94,T('1971：Engvall–Perlmann 与 van Weemen–Schuurs 的酶免疫分析工作','1971: enzyme immunoassay work by Engvall–Perlmann and van Weemen–Schuurs'),ha='center',fontsize=12)
    fig.text(.5,.015,T('现代夹心法的原创示意；酶 E 把分子识别转成可积累的颜色信号。','Original modern sandwich schematic: enzyme E converts recognition into accumulating color.'),ha='center',fontsize=10);save(fig,'history')
    grid=np.geomspace(2,3000,300);fig,ax=plt.subplots(2,2,figsize=(11,8.4))
    ax[0,0].scatter(x[x>0],raw[x>0],s=18,color=BLUE,label=T('构造标准复孔','Constructed standard wells'));ax[0,0].semilogx(grid,fourpl(grid,*fit),color=AMBER,label='4PL');ax[0,0].legend(fontsize=8);ax[0,0].set(xlabel=T('浓度 / pg/mL','Concentration / pg/mL'),ylabel=T('吸光度','Absorbance'),title=T('A  信号随浓度上升后逐渐变平','A  Response approaches a plateau'))
    ax[0,1].scatter(x,raw-fourpl(x,*fit),color=PURPLE,s=20);ax[0,1].set_xscale('symlog',linthresh=5);ax[0,1].axhline(0,color='grey',lw=1);ax[0,1].set(xlabel=T('浓度 / pg/mL','Concentration / pg/mL'),ylabel=T('实测构造值 − 拟合值','Constructed observation − fit'),title=T('B  残差保留误差的方向','B  Residuals retain error direction'))
    y=fourpl(grid);low=inverse(y-.02);high=inverse(y+.02);ax[1,0].semilogx(grid,100*(high-low)/(2*grid),color=GREEN);ax[1,0].set(xlabel=T('真实浓度 / pg/mL','True concentration / pg/mL'),ylabel=T('±0.02 信号误差对应的半宽 / %','Concentration half-width from ±0.02 signal / %'),title=T('C  同样的信号误差，不同的浓度误差','C  Equal signal error, unequal concentration error'),ylim=(0,50))
    plate=np.full((8,12),np.nan);plate_levels=np.array([0,12.5,25,50,100,200,400,800]);plate[:,:2]=fourpl(plate_levels)[:,None]+rng.normal(0,.01,(8,2));plate[:6,3:6]=sample_raw;plate[6:,3:6]=fourpl([50,300])[:,None]+rng.normal(0,.01,(2,3))
    plate_cmap=plt.get_cmap('cividis').copy();plate_cmap.set_bad('#e1e5e6')
    im=ax[1,1].imshow(plate,cmap=plate_cmap,vmin=0,vmax=2);ax[1,1].set_xticks(range(12),range(1,13));ax[1,1].set_yticks(range(8),list('ABCDEFGH'));ax[1,1].set_title(T('D  示例板：标准、稀释系列、质控','D  Example plate: standards, dilution series, QC'));fig.colorbar(im,ax=ax[1,1],label=T('吸光度','Absorbance'),fraction=.04)
    fig.tight_layout();save(fig,'calibration')
    np.savetxt(out/'plate.csv',plate,delimiter=',',header='constructed demonstration plate; NaN unused')
    fig,ax=plt.subplots(1,2,figsize=(11,4.8));ideal=inverse(sample_signal)*dilutions
    ax[0].plot(dilutions,ideal,'o-',color=BLUE,label=T('无噪声、含基质效应','Noiseless, matrix effect'));ax[0].errorbar(dilutions,back.mean(axis=1),yerr=back.std(axis=1,ddof=1),fmt='s',color=AMBER,label=T('拟合反算，3 复孔均值 ± SD','Fitted inversion, mean ± SD of 3 wells'));ax[0].axhline(800,color=GREEN,ls='--',label=T('真实原样浓度','True original concentration'));ax[0].set_xscale('log',base=2);ax[0].set_xticks(dilutions,dilutions);ax[0].set(xlabel=T('稀释倍数','Dilution factor'),ylabel=T('折算原样浓度 / pg/mL','Back-corrected concentration / pg/mL'),title=T('A  稀释减弱构造的基质抑制','A  Dilution reduces constructed matrix suppression'));ax[0].legend(fontsize=8)
    ax[1].bar([0,1,2],[40,65,62],color=[BLUE,GREEN,AMBER]);ax[1].set_xticks([0,1,2],[T('未加标','Unspiked'),T('理论加标后','Expected spiked'),T('测得加标后','Measured spiked')]);ax[1].set(ylabel=T('浓度 / pg/mL','Concentration / pg/mL'),title=T('B  加入 25，测得增加 22：回收 88%','B  Add 25, recover 22: 88% recovery'));fig.tight_layout();save(fig,'matrix')
    fig,ax=plt.subplots(figsize=(8.2,12.6));ax.imshow(Image.open(Path(__file__).resolve().parent/'feng2019-figure2.png'));ax.axis('off');ax.set_title(T('真实实验：试剂批次改变标准曲线','Measured experiment: lot-dependent standard curves'),fontsize=12)
    fig.text(.5,.012,T('Feng 等，2019，图 2；CC BY 4.0。\nA：均值 ± SD；批次 1–5 的曲线数分别为 28、19、8、4、9。','Feng et al., 2019, Fig. 2; CC BY 4.0.\nA: mean ± SD; lots 1–5 contain 28, 19, 8, 4, 9 curves.'),ha='center',fontsize=9);fig.tight_layout(rect=[0,.07,1,1]);save(fig,'published')
    assert np.isclose(fourpl(100),1.05) and np.isclose(inverse(1.05),100)
    assert np.allclose(ideal,800*(1-.4/dilutions))
    cv=np.std([98,100,102],ddof=1)/100*100
    summary={'model':{'midpoint_signal':float(fourpl(100)),'inverse_midpoint':float(inverse(1.05)),'midpoint_slope':2*1.2/(4*100),'midpoint_delta_c_for_002':.02/(2*1.2/(4*100))},'dilution':{'no_matrix_original':float(inverse(fourpl(100))*8),'one_matrix':float(ideal[0]),'eight_matrix':float(ideal[3]),'sixteen_matrix':float(ideal[4])},'spike':{'recovery_percent':(62-40)/25*100},'precision':{'cv_percent':float(cv)},'fit':{'a':float(fit[0]),'d':float(fit[1]),'m':float(fit[2]),'b':float(fit[3]),'sample_eightfold_mean':float(back[3].mean())}}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
