# Public sources and third-party materials

- Engvall & Perlmann (1971): Quantitative assay of immunoglobulin G: https://pubmed.ncbi.nlm.nih.gov/5135623/
  Bibliographic reference; original text not reproduced
- van Weemen & Schuurs (1971): Immunoassay using antigen-enzyme conjugates: https://pubmed.ncbi.nlm.nih.gov/11945853/
  Bibliographic reference
- Cox et al.: Immunoassay Methods, Assay Guidance Manual: https://www.ncbi.nlm.nih.gov/sites/books/NBK92434/
  Technical reference
- Thermo Fisher: Spike-and-recovery and linearity-of-dilution assessment: https://documents.thermofisher.com/TFS-Assets/LSG/Application-Notes/TR0058-Spike-and-Recovery.pdf
  Technical reference
- Feng et al. (2019): A computational solution to improve biomarker reproducibility during long-term projects: https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0209060
  CC BY 4.0; Fig. 2 reproduced without cropping
- SciPy: scipy.optimize.curve_fit: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html
  Technical documentation
