# Public sources and third-party materials

- TA Instruments — DMA Basic Theory and Applications: https://www.tainstruments.com/wp-content/uploads/2020_DMA_Online_Training_Part_1.pdf
  Technical reference; no figures reproduced.
- TA Instruments — Introduction to DMA of Polymer Solids: https://www.tainstruments.com/applications-notes/introduction-to-dynamic-mechanical-analysis-and-its-application-to-testing-of-polymer-solids/
  Technical reference; original prose and illustrations.
- RepTate — LVE Theories: https://reptate.readthedocs.io/manual/Applications/LVE/Theory/theory.html
  Technical reference.
- RepTate — TTS Theories: https://reptate.readthedocs.io/manual/Applications/TTS/Theory/theory.html
  Technical reference.
- Williams, Landel and Ferry (1955) — Temperature Dependence of Relaxation Mechanisms: https://doi.org/10.1021/ja01619a008
  Bibliographic reference; no paper text or figures reproduced.
- NumPy — numpy.linalg.lstsq: https://numpy.org/doc/stable/reference/generated/numpy.linalg.lstsq.html
  Technical reference; NumPy software is BSD-3-Clause.
