"""DMA from complete waveforms: original constructed data and SI-unit analysis."""
from pathlib import Path
import argparse, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon, FancyArrowPatch


def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def moduli(omega, tau=0.1, equilibrium=2e6, branch=8e6):
    x=np.asarray(omega)*tau
    return equilibrium+branch*x*x/(1+x*x), branch*x/(1+x*x)


def shift_factor(temperature, reference=20., c1=8., c2=80.):
    difference=np.asarray(temperature)-reference
    return 10.**(-c1*difference/(c2+difference))


def main(output, language):
    from matplotlib import font_manager
    output.mkdir(parents=True,exist_ok=True)
    fonts={f.name for f in font_manager.fontManager.ttflist}
    cjk=next((n for n in ['Microsoft YaHei','Noto Sans CJK SC','SimHei'] if n in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':cjk if language=='zh' else 'DejaVu Sans','font.size':11,
      'svg.fonttype':'none','axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,
      'axes.prop_cycle':plt.cycler(color=['#186e83','#cc7d3d','#8160a1','#3e876d']),
      'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5'})
    tr=lambda zh,en:zh if language=='zh' else _label(en)
    def save(fig,name):fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    omega,amplitude=10.,.002;storage,loss=moduli(omega)
    time=np.linspace(0,8*np.pi/omega,1600,endpoint=False)
    strain=amplitude*np.sin(omega*time)
    true_stress=amplitude*(storage*np.sin(omega*time)+loss*np.cos(omega*time))
    noise_sd=100.;offset=120.
    observed=true_stress+offset+np.random.default_rng(707).normal(0,noise_sd,time.size)
    design=np.c_[np.sin(omega*time),np.cos(omega*time),np.ones(time.size)]
    coefficients=np.linalg.lstsq(design,observed,rcond=None)[0]
    fit_storage,fit_loss=coefficients[:2]/amplitude
    predicted=design@coefficients;residual=observed-predicted
    phase=np.linspace(0,2*np.pi,2001)
    loop_strain=amplitude*np.sin(phase)
    loop_stress=amplitude*(storage*np.sin(phase)+loss*np.cos(phase))
    energy=float(np.pi*loss*amplitude**2)
    integrated=float(np.trapezoid(loop_stress,loop_strain))
    summary={'data_kind':'constructed teaching experiment','seed':707,
      'storage_Pa':float(storage),'loss_Pa':float(loss),'tan_delta':float(loss/storage),
      'phase_degrees':float(np.degrees(np.arctan2(loss,storage))),
      'energy_per_cycle_J_m3':energy,'integrated_energy_J_m3':integrated,
      'power_density_W_m3':energy*omega/(2*np.pi),'shift_at_40C':float(shift_factor(40)),
      'fitted_storage_Pa':float(fit_storage),'fitted_loss_Pa':float(fit_loss),
      'fitted_offset_Pa':float(coefficients[2]),'residual_sd_Pa':float(np.std(residual,ddof=3))}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    np.savetxt(output/'waveforms.csv',np.c_[time,strain,true_stress,observed,predicted,residual],delimiter=',',comments='',header='time_s,strain,true_stress_Pa,observed_stress_Pa,fitted_stress_Pa,residual_Pa')
    frequencies=np.geomspace(.01,100,241);w=2*np.pi*frequencies;sp,lp=moduli(w)
    np.savetxt(output/'spectrum.csv',np.c_[frequencies,sp,lp,lp/sp],delimiter=',',comments='',header='frequency_Hz,storage_Pa,loss_Pa,tan_delta')

    fig,axes=plt.subplots(1,3,figsize=(12,4.4),layout='constrained')
    for ax in axes:ax.set(xlim=(0,10),ylim=(0,10));ax.axis('off')
    a,b,c=axes
    a.set_title(tr('A  薄膜拉伸','A  Film tension'),loc='left',fontweight='bold')
    for y in [1.5,7.6]:a.add_patch(Rectangle((2.5,y),5,.8,facecolor='#8b9aa1'))
    a.add_patch(Rectangle((4,2.3),2,5.3,facecolor='#badbd9',edgecolor='#186e83',lw=2))
    a.add_patch(FancyArrowPatch((8,2.2),(8,7.8),arrowstyle='<->',mutation_scale=14,color='#cc7d3d',lw=2))
    a.text(8.5,5,tr('标距','Gauge'),rotation=90,ha='center');a.text(5,.35,tr('力 ÷ 面积 → 应力','Force ÷ area → stress'),ha='center',fontsize=10)
    b.set_title(tr('B  三点弯曲','B  Three-point bending'),loc='left',fontweight='bold')
    xs=np.linspace(1,9,101);ys=5-.8*np.sin(np.pi*(xs-1)/8)
    b.plot(xs,ys,color='#186e83',lw=8)
    for x in [1,9]:b.add_patch(Polygon([[x-.6,3.7],[x+.6,3.7],[x,4.8]],facecolor='#8b9aa1'))
    b.add_patch(FancyArrowPatch((5,8),(5,4.5),arrowstyle='-|>',mutation_scale=18,color='#cc7d3d',lw=2))
    b.text(5,2.6,tr('跨度、厚度决定换算','Span and thickness enter conversion'),ha='center',fontsize=10)
    b.text(5,.35,tr('图为变形与夹持概念示意','Conceptual deformation and fixture'),ha='center',fontsize=9)
    c.set_title(tr('C  同时记录两个信号','C  Record two signals together'),loc='left',fontweight='bold')
    for y,text,color in [(7,tr('位移 → 应变','Displacement → strain'),'#186e83'),(4.8,tr('力 → 应力','Force → stress'),'#cc7d3d'),(2.6,tr('时间差 → 相位','Time difference → phase'),'#8160a1')]:
        c.add_patch(Rectangle((.4,y-.4),9,1.3,facecolor='white',edgecolor=color,lw=1.5));c.text(4.9,y+.25,text,ha='center',va='center',fontsize=11)
    c.text(5,.35,tr('环境：温度、湿度、浸液','Environment: temperature, humidity, liquid'),ha='center',fontsize=9)
    save(fig,'measurement')

    fig,axs=plt.subplots(2,1,figsize=(11,6),sharex=True,layout='constrained')
    mask=time<2*2*np.pi/omega
    axs[0].plot(time[mask],strain[mask]*100,color='#186e83',lw=2.3)
    axs[0].set(ylabel=tr('应变 / %','Strain / %'),title=tr('A  受控应变：幅值 0.2%','A  Controlled strain: amplitude 0.2%'))
    axs[1].scatter(time[mask][::4],observed[mask][::4]/1000,s=9,color='#a9b5b7',label=tr('含噪声信号','Noisy signal'))
    axs[1].plot(time[mask],predicted[mask]/1000,color='#cc7d3d',lw=2,label=tr('正弦与余弦分解拟合','Sine–cosine fit'))
    axs[1].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('应力 / kPa','Stress / kPa'),title=tr('B  应力提前：相位约 33.69°','B  Stress leads: phase approximately 33.69°'))
    for ax in axs:ax.axhline(0,color='#b5c0c3',lw=.8);ax.grid(axis='x',alpha=.15)
    axs[1].legend(frameon=False,fontsize=9,ncols=2);save(fig,'waveforms')

    fig,axs=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
    axs[0].fill(loop_strain*100,loop_stress/1000,color='#186e83',alpha=.16)
    axs[0].plot(loop_strain*100,loop_stress/1000,color='#186e83',lw=2)
    axs[0].plot(loop_strain*100,storage*loop_strain/1000,color='#cc7d3d',ls='--',label=tr('储能分量','Storage contribution'))
    axs[0].set(xlabel=tr('应变 / %','Strain / %'),ylabel=tr('应力 / kPa','Stress / kPa'),title=tr('A  回线面积：50.27 J/m³ / 周期','A  Loop area: 50.27 J/m³ per cycle'));axs[0].legend(frameon=False,fontsize=9)
    axs[1].scatter((omega*time)%(2*np.pi),residual,s=7,alpha=.45,color='#8160a1')
    axs[1].axhline(0,color='#818e94',lw=1);axs[1].axhspan(-200,200,color='#8160a1',alpha=.08)
    axs[1].set(xlabel=tr('周期内相位 / rad','Phase within cycle / rad'),ylabel=tr('残差 / Pa','Residual / Pa'),title=tr('B  残差保留了周期结构吗','B  Does residual structure follow the cycle?'))
    save(fig,'energy')

    fig,axs=plt.subplots(2,2,figsize=(12,8.2),layout='constrained')
    axs[0,0].loglog(frequencies,sp/1e6,label="E′",lw=2);axs[0,0].loglog(frequencies,lp/1e6,label="E″",lw=2)
    axs[0,0].axvline(omega/(2*np.pi),color='#8d999e',ls=':',lw=1)
    axs[0,0].set(xlabel=tr('频率 / Hz','Frequency / Hz'),ylabel=tr('模量 / MPa','Modulus / MPa'),title=tr('A  单一松弛过程与平衡弹簧','A  One relaxation process and equilibrium spring'));axs[0,0].legend(frameon=False)
    axs[0,1].semilogx(frequencies,np.degrees(np.arctan2(lp,sp)),color='#8160a1',lw=2)
    axs[0,1].set(xlabel=tr('频率 / Hz','Frequency / Hz'),ylabel=tr('相位角 / °','Phase angle / °'),title=tr('B  相位随观察节奏变化','B  Phase depends on the observation pace'))
    for temp,color in [(0,'#186e83'),(20,'#cc7d3d'),(40,'#3e876d')]:
        at=shift_factor(temp);_,loss_t=moduli(w,tau=.1*at)
        axs[1,0].loglog(frequencies,loss_t/1e6,label=f'{temp} °C',color=color,lw=2)
        axs[1,1].loglog(frequencies*at,loss_t/1e6,color=color,lw=2,ls=['-',':','--'][temp//20],label=f'{temp} °C')
    axs[1,0].set(xlabel=tr('频率 / Hz','Frequency / Hz'),ylabel=tr('损耗模量 / MPa','Loss modulus / MPa'),title=tr('C  1955 WLF 关系：温度改变时钟','C  The 1955 WLF relation: changing the clock'));axs[1,0].legend(frameon=False,fontsize=9)
    axs[1,1].set(xlabel=tr('平移后频率 aT·f / Hz','Shifted frequency aT·f / Hz'),ylabel=tr('损耗模量 / MPa','Loss modulus / MPa'),title=tr('D  一致平移后形成主曲线','D  Consistent shifts produce a master curve'));axs[1,1].legend(frameon=False,fontsize=9)
    for ax in axs.flat:ax.grid(alpha=.13,which='major')
    save(fig,'spectrum')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en')
    a=p.parse_args();main(a.output,a.language)
