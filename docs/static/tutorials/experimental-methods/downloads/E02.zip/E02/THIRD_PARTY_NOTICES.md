# Public sources and third-party materials

- IUPAC Gold Book: gel fraction: https://goldbook.iupac.org/terms/view/GT07551
  Definition reference; no assets reproduced.
- Stockmayer (1943). Theory of Molecular Size Distribution and Gel Formation in Branched-Chain Polymers: https://doi.org/10.1063/1.1723803
  Bibliographic reference; no text or figures reproduced.
- Kovac and Fixman (2017). Walter H. Stockmayer, National Academy of Sciences Biographical Memoir: https://www.nasonline.org/wp-content/uploads/2024/10/Stockmayer_Walter.pdf
  Historical reference; no photographs or text reproduced.
- Hiroki et al. (2011). Biodegradability of Blend Hydrogels Based on Carboxymethyl Cellulose and Carboxymethyl Starch: https://www.jstage.jst.go.jp/article/tmrsj/36/3/36_397/_pdf
  Technical reference; no figures reproduced.
- Velasco-Rodriguez et al. (2021). Hybrid Methacrylated Gelatin and Hyaluronic Acid Hydrogel Scaffolds: https://www.mdpi.com/1422-0067/22/13/6758
  CC BY 4.0; Table 1 data transcribed and plotted with attribution.
