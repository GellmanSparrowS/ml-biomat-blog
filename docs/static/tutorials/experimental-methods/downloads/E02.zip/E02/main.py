"""Gel fraction: extraction mass balance, filler correction, and published network properties."""
from pathlib import Path
import argparse,json,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,FancyArrowPatch

def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def extraction(cycles,removal=.7,initial=100.,filler=20.,gel_fraction=.8):
    polymer=initial-filler;network=polymer*gel_fraction;sol=polymer-network
    trapped=sol*(1-removal)**np.asarray(cycles)
    residual=network+filler+trapped
    return residual,100*residual/initial,100*(residual-filler)/polymer,trapped

def connected_components(n,edges):
    parent=list(range(n))
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    for i,j in edges:parent[find(i)]=find(j)
    groups={}
    for i in range(n):groups.setdefault(find(i),[]).append(i)
    return sorted(groups.values(),key=len,reverse=True)

def main(output,language):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    from matplotlib import font_manager
    fonts={x.name for x in font_manager.fontManager.ttflist};font=next((f for f in ['Microsoft YaHei','Noto Sans CJK SC','SimHei'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[font,'DejaVu Sans'] if language=='zh' else ['DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','axes.prop_cycle':plt.cycler(color=['#186e83','#cd803f','#8160a1','#3c8a6a'])})
    tr=lambda z,e:z if language=='zh' else _label(e)
    def save(fig,name):fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    rng=np.random.default_rng(202);coords=np.array([(i%6,i//6) for i in range(36)]);edges=[(i,j) for i in range(36) for j in range(i+1,36) if np.abs(coords[i]-coords[j]).sum()==1];scores=rng.random(len(edges));sizes=[]
    fig,ax=plt.subplots(1,3,figsize=(12,4.5))
    for a,p in zip(ax,[.2,.5,.85]):
        active=[e for e,s in zip(edges,scores) if s<p];groups=connected_components(36,active);largest=set(groups[0]);sizes.append(len(largest))
        for i,j in active:a.plot(coords[[i,j],0],coords[[i,j],1],color='#186e83' if i in largest else '#c4cbd0',lw=2)
        a.scatter(*coords.T,c=['#186e83' if i in largest else '#cd803f' for i in range(36)],s=36,zorder=4);a.set_aspect('equal');a.axis('off');a.set_title(tr(f'连接概率 {p:.2f}\n最大连通簇 {len(largest)}/36',f'Bond probability {p:.2f}\nLargest connected cluster {len(largest)}/36'))
    fig.text(.5,.02,tr('1941–1943：Flory 与 Stockmayer 将成胶理解为分支连接的统计问题。','1941–1943: Flory and Stockmayer treated gelation as a statistical connectivity problem.'),ha='center',fontsize=10);save(fig,'connectivity')
    fig,ax=plt.subplots(1,2,figsize=(11,4.8));names=tr(['提取前','充分提取后'],['Before extraction','After complete extraction'])
    ax[0].bar(names,[64,64],label=tr('网络聚合物','Network polymer'),color='#186e83');ax[0].bar(names,[16,0],bottom=[64,64],label=tr('可溶聚合物','Soluble polymer'),color='#cd803f');ax[0].bar(names,[20,20],bottom=[80,64],label=tr('不溶填料','Insoluble filler'),color='#8160a1');ax[0].set(ylabel=tr('干质量 / mg','Dry mass / mg'),title=tr('A  100 mg 复合材料的质量去向','A  Mass accounting for a 100 mg composite'));ax[0].legend(fontsize=9)
    ax[1].barh(tr(['原始残留比','聚合物凝胶分数'],['Raw residue fraction','Polymer gel fraction']),[84,80],color=['#8160a1','#186e83']);ax[1].set(xlim=(0,105),xlabel=tr('质量分数 / %','Mass fraction / %'),title=tr('B  分子和分母同时扣除填料','B  Remove filler from numerator and denominator'))
    for i,v in enumerate([84,80]):ax[1].text(v+1,i,str(v),va='center')
    fig.tight_layout();save(fig,'accounting')
    cycles=np.arange(7);residual,raw,corrected,trapped=extraction(cycles);removed=np.r_[0,-np.diff(trapped)];np.savetxt(output/'extraction.csv',np.column_stack([cycles,residual,raw,corrected,trapped,removed]),delimiter=',',header='cycle,residual_mg,raw_percent,polymer_corrected_percent,trapped_sol_mg,removed_this_cycle_mg',comments='')
    specimen_initial=np.array([100.,120.,90.]);specimen_filler=.2*specimen_initial;specimen_final=.8*(specimen_initial-specimen_filler)+specimen_filler+np.array([.3,-.2,.1]);measured=100*(specimen_final-specimen_filler)/(specimen_initial-specimen_filler)
    np.savetxt(output/'specimens.csv',np.column_stack([specimen_initial,specimen_filler,specimen_final,measured]),delimiter=',',header='initial_mg,filler_mg,extracted_dry_mg,polymer_gel_percent',comments='')
    fig,ax=plt.subplots(2,2,figsize=(11,7));ax=ax.ravel();ax[0].plot(cycles,raw,'o-',label=tr('未扣填料','Filler uncorrected'));ax[0].plot(cycles,corrected,'s-',label=tr('扣除填料','Filler corrected'));ax[0].axhline(80,color='#707c82',ls='--');ax[0].set(ylabel=tr('残留分数 / %','Remaining fraction / %'),title=tr('A  提取不足与填料是两个偏差','A  Incomplete extraction and filler are distinct biases'));ax[0].legend(fontsize=9)
    ax[1].bar(cycles[1:],removed[1:],color='#cd803f');ax[1].set(ylabel=tr('本次提取物 / mg','Mass extracted in this wash / mg'),title=tr('B  每一次换液带走多少','B  Material removed by each wash'))
    for f in [.3,.5,.7,.9]:ax[2].plot(cycles,extraction(cycles,f)[2],'.-',label=f'{f:.1f}')
    ax[2].axhline(80,color='#707c82',ls='--');ax[2].set(ylabel=tr('校正后残留分数 / %','Corrected remaining fraction / %'),title=tr('C  每次去除比例改变终点接近速度','C  Removal fraction controls endpoint approach'));ax[2].legend(title=tr('每次去除比例','Removal per wash'),fontsize=9)
    ax[3].plot(np.arange(1,4),measured,'o',ms=8);ax[3].axhline(measured.mean(),color='#cd803f');ax[3].set(xticks=[1,2,3],ylim=(78,82),xlabel=tr('独立样品编号','Independent specimen'),ylabel=tr('聚合物凝胶分数 / %','Polymer gel fraction / %'),title=tr('D  先逐样品校正，再汇总','D  Correct individual specimens before averaging'))
    for a in ax[:3]:a.set_xlabel(tr('提取循环次数','Extraction cycle'))
    fig.tight_layout();save(fig,'extraction')
    with Path(__file__).with_name('published_table.csv').open(encoding='utf8') as f:rows=list(csv.DictReader(f))
    g=np.array([float(r['gel_percent']) for r in rows]);ge=np.array([float(r['gel_error']) for r in rows]);m=np.array([float(r['modulus_kPa']) for r in rows]);me=np.array([float(r['modulus_error']) for r in rows]);labels=[r['formulation'] for r in rows]
    fig,ax=plt.subplots(1,2,figsize=(12,6.8),gridspec_kw={'width_ratios':[1.3,1]});y=np.arange(len(rows));ax[0].errorbar(g,y,xerr=ge,fmt='o',capsize=3,color='#186e83');ax[0].set(yticks=y,yticklabels=labels,xlim=(55,109),xlabel=tr('凝胶分数 / %','Gel fraction / %'),title=tr('A  公开表格中的凝胶分数','A  Gel fractions from a published table'));ax[0].invert_yaxis()
    colors=['#186e83']*3+['#cd803f']*3+['#8160a1']*6
    for i in range(len(rows)):ax[1].errorbar(g[i],m[i],xerr=ge[i],yerr=me[i],fmt='o',color=colors[i],alpha=.8,capsize=2)
    ax[1].set(xlabel=tr('凝胶分数 / %','Gel fraction / %'),ylabel=tr('弹性模量 / kPa','Elastic modulus / kPa'),title=tr('B  质量连入网络与刚度并非一一对应','B  Network mass and stiffness are not one-to-one'))
    ax[1].text(.04,.96,tr('蓝：HAMA\n橙：GelMA\n紫：混合网络','Blue: HAMA\nOrange: GelMA\nPurple: mixed networks'),transform=ax[1].transAxes,va='top',fontsize=10)
    fig.suptitle('Velasco-Rodriguez et al. (2021), Table 1 · CC BY 4.0',fontsize=11);fig.tight_layout();save(fig,'published')
    summary={'worked_example':{'network_mg':64.,'raw_fraction_percent':84.,'polymer_fraction_percent':80.,'sol_fraction_percent':20.,'closure_percent':99.2},'extraction':{'cycle1_corrected_percent':float(corrected[1]),'cycle3_corrected_percent':float(corrected[3]),'cycle6_trapped_mg':float(trapped[6])},'specimens':{'mean_percent':float(measured.mean()),'sd_percent':float(measured.std(ddof=1))},'published':{'rows':len(rows),'hama_modulus_ratio':m[2]/m[0]},'connectivity':{'largest_cluster_sizes':sizes}}
    assert abs(corrected[1]-86)<1e-12;assert abs(corrected[3]-80.54)<1e-12;assert abs(residual[-1]+sum(removed)-100)<1e-12
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--language',choices=['zh','en'],default='zh');args=parser.parse_args();main(args.output,args.language)
