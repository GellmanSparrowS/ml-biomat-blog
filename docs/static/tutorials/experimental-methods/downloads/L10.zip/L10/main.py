"""Offline constructed scratch, tracking and Transwell examples with a licensed measured figure."""
from pathlib import Path
import argparse,csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle
from scipy.ndimage import gaussian_filter,label
from PIL import Image
BLUE='#186e83';AMBER='#cd803f';PURPLE='#8160a1';GREEN='#3c8a6a'

def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def metrics(track,dt):
    track=np.asarray(track,dtype=float)
    if track.ndim!=2 or track.shape[1]!=2 or len(track)<2 or not np.isfinite(track).all() or not np.isfinite(dt) or dt<=0:
        raise ValueError('Provide at least two finite x/y positions and a positive sampling interval.')
    length=float(np.linalg.norm(np.diff(track,axis=0),axis=1).sum());displacement=track[-1]-track[0]
    stationary=length==0
    return {'path_um':length,'speed_um_per_h':float(length/((len(track)-1)*dt)),'stationary':stationary,'directness':None if stationary else float(np.linalg.norm(displacement)/length),'fmi_x':None if stationary else float(displacement[0]/length)}

def population_metrics(tracks,dt):
    values=[metrics(track,dt) for track in tracks]
    directional=[value['fmi_x'] for value in values if not value['stationary']]
    return {'mean_fmi_x':float(np.mean(directional)) if directional else None,'mean_speed_um_h':float(np.mean([value['speed_um_per_h'] for value in values])),'stationary_fraction':float(np.mean([value['stationary'] for value in values])),'directional_track_count':len(directional)}
def main(output,language='zh'):
    out=Path(output);out.mkdir(parents=True,exist_ok=True);zh=language=='zh';T=lambda a,b:a if zh else _label(b)
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5'})
    def save(fig,n):fig.savefig(out/f'{n}-{language}.svg',bbox_inches='tight');plt.close(fig)
    rng=np.random.default_rng(1010);px=2.;yy,xx=np.mgrid[:300,:480];x=xx*px;y=yy*px;center=480+12*np.sin(y/60);times=np.array([0,6,12,18,24]);images=[];masks=[];truth_masks=[];areas=[]
    for t in times:
        width=400-10*t;gap=abs(x-center)<width/2;raw=np.where(gap,30.,120.)+rng.normal(0,5,gap.shape)+8*np.sin(x/13)*np.cos(y/17)*(~gap);raw=gaussian_filter(raw,.7)
        candidate=gaussian_filter(raw,1)<75;labs,n=label(candidate);sizes=np.bincount(labs.ravel());sizes[0]=0;mask=labs==np.argmax(sizes)
        images.append(raw);masks.append(mask);truth_masks.append(gap);areas.append(mask.sum()*px**2)
    areas=np.array(areas);closure=100*(1-areas/areas[0]);np.savez_compressed(out/'scratch_images.npz',time_h=times,image=np.array(images),segmented_gap=np.array(masks),known_gap=np.array(truth_masks),pixel_um=px)
    with(out/'closure.csv').open('w',newline='',encoding='utf8')as f:
        w=csv.writer(f);w.writerow(['time_h','segmented_area_um2','closure_percent','ideal_width_um']);w.writerows(zip(times,areas,closure,400-10*times))
    tracksets={};trackrows=[]
    for name in ['random','directed']:
        tracks=[]
        for j in range(20):
            angle=rng.uniform(-np.pi,np.pi,24)if name=='random'else rng.normal(0,.35,24)
            step=10*np.column_stack([np.cos(angle),np.sin(angle)]);track=np.vstack([np.zeros(2),np.cumsum(step,axis=0)]);tracks.append(track)
            for k,(tx,ty)in enumerate(track):trackrows.append([name,j+1,k*.5,tx,ty])
        tracksets[name]=tracks
    with(out/'tracks.csv').open('w',newline='',encoding='utf8')as f:
        w=csv.writer(f);w.writerow(['group','cell_id','time_h','x_um','y_um']);w.writerows(trackrows)
    counts={'no_cue':[180,200,220],'lower_cue':[540,600,660],'uniform_cue':[360,400,440],'upper_cue':[135,150,165],'coated_lower_cue':[150,180,210]}
    with(out/'transwell_counts.csv').open('w',newline='',encoding='utf8')as f:
        w=csv.writer(f);w.writerow(['condition','independent_insert','whole_membrane_count','input_cells']);w.writerows([k,i+1,v,50000]for k,vals in counts.items()for i,v in enumerate(vals))
    t=np.linspace(0,12,121);vu=.1;vl=.6;k=.02;equilibrium=10*vl/(vu+vl);decay=np.exp(-k*(1/vu+1/vl)*t);cu=equilibrium*(1-decay);cl=equilibrium+(10-equilibrium)*decay
    with(out/'gradient.csv').open('w',newline='',encoding='utf8')as f:
        w=csv.writer(f);w.writerow(['time_h','upper_ng_ml','lower_ng_ml','total_ng']);w.writerows(zip(t,cu,cl,vu*cu+vl*cl))
    fig,ax=plt.subplots(1,2,figsize=(11,5.3))
    for a in ax:a.axis('off');a.set(xlim=(0,10),ylim=(0,7))
    ax[0].add_patch(Rectangle((.5,1.1),9,4,fc=BLUE,alpha=.1));ax[0].add_patch(Rectangle((4,1.1),2,4,fc='#faf9f5'))
    for j in range(4):
        for i in range(3):
            for shift in[0,6]:ax[0].add_patch(Circle((1+i*.8+shift,1.6+j*.9),.28,fc=BLUE,alpha=.7))
    ax[0].annotate('',xy=(4.7,3),xytext=(3.1,3),arrowprops={'arrowstyle':'->','lw':2,'color':AMBER});ax[0].annotate('',xy=(5.3,3),xytext=(6.9,3),arrowprops={'arrowstyle':'->','lw':2,'color':AMBER});ax[0].text(5,6,T('同一平面：空隙如何闭合','One plane: how a gap closes'),ha='center',fontsize=12);ax[0].text(5,.3,T('迁移、铺展与增殖共同改变覆盖面积','Migration, spreading and division change coverage'),ha='center',fontsize=9)
    ax[1].add_patch(Rectangle((1,1),8,4.7,fill=False,ec=BLUE,lw=2));ax[1].add_patch(Rectangle((2.2,3),5.6,3,fill=False,ec=PURPLE,lw=2));
    for i in range(6):ax[1].plot([2.2+i*.95,2.7+i*.95],[3,3],color=PURPLE,lw=4)
    for xx0 in[3,4.4,6,7]:ax[1].add_patch(Circle((xx0,3.6),.22,fc=BLUE))
    for xx0 in[2,3,4,5,6,7,8]:ax[1].add_patch(Circle((xx0,1.8),.07,fc=AMBER))
    ax[1].annotate('',xy=(5,2.3),xytext=(5,3.6),arrowprops={'arrowstyle':'->','lw':2,'color':AMBER});ax[1].text(5,6.6,T('1962 Boyden：用膜连接两个室','1962 Boyden: two compartments and a membrane'),ha='center',fontsize=12);ax[1].text(5,.3,T('现代插入式装置原创示意，非历史原件','Original modern-insert schematic, not the historical apparatus'),ha='center',fontsize=9);fig.tight_layout();save(fig,'history')
    fig,ax=plt.subplots(2,3,figsize=(12,7.7))
    for j,idx in enumerate([0,2,4]):
        a=ax[0,j];a.imshow(images[idx],cmap='gray',vmin=20,vmax=140,extent=[0,960,600,0]);a.contour(x,y,masks[idx],levels=[.5],colors=[AMBER],linewidths=.7);a.set(title=f'{times[idx]} h',xlabel='x / μm',ylabel='y / μm')
    ax[1,0].plot(times,closure,'o-',color=BLUE);ax[1,0].plot(times,100*10*times/400,'--',color=AMBER);ax[1,0].set(xlabel=T('时间 / h','Time / h'),ylabel=T('空隙闭合 / %','Gap closure / %'),title=T('A  分割值与几何真值','A  Segmentation and geometric truth'))
    width=np.linspace(200,800,100);ax[1,1].plot(width,np.minimum(100,100*240/width),color=PURPLE);ax[1,1].set(xlabel=T('初始宽度 / μm','Initial width / μm'),ylabel=T('24小时闭合 / %','Closure at24 h / %'),title=T('B  同一边缘速度，起始宽度不同','B  Same edge speed, different initial widths'))
    th=np.arange(50,101,5);sensitivity=[]
    for q in th:
        aa=[(gaussian_filter(im,1)<q).sum()*px**2 for im in[images[0],images[-1]]];sensitivity.append(100*(1-aa[1]/aa[0]))
    ax[1,2].plot(th,sensitivity,'o-',color=GREEN);ax[1,2].axhline(60,color='gray',ls='--');ax[1,2].set(xlabel=T('分割阈值 / a.u.','Segmentation threshold / a.u.'),ylabel=T('24小时闭合 / %','Closure at24 h / %'),title=T('C  边界判断的敏感性','C  Sensitivity to boundary definition'));fig.tight_layout();save(fig,'scratch')
    fig,ax=plt.subplots(2,2,figsize=(11,8.7))
    for j,name in enumerate(['random','directed']):
        a=ax[0,j]
        for track in tracksets[name]:a.plot(track[:,0],track[:,1],alpha=.6,lw=1.2,color=BLUE if j==0 else AMBER);a.scatter(*track[-1],s=8,color=PURPLE)
        a.set_aspect('equal');a.set(xlim=(-130,260),ylim=(-140,140),xlabel='x / μm',ylabel='y / μm',title=T('A  无偏方向，步长相同','A  Unbiased headings, equal step length')if j==0 else T('B  方向偏向正x，步长仍相同','B  Headings biased toward+x, same steps'));a.axhline(0,color='gray',lw=.5);a.axvline(0,color='gray',lw=.5)
    for j,name in enumerate(['random','directed']):
        ms=[metrics(q,.5)for q in tracksets[name]];ax[1,0].scatter(np.full(20,j),[m['fmi_x']for m in ms],color=BLUE if j==0 else AMBER,alpha=.65)
        for stride,col in[(1,BLUE),(4,AMBER)]:ax[1,1].scatter(j+(.12 if stride==4 else-.12),np.mean([metrics(q[::stride],.5*stride)['speed_um_per_h']for q in tracksets[name]]),color=col,s=60)
    for a in ax[1]:a.set_xticks([0,1],[T('随机方向','Random'),T('定向','Directed')]);a.grid(alpha=.15)
    ax[1,0].set(ylabel=T('沿x前向迁移指数','Forward migration index along x'),title=T('C  方向性由投影位移体现','C  Projected displacement measures bias'))
    ax[1,1].set(ylabel=T('估计平均速度 / μm/h','Estimated mean speed / μm/h'),title=T('D  蓝：0.5h采样；橙：2h采样','D  Blue:0.5h sampling; orange:2h'));fig.tight_layout();save(fig,'tracks')
    fig,ax=plt.subplots(1,2,figsize=(11,4.8));ax[0].plot(t,cu,color=BLUE,label=T('上室','Upper'));ax[0].plot(t,cl,color=AMBER,label=T('下室','Lower'));ax[0].set(xlabel=T('时间 / h','Time / h'),ylabel=T('体积平均浓度 / ng/mL','Volume-averaged concentration / ng/mL'),title=T('A  两室交换的构造模型','A  Constructed two-compartment exchange'));ax[0].legend()
    labels=[T('无信号','No cue'),T('下室信号','Lower cue'),T('均匀信号','Uniform cue'),T('上室信号','Upper cue'),T('涂层+下室','Coated+lower')]
    for i,(name,values)in enumerate(counts.items()):ax[1].scatter(np.full(3,i),values,color=BLUE);ax[1].plot([i-.15,i+.15],[np.mean(values)]*2,color=AMBER,lw=3)
    ax[1].set_xticks(range(5),labels,rotation=20,ha='right');ax[1].set(ylabel=T('每张膜通过的细胞数','Crossed cells per membrane'),title=T('B  构造计数：每点是独立插入件','B  Constructed counts: each dot is an insert'))
    for a in ax:a.grid(alpha=.15)
    fig.tight_layout();save(fig,'transwell')
    fig,ax=plt.subplots(figsize=(11,10));ax.imshow(Image.open(Path(__file__).resolve().parent/'yarrow2004-figure1.jpg').convert('RGB'));ax.axis('off');ax.set_title(T('真实划痕实验：闭合之外还有形态与分裂信息','Measured scratch assay: closure, morphology and division'),fontsize=12);fig.text(.5,.015,T('Yarrow等2004，图1；CC BY2.0，完整转载。\n原图比例尺：A20μm；B、D100μm；C底部500μm。','Yarrow et al.2004,Fig1; CC BY2.0, reproduced in full.\nOriginal scale bars:A20μm;B/D100μm;Cbottom500μm.'),ha='center',fontsize=9);fig.tight_layout(rect=[0,.07,1,1]);save(fig,'published')
    simple=metrics(np.array([[0.,0.],[3.,4.],[6.,4.]]),1)
    stationary=metrics(np.zeros((3,2)),1)
    assert stationary['speed_um_per_h']==0 and stationary['directness'] is None and stationary['fmi_x'] is None
    summary={'geometry':{'initial_area_um2':400*600,'final_area_um2':160*600,'closure_percent':60,'one_edge_speed_um_h':(400-160)/(2*24),'equivalent_area_from_60000_pixels_um2':60000*2**2},'tracking':simple,'stationary_tracking':stationary,'stationary_population':population_metrics([np.zeros((3,2))],1),'transwell':{'migration_percent':600/50000*100,'coated_to_uncoated_percent':180/600*100,'initial_total_ng':.6*10,'final_total_ng':float(vu*cu[-1]+vl*cl[-1]),'equilibrium_ng_ml':equilibrium},'segmentation':{'initial_area_um2':float(areas[0]),'final_closure_percent':float(closure[-1])},'populations':{name:population_metrics(tracks,.5) for name,tracks in tracksets.items()}}
    assert abs(closure[-1]-60)<.15
    (out/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False),encoding='utf8');print(json.dumps(summary,allow_nan=False))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
