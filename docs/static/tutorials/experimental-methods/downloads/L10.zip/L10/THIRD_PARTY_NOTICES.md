# Public sources and third-party materials

- Boyden (1962): The chemotactic effect of mixtures of antibody and antigen on polymorphonuclear leucocytes: https://pmc.ncbi.nlm.nih.gov/articles/PMC2137509/
  Historical technical reference; original figure not reproduced
- Yarrow et al. (2004): A high-throughput cell migration assay using scratch wound healing: https://pmc.ncbi.nlm.nih.gov/articles/PMC521074/
  CC BY 2.0; Fig. 1 reproduced in full.
- Justus et al. (2023): Transwell In Vitro Cell Migration and Invasion Assays: https://pmc.ncbi.nlm.nih.gov/articles/PMC10335869/
  Technical reference; BioRender figures not reproduced
- Corning: Assay Methods—Cell Invasion Assay: https://www.corning.com/catalog/cls/documents/protocols/protocol_DL_031_Cell_Invasion_Assay.pdf
  Technical reference
- ibidi: Chemotaxis and Migration Tool 2.0 manual: https://ibidi.com/img/cms/products/software/chemotaxis_tool/Manual_ChemotaxisTool_2_0_eng.pdf
  Technical reference; no figures reproduced
- ImageJ: Analyze menu: https://imagej.net/ij/docs/menus/analyze.html
  Technical documentation
