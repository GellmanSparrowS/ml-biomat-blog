Water viscosity values from Hackley and Clogston, NIST SP1200-6 (2015), printed page9, aqueous-medium table. https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.1200-6.pdf
These are published thermophysical-property values, not measurements performed in this tutorial. Numerical facts retained exactly; no source artwork reproduced. Other chapter datasets are explicitly constructed.
