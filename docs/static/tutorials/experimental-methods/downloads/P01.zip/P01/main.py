"""DLS: Brownian motion, photon correlation, mixtures and solvent inputs.

All particle traces are constructed. Bundled water viscosities are published
NIST SP1200-6 values, retained with attribution in data/README.txt.
Run: python main.py --output results --language en
"""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.signal import lfilter
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle

p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();O=args.output;O.mkdir(parents=True,exist_ok=True)
ZH=args.language=='zh'
def L(z,e):return z if ZH else e
plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.facecolor':'#fcfbf7','figure.facecolor':'#fcfbf7','svg.fonttype':'none','text.color':'#20333e','axes.labelcolor':'#20333e','axes.titleweight':'bold'})
B='#167d9a';R='#d35f47';G='#37967d';Y='#c49b35';K='#20333e'
def save(f,n):
 for e in ['svg','png']:f.savefig(O/f'{n}-{args.language}.{e}',dpi=145,bbox_inches='tight')
 plt.close(f)
def csv(n,heads,cols):np.savetxt(O/n,np.column_stack(cols),delimiter=',',header=','.join(heads),comments='',fmt='%.10g')
kB=1.380649e-23;TK=298.15;eta=.000890;nmed=1.333;wave=633e-9;theta=np.pi/2
q=4*np.pi*nmed/wave*np.sin(theta/2)
def diffusion(d_nm,visc=eta,T=TK):return kB*T/(3*np.pi*visc*d_nm*1e-9)
def diameter(D,visc=eta,T=TK):return kB*T/(3*np.pi*visc*D)*1e9
rng=np.random.default_rng(810);D80=diffusion(80);D240=diffusion(240)
dtpath=.001;tp=np.arange(301)*dtpath
paths={};msds={}
for d in [80,240]:
 step=rng.normal(size=(2048,300,2))*np.sqrt(2*diffusion(d)*dtpath)*1e6
 xy=np.concatenate([np.zeros((2048,1,2)),np.cumsum(step,axis=1)],axis=1);paths[d]=xy[:3];msds[d]=np.mean(np.sum(xy*xy,axis=2),axis=0)
csv('brownian_msd.csv',['time_s','msd80_um2','theory80_um2','msd240_um2','theory240_um2'],[tp,msds[80],4*D80*tp*1e12,msds[240],4*D240*tp*1e12])
fig,axs=plt.subplots(1,2,figsize=(12,5.2),layout='constrained')
a=axs[0]
for d,c in [(80,B),(240,R)]:
 xy=paths[d][0];a.plot(xy[:,0],xy[:,1],color=c,lw=1.3,label=f'{d} nm');a.scatter(*xy[-1],color=c,s=35)
a.scatter(0,0,color=K,marker='x',s=55);a.set(aspect='equal',xlabel=L('x 位移 / μm','x displacement / μm'),ylabel=L('y 位移 / μm','y displacement / μm'),title=L('A  相同 0.3 s，不同扩散尺度','A  Same 0.3 s, different diffusion scales'));a.legend(frameon=False)
a=axs[1]
for d,c in [(80,B),(240,R)]:a.plot(tp,msds[d],color=c,lw=2,label=L(f'{d} nm：2048 条轨迹',f'{d} nm: 2048 paths'));a.plot(tp,4*diffusion(d)*tp*1e12,color=c,ls='--',lw=1)
a.set(xlabel=L('经过时间 / s','Elapsed time / s'),ylabel=L('二维平均平方位移 / μm²','Two-dimensional mean squared displacement / μm²'),title=L('B  杂乱路径可以有清楚的统计规律','B  Irregular paths have a statistical law'));a.legend(frameon=False,fontsize=9)
fig.suptitle(L('从 Brown 的观察，到 Einstein、Smoluchowski 与 Perrin 的定量研究\n原创数值示意；不是历史测量轨迹','From Brown’s observations to Einstein, Smoluchowski and Perrin\nOriginal numerical illustration, not historical measured trajectories'),fontsize=11);save(fig,'brownian-history')

# Two independent complex Gaussian optical modes give coherence factor 1/2.
# Poisson counts model photon detection; the zero-lag shot-noise spike is excluded.
N=1048576;dt=2e-6;burn=8192;Gamma=D80*q*q;a=np.exp(-Gamma*dt);intensity=np.zeros(N)
for _ in range(2):
 noise=(rng.normal(size=N+burn)+1j*rng.normal(size=N+burn))*np.sqrt((1-a*a)/2)
 field=lfilter([1],[1,-a],noise)[burn:];intensity+=np.abs(field)**2/2
counts=rng.poisson(.8*intensity).astype(np.int16);center=counts-counts.mean();pad=1<<(2*N-1).bit_length()
fft=np.fft.rfft(center,pad);cov=np.fft.irfft(fft*np.conj(fft),pad)[:6001]/(N-np.arange(6001))
lags=np.unique(np.geomspace(1,6000,250).astype(int));tau=lags*dt;g2=1+cov[lags]/counts.mean()**2
def mono(t,beta,rate,base):return base+beta*np.exp(-2*rate*t)
mask=tau<=.006;fit,_=curve_fit(mono,tau[mask],g2[mask],p0=[.5,Gamma,1],bounds=([.05,1,.9],[1.5,1e6,1.1]),maxfev=20000)
beta_fit,rate_fit,base_fit=fit;dfit=diameter(rate_fit/q**2);fitted=mono(tau,*fit)
np.savez_compressed(O/'photon_counts.npz',counts=counts,bin_seconds=dt,diameter_nm=80,seed=810)
csv('correlation.csv',['delay_s','g2_from_counts','single_exponential_fit','fit_residual'],[tau,g2,fitted,g2-fitted])
block=25;preview=counts[:5000].reshape(-1,block).sum(axis=1);tprev=(np.arange(preview.size)+.5)*block*dt
csv('photon_preview.csv',['time_s','counts_per50us'],[tprev,preview])
fig,axs=plt.subplots(2,2,figsize=(12,8.6),layout='constrained')
ax=axs[0,0];ax.axis('off');ax.set(xlim=(0,10),ylim=(0,7));ax.set_title(L('A  接收一个方向的散射波动','A  Collect fluctuations in one direction'))
ax.add_patch(Rectangle((.3,2.4),1.8,1.2,fc=R,alpha=.8));ax.text(1.2,3,L('激光','Laser'),ha='center',va='center',color='white');ax.add_patch(Rectangle((4,1.7),2,2.7,fc='#d9e9e8',ec=B));ax.text(5,1.1,L('样品池','Cuvette'),ha='center');ax.annotate('',xy=(4.8,3),xytext=(2.1,3),arrowprops={'arrowstyle':'->','lw':2,'color':R});ax.plot([5,8.8],[3,3],ls='--',color='#8d9ba3');ax.annotate('',xy=(5,5.6),xytext=(5,3),arrowprops={'arrowstyle':'->','lw':2,'color':B});ax.add_patch(Rectangle((4,5.7),2,1,fc=B));ax.text(5,6.2,L('探测器','Detector'),ha='center',va='center',color='white');ax.text(5.4,3.5,'90°',color=B);ax.text(7.3,2,L('干涉随位置改变\n记录光子数随时间变化','Positions change interference\nRecord photons versus time'),ha='center',fontsize=9)
ax=axs[0,1];ax.plot(tprev*1e3,preview,color=B,lw=1);ax.set(xlabel=L('记录时间 / ms','Acquisition time / ms'),ylabel=L('每 50 μs 的光子数','Photons per 50 μs'),title=L('B  同一构造记录的前 10 ms','B  First 10 ms of the constructed record'))
ax=axs[1,0];ax.semilogx(tau*1e6,g2,'o',ms=3,color='#9bb9c0',label=L('由光子记录计算','Computed from photon record'));ax.semilogx(tau*1e6,fitted,color=R,lw=2,label=L(f'拟合直径 {dfit:.2f} nm',f'Fitted diameter {dfit:.2f} nm'));ax.set(xlabel=L('延迟时间 τ / μs','Delay time τ / μs'),ylabel='g₂(τ)',title=L('C  相关曲线衰减到约 1','C  Correlation decays toward about 1'));ax.legend(frameon=False,fontsize=9)
ax=axs[1,1];ax.semilogx(tau*1e6,g2-fitted,color=B);ax.axhline(0,color=K,lw=.8);ax.set(xlabel=L('延迟时间 τ / μs','Delay time τ / μs'),ylabel=L('数据 − 拟合','Data − fit'),title=L('D  残差保留有限采样的起伏','D  Residuals retain finite-record fluctuations'));save(fig,'photon-correlation')

# Ideal Rayleigh mixture: homogeneous spheres of the same optical contrast.
ds=np.array([10.,30.]);num=np.array([.999,.001]);w=num*ds**6;w/=w.sum();rates=np.array([diffusion(d)*q*q for d in ds]);meanrate=np.dot(w,rates);variance=np.dot(w,(rates-meanrate)**2);PDI=variance/meanrate**2;z=diameter(meanrate/q**2)
tmix=np.geomspace(1e-7,.003,450);g1=np.exp(-tmix[:,None]*rates)@w;gmix=1+.5*g1*g1
cuts=np.array([.15,.3,.6,1.,1.5]);winz=[];winp=[]
for cut in cuts:
 m=tmix*meanrate<=cut;coef=np.polyfit(tmix[m]*meanrate,np.log(g1[m]),2);gr=-coef[1]*meanrate;mu2=2*coef[0]*meanrate**2;winz.append(diameter(gr/q**2));winp.append(mu2/gr**2)
csv('mixture.csv',['delay_s','field_correlation','intensity_correlation','matched_first_cumulant_g2'],[tmix,g1,gmix,1+.5*np.exp(-2*meanrate*tmix)])
csv('cumulant_window.csv',['maximum_scaled_delay','fitted_z_nm','fitted_PDI'],[cuts,winz,winp])
fig,axs=plt.subplots(2,2,figsize=(12,8.2),layout='constrained')
ax=axs[0,0];weightings=[num,num*ds**3/(num*ds**3).sum(),w];lab=L(['数量','体积','光强'],['Number','Volume','Intensity'])
for i,ww in enumerate(weightings):ax.barh(i,100*ww[0],color=B);ax.barh(i,100*ww[1],left=100*ww[0],color=R);ax.text(101,i,f'{100*ww[1]:.2f}%',va='center',fontsize=9)
ax.set(yticks=range(3),yticklabels=lab,xlim=(0,122),ylim=(-.5,3.1),xlabel=L('各类比例 / %','Fraction on each basis / %'),title=L('A  30 nm 颗粒只占数量的 0.1%','A  30 nm particles are only 0.1% by number'));ax.text(1,2.73,L('蓝：10 nm；红：30 nm','Blue: 10 nm; red: 30 nm'),fontsize=9)
ax=axs[0,1];ax.semilogx(tmix*1e6,gmix,color=B,lw=2,label=L('双粒径混合物','Two-size mixture'));ax.semilogx(tmix*1e6,1+.5*np.exp(-2*meanrate*tmix),color=R,ls='--',label=L('同一初始衰减率的单指数','Single exponential, same initial rate'));ax.set(xlabel=L('延迟时间 / μs','Delay time / μs'),ylabel='g₂(τ)',title=L('B  一条平滑曲线里可以藏着混合物','B  A smooth curve can conceal a mixture'));ax.legend(frameon=False,fontsize=8)
ax=axs[1,0];ax.plot(cuts,winz,'o-',color=B);ax.axhline(z,color=R,ls='--',label=L('精确初始矩','Exact initial moment'));ax.set(xlabel=L('拟合窗上限 Γ̄τ','Fit-window upper limit Γ̄τ'),ylabel=L('二阶展开给出的直径 / nm','Diameter from second-order expansion / nm'),title=L('C  截断展开依赖拟合区间','C  Truncated expansion depends on its window'));ax.legend(frameon=False,fontsize=9)
ax=axs[1,1];means=[np.dot(num,ds),z,np.dot(w,ds)];ax.bar(L(['数量均值','z 均值','光强算术均值'],['Number mean','z-average','Intensity arithmetic']),means,color=[G,B,R]);ax.set(ylabel=L('直径 / nm','Diameter / nm'),ylim=(0,24),title=L('D  三个“平均”回答不同问题','D  Three averages answer different questions'))
for j,v in enumerate(means):ax.text(j,v+.5,f'{v:.3f}',ha='center')
save(fig,'mixture-weighting')

tab=np.genfromtxt(Path(__file__).parent/'data/water_viscosity.csv',delimiter=',',names=True);temps=tab['temperature_C'];viscosities=tab['viscosity_mPa_s'];dapp=80*viscosities/.890
csv('viscosity_bias.csv',['temperature_C','published_viscosity_mPa_s','true_diameter_nm','inferred_with_fixed0890_nm'],[temps,viscosities,np.full(3,80),dapp])
fig,axs=plt.subplots(1,3,figsize=(14,4.8),gridspec_kw={'width_ratios':[1,1.1,1]},layout='constrained')
ax=axs[0];ax.plot(temps,viscosities,'o-',color=B);ax.set(xlabel=L('温度 / °C','Temperature / °C'),ylabel=L('水的黏度 / mPa·s','Water viscosity / mPa·s'),title=L('A  公开的水黏度数值','A  Published water viscosities'));ax.text(20.2,.72,'NIST SP1200-6, p.9',fontsize=9)
ax=axs[1];ax.plot(temps,dapp,'o-',color=R,label=L('误用固定 0.890 mPa·s','Fixed0.890 mPa·s input'));ax.axhline(80,color=B,ls='--',label=L('正确黏度：80 nm','Correct viscosity:80 nm'));ax.set(xlabel=L('真实温度 / °C','Actual temperature / °C'),ylabel=L('推算直径 / nm','Inferred diameter / nm'),ylim=(55,100),title=L('B  颗粒没变，错误输入制造变化','B  Wrong inputs create a size change'));ax.legend(frameon=False,fontsize=8)
ax=axs[2];ax.set(xlim=(-1.6,1.6),ylim=(-1.7,1.7),aspect='equal');ax.axis('off');ax.add_patch(Circle((0,.25),1.05,fc='#d9e9e8',ec=B,ls='--',lw=2));ax.add_patch(Circle((0,.25),.65,fc=Y,ec=K));ax.text(0,.25,L('核心','Core'),ha='center',va='center');ax.text(0,-1.18,L('溶剂化与表面层影响阻力\n水动力等效边界不是硬壳','Solvation and surface layers affect drag\nHydrodynamic equivalence is not a rigid shell'),ha='center',fontsize=9);ax.set_title(L('C  扩散测的是带环境的颗粒','C  Diffusion includes the environment'));save(fig,'viscosity-measurand')
summary={'data_kind':'constructed particle traces; published water-viscosity values','seed':810,'temperature_K':TK,'viscosity_Pa_s':eta,'q_per_m':float(q),'diffusion80_m2_per_s':float(D80),'diffusion240_m2_per_s':float(D240),'diffusion_size_ratio':float(D80/D240),'two_dimensional_msd80_at03s_um2':float(4*D80*.3*1e12),'photon_record_seconds':N*dt,'photon_mean_count_per_bin':float(counts.mean()),'fitted_diameter_nm':float(dfit),'fitted_coherence':float(beta_fit),'fitted_baseline':float(base_fit),'mixture_large_number_percent':.1,'mixture_large_intensity_percent':float(w[1]*100),'mixture_number_mean_nm':float(np.dot(num,ds)),'mixture_z_average_nm':float(z),'mixture_intensity_arithmetic_nm':float(np.dot(w,ds)),'mixture_PDI':float(PDI),'wrong_viscosity_diameter_at20C_nm':float(dapp[0]),'wrong_viscosity_diameter_at37C_nm':float(dapp[-1]),'published_water_viscosity25_mPa_s':float(viscosities[1])}
assert abs(D80/D240-3)<1e-12
assert abs(w[1]-.421875)<1e-12
assert abs(z-320/23)<1e-10
assert abs(summary['mixture_number_mean_nm']-10.02)<1e-12
assert 74<dfit<86 and .9<base_fit<1.1
assert abs(dapp[-1]-80*.692/.890)<1e-12
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary,ensure_ascii=False,indent=2))
