# Public sources and third-party materials

- Perrin: Nobel Lecture, Discontinuous Structure of Matter (1926): https://www.nobelprize.org/prizes/physics/1926/perrin/lecture/
  Technical/historical reference only; no source artwork or data reproduced.
- Hackley & Clogston: NIST SP1200-6, Batch-Mode DLS (2015): https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.1200-6.pdf
  Published numerical water-property facts retained with attribution; no source artwork reproduced.
- Malvern: Dynamic Light Scattering, An Introduction: https://www.malvernpanalytical.com/en/learn/knowledge-center/technical-notes/tn101104dynamiclightscatteringintroduction
  Technical/historical reference only; no source artwork or data reproduced.
- Mailer, Clegg & Pusey: Particle Sizing by DLS, Non-linear Cumulant Analysis: https://arxiv.org/pdf/1504.06502
  Technical/historical reference only; no source artwork or data reproduced.
- Malvern: Dynamic Light Scattering, Common Terms Defined: https://www.malvernpanalytical.com/en/learn/knowledge-center/whitepapers/wp111214dlstermsdefined
  Technical/historical reference only; no source artwork or data reproduced.
- Malvern: Cumulants and Distribution Algorithms: https://www.malvernpanalytical.com/en/learn/knowledge-center/faqs/faq160705cumulantsnnls
  Technical/historical reference only; no source artwork or data reproduced.
