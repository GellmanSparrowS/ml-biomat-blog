"""Mass spectrometry: charge, real MS/MS, LC-MS extraction and quantitation.
Run: python main.py --output results --language en
Requires numpy and matplotlib. Reads the bundled CC BY MassBank record offline.
Other signals are explicitly constructed teaching data, seed 630.
"""
from pathlib import Path
import argparse,json,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Rectangle,Polygon,FancyArrowPatch
P=argparse.ArgumentParser();P.add_argument('--output',type=Path,required=True);P.add_argument('--language',choices=['zh','en'],default='en');a=P.parse_args();O=a.output;O.mkdir(parents=True,exist_ok=True);L=a.language
def t(z,e):return z if L=='zh' else e
plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fcfbf7','axes.facecolor':'#fcfbf7','svg.fonttype':'none','text.color':'#25364a','axes.titleweight':'bold'})
B='#167d9a';R='#d35f47';G='#37967d';Y='#c49b35';D='#25364a'
def save(f,n):f.savefig(O/f'{n}-{L}.svg',bbox_inches='tight');f.savefig(O/f'{n}-{L}.png',bbox_inches='tight',dpi=145);plt.close(f)
def g(x,m,s):return np.exp(-.5*((x-m)/s)**2)
def csv(n,h,x):np.savetxt(O/n,x,delimiter=',',header=','.join(h),comments='',fmt='%.10g')
h=1.0072764665789;u=1.66053906892e-27;e=1.602176634e-19
neutral=8*12+10*1.00782503223+4*14.00307400443+2*15.99491461957;target=neutral+h
fig,axs=plt.subplots(1,3,figsize=(14.4,4.6),layout='constrained')
ax=axs[0];ax.set(xlim=(0,10),ylim=(0,8));ax.axis('off');ax.set_title(t('A  电喷雾：从液滴到离子','A  Electrospray: droplets to ions'))
ax.add_patch(Rectangle((.2,3.2),2,1.2,facecolor='#d3e2e6',edgecolor=B));ax.add_patch(Polygon([[2.2,3.2],[3,3.8],[2.2,4.4]],facecolor='#d3e2e6',edgecolor=B))
for x,y,r in [(3.5,3.8,.48),(4.8,4.3,.32),(5.6,3.4,.23),(6.7,4,.15)]:ax.add_patch(Circle((x,y),r,fc='#bad8df',ec=B));ax.text(x,y,'+',ha='center',va='center',color=B)
for y in [3.4,4,4.6]:ax.text(8,y,'M⁺',fontsize=12,color=R)
ax.annotate('',(9.5,3.9),(7.4,3.9),arrowprops={'arrowstyle':'->','color':R});ax.text(.5,6.4,t('电压 + 溶液\n蒸发与带电液滴演化','Voltage + solution\nEvaporation and charged droplets'),fontsize=10);ax.text(.5,1,t('1989：Fenn 等报告完整生物分子多电荷谱','1989: Fenn et al., multiply charged biomolecules'),fontsize=9,wrap=True)
ax=axs[1];ax.set(xlim=(0,10),ylim=(0,8));ax.axis('off');ax.set_title(t('B  激光解吸：基质帮助能量传递','B  Laser desorption: a supporting matrix'))
ax.add_patch(Rectangle((1,1.4),8,.4,fc='#8f9aab'));ax.add_patch(Polygon([[2,1.8],[3,2.5],[4,1.8],[5,2.7],[6,1.8],[7,2.4],[8,1.8]],fc='#e4c775',ec=Y));ax.annotate('',(4.8,2.6),(2,6.5),arrowprops={'arrowstyle':'->','lw':3,'color':R})
for x,y in [(5.5,3.7),(6.4,4.9),(7.4,5.8)]:ax.text(x,y,'M⁺',color=B)
ax.text(1,7,t('脉冲激光','Pulsed laser'),color=R);ax.text(1,.2,t('基质 + 待测分子；示意不按尺度','Matrix + analyte; schematic dimensions'),fontsize=9);ax.text(1,.95,t('1987：Tanaka 团队的软激光解吸','1987: Tanaka team, soft laser desorption'),fontsize=9)
ax=axs[2];mass=np.array([100,400,1600]);tof=1*np.sqrt(mass*u/(2*e*5000))*1e6;ax.plot(mass,tof,'o-',color=G);ax.set(xlabel=t('单电荷离子质量 / Da','Singly charged ion mass / Da'),ylabel=t('理想飞行时间 / μs','Ideal flight time / μs'),title=t('C  飞行时间：质量越大越慢','C  Flight time: larger mass, slower ion'));ax.text(.04,.83,'L=1 m; U=5 kV; z=1',transform=ax.transAxes,fontsize=10)
save(fig,'ionization')

fig,axs=plt.subplots(1,3,figsize=(14.4,4.8),layout='constrained');charge=np.arange(6,13);mz=12000/charge+h;intens=g(charge,9,1.6)
ax=axs[0];ax.vlines(mz,0,intens,color=B,lw=3)
for x,z,y in zip(mz,charge,intens):ax.text(x,y+.04,f'{z}+',ha='center',fontsize=9)
ax.set(xlabel='m/z',ylabel=t('构造相对强度','Constructed relative intensity'),title=t('A  一个 12,000 Da 分子的电荷系列','A  Charge series of one 12,000 Da molecule'),ylim=(0,1.25))
ax=axs[1];k=np.arange(5);pr=np.array([math.comb(50,int(i))*.0107**i*(1-.0107)**(50-i) for i in k]);pr/=pr.max()
for z,col in [(1,B),(2,R),(3,G)]:ax.vlines(k*1.00335483507/z,z-1,z-1+.65*pr,color=col,lw=3,label=f'z={z}')
ax.set(xlabel=t('相对首峰的 m/z 间隔','m/z displacement from first isotope'),ylabel=t('为比较而上下错开','Vertically offset for comparison'),title=t('B  同位素间距随电荷压缩','B  Charge compresses isotope spacing'),yticks=[]);ax.legend(frameon=False)
ax=axs[2];x=np.linspace(195.02,195.17,3000)
for j,(res,col) in enumerate([(5000,Y),(50000,B)]):
 sig=target/res/2.354820045;yy=g(x,target,sig)+.7*g(x,target+.01435,sig);ax.plot(x,yy+j*1.8,color=col,label=f'R={res:,}')
ax.set(xlabel='m/z',ylabel=t('构造信号，垂直错开','Constructed signal, offset'),title=t('C  分辨本领决定能否分开近邻','C  Resolving nearby ions'));ax.ticklabel_format(useOffset=False,axis='x');ax.legend(frameon=False,fontsize=9)
save(fig,'charge-resolution')

record=(Path(__file__).parent/'data/MSBNK-BAFG-CSL2311094663.txt').read_text(encoding='utf8');peaktext=record.split('PK$PEAK: m/z int. rel.int.')[1].split('//')[0];peaks=np.array([[float(x) for x in ln.split()] for ln in peaktext.splitlines() if ln.strip()]);assert len(peaks)==23
relative=100*peaks[:,1]/peaks[:,1].max();base=peaks[np.argmax(peaks[:,1]),0]
fig,axs=plt.subplots(1,2,figsize=(12.8,4.9),gridspec_kw={'width_ratios':[1.55,1]},layout='constrained');ax=axs[0];ax.vlines(peaks[:,0],0,relative,color=B,lw=1.8)
for i in np.argsort(relative)[-5:]:ax.text(peaks[i,0],relative[i]+3,f'{peaks[i,0]:.4f}',ha='center',fontsize=9,rotation=50)
ax.set(xlabel='m/z',ylabel=t('相对最大峰的强度 / %','Intensity relative to base peak / %'),ylim=(0,130),title=t('A  真实咖啡因 MS/MS：40 V','A  Actual caffeine MS/MS: 40 V'));ax.text(.03,.88,'MSBNK-BAFG-CSL2311094663',transform=ax.transAxes,fontsize=8)
ax=axs[1];ax.axis('off');ax.text(.02,.93,t('B  一个记录里的不同质量信息','B  Different mass information in one record'),weight='bold');lines=[t('分子式：C₈H₁₀N₄O₂','Formula: C₈H₁₀N₄O₂'),t('由同位素质量计算中性质量','Neutral mass calculated from isotope masses')+f'\n{neutral:.6f} Da',t('计算 [M+H]⁺','Calculated [M+H]⁺')+f'\nm/z {target:.6f}',t('记录前体设置：195.0877','Record precursor metadata: 195.0877'),t('谱内保留的峰：195.0873','Retained spectral peak: 195.0873'),t('CC BY；Ehlig, Lessmann, Jewell, Wick / BfG','CC BY; Ehlig, Lessmann, Jewell, Wick / BfG')]
for j,txt in enumerate(lines):ax.text(.02,.79-j*.145,txt,fontsize=10,va='top')
save(fig,'reference-spectrum');csv('reference_peaks.csv',['mz','original_intensity','record_relative_0_999','replotted_percent'],np.c_[peaks,relative])

# Constructed LC-MS scan matrix with target and nearby interfering ion.
rng=np.random.default_rng(630);time=np.linspace(0,8,801);masses=np.linspace(target-.04,target+.04,801);sig=target/40000/2.354820045
lc=g(time,4,.22);inter=g(time,4.4,.28);spectra=1000*lc[:,None]*g(masses,target,sig)[None,:]+800*inter[:,None]*g(masses,target+.01435,sig)[None,:]+rng.uniform(0,1,(len(time),len(masses)))
tic=spectra.sum(axis=1);narrow=np.abs(masses-target)<=target*5e-6;wide=np.abs(masses-target)<=target*100e-6;xic=spectra[:,narrow].sum(axis=1);broad=spectra[:,wide].sum(axis=1)
fig=plt.figure(figsize=(12.8,8),layout='constrained');gs=fig.add_gridspec(2,2);ax=fig.add_subplot(gs[:,0]);im=ax.imshow(np.log10(1+spectra),aspect='auto',origin='lower',extent=[masses[0],masses[-1],time[0],time[-1]],cmap='magma');ax.set(xlabel='m/z',ylabel=t('保留时间 / min','Retention time / min'),title=t('A  每个时间都有一张质谱','A  A spectrum at each time'));ax.ticklabel_format(useOffset=False,axis='x');fig.colorbar(im,ax=ax,label='log₁₀ (1 + signal)')
ax=fig.add_subplot(gs[0,1]);ax.plot(time,tic/tic.max(),color=Y,label=t('所示质量窗口总信号','Total in displayed mass window'));ax.plot(time,xic/xic.max(),color=B,label=t('目标 ±5 ppm','Target ±5 ppm'));ax.set(xlim=(3,5.5),xlabel=t('时间 / min','Time / min'),ylabel=t('各曲线除以自身最大值','Each curve / its own maximum'),title=t('B  提取目标的时间轨迹','B  Extract the target time trace'));ax.legend(frameon=False,fontsize=9)
ax=fig.add_subplot(gs[1,1]);ax.plot(time,xic/xic.max(),color=B,label='±5 ppm');ax.plot(time,broad/broad.max(),color=R,label='±100 ppm');ax.set(xlim=(3,5.5),xlabel=t('时间 / min','Time / min'),ylabel=t('各自归一化信号','Individually normalized signal'),title=t('C  宽窗口混入近邻','C  A wide window admits interference'));ax.legend(frameon=False)
save(fig,'lcms-map');csv('extracted_chromatograms.csv',['time_min','displayed_window_total','target_5ppm','target_100ppm'],np.c_[time,tic,xic,broad]);np.savez_compressed(O/'constructed_lcms.npz',time_min=time,mz=masses,signal=spectra)

c=np.repeat([0,1,2,5,10,20],3);ratio=.08*c+.01+rng.normal(0,.008,len(c));slope,intercept=np.polyfit(c,ratio,1);sample_true=8.;supp=.55;IS=500.;response=1000.;analyte=sample_true*response*supp;internal=IS*supp
# This separate ratio calibration uses response ratio = 0.08*c+0.01.
unknown_ratio=.08*sample_true+.01;estimated=(unknown_ratio-intercept)/slope
fig,axs=plt.subplots(2,2,figsize=(12.8,8),layout='constrained');ax=axs[0,0];ax.bar([0,1],[100,55],color=[G,R]);ax.set_xticks([0,1],[t('纯溶剂','Neat solvent'),t('提取后基质','Post-extraction matrix')]);ax.set(ylabel=t('等浓度目标响应 / %','Equal-concentration response / %'),title=t('A  基质因子 0.55','A  Matrix factor 0.55'),ylim=(0,115))
ax=axs[0,1];supps=np.linspace(.3,1,100);ax.plot(supps,sample_true*supps,color=R,label=t('按纯溶剂外标','Neat external calibration'));ax.plot(supps,np.full_like(supps,sample_true),color=B,label=t('同受抑制的内标比值','Matched internal-standard ratio'));ax.set(xlabel=t('共同响应因子','Common response factor'),ylabel=t('估计浓度 / ng/mL','Estimated concentration / ng/mL'),title=t('B  比值抵消共同变化','B  Ratios cancel shared changes'));ax.legend(frameon=False,fontsize=9)
ax=axs[1,0];ax.scatter(c,ratio,color=B,s=18);ax.plot([0,20],[intercept,20*slope+intercept],color=D);ax.set(xlabel=t('目标浓度 / ng/mL','Analyte concentration / ng/mL'),ylabel=t('目标 / 内标面积比','Analyte / internal-standard area'),title=t('C  构造比值校准与重复值','C  Constructed ratio calibration'))
ax=axs[1,1];xx=np.linspace(.3,1,100);ax.plot(xx,sample_true*.55/xx,color=R);ax.axhline(8,color=B,ls='--');ax.axvline(.55,color=Y,ls='--');ax.set(xlabel=t('内标响应因子','Internal-standard response factor'),ylabel=t('估计浓度 / ng/mL','Estimated concentration / ng/mL'),title=t('D  内标与目标不同步时','D  When the standard does not track analyte'))
save(fig,'quantitation');csv('ratio_calibration.csv',['concentration_ng_per_mL','area_ratio'],np.c_[c,ratio])
summary={'neutral_caffeine_Da':neutral,'protonated_caffeine_mz':target,'reference_peak_count':len(peaks),'reference_base_peak_mz':base,'reference_precursor_metadata_ppm':(195.0877-target)/target*1e6,'reference_retained_peak_ppm':(195.0873-target)/target*1e6,'charge_12_mz':12000/12+h,'isotope_spacing_z2':1.00335483507/2,'tof_400Da_5kV_us':float(tof[1]),'resolution_FWHM_R40000':target/40000,'matrix_factor':.55,'neat_external_apparent_ng_per_mL':8*.55,'matched_internal_standard_ng_per_mL':8.,'ratio_calibration_slope':float(slope),'ratio_calibration_unknown_ng_per_mL':float(estimated),'target_XIC_apex_min':float(time[np.argmax(xic)])}
assert abs(target-195.087652)<1e-6 and base==138.0657
assert abs(estimated-8)<.3 and abs(time[np.argmax(xic)]-4)<=.01
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
