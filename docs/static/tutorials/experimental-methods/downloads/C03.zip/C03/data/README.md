# Caffeine reference tandem mass spectrum

Record: MSBNK-BAFG-CSL2311094663, Caffeine; LC-ESI-QTOF; MS2; 40 V.
Authors: Björn Ehlig; Ole Lessmann; Kevin S. Jewell; Arne Wick.
Copyright 2026 Federal Institute of Hydrology (Bundesanstalt für Gewässerkunde), Koblenz, Germany.
Record license: CC BY. The record does not specify a license version. Its original license and attribution are retained in the unmodified bundled record.

Source: https://github.com/MassBank/MassBank-data/blob/dev/BAFG/MSBNK-BAFG-CSL2311094663.txt
Display: https://massbank.eu/MassBank/RecordDisplay?id=MSBNK-BAFG-CSL2311094663
Format and reuse documentation: https://github.com/MassBank/MassBank-documentation/blob/dev/MassBankRecordFormat.md

The record identifies a reference-standard spectrum with positive electrospray, collision-induced dissociation, SCIEX TripleTOF 5600, and precursor [M+H]+. The 23 original m/z and intensity pairs are retained. The plot divides original intensity by the largest intensity and multiplies by 100; it does not substitute the record's separately rounded 0–999 relative-intensity column. No chemical fragment formulas are newly assigned. Precursor metadata m/z=195.0877 differs from the retained precursor-like product peak at 195.0873; these are kept distinct.

Other chromatograms, isotope illustrations, calibration, suppression and resolution examples are original constructed teaching models, identified as such. They are not additional measurements of this record.
