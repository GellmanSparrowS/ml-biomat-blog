# Public sources and third-party materials

- Fenn et al. (1989): Electrospray ionization for mass spectrometry of large biomolecules: https://pubmed.ncbi.nlm.nih.gov/2675315/
  Technical/historical reference; original diagrams, no source artwork copied.
- Shimadzu: Koichi Tanaka research history: https://www.shimadzu.com/about/nobel/noblesoul/re_hstry.html
  Technical/historical reference; original diagrams, no source artwork copied.
- MassBank: MSBNK-BAFG-CSL2311094663: https://github.com/MassBank/MassBank-data/blob/dev/BAFG/MSBNK-BAFG-CSL2311094663.txt
  CC BY as specified in the record; authors and copyright retained; replotted intensities normalized to base peak.
- MassBank record format 2.6: https://github.com/MassBank/MassBank-documentation/blob/dev/MassBankRecordFormat.md
  Technical/historical reference; original diagrams, no source artwork copied.
- Waters: Mass accuracy and resolution: https://www.waters.com/nextgen/us/en/education/primers/the-mass-spectrometry-primer/mass-accuracy-and-resolution.html
  Technical/historical reference; original diagrams, no source artwork copied.
- Waters: Solvents and caveats for LC-MS: https://www.waters.com/nextgen/us/en/education/primers/the-mass-spectrometry-primer/solvents-and-caveats-for-lcms.html
  Technical/historical reference; original diagrams, no source artwork copied.
- Waters: Quantitation and calibration: https://www.waters.com/nextgen/us/en/education/primers/the-mass-spectrometry-primer/quantitation-and-calibration.html
  Technical/historical reference; original diagrams, no source artwork copied.
- NIST: Atomic weights and isotopic compositions: https://physics.nist.gov/cgi-bin/Compositions/stand_alone.pl
  Technical/historical reference; original diagrams, no source artwork copied.
- NIST: CODATA recommended constants 2022: https://physics.nist.gov/cuu/pdf/wall_2022.pdf
  Technical/historical reference; original diagrams, no source artwork copied.
