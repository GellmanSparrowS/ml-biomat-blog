# Public sources and third-party materials

- IUCr — Scope, potential and applications of X-ray analysis: https://www.iucr.org/education/pamphlets/2
  Public educational reference; figures original.
- IUCr — Calculation of structure factors: https://www.iucr.org/education/pamphlets/3
  Public educational reference; figures original.
- Nobel Foundation — 1915 presentation speech: https://www.nobelprize.org/prizes/physics/1915/ceremony-speech/
  Historical primary record; no historical image reproduced.
- NIST — SRM 1979 diffraction line-profile standard: https://www.nist.gov/publications/certification-standard-reference-material-1979-powder-diffraction-line-profile-standard
  Government research reference.
- NIST SRM 1979 certification paper: https://nvlpubs.nist.gov/nistpubs/jres/125/jres.125.020.pdf
  Government research publication; figures not reused.
