"""XRD teaching model: Bragg geometry, coherent domains and profile fitting.

Patterns are constructed, with no claimed identity as a measured material.
Peak areas use normalized discrete basis functions over this scan range.
"""
from pathlib import Path
import argparse,json,csv
import numpy as np
from scipy.optimize import nnls
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Arc

def peak_properties(d=.25,D=30.,instrument=.12,wavelength=.15406):
    theta=np.arcsin(wavelength/(2*d));center=np.rad2deg(2*theta)
    beta=np.rad2deg(.9*wavelength/(D*np.cos(theta)))
    observed=np.hypot(beta,instrument)
    naive=.9*wavelength/(np.deg2rad(observed)*np.cos(theta))
    return center,beta,observed,naive

def main(output,language):
    output.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'svg.fonttype':'none','font.size':11,'axes.titleweight':'bold','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','text.color':'#243b45','axes.labelcolor':'#243b45'})
    tr=lambda a,b:a if language=='zh' else b
    green,blue,red,gray='#168477','#3474a8','#bd624b','#788b90'
    def save(fig,name):
        fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');fig.savefig(output/f'{name}-{language}.png',dpi=140,bbox_inches='tight');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,5.5),layout='constrained')
    ax=axes[0];ax.set(xlim=(-5,5),ylim=(-3.8,4.5));ax.set_aspect('equal');ax.axis('off');ax.set_title(tr('A  布拉格几何：比较两条路程','A  Bragg geometry: compare two paths'))
    for y in [0,-1.6,-3.2]:
        ax.plot([-4.8,4.8],[y,y],color=gray,lw=1)
        ax.scatter(np.linspace(-4.5,4.5,10),np.full(10,y),s=23,color=gray)
    for y,col in [(0,green),(-1.6,blue)]:
        ax.annotate('',(0,y),(-4,y+2.8),arrowprops={'arrowstyle':'->','color':col,'lw':2});ax.annotate('',(4,y+2.8),(0,y),arrowprops={'arrowstyle':'->','color':col,'lw':2})
    ax.annotate('',(4.5,0),(4.5,-1.6),arrowprops={'arrowstyle':'<->','color':red});ax.text(4.65,-.8,'d',color=red);ax.text(-2.4,.25,'θ',color=green);ax.text(1.9,.25,'θ',color=green)
    ax.text(0,3.9,tr('额外路程：2d sinθ = nλ','Extra path: 2d sinθ = nλ'),ha='center',fontsize=13)
    ax.text(0,-3.75,tr('原子面为几何构造；电子散射形成干涉','Planes are a geometrical construction; scattering interferes'),ha='center',fontsize=9)
    ax=axes[1];ax.set(xlim=(0,10),ylim=(0,8));ax.axis('off');ax.set_title(tr('B  1912—1913：角度变成结构信息','B  1912–1913: angle becomes structure'))
    ax.plot([1,5,9],[6,2,6],color=blue,lw=3);ax.scatter([5],[2],s=400,marker='D',color=green);ax.text(.5,6.6,tr('X射线','X-rays'));ax.text(4.3,1,tr('晶体','Crystal'));ax.text(8,6.6,tr('探测器','Detector'))
    ax.add_patch(Arc((5,2),5,5,theta1=45,theta2=135,color=red,lw=1.5));ax.text(5,5,tr('扫描散射方向','Scan scattering direction'),ha='center')
    ax.text(5,.1,tr('晶体周期 → 峰位置；内部排列 → 强度','Crystal periodicity → positions; arrangement → intensities'),ha='center',fontsize=10)
    save(fig,'bragg')
    fig,axes=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
    phase=np.linspace(-.7,.7,2001)
    for N,col in [(10,green),(30,red),(80,blue)]:
        amplitude=np.sum(np.exp(1j*np.outer(phase,np.arange(N))),axis=1)/N
        axes[0].plot(phase,np.abs(amplitude)**2,color=col,label=f'N={N}',lw=2)
    axes[0].set(xlabel=tr('相邻周期相位偏离 / rad','Phase offset per repeat / rad'),ylabel=tr('归一化干涉强度','Normalized interference intensity'),title=tr('A  有序周期越多，峰越窄','A  More coherent repeats, narrower peaks'));axes[0].legend(frameon=False)
    sizes=np.linspace(5,120,200);widths=np.array([peak_properties(D=d)[2] for d in sizes]);naive=np.array([peak_properties(D=d)[3] for d in sizes]);axes[1].plot(sizes,naive,color=red,lw=2,label=tr('直接用观测宽度','Using observed width'));axes[1].plot(sizes,sizes,color=green,ls='--',label=tr('扣除已知仪器高斯宽度','Known Gaussian instrument correction'));axes[1].set(xlabel=tr('设定相干尺寸 / nm','Specified coherent size / nm'),ylabel=tr('估计尺寸 / nm','Estimated size / nm'),title=tr('B  仪器展宽需要标定','B  Instrument broadening needs calibration'));axes[1].legend(frameon=False,fontsize=9)
    save(fig,'coherence')
    angle=np.linspace(10,70,3001);ds=np.array([.4,.25,.2]);centers=np.array([peak_properties(d=d)[0] for d in ds]);widths=np.array([peak_properties(d=d)[2] for d in ds])
    def g(center,width):
        v=np.exp(-4*np.log(2)*((angle-center)/width)**2);return v/v.sum()
    crystalline=np.column_stack([g(c,w) for c,w in zip(centers,widths)]);amorphous=g(23,9);design=np.column_stack([crystalline,amorphous,np.ones(len(angle))]);truth=np.array([16000.,22000.,12000.,35000.,12.]);expected=design@truth;rng=np.random.default_rng(1706);observed=rng.poisson(expected);coef,_=nnls(design,observed);fit=design@coef;residual=(observed-fit)/np.sqrt(np.maximum(fit,1))
    fig,axes=plt.subplots(2,2,figsize=(11,8),layout='constrained')
    axes[0,0].plot(angle,observed,color=gray,lw=.7,label=tr('构造观测','Constructed observation'));axes[0,0].plot(angle,fit,color=green,lw=1.5,label=tr('已知峰形联合拟合','Joint fit with known shapes'));axes[0,0].set(xlabel='2θ / °',ylabel=tr('计数 / 步','Counts / step'),title=tr('A  完整扫描与拟合','A  Full scan and profile fit'));axes[0,0].legend(frameon=False,fontsize=9)
    axes[0,1].plot(angle,crystalline@coef[:3],color=blue,label=tr('晶体峰贡献','Crystalline peaks'));axes[0,1].plot(angle,amorphous*coef[3],color=red,label=tr('宽散射贡献','Broad contribution'));axes[0,1].axhline(coef[4],color=gray,label=tr('常数背景','Constant background'));axes[0,1].set(xlabel='2θ / °',ylabel=tr('计数 / 步','Counts / step'),title=tr('B  区分峰、宽散射与背景','B  Peaks, broad scattering and background'));axes[0,1].legend(frameon=False,fontsize=9)
    axes[1,0].plot(angle,residual,color=green,lw=.6);axes[1,0].axhline(0,color=gray);axes[1,0].set(xlabel='2θ / °',ylabel=tr('标准化残差','Standardized residual'),title=tr('C  检查未解释的角度结构','C  Inspect unexplained angular structure'))
    choices=np.linspace(8,16,80);indices=[]
    for bg in choices:
        a,_=nnls(design[:,:4],observed-bg);indices.append(a[:3].sum()/a[:4].sum())
    axes[1,1].plot(choices,np.array(indices)*100,color=red,lw=2);axes[1,1].axvline(12,color=gray,ls='--');axes[1,1].set(xlabel=tr('固定背景 / 计数每步','Fixed background / counts per step'),ylabel=tr('模型峰面积指数 / %','Model peak-area index / %'),title=tr('D  背景选择改变面积分解','D  Background changes the area decomposition'))
    save(fig,'profile')
    with (output/'data.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['two_theta_deg','expected_counts','constructed_counts','fitted_counts','standardized_residual']);w.writerows(zip(angle,expected,observed,fit,residual))
    center,beta,bobs,naive=peak_properties();exact,_=nnls(design,expected)
    summary={'center_d025_deg':center,'size_fwhm_D30_deg':beta,'observed_fwhm_deg':bobs,'uncorrected_size_nm':naive,'corrected_size_nm':.9*.15406/(np.deg2rad(np.sqrt(bobs*bobs-.12**2))*np.cos(np.deg2rad(center/2))),'true_area_index':50000/85000,'fitted_area_index':float(coef[:3].sum()/coef[:4].sum()),'noiseless_area_index':float(exact[:3].sum()/exact[:4].sum()),'q_d025_invnm':2*np.pi/.25,'peak_positions_deg':centers.tolist(),'data_origin':'Constructed teaching pattern, not an experimental phase or crystallinity measurement.'}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
