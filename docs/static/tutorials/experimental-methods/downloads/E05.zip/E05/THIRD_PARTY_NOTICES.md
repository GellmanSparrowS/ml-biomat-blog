# Public sources and third-party materials

- Fick (1855). On liquid diffusion: https://doi.org/10.1080/14786445508641925
  Bibliographic reference; no assets reproduced.
- Daynes (1920). The process of diffusion through a rubber membrane: https://doi.org/10.1098/rspa.1920.0034
  Historical reference; no assets reproduced.
- Imperial College London ReCoDe: Time Lag Analysis, A Theoretical Foundation: https://raw.githubusercontent.com/ImperialCollegeLondon/ReCoDe-permeation-analysis-app/main/docs/02-Theoretical-Background.md
  Technical reference; original code and figures authored for this chapter.
- COMSOL: Diffusion Equation: https://www.comsol.com/multiphysics/diffusion-equation
  Technical reference; no assets reproduced.
- COMSOL: Diffusion Length and Timescales: https://www.comsol.com/multiphysics/diffusion-length-and-time-scales
  Technical reference; no assets reproduced.
- Axelrod et al. (1976). Mobility measurement by analysis of fluorescence photobleaching recovery kinetics: https://pubmed.ncbi.nlm.nih.gov/786399/
  Original abstract reference; no images reproduced.
- FDA (2022 draft). In Vitro Permeation Test Studies for Topical Drug Products Submitted in ANDAs: https://www.fda.gov/regulatory-information/search-fda-guidance-documents/in-vitro-permeation-test-studies-topical-drug-products-submitted-andas
  Official draft guidance; technical reading, with no assets reproduced.
