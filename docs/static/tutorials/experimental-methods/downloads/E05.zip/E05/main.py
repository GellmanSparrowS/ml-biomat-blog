"""Planar diffusion, steady permeation, time-lag analysis and idealized FRAP."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,FancyArrowPatch,Circle

def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def permeated(time,D=1e-6,L=.05,K=.5,C=100.,area=1.):
    t=np.atleast_1d(time).astype(float);n=np.arange(1,201)[:,None]
    correction=np.sum((-1.)**n/n**2*np.exp(-D*n*n*np.pi**2*t[None,:]/L**2),axis=0)
    q=area*D*K*C/L*(t-L**2/(6*D)-2*L**2/(np.pi**2*D)*correction)
    return np.where(t==0,0,np.maximum(q,0))

def profile(x,time,D=1e-6,L=.05,K=.5,C=100.):
    x=np.asarray(x);n=np.arange(1,201)[:,None]
    if time==0:return np.where(x==0,K*C,0.)
    return K*C*(1-x/L-2/np.pi*np.sum(np.sin(n*np.pi*x/L)/n*np.exp(-D*n*n*np.pi**2*time/L**2),axis=0))

def frap_center(time,D=1.,radius=5.,mobile=.75,depth=.8):
    return 1-depth*((1-mobile)+mobile*radius**2/(radius**2+4*D*np.asarray(time)))

def main(output,language):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    from matplotlib import font_manager
    fonts={f.name for f in font_manager.fontManager.ttflist};font=next((f for f in ['Microsoft YaHei','Noto Sans CJK SC','SimHei'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[font,'DejaVu Sans'] if language=='zh' else ['DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','axes.prop_cycle':plt.cycler(color=['#186e83','#cd803f','#8160a1','#3c8a6a'])})
    tr=lambda z,e:z if language=='zh' else _label(e)
    def save(fig,n):fig.savefig(output/f'{n}-{language}.svg',bbox_inches='tight');plt.close(fig)
    fig,ax=plt.subplots(1,3,figsize=(12,4.2))
    for a in ax:a.set(xlim=(0,10),ylim=(0,10));a.axis('off')
    ax[0].add_patch(Rectangle((1,2),8,6,facecolor='#e2eef0'));rng=np.random.default_rng(505)
    ax[0].scatter(rng.uniform(1.5,4.8,40),rng.uniform(2.5,7.5,40),s=12,color='#186e83');ax[0].scatter(rng.uniform(5.2,8.5,12),rng.uniform(2.5,7.5,12),s=12,color='#186e83');ax[0].add_patch(FancyArrowPatch((3,1.5),(7,1.5),arrowstyle='->',mutation_scale=17,color='#cd803f'));ax[0].set_title(tr('1855 · Fick：浓度梯度与通量','1855 · Fick: gradient and flux'));ax[0].text(5,.5,tr('从高浓度到低浓度的净传输','Net transfer from high to low concentration'),ha='center',fontsize=9)
    ax[1].add_patch(Rectangle((1,2),3.5,6,facecolor='#a2cdd9'));ax[1].add_patch(Rectangle((5.5,2),3.5,6,facecolor='#e2eef0'));ax[1].add_patch(Rectangle((4.5,2),1,6,facecolor='#8160a1'));ax[1].text(2.6,5,tr('供体','Donor'),ha='center');ax[1].text(7.3,5,tr('接收体','Receiver'),ha='center');ax[1].add_patch(FancyArrowPatch((3,1.5),(7,1.5),arrowstyle='->',mutation_scale=17,color='#cd803f'));ax[1].set_title(tr('1920 · Daynes：穿膜的时间滞后','1920 · Daynes: permeation time lag'));ax[1].text(5,.5,tr('膜内先建立浓度分布','A concentration profile develops in the membrane'),ha='center',fontsize=8.5)
    ax[2].add_patch(Rectangle((1,2),8,6,facecolor='#3c8a6a'));ax[2].add_patch(Circle((5,5),1.4,color='#123d36'));ax[2].add_patch(FancyArrowPatch((2,5),(4,5),arrowstyle='->',mutation_scale=17,color='white'));ax[2].add_patch(FancyArrowPatch((8,5),(6,5),arrowstyle='->',mutation_scale=17,color='white'));ax[2].set_title(tr('1976 · Axelrod 等：漂白后的恢复','1976 · Axelrod et al.: recovery after bleaching'));ax[2].text(5,1,tr('跟随明亮分子进入暗区','Follow bright molecules entering a bleached region'),ha='center',fontsize=9);fig.tight_layout();save(fig,'history')
    x=np.linspace(0,.05,201);times=np.linspace(0,1800,181);field=np.array([profile(x,t) for t in times]);fig,ax=plt.subplots(1,2,figsize=(11,4.8));im=ax[0].imshow(field,origin='lower',aspect='auto',extent=(0,.5,0,30),cmap='cividis',vmin=0,vmax=50);fig.colorbar(im,ax=ax[0],label=tr('膜内浓度 / μg mL⁻¹','Membrane concentration / μg mL⁻¹'));ax[0].set(xlabel=tr('膜内位置 / mm','Position in membrane / mm'),ylabel=tr('时间 / min','Time / min'),title=tr('A  浓度如何逐渐建立','A  Development of concentration'))
    for t in [30,120,600,1800]:ax[1].plot(x*10,profile(x,t),label=f'{t/60:g} min')
    ax[1].plot(x*10,50*(1-x/.05),'--',color='#8f979a',label=tr('稳态','Steady state'));ax[1].set(xlabel=tr('膜内位置 / mm','Position in membrane / mm'),ylabel=tr('浓度 / μg mL⁻¹','Concentration / μg mL⁻¹'),title=tr('B  从弯曲分布到稳定梯度','B  Curved profiles approach a stable gradient'));ax[1].legend(fontsize=9);fig.tight_layout();save(fig,'profiles')
    t=np.linspace(0,7200,121);q=permeated(t);noisy=q+rng.normal(0,.01,len(t));mask=t>=2400;slope,intercept=np.polyfit(t[mask],noisy[mask],1);lag=-intercept/slope;dfit=.05**2/(6*lag);pfit=slope/100
    np.savetxt(output/'permeation.csv',np.column_stack([t,t/60,q,noisy]),delimiter=',',header='time_s,time_min,ideal_received_ug,constructed_observed_ug',comments='');np.savez(output/'profiles.npz',position_cm=x,time_s=times,concentration_ug_ml=field)
    fig,ax=plt.subplots(2,2,figsize=(11.4,7.3));ax=ax.ravel();ax[0].plot(t/60,noisy,'.',ms=3,label=tr('构造观测','Constructed observations'));ax[0].plot(t/60,slope*t+intercept,label=tr('40 min 后拟合','Fit after 40 min'));ax[0].scatter([lag/60],[0],color='#cd803f',zorder=5);ax[0].set(xlabel=tr('时间 / min','Time / min'),ylabel=tr('接收量 / μg','Received mass / μg'),title=tr('A  稳态斜率与时间轴截距','A  Steady slope and time-axis intercept'));ax[0].legend(fontsize=8)
    starts=np.arange(120,4201,120);fits=[]
    for start in starts:
        m=t>=start;ss,ii=np.polyfit(t[m],noisy[m],1);fits.append(-ii/ss/60)
    ax[1].plot(starts/60,fits);ax[1].axhline(.05**2/6e-6/60,color='#cd803f',ls='--');ax[1].set(xlabel=tr('拟合开始时间 / min','Fit start time / min'),ylabel=tr('估计滞后 / min','Estimated lag / min'),title=tr('B  拟合窗口的敏感性','B  Sensitivity to fitting window'))
    for L in [.025,.05,.1]:ax[2].plot(t/60,permeated(t,L=L),label=f'{L*10:g} mm')
    ax[2].set(xlabel=tr('时间 / min','Time / min'),ylabel=tr('接收量 / μg','Received mass / μg'),title=tr('C  厚度改变速率与滞后','C  Thickness changes rate and lag'));ax[2].legend(fontsize=9)
    finite_t=np.linspace(0,48*3600,300);qfinite=(100*2*10/12)*(-np.expm1(-1e-5*(1/2+1/10)*finite_t));ax[3].plot(finite_t/3600,qfinite,label=tr('有限供体与接收体','Finite donor and receiver'));ax[3].plot(finite_t/3600,.001*finite_t,'--',label=tr('恒定驱动力外推','Constant-driving-force extrapolation'));ax[3].axhline(200,color='#8f979a',ls=':');ax[3].set(xlabel=tr('时间 / h','Time / h'),ylabel=tr('接收量 / μg','Received mass / μg'),title=tr('D  有限容积改变长期驱动力','D  Finite volumes change long-term driving force'));ax[3].legend(fontsize=8);fig.tight_layout();save(fig,'analysis')
    grid=np.linspace(-15,15,181);xx,yy=np.meshgrid(grid,grid);r2=xx**2+yy**2;fig=plt.figure(figsize=(11,7));gs=fig.add_gridspec(2,3,height_ratios=[1,1.1]);axs=[fig.add_subplot(gs[0,j]) for j in range(3)]
    for a,tm in zip(axs,[0,5,30]):
        intensity=1-.8*(.25*np.exp(-r2/25)+.75*25/(25+4*tm)*np.exp(-r2/(25+4*tm)));a.imshow(intensity,origin='lower',extent=(-15,15,-15,15),cmap='viridis',vmin=0,vmax=1);a.plot([5,10],[-12,-12],color='#17333a',lw=3);a.text(7.5,-10,'5 μm',ha='center',color='#17333a',fontsize=8);a.set_title(f'{tm} s');a.set_xticks([]);a.set_yticks([])
    a=fig.add_subplot(gs[1,:]);ft=np.linspace(0,120,241)
    for radius,mobile in [(5,.75),(10,.75),(5,1)]:a.plot(ft,frap_center(ft,radius=radius,mobile=mobile),label=tr(f'半径 {radius} μm，可动比例 {mobile:.2f}',f'Radius {radius} μm, mobile fraction {mobile:.2f}'))
    a.set(xlabel=tr('漂白后时间 / s','Time after bleaching / s'),ylabel=tr('中心归一化亮度','Normalized central brightness'),title=tr('理想二维高斯漂白模型：空间扩散与可动比例','Ideal 2D Gaussian-bleach model: spreading and mobile fraction'));a.legend(fontsize=9);fig.tight_layout();save(fig,'frap')
    summary={'nominal':{'D_cm2_s':1e-6,'partition':.5,'thickness_cm':.05,'P_cm_s':1e-5,'steady_flux_ug_cm2_h':3.6,'lag_s':.05**2/6e-6,'lag_min':.05**2/6e-6/60},'fit':{'slope_ug_s':float(slope),'lag_s':float(lag),'D_cm2_s':float(dfit),'P_cm_s':float(pfit)},'scaling':{'double_thickness_flux_ratio':.5,'double_thickness_lag_ratio':4,'double_distance_time_ratio':4},'frap':{'prebleach':1,'immediate':float(frap_center(0)),'plateau':.8,'mobile_fraction':.75,'half_recovery_s':6.25,'at_half_recovery':float(frap_center(6.25))},'finite_bath':{'initial_mass_ug':200,'equilibrium_received_ug':100*2*10/12},'checks':{'q_at_zero':float(permeated([0])[0]),'late_mass_ug':float(permeated([7200])[0]),'late_linear_ug':.001*(7200-.05**2/6e-6)}}
    assert abs(summary['checks']['late_mass_ug']-summary['checks']['late_linear_ug'])<1e-9;assert abs(frap_center(6.25)-.5)<1e-12;assert np.all(field>=-1e-9)
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
