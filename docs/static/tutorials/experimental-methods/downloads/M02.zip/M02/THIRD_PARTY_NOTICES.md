# Public sources and third-party materials

- Mow et al. — Biphasic creep and stress relaxation (1980): https://pubmed.ncbi.nlm.nih.gov/7382457/
  Bibliographic record consulted; no figures reused.
- CellScale — Compression testing methods for soft materials and biomaterials: https://cellscale.com/applications/testing-methods/compression/
  Copyright CellScale; technical reading only, no data or figures reused.
- DoITPoMS — Compression, friction and barrelling: https://eng.libretexts.org/Bookshelves/Materials_Science/TLP_Library_II/5:_Mechanical_Testing_of_Metals/5.7:_Compression_Testing_-_Practical_Basics_Friction_and_Barrelling
  CC BY-NC-SA reference consulted; no figures or text adapted.
- Lakes — Meaning of Poisson ratio: https://lakeslab.ep.wisc.edu/PoissonIntro2.html
  University teaching reference; original derivation and diagrams here.
- Sandia LAMÉ manual — Neo-Hookean model: https://www.sandia.gov/files/sierra/SM_LAME_5_24/main/models/neo_hookean.html
  Official technical reference; no figures reused.
