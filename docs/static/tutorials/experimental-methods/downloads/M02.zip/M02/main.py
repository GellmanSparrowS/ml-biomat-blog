"""Compression geometry, contact identification and a specified drainage model.
All numerical records are constructed teaching examples, not tissue measurements.
python main.py --output results --language en
"""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Polygon

def nominal(e,mu=20.):
    lam=1-np.asarray(e)
    return mu*(lam**-2-lam)

def pressure_mean(t,H=2.,D=.01,p0=10.):
    t=np.asarray(t,dtype=float);n=np.arange(1,400,2,dtype=float)
    y=8*p0/np.pi**2*np.sum(np.exp(-np.outer(t.ravel(),n*n)*np.pi**2*D/H**2)/(n*n),axis=1)
    return np.where(t.ravel()==0,p0,y).reshape(t.shape)

def pressure_field(z,t,H=2.,D=.01,p0=10.):
    z=np.asarray(z);n=np.arange(1,400,2,dtype=float)
    if t==0:return np.where((z>0)&(z<H),p0,0.)
    return 4*p0/np.pi*np.sum(np.sin(np.outer(z,n)*np.pi/H)*np.exp(-n*n*np.pi**2*D*t/H**2)/n,axis=1)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();o=a.output;o.mkdir(parents=True,exist_ok=True);tr=lambda z,e:z if a.language=='zh' else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fbfcfc','savefig.facecolor':'#fbfcfc','text.color':'#18344a'})
    B='#186c94';G='#188777';O='#d27839';P='#8a5d92'
    def save(f,n):f.savefig(o/f'{n}-{a.language}.svg',bbox_inches='tight');f.savefig(o/f'{n}-{a.language}.png',bbox_inches='tight',dpi=150);plt.close(f)
    rng=np.random.default_rng(1902);R=3.;H=2.;A=np.pi*R*R;u=np.linspace(-.1,.8,241);contact=.06;baseline=.0015
    model=lambda v:nominal(np.maximum(u-v[1],0)/H,v[0])*A/1000+v[2]
    force=model([20,contact,baseline])+rng.normal(0,.002,len(u))
    fit=least_squares(lambda v:model(v)-force,[18,.04,0],bounds=([1,-.05,-.02],[100,.15,.02])).x;pred=model(fit)
    t=np.linspace(0,300,301);pmean=pressure_mean(t);F=(5+pmean)*A/1000;Fobs=F+rng.normal(0,.0005,len(t))
    Dfit=float(np.exp(least_squares(lambda q:((5+pressure_mean(t,D=np.exp(q[0])))*A/1000-Fobs),[np.log(.02)]).x[0]))
    summary={'fit_mu_kPa':float(fit[0]),'fit_contact_mm':float(fit[1]),'fit_baseline_N':float(fit[2]),'residual_rms_mN':float(np.sqrt(np.mean((pred-force)**2))*1000),'nominal_at_20pct_kPa':float(nominal(.2)),'true_at_20pct_kPa':float(.8*nominal(.2)),'force_at_20pct_N':float(nominal(.2)*A/1000),'free_modulus_kPa':60.,'confined_modulus_nu045_kPa':60*.55/(1.45*.1),'tau_H2_s':4/(np.pi**2*.01),'tau_H4_s':16/(np.pi**2*.01),'fit_diffusivity_mm2_s':Dfit,'initial_force_N':float(15*A/1000),'equilibrium_force_N':float(5*A/1000),'mean_pressure_40s_kPa':float(pressure_mean(40.))}
    (o/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');np.savetxt(o/'data.csv',np.c_[u,force,pred,force-pred],delimiter=',',header='stage_closure_mm,observed_force_N,fitted_force_N,residual_N',comments='');np.savetxt(o/'drainage.csv',np.c_[t,pmean,F,Fobs],delimiter=',',header='time_s,mean_excess_pressure_kPa,model_force_N,observed_force_N',comments='')
    z=np.linspace(0,H,201);times=np.array([0,2,10,40,100,300]);fields=np.array([pressure_field(z,tt) for tt in times]);np.savez(o/'pressure_fields.npz',z_mm=z,time_s=times,pressure_kPa=fields)
    f,ax=plt.subplots(2,2,figsize=(12,8));labels=[tr('a  自由侧向膨胀','a  Free lateral expansion'),tr('b  端面摩擦与鼓肚','b  End friction and barrelling'),tr('c  刚性侧壁约束','c  Rigid lateral confinement'),tr('d  1980：固体网络与流体共同承载','d  1980: solid network and fluid support')]
    for i,x in enumerate(ax.flat):
        x.set(xlim=(0,10),ylim=(0,7));x.axis('off');x.set_title(labels[i],loc='left',fontweight='bold',fontsize=12)
        if i<3:
            for yy in [1,5]:x.add_patch(Rectangle((1,yy),8,.45,facecolor='#8b9ca7'))
            if i==1:
                yy=np.linspace(1.45,5,80);left=3-.8*np.sin(np.pi*(yy-1.45)/3.55);right=7+.8*np.sin(np.pi*(yy-1.45)/3.55);x.fill(np.r_[left,right[::-1]],np.r_[yy,yy[::-1]],color=G,alpha=.28);x.plot(left,yy,color=G);x.plot(right,yy,color=G)
            else:x.add_patch(Rectangle((2.7 if i==0 else 3,1.45),4.6 if i==0 else 4,3.55,facecolor='#d0e9e4',edgecolor=G,lw=2))
            if i==2:
                for xx in [2.5,7]:x.add_patch(Rectangle((xx,1),.5,4.4,facecolor='#526b7a'))
            x.annotate('',(5,5.5),(5,6.6),arrowprops={'arrowstyle':'->','color':O,'lw':2})
            x.text(5,.3,[tr('侧面自由；端面滑动','Free sides; sliding ends'),tr('端部受阻；中部更宽','Restrained ends; wider middle'),tr('横向应变为零','Zero lateral strain')][i],ha='center')
        else:
            for xx in np.linspace(2,8,5):x.plot([xx,xx],[1.7,5.3],color=G,lw=2)
            for yy in np.linspace(1.7,5.3,4):x.plot([2,8],[yy,yy],color=G,lw=2)
            for xx in np.linspace(2.6,7.4,4):
                for yy in [2.3,3.5,4.7]:x.scatter(xx,yy,s=70,color=B,alpha=.55)
            x.annotate('',(8.9,3.5),(7.8,3.5),arrowprops={'arrowstyle':'->','color':B,'lw':2});x.text(5,.5,tr('Mow、Kuei、Lai、Armstrong：双相力学','Mow, Kuei, Lai, Armstrong: biphasic mechanics'),ha='center',fontsize=10)
    f.tight_layout();save(f,'geometry')
    f,ax=plt.subplots(2,2,figsize=(12,8));ax[0,0].scatter(u,force,s=9,color=B,alpha=.55,label=tr('构造观测','Constructed observations'));ax[0,0].plot(u,pred,color=O,label=tr('接触点与材料联合拟合','Joint contact/material fit'));ax[0,0].axvline(contact,color=G,ls='--');ax[0,0].set(xlabel=tr('平台闭合位移 / mm','Stage closure / mm'),ylabel=tr('力 / N','Force / N'),title=tr('a  先找到接触，再计算压缩','a  Find contact before compression'));ax[0,0].legend(fontsize=9)
    ax[0,1].scatter(u,(force-pred)*1000,s=9,color=B);ax[0,1].axhline(0,color='#82939c');ax[0,1].set(xlabel=tr('平台闭合位移 / mm','Stage closure / mm'),ylabel=tr('残差 / mN','Residual / mN'),title=tr('b  剩下的是怎样的误差','b  What remains after fitting'))
    e=np.linspace(0,.4,201);ax[1,0].plot(e*100,nominal(e),color=B,label='Neo-Hookean');ax[1,0].plot(e*100,60*e,color=G,ls='--',label=tr('初始切线 E₀=60 kPa','Initial tangent E₀=60 kPa'));ax[1,0].scatter([20],[15.25],color=O);ax[1,0].set(xlabel=tr('压缩工程应变 / %','Engineering compression / %'),ylabel=tr('名义压应力 / kPa','Nominal compression stress / kPa'),title=tr('c  弯曲曲线仍可完全弹性','c  A curved response can be elastic'));ax[1,0].legend(fontsize=9)
    ax[1,1].plot(e*100,nominal(e),label=tr('原始面积','Original area'),color=B);ax[1,1].plot(e*100,(1-e)*nominal(e),label=tr('当前面积','Current area'),color=O);ax[1,1].set(xlabel=tr('压缩工程应变 / %','Engineering compression / %'),ylabel=tr('压应力 / kPa','Compression stress / kPa'),title=tr('d  分母面积改变数值','d  Area definition changes the value'));ax[1,1].legend();f.tight_layout();save(f,'contact')
    f,ax=plt.subplots(1,2,figsize=(12,4.8));nu=np.linspace(0,.49,200);M=60*(1-nu)/((1+nu)*(1-2*nu));ax[0].plot(nu,M,color=P);ax[0].axhline(60,color=G,ls='--',label=tr('自由压缩 E=60 kPa','Free compression E=60 kPa'));ax[0].scatter([.45],[60*.55/(1.45*.1)],color=O);ax[0].set(xlabel=tr('泊松比 ν','Poisson ratio ν'),ylabel=tr('约束压缩模量 / kPa','Constrained modulus / kPa'),title=tr('a  同一材料，不同侧向约束','a  Same material, different constraint'));ax[0].legend()
    ax[1].plot(e*100,1/(1-e),color=B,label=tr('面积 / 原始面积','Area / original area'));ax[1].plot(e*100,1/np.sqrt(1-e),color=O,label=tr('半径 / 原始半径','Radius / original radius'));ax[1].set(xlabel=tr('压缩工程应变 / %','Engineering compression / %'),ylabel=tr('几何比值','Geometric ratio'),title=tr('b  不可压缩指体积守恒','b  Incompressible means constant volume'));ax[1].legend();f.tight_layout();save(f,'constraint')
    f,ax=plt.subplots(2,2,figsize=(12,8));colors=plt.cm.viridis(np.linspace(.05,.85,5))
    for tt,c in zip([2,10,40,100,300],colors):ax[0,0].plot(z,pressure_field(z,tt),color=c,label=f'{tt} s')
    ax[0,0].set(xlabel=tr('层内位置 / mm','Position in layer / mm'),ylabel=tr('超额压力 / kPa','Excess pressure / kPa'),title=tr('a  两端排液的压力分布','a  Pressure with two drained faces'));ax[0,0].legend(ncol=2,fontsize=9)
    for hh,c in [(2,B),(4,O)]:ax[0,1].plot(t,pressure_mean(t,H=hh),color=c,label=f'H={hh} mm')
    ax[0,1].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('平均超额压力 / kPa','Mean excess pressure / kPa'),title=tr('b  厚度翻倍，时间尺度乘四','b  Double thickness, four times the scale'));ax[0,1].legend()
    for hh,c,st in [(2,B,'-'),(4,O,'--')]:ax[1,0].plot(t*.01/hh**2,pressure_mean(t,H=hh)/10,color=c,ls=st,label=f'H={hh} mm')
    ax[1,0].set(xlim=(0,.5),xlabel='Dt / H²',ylabel=tr('平均压力 / 初始压力','Mean / initial pressure'),title=tr('c  用排液长度归一化','c  Scale time by drainage length'));ax[1,0].legend()
    ax[1,1].fill_between(t,0,np.full_like(t,5*A/1000),color=G,alpha=.35,label=tr('指定固体部分','Specified solid contribution'));ax[1,1].fill_between(t,5*A/1000,F,color=B,alpha=.3,label=tr('压力部分','Pressure contribution'));ax[1,1].plot(t,F,color=B);ax[1,1].scatter(t[::10],Fobs[::10],s=12,color=O,label=tr('构造观测','Constructed observations'));ax[1,1].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('合力 / N','Total force / N'),title=tr('d  一个明确规定的载荷分担模型','d  A specified load-sharing model'));ax[1,1].legend(fontsize=9);f.tight_layout();save(f,'drainage')
    print(json.dumps(summary))
if __name__=='__main__':main()
