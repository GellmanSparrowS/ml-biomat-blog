"""Tensile-test analysis with constructed force and local-extension observations.
Run: python main.py --output results --language en
The piecewise engineering curve is a teaching specification, not measured data.
"""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import brentq
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Polygon

def stress(strain,E=2000.):
    e=np.asarray(strain);ey=40/E;peak=40+60*(.2-ey)
    return np.where(e<=ey,E*e,np.where(e<=.2,40+60*(e-ey),peak-80*(e-.2)))

def apparent_modulus(area_entered=10.,compliance=.001,method='crosshead'):
    return 2000*10/area_entered/(1+400*compliance if method=='crosshead' else 1)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();o=a.output;o.mkdir(parents=True,exist_ok=True);tr=lambda z,e:z if a.language=='zh' else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fbfcfc','savefig.facecolor':'#fbfcfc','text.color':'#18344a'})
    blue='#186c94';green='#188777';orange='#d27839';purple='#8a5d92'
    def save(f,n):f.savefig(o/f'{n}-{a.language}.svg',bbox_inches='tight');f.savefig(o/f'{n}-{a.language}.png',bbox_inches='tight',dpi=150);plt.close(f)
    rng=np.random.default_rng(1901);eps=np.unique(np.r_[np.linspace(0,.03,301),np.linspace(.03,.4,371)]);sig=stress(eps);A=10.;L=50.;C=.001
    force=sig*A+rng.normal(0,.3,len(eps));local=eps+rng.normal(0,.00002,len(eps));cross=(L*eps+C*force)/L
    mask=(eps>=.001)&(eps<=.008);E,b=np.polyfit(local[mask],force[mask]/A,1);Ex,bx=np.polyfit(cross[mask],force[mask]/A,1)
    # Use monotonically ordered imposed strain to interpolate a noisy measured curve.
    fy=lambda x:np.interp(x,eps,force/A)-(E*(x-.002)+b)
    offset=brentq(fy,.02,.03);offset_sig=np.interp(offset,eps,force/A)
    offset_exact=brentq(lambda x:float(stress(x))-2000*(x-.002),.02,.03)
    energy=float(np.trapezoid(sig,eps));peak_idx=int(np.argmax(force));valid=eps<=.2
    true_sig=np.where(valid,sig*(1+eps),np.nan);true_eps=np.where(valid,np.log1p(eps),np.nan)
    ends=np.linspace(.002,.035,60);slopes=[np.polyfit(local[(eps>=.001)&(eps<=en)],force[(eps>=.001)&(eps<=en)]/A,1)[0] for en in ends]
    reps=2000+rng.normal(0,80,7)
    summary={'fit_local_modulus_MPa':float(E),'fit_crosshead_modulus_MPa':float(Ex),'analytic_crosshead_modulus_MPa':apparent_modulus(),
      'offset_yield_MPa':float(offset_sig),'offset_strain':float(offset),'noiseless_offset_yield_MPa':float(stress(offset_exact)),
      'specified_peak_MPa':50.8,'observed_peak_MPa':float(force[peak_idx]/A),'observed_peak_strain':float(eps[peak_idx]),
      'specified_work_MJ_m3':energy,'work_hand_integral_MJ_m3':17.132,'true_stress_at_20pct_MPa':60.96,'true_strain_at_20pct':float(np.log(1.2)),
      'area_11mm2_modulus_MPa':apparent_modulus(11,0,'local'),'replicate_mean_MPa':float(reps.mean()),'replicate_sd_MPa':float(reps.std(ddof=1)),'data_kind':'Constructed teaching observations and specified piecewise engineering response'}
    (o/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    np.savetxt(o/'data.csv',np.column_stack([eps,force,local*L,cross*L,force/A,local,cross,true_sig,true_eps]),delimiter=',',header='imposed_strain,force_N,local_extension_mm,crosshead_extension_mm,engineering_stress_MPa,local_strain,crosshead_strain,uniform_true_stress_MPa,uniform_true_strain',comments='')
    np.savetxt(o/'fit_windows.csv',np.column_stack([ends,slopes]),delimiter=',',header='upper_strain,fit_modulus_MPa',comments='')
    np.savetxt(o/'replicates.csv',reps,delimiter=',',header='constructed_modulus_MPa',comments='')
    fig,axs=plt.subplots(1,3,figsize=(14.5,5));
    for ax in axs:ax.set_xlim(0,10);ax.set_ylim(0,10);ax.axis('off')
    ax=axs[0];ax.plot([.8,9.2],[8.8,8.8],lw=4,color='#6b808d')
    for x,le,n in [(3,3,1),(7,5,2)]:
        yy=np.linspace(8.8,8.8-le,180);xx=x+.4*np.sin(np.linspace(0,12*np.pi,180));ax.plot(xx,yy,color=blue);ax.plot([x,x],[8.8-le,8.2-le],color=blue);ax.add_patch(Rectangle((x-.65,7.2-le),1.3,1,facecolor=orange));ax.text(x,6.6-le,f'{n}F',ha='center')
    ax.text(5,9.5,tr('Hooke，1678：负载与伸长','Hooke, 1678: load and extension'),ha='center',fontsize=10);ax.text(5,.3,tr('弹簧长度变化体现结构刚度','Extension reveals structural stiffness'),ha='center',fontsize=9)
    ax=axs[1];pts=[(2,1),(8,1),(8,2.5),(6.2,3.5),(6.2,6.5),(8,7.5),(8,9),(2,9),(2,7.5),(3.8,6.5),(3.8,3.5),(2,2.5)];ax.add_patch(Polygon(pts,facecolor='#cce2e8',edgecolor=blue,lw=2));ax.add_patch(Rectangle((1.5,.4),7,1.1,color='#8f9fa8'));ax.add_patch(Rectangle((1.5,8.5),7,1.1,color='#8f9fa8'))
    ax.scatter([5,5],[4,6],s=45,color=orange);ax.annotate('',xy=(7,6),xytext=(7,4),arrowprops={'arrowstyle':'<->'});ax.text(7.3,5,'L₀',va='center');ax.text(5,.1,tr('标距内直接跟踪材料伸长','Track local extension inside the gauge'),ha='center',fontsize=9)
    ax=axs[2];ax.add_patch(Rectangle((1.5,7),7,1.2,facecolor='#cce2e8',edgecolor=blue));ax.text(5,7.6,tr('试样','Specimen'),ha='center',va='center');ax.add_patch(Rectangle((1.5,3.4),7,1.2,facecolor='#f1d5be',edgecolor=orange));ax.text(5,4,tr('机架与夹具','Frame and grips'),ha='center',va='center');ax.plot([5,5],[4.6,7],color='#6b808d');ax.annotate('',xy=(5,1),xytext=(5,3.4),arrowprops={'arrowstyle':'->','lw':2});ax.text(5,9.4,tr('串联位移：各部分相加','Series displacement: contributions add'),ha='center',fontsize=10);ax.text(5,.3,tr('横梁移动量包含两者变形','Crosshead travel includes both'),ha='center',fontsize=9);save(fig,'geometry')
    fig,axs=plt.subplots(2,2,figsize=(12,9));aa,bb,cc,dd=axs.ravel();aa.plot(local*L,force,color=blue,label=tr('标距伸长','Gauge extension'));aa.plot(cross*L,force,color=orange,label=tr('横梁位移','Crosshead travel'));aa.set_xlabel(tr('位移 / mm','Displacement / mm'));aa.set_ylabel(tr('力 / N','Force / N'));aa.legend(fontsize=9);aa.set_title(tr('A  原始力与两种位移','A  Force and two displacement channels'),loc='left')
    bb.plot(local*100,force/A,color=blue);bb.scatter(eps[peak_idx]*100,force[peak_idx]/A,color=orange,zorder=3);bb.set_xlabel(tr('工程应变 / %','Engineering strain / %'));bb.set_ylabel(tr('工程应力 / MPa','Engineering stress / MPa'));bb.set_title(tr('B  从尺寸归一化到曲线','B  Normalise by specimen dimensions'),loc='left')
    small=eps<=.012;cc.scatter(local[small]*100,force[small]/A,s=8,color=blue,label=tr('标距','Gauge'));cc.plot(cross[small]*100,force[small]/A,color=orange,label=tr('横梁','Crosshead'));cc.plot(local[mask]*100,E*local[mask]+b,color=green,lw=2,label=tr('标距拟合','Gauge fit'));cc.set_xlabel(tr('应变 / %','Strain / %'));cc.set_ylabel(tr('工程应力 / MPa','Engineering stress / MPa'));cc.legend(fontsize=8);cc.set_title(tr('C  小应变处的柔度差异','C  Compliance matters at small strain'),loc='left')
    dd.plot(ends*100,slopes,color=blue);dd.axhline(2000,color=green,ls='--');dd.axvline(2,color=orange,ls=':');dd.set_xlabel(tr('拟合上限应变 / %','Upper fit strain / %'));dd.set_ylabel(tr('拟合斜率 / MPa','Fitted slope / MPa'));dd.set_title(tr('D  拟合窗口跨入非线性区','D  A fit window enters nonlinearity'),loc='left');fig.tight_layout();save(fig,'analysis')
    fig,axs=plt.subplots(1,3,figsize=(14.5,4.7));aa,bb,cc=axs
    aa.plot(eps*100,sig,color=blue);x=np.linspace(.002,.04,100);aa.plot(x*100,2000*(x-.002),color=orange,ls='--');aa.scatter(offset_exact*100,float(stress(offset_exact)),color=green,zorder=5);aa.set_xlim(0,4);aa.set_ylim(0,65);aa.set_xlabel(tr('工程应变 / %','Engineering strain / %'));aa.set_ylabel(tr('应力 / MPa','Stress / MPa'));aa.set_title(tr('A  0.2%偏移交点','A  Intersection at 0.2% offset'),loc='left')
    bb.plot(eps[valid]*100,sig[valid],color=blue,label=tr('工程应力','Engineering stress'));bb.plot(eps[valid]*100,true_sig[valid],color=orange,label=tr('真应力','True stress'));bb.set_xlabel(tr('工程应变 / %','Engineering strain / %'));bb.set_ylabel(tr('应力 / MPa','Stress / MPa'));bb.legend(fontsize=9);bb.set_title(tr('B  均匀、恒体积阶段','B  Uniform constant-volume interval'),loc='left')
    cc.fill_between(eps*100,0,sig,color='#cce2e8');cc.plot(eps*100,sig,color=blue);cc.text(.05,.85,'17.132 MJ/m³',transform=cc.transAxes);cc.set_xlabel(tr('工程应变 / %','Engineering strain / %'));cc.set_ylabel(tr('工程应力 / MPa','Engineering stress / MPa'));cc.set_title(tr('C  体积归一化的拉伸功','C  Tensile work per initial volume'),loc='left');fig.tight_layout();save(fig,'properties')
    fig,axs=plt.subplots(1,3,figsize=(14,4.8));cm=np.linspace(0,.003,100);axs[0].plot(cm,2000/(1+400*cm),color=orange);axs[0].axhline(2000,color=green,ls='--');axs[0].set_xlabel(tr('系统柔度 / mm/N','System compliance / mm/N'));axs[0].set_ylabel(tr('表观模量 / MPa','Apparent modulus / MPa'));axs[0].set_title(tr('A  横梁法中的系统柔度','A  Compliance in crosshead analysis'),loc='left');area=np.linspace(8,12,100);axs[1].plot(area,2000*10/area,color=blue);axs[1].axvline(10,color=green,ls='--');axs[1].set_xlabel(tr('输入面积 / mm²','Entered area / mm²'));axs[1].set_ylabel(tr('表观模量 / MPa','Apparent modulus / MPa'));axs[1].set_title(tr('B  几何分母影响全部应力','B  Area scales every stress value'),loc='left');axs[2].scatter(np.arange(1,8),reps,color=blue,s=35);axs[2].axhline(reps.mean(),color=green);axs[2].axhspan(reps.mean()-reps.std(ddof=1),reps.mean()+reps.std(ddof=1),color=green,alpha=.12);axs[2].set_xlabel(tr('构造试样编号','Constructed specimen number'));axs[2].set_ylabel(tr('模量 / MPa','Modulus / MPa'));axs[2].set_title(tr('C  独立试样：均值±样本标准差','C  Specimens: mean ± sample SD'),loc='left',fontsize=10);fig.tight_layout();save(fig,'sensitivity')
    print(json.dumps(summary))
if __name__=='__main__':main()
