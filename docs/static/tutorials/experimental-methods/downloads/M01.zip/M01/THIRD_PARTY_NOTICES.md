# Public sources and third-party materials

- Hooke — Potentia Restitutiva, or Spring (historical text): https://doi.org/10.1190/1.9781560801931.ch3a
  Historical text excerpt consulted through publisher index; no image reused.
- MacTutor — Robert Hooke: https://mathshistory.st-andrews.ac.uk/Biographies/Hooke/
  Historical reference; no image reused.
- Instron — Tensile testing: https://www.instron.com/en/resources/test-types/tensile-test/
  Technical reference; no figures reused.
- Instron — Extensometers: https://www.instron.com/en/products/testing-accessories/extensometers/
  Technical reference; no figures reused.
- Instron — Offset yield strength: https://www.instron.com/en/resources/glossary/offset-yield-strength/
  Technical reference; no figures reused.
- DoITPoMS — True and nominal stresses and strains: https://eng.libretexts.org/Bookshelves/Materials_Science/TLP_Library_II/5:_Mechanical_Testing_of_Metals/5.3:_True_and_Nominal_Stresses_and_Strains
  CC BY-NC-SA source consulted; no text or figures adapted.
- DoITPoMS — Tensile testing, necking and failure: https://eng.libretexts.org/Bookshelves/Materials_Science/TLP_Library_II/5:_Mechanical_Testing_of_Metals/5.6:_Tensile_Testing_-_Necking_and_Failure
  CC BY-NC-SA source consulted; no text or figures adapted.
- Lord and Morrell — Elastic modulus measurement (2010): https://doi.org/10.1088/0026-1394/47/2/s05
  Publisher abstract consulted; no figures reused.
