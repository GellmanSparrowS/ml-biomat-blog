"""TEM teaching experiment: projection ambiguity, calibration and diffraction.

All images and particle coordinates here are constructed teaching models.
Projection maps describe geometry, not a full coherent electron-optical simulation.
"""
from pathlib import Path
import argparse,csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Ellipse,Circle

def wavelength(voltage):
    h,e,m,c=6.62607015e-34,1.602176634e-19,9.1093837139e-31,299792458.
    return h/np.sqrt(2*m*e*voltage*(1+e*voltage/(2*m*c*c)))

def main(output,language):
    output.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'svg.fonttype':'none','font.size':11,'axes.titleweight':'bold','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','text.color':'#243b45','axes.labelcolor':'#243b45'})
    tr=lambda a,b:a if language=='zh' else b
    green,blue,red,gray='#168477','#3474a8','#bd624b','#788b90'
    def save(fig,name):
        fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');fig.savefig(output/f'{name}-{language}.png',dpi=140,bbox_inches='tight');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(13,6),layout='constrained')
    for ax in axes:ax.axis('off');ax.set(xlim=(-3,3),ylim=(0,10))
    ax=axes[0];ax.set_title(tr('A  1931：磁透镜形成放大像','A  1931: magnetic-lens magnification'),fontsize=12)
    for y,label in [(8.8,tr('薄样品','Thin specimen')),(6.4,tr('物镜','Objective lens')),(3.8,tr('投影系统','Projector system')),(1,tr('探测器','Detector'))]:
        ax.add_patch(Rectangle((-1.4,y-.12),2.8,.24,fc=gray if y>8 else '#a9c6d1',ec=gray));ax.text(0,y+.4,label,ha='center')
    for dx in [-.9,0,.9]:ax.plot([.5,dx,-.5*1.4/2.4],[8.8,6.4,5],color=blue,lw=1.5)
    for dx in [-1,0,1]:ax.plot([-.5*1.4/2.4,dx,.5*1.4/2.4*2.8/1.2],[5,3.8,1],color=blue,lw=1.5)
    ax.text(0,.1,tr('原创电子光路概念图；不按比例','Original electron-optical concept; not to scale'),ha='center',fontsize=9)
    ax=axes[1];ax.set_title(tr('B  选择电子，改变图像对比','B  Select electrons, change contrast'),fontsize=12)
    ax.add_patch(Rectangle((-2,7),4,.3,fc='#ccbda9'));ax.text(0,8,tr('薄片散射电子','Thin section scatters electrons'),ha='center')
    ax.annotate('',(0,2),(0,7),arrowprops={'arrowstyle':'->','color':green,'lw':2})
    for end in [-1.14,1.14]:ax.annotate('',(end,4.15),(0,7),arrowprops={'arrowstyle':'->','color':red,'lw':2})
    ax.add_patch(Rectangle((-2.7,3.9),2.2,.25,fc=gray));ax.add_patch(Rectangle((.5,3.9),2.2,.25,fc=gray));ax.text(0,4.6,tr('物镜光阑','Objective aperture'),ha='center')
    ax.text(0,.7,tr('明场：主要接收近轴透射束\n散射、厚度和取向共同影响明暗','Bright field: mainly near-axis electrons\nScattering, thickness and orientation matter'),ha='center',fontsize=10)
    ax=axes[2];ax.set_title(tr('C  玻璃态冰保留水合环境','C  Vitreous ice preserves hydration'),fontsize=12)
    ax.add_patch(Rectangle((-2.5,4),5,2,fc='#dce8ec',ec=blue));rng=np.random.default_rng(44)
    for x,y in rng.uniform([-2.3,4.2],[2.3,5.8],(35,2)):ax.add_patch(Circle((x,y),.05,color=blue,alpha=.5))
    for x,y in [(-1.4,5.3),(.1,4.7),(1.5,5.2)]:ax.add_patch(Ellipse((x,y),.8,.45,angle=x*40,fc=green))
    ax.text(0,7.3,tr('20世纪80年代：玻璃化制样发展','1980s: development of vitrification'),ha='center',fontsize=10)
    ax.text(0,2.5,tr('无规则排列的水分子\n避免大冰晶重排样品','Disordered water arrangement\nAvoid large ice crystals rearranging specimens'),ha='center',fontsize=10)
    save(fig,'principle')
    pts=np.array([[-8.,0.,-25.],[8.,0.,25.]])
    def project(angle):
        a=np.deg2rad(angle);return np.column_stack([pts[:,0]*np.cos(a)+pts[:,2]*np.sin(a),pts[:,1]])
    fig,axes=plt.subplots(1,3,figsize=(12,4.5),layout='constrained')
    for ax,angle in zip(axes,[0,30,60]):
        pr=project(angle)
        for i,(x,y) in enumerate(pr):ax.add_patch(Circle((x,y),12,fc=[green,red][i],alpha=.65,ec='white'))
        sep=np.linalg.norm(pr[1]-pr[0]);ax.set(xlim=(-50,50),ylim=(-35,35),xlabel=tr('投影位置 / nm','Projected position / nm'),ylabel='y / nm',title=tr(f'倾转 {angle}°：中心距 {sep:.1f} nm',f'Tilt {angle}°: centers {sep:.1f} nm'));ax.set_aspect('equal');ax.axhline(0,color=gray,lw=.6,ls=':')
    fig.suptitle(tr('相同的两个球：重叠随观察方向改变','The same two spheres: overlap changes with viewing angle'),fontsize=15)
    save(fig,'projection')
    fig,axes=plt.subplots(2,2,figsize=(11,8),layout='constrained')
    voltage=np.linspace(60,300,300);lam=wavelength(voltage*1000)*1e12
    axes[0,0].plot(voltage,lam,color=blue,lw=2);axes[0,0].set(xlabel=tr('加速电压 / kV','Accelerating voltage / kV'),ylabel=tr('电子波长 / pm','Electron wavelength / pm'),title=tr('A  波长很短，成像仍受透镜与样品影响','A  Short wavelength is only one ingredient'))
    ds=np.array([.2,.25,.35]);camera_mm=500.;lam_nm=wavelength(200e3)*1e9;rings=camera_mm*lam_nm/ds
    ax=axes[0,1]
    for r,d,col in zip(rings,ds,[green,blue,red]):ax.add_patch(Circle((0,0),r,fill=False,lw=2,color=col,label=f'd = {d:.2f} nm'))
    ax.plot(0,0,'o',color=gray);ax.set(xlim=(-7.5,7.5),ylim=(-7.5,7.5),xlabel=tr('屏上位置 / mm','Screen position / mm'),ylabel=tr('屏上位置 / mm','Screen position / mm'),title=tr('B  晶面间距越小，衍射环越外','B  Smaller spacings give outer rings'));ax.set_aspect('equal');ax.legend(frameon=False,fontsize=9,loc='upper left')
    diam=np.array([18,19,20,20,21,22,23,25,27,35.]);weights=diam**2
    edges=np.arange(15,41,5);axes[1,0].hist(diam,bins=edges,color=green,alpha=.8,edgecolor='white');axes[1,0].set(xlabel=tr('等效圆直径 / nm','Equivalent-circle diameter / nm'),ylabel=tr('颗粒数','Particle count'),title=tr('C  数目分布保留大颗粒尾部','C  Number distribution retains the large tail'))
    definitions=[tr('数目平均','Number mean'),tr('面积加权平均','Area-weighted mean')];means=[diam.mean(),np.average(diam,weights=weights)]
    axes[1,1].bar(definitions,means,color=[green,red],width=.55)
    for i,v in enumerate(means):axes[1,1].text(i,v+.6,f'{v:.2f} nm',ha='center')
    axes[1,1].set(ylabel=tr('平均直径 / nm','Mean diameter / nm'),ylim=(0,33),title=tr('D  权重改变，回答的问题也改变','D  Different weights answer different questions'))
    save(fig,'measurement')
    with (output/'data.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['particle','diameter_nm','projected_area_nm2','area_weight']);w.writerows((i+1,d,np.pi*d*d/4,weights[i]/weights.sum()) for i,d in enumerate(diam))
    summary={'wavelength_200kV_pm':float(wavelength(200e3)*1e12),'ring_radius_d025_nm_mm':float(camera_mm*lam_nm/.25),'projected_separation_0_nm':float(np.linalg.norm(project(0)[1]-project(0)[0])),'projected_separation_60_nm':float(np.linalg.norm(project(60)[1]-project(60)[0])),'true_center_distance_nm':float(np.linalg.norm(pts[1]-pts[0])),'number_mean_nm':float(diam.mean()),'area_weighted_mean_nm':float(np.average(diam,weights=weights)),'diameter_from_area_314159_nm2':float(2*np.sqrt(314.1592653589793/np.pi)),'data_origin':'Constructed geometric and numerical teaching examples; no experimental TEM image claimed.'}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
