# Public sources and third-party materials

- Ernst Ruska — Nobel lecture: https://www.nobelprize.org/uploads/2018/06/ruska-lecture.pdf
  Historical primary source; original diagram here.
- JEOL Bionote — TEM specimen preparation: https://www.jeol.com/applications/pdf/others/1462_en.pdf
  Technical reference; figures not reproduced.
- JEOL — wavelength of electron: https://www.jeol.com/words/emterms/20121023.071258.php
  Technical reference.
- JEOL — selected-area diffraction: https://www.jeol.com/words/emterms/20121023.052558.php
  Technical reference.
- EMBL — Jacques Dubochet and vitrification: https://www.embl.org/news/science/jacques-dubochet-awarded-nobel-prize-for-chemistry/
  Institutional historical reference; original illustration.
- Royal Swedish Academy of Sciences — cryo-EM scientific background: https://www.nobelprize.org/uploads/2018/06/advanced-chemistryprize2017-1.pdf
  Public scientific background; no figures reused.
