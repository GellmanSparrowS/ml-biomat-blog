"""Fatigue teaching: censored stress-life data and a separate Paris growth model.
The bundled photograph is actual CC BY 4.0 research; see data/NOTICE.txt.
All numerical records generated here are constructed, not that paper's data.
python main.py --output results --language en
"""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,Arc

def life(stress):return 1e6*(np.asarray(stress)/100.)**-5
def growth_life(a0=.001,af=.006,ds=60.,C=1e-10):
    return 2*(a0**-.5-af**-.5)/(C*(ds*np.sqrt(np.pi))**3)
def growth(n,a0=.001,ds=60.,C=1e-10,af=.006):
    ne=np.minimum(np.asarray(n),growth_life(a0,af,ds,C));return (a0**-.5-.5*C*(ds*np.sqrt(np.pi))**3*ne)**-2

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();o=a.output;o.mkdir(parents=True,exist_ok=True);tr=lambda z,e:z if a.language=='zh' else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fbfcfc','savefig.facecolor':'#fbfcfc','text.color':'#18344a'})
    B='#186c94';G='#188777';O='#d27839';P='#8a5d92'
    def save(f,n):f.savefig(o/f'{n}-{a.language}.svg',bbox_inches='tight');f.savefig(o/f'{n}-{a.language}.png',bbox_inches='tight',dpi=150);plt.close(f)
    rng=np.random.default_rng(1904);S=np.repeat([80.,90.,105.,125.,150.,180.],4);true_log=np.log10(life(S))+rng.normal(0,.16,len(S));stop=1e6;Ntrue=10**true_log;failed=Ntrue<=stop;Nobs=np.minimum(Ntrue,stop);x=np.log10(S/100);y=np.log10(Nobs)
    def objective(q):
        mu=q[0]-q[1]*x;sd=np.exp(q[2]);z=(y-mu)/sd
        return -np.sum(np.where(failed,norm.logpdf(z)-np.log(sd),norm.logsf(z)))
    fit=minimize(objective,[6,5,np.log(.16)],method='L-BFGS-B',bounds=[(4,8),(1,10),(np.log(.03),np.log(.7))]);assert fit.success,fit.message
    intercept,m,logsd=fit.x;sd=float(np.exp(logsd));ols=np.polyfit(x[failed],y[failed],1)
    DK=np.geomspace(3.5,12,36);rate=1e-10*DK**3*10**rng.normal(0,.08,len(DK));mp,cp=np.polyfit(np.log10(DK),np.log10(rate),1);Cfit=10**cp
    nend=growth_life();nn=np.linspace(0,nend,401);aa=growth(nn);ode=solve_ivp(lambda n,v:[1e-10*(60*np.sqrt(np.pi*v[0]))**3],(0,nend),[.001],rtol=1e-10,atol=1e-13,dense_output=True);ode_error=float(np.max(abs(ode.sol(nn)[0]-aa)))
    blocks=np.array([100000.,200000.]);levels=np.array([125.,100.]);damage=blocks/life(levels)
    summary={'specimens':len(S),'failures':int(failed.sum()),'runouts':int((~failed).sum()),'fit_intercept_log10N':float(intercept),'fit_stress_exponent':float(m),'fit_log10_scatter':sd,'failures_only_intercept':float(ols[1]),'fit_median_life_at100':float(10**intercept),'specified_median_life_at125':float(life(125)),'specified_damage_sum':float(damage.sum()),'hours_300000cycles_at5Hz':300000/5/3600,'paris_fit_C':float(Cfit),'paris_fit_m':float(mp),'growth_cycles_1to6mm':float(nend),'growth_cycles_2to6mm':float(growth_life(.002)),'ode_max_error_m':ode_error,'growth_at_start_m_cycle':float(1e-10*(60*np.sqrt(np.pi*.001))**3),'stress_amplitude_100_10_MPa':45.,'mean_stress_100_10_MPa':55.,'stress_ratio_100_10':.1}
    (o/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');np.savetxt(o/'data.csv',np.c_[S,Nobs,failed.astype(int)],delimiter=',',header='stress_amplitude_MPa,observed_cycles,failure_observed_1',comments='');np.savetxt(o/'growth.csv',np.c_[nn,aa*1000,60*np.sqrt(np.pi*aa),1e-10*(60*np.sqrt(np.pi*aa))**3],delimiter=',',header='cycles,crack_half_length_mm,delta_K_MPa_sqrt_m,da_dN_m_cycle',comments='');np.savetxt(o/'paris.csv',np.c_[DK,rate],delimiter=',',header='delta_K_MPa_sqrt_m,growth_rate_m_cycle',comments='');np.savetxt(o/'blocks.csv',np.c_[levels,blocks,life(levels),damage],delimiter=',',header='stress_amplitude_MPa,applied_cycles,median_constant_amplitude_life,miner_fraction',comments='')
    f,ax=plt.subplots(1,2,figsize=(12,4.8));ax[0].set(xlim=(0,10),ylim=(0,7));ax[0].axis('off');ax[0].add_patch(Rectangle((1,3),8,.55,facecolor='#c5d6df',edgecolor=B));
    for xx in [2,8]:ax[0].add_patch(Rectangle((xx-.3,2.6),.6,1.4,facecolor='#6e8593'))
    ax[0].annotate('',(5,3.7),(5,5.7),arrowprops={'arrowstyle':'->','color':O,'lw':2});ax[0].text(5,6,tr('固定方向弯曲载荷','Bending load in a fixed direction'),ha='center');ax[0].add_patch(Arc((5,3.3),2,2,theta1=30,theta2=320,color=G,lw=2));ax[0].annotate('',(5.9,3.8),(5.8,4.1),arrowprops={'arrowstyle':'->','color':G});ax[0].scatter([4],[3.5],s=55,color=O);ax[0].text(5,1.3,tr('表面一点随转动交替受拉、受压','One surface point alternates tension and compression'),ha='center',fontsize=10);ax[0].text(5,.4,tr('Wöhler：1858–1870年的系统试验','Wöhler: systematic tests, 1858–1870'),ha='center',fontsize=10);ax[0].set_title(tr('a  旋转弯曲的历史问题','a  The historical rotating-bending question'),fontsize=12)
    theta=np.linspace(0,2*np.pi,250);ax[1].plot(theta/(2*np.pi),100*np.cos(theta),color=B);ax[1].axhline(0,color='#8a9ca7',ls='--');ax[1].set(xlabel=tr('一圈中的转数','Fraction of one revolution'),ylabel=tr('归一示例应力 / MPa','Illustrative stress / MPa'),title=tr('b  外力不换向，材料点仍经历循环','b  A rotating point still sees a stress cycle'));f.tight_layout();save(f,'history')
    f,ax=plt.subplots(1,2,figsize=(12,4.8));t=np.linspace(0,2,501)
    for r,c in [(.1,B),(.5,O)]:mean=100*(1+r)/2;amp=100*(1-r)/2;ax[0].plot(t,mean+amp*np.sin(2*np.pi*t),color=c,label=f'R={r}')
    ax[0].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('应力 / MPa','Stress / MPa'),title=tr('a  相同最大应力，不同循环','a  Same maximum stress, different cycles'));ax[0].legend()
    eps=.03*np.sin(theta);sig=3*np.sin(theta)+.8*np.cos(theta);ax[1].plot(eps*100,sig,color=G);ax[1].fill(eps*100,sig,color=G,alpha=.18);ax[1].set(xlabel=tr('应变 / %','Strain / %'),ylabel=tr('应力 / kPa','Stress / kPa'),title=tr('b  示意滞后环：每圈消耗能量','b  Illustrative hysteresis: energy lost per cycle'));ax[1].text(0,0,tr('面积有能量含义','Area has an energy meaning'),ha='center',fontsize=10);f.tight_layout();save(f,'waveform')
    f,ax=plt.subplots(1,2,figsize=(12,4.9));ss=np.linspace(75,185,180);mu=intercept-m*np.log10(ss/100);med=10**mu;lo=10**(mu+norm.ppf(.1)*sd);hi=10**(mu+norm.ppf(.9)*sd);ax[0].fill_betweenx(ss,lo,hi,color=B,alpha=.15,label=tr('拟合寿命分布10–90%分位','Fitted life distribution 10–90% quantiles'));ax[0].plot(med,ss,color=B,label=tr('包含未失效试样','Includes runouts'));ax[0].plot(10**np.polyval(ols,np.log10(ss/100)),ss,color=O,ls='--',label=tr('仅拟合失效点','Fit failures only'));ax[0].scatter(Nobs[failed],S[failed],color='#163b51',s=25)
    for nx,sy in zip(Nobs[~failed],S[~failed]):ax[0].annotate('',(nx*1.7,sy),(nx,sy),arrowprops={'arrowstyle':'->','color':G});ax[0].scatter([nx],[sy],facecolors='none',edgecolors=G,s=30)
    ax[0].set(xscale='log',xlabel=tr('观测循环数 / cycles','Observed cycles'),ylabel=tr('应力幅 / MPa','Stress amplitude / MPa'),title=tr('a  箭头表示达到停机上限仍未失效','a  Arrows mark survival to the test limit'));ax[0].legend(fontsize=8,loc='lower left')
    yy=np.linspace(4.7,7,500);pdf=norm.pdf(yy,intercept,sd);ax[1].plot(yy,pdf,color=B);ax[1].fill_between(yy,0,pdf,where=yy>=6,color=G,alpha=.3,label=tr('寿命超过10⁶的概率','Probability of life above 10⁶'));ax[1].axvline(6,color=O,ls='--');ax[1].set(xlabel='log₁₀(N)',ylabel=tr('对数寿命概率密度','Density of log life'),title=tr('b  100 MPa下的分布与删失','b  Distribution and censoring at 100 MPa'));ax[1].legend(fontsize=9);f.tight_layout();save(f,'life')
    f,ax=plt.subplots(2,2,figsize=(12,8));ax[0,0].loglog(DK,rate,'o',color=B,ms=4,label=tr('构造增长数据','Constructed growth data'));ax[0,0].loglog(DK,Cfit*DK**mp,color=O,label=f'm={mp:.3f}');ax[0,0].set(xlabel='ΔK / MPa √m',ylabel='da/dN / m cycle⁻¹',title=tr('a  Paris中段关系','a  Paris-regime relation'));ax[0,0].legend(fontsize=9)
    for start,c in [(.001,B),(.002,O)]:ns=np.linspace(0,growth_life(start),300);ax[0,1].plot(ns,growth(ns,start)*1000,color=c,label=f'a₀={start*1000:g} mm')
    ax[0,1].set(xlabel=tr('循环数','Cycles'),ylabel=tr('裂纹半长 / mm','Crack half-length / mm'),title=tr('b  从已知裂纹到规定6 mm终点','b  Known crack to a specified 6 mm endpoint'));ax[0,1].legend()
    ax[1,0].bar([0,1],damage,color=[B,O]);ax[1,0].set(xticks=[0,1],xticklabels=['125 MPa\n100,000 cycles','100 MPa\n200,000 cycles'],ylabel=tr('线性损伤份额','Linear damage fraction'),title=tr('c  Miner相加，不包含先后次序','c  Miner addition omits sequence effects'));ax[1,0].text(.5,.28,f'D={damage.sum():.4f}',ha='center')
    aa0=np.linspace(.0005,.0025,150);ax[1,1].plot(aa0*1000,[growth_life(q) for q in aa0],color=P);ax[1,1].set(xlabel=tr('初始裂纹半长 / mm','Initial crack half-length / mm'),ylabel=tr('到6 mm的循环数','Cycles to 6 mm'),title=tr('d  初始缺陷改变传播寿命','d  Initial defect changes propagation life'));f.tight_layout();save(f,'growth')
    img=plt.imread(Path(__file__).resolve().parent/'data/lin2018-fig3h.png');f,ax=plt.subplots(figsize=(12,5.3));ax.imshow(img);ax.axis('off');ax.set_title(tr('真实研究图：PVA凝胶在循环载荷下的缺口观测','Actual research figure: a PVA-gel notch under repeated loading'),loc='left',pad=18,fontsize=14);f.text(.5,.03,tr('Lin等，arXiv:1812.06403v1，图3H裁切，CC BY 4.0；保留原始标注与比例尺。','Lin et al., arXiv:1812.06403v1, cropped Fig. 3H, CC BY 4.0; original labels and scale bars retained.'),ha='center',fontsize=10);f.tight_layout(rect=[0,.06,1,1]);save(f,'published')
    print(json.dumps(summary))
if __name__=='__main__':main()
