# Public sources and third-party materials

- Deutsche Biographie — August Wöhler: https://www.deutsche-biographie.de/sfz26909.html?language=en
  Biographical reference; original diagram here.
- Instron — Dynamic fatigue testing: https://instron.com/en/resources/test-types/dynamic-test/
  Official technical reference; no images reused.
- NIST — Censoring: https://www.itl.nist.gov/div898/handbook/apr/section1/apr131.htm
  Official statistical handbook; original example here.
- NIST — Maximum likelihood with censored reliability data: https://www.itl.nist.gov/div898/handbook/apr/section4/apr413.htm
  Official statistical reference; no example data reused.
- JCSS — Fatigue models for metallic structures: https://www.jcss-lc.org/publications/jcsspmc/JCSS-3-12-Fatigue.pdf
  Technical reference; no figures or data reused.
- Paris and Erdogan — A critical analysis of crack propagation laws (1963): https://doi.org/10.1115/1.3656900
  Publisher indexed abstract consulted; no figures reused.
- Lin et al. — Anti-fatigue-fracture hydrogels: https://arxiv.org/abs/1812.06403v1
  CC BY 4.0, confirmed by arXiv license link. Fig. 3H cropped; attribution and change notice in data/NOTICE.txt.
