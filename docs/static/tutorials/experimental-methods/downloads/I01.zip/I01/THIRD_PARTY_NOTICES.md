# Public sources and third-party materials

- Nikon MicroscopyU — Numerical Aperture: https://www.microscopyu.com/microscopy-basics/numerical-aperture
  Technical reference; original drawings in this chapter.
- Nikon MicroscopyU — Introduction to Fluorescence Microscopy: https://www.microscopyu.com/techniques/fluorescence/introduction-to-fluorescence-microscopy
  Technical reference; original drawings in this chapter.
- Introduction to Bioimage Analysis — Blur & the PSF: https://bioimagebook.github.io/chapters/3-fluorescence/2-formation_spatial/formation_spatial.html
  Book original content CC BY 4.0; linked reading.
- Introduction to Bioimage Analysis — From photons to pixels: https://bioimagebook.github.io/chapters/3-fluorescence/1-formation_overview/formation_overview.html
  Book original content CC BY 4.0; linked reading.
- scikit-image — human_mitosis dataset: https://scikit-image.org/docs/stable/api/skimage.data.html#skimage.data.human_mitosis
  Image copyright David Root, CC0.
- scikit-image — Segment human cells in mitosis: https://scikit-image.org/docs/stable/auto_examples/applications/plot_human_mitosis.html
  Technical reference; independent implementation here.
- Robert Hooke — Micrographia, 1665 / Wellcome Collection: https://wellcomecollection.org/works/apmaw56u
  Digitized work marked Public Domain by Wellcome Collection.
