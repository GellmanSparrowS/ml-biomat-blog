"""Optical microscopy: resolution, photon statistics and a real CC0 image.

The microscopy data are mitosis.tif, David Root / CellProfiler, CC0.
The analytical point-spread profiles and photon experiment are teaching models.
"""
from pathlib import Path
import argparse
import csv
import json
import numpy as np
from PIL import Image
from scipy import ndimage
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, Rectangle, FancyArrowPatch


def style():
    plt.rcParams.update({'font.family': 'sans-serif',
        'font.sans-serif': ['Microsoft YaHei', 'Noto Sans CJK SC', 'DejaVu Sans'],
        'svg.fonttype': 'none', 'axes.spines.top': False, 'axes.spines.right': False,
        'axes.labelcolor': '#243b45', 'text.color': '#243b45',
        'axes.edgecolor': '#849398', 'axes.titleweight': 'bold',
        'font.size': 11, 'savefig.facecolor': '#faf9f5', 'figure.facecolor': '#faf9f5'})


def main(output, language):
    output.mkdir(parents=True, exist_ok=True)
    style()
    zh = language == 'zh'
    def tr(a, b): return a if zh else b
    def save(fig, name):
        fig.savefig(output / f'{name}-{language}.svg', bbox_inches='tight')
        fig.savefig(output / f'{name}-{language}.png', dpi=140, bbox_inches='tight')
        plt.close(fig)
    blue, green, red, gray = '#3473a8', '#168477', '#bb6046', '#69787e'

    # Original explanatory drawing: the optical geometry is schematic.
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.5), layout='constrained')
    for ax in axes:
        ax.set(xlim=(0, 10), ylim=(0, 10)); ax.axis('off')
    a = axes[0]
    a.set_title(tr('A  从照明到观察：早期复合显微镜', 'A  Illumination and viewing: a compound microscope'))
    a.add_patch(Rectangle((4.55, 4), .9, 4.5, color='#ded4bd'))
    a.add_patch(Ellipse((5, 8.2), 1.2, .3, fc='#d7e8ed', ec=blue))
    a.add_patch(Ellipse((5, 4.3), 1.2, .3, fc='#d7e8ed', ec=blue))
    a.plot([3, 7], [2.8, 2.8], color=gray, lw=5)
    a.add_patch(Ellipse((5, 2.9), .6, .15, color=red))
    a.add_patch(Ellipse((1.5, 2.8), .7, .7, color='#e8af58'))
    a.annotate('', (4.8, 2.9), (1.9, 2.9), arrowprops={'arrowstyle':'->','color':'#c58c37','lw':2})
    a.annotate('', (5, 8.9), (5, 3.1), arrowprops={'arrowstyle':'->','color':green,'lw':2})
    for x, y, label in [(6,8.2,tr('目镜','Eyepiece')),(6,4.3,tr('物镜','Objective')),
        (6,2.4,tr('样品','Specimen')),(.3,1.7,tr('照明','Illumination'))]:
        a.text(x,y,label,fontsize=10)
    a.text(.3,.3,tr('1665：《显微图谱》把观察与绘图联系起来\n图示说明光路，并非历史仪器的尺寸复原',
        '1665: Micrographia connects observation and illustration\nOptical schematic; not a dimensional reconstruction'),fontsize=10)
    a = axes[1]
    a.set_title(tr('B  荧光显微镜：分开激发光与发射光','B  Fluorescence: separate excitation and emission'))
    a.plot([.8,5,5],[6.8,6.8,2.7],color=blue,lw=3)
    a.plot([5.25,5.25],[2.7,9],color=green,lw=3)
    a.plot([4.3,5.7],[6.1,7.5],color=gray,lw=4)
    a.add_patch(Ellipse((5.1,4.3),1.7,.45,fc='#d7e8ed',ec=blue))
    a.add_patch(Rectangle((4.6,8.7),1.2,.7,fc='#dde5e3',ec=gray))
    a.add_patch(Ellipse((5.1,2.5),2,.35,fc='#d5a190'))
    a.add_patch(Rectangle((2.4,6.1),.15,1.4,fc=blue,alpha=.5))
    a.add_patch(Rectangle((4.6,7.9),1.2,.12,fc=green,alpha=.6))
    a.text(.2,7.4,tr('激发光','Excitation'),color=blue)
    a.text(6.2,6.7,tr('二向色镜','Dichroic mirror'))
    a.text(6.2,4.2,tr('物镜','Objective'))
    a.text(6.2,2.4,tr('荧光样品','Fluorescent specimen'))
    a.text(6.2,8.1,tr('发射滤光片','Emission filter'))
    a.text(6.2,9,tr('相机','Camera'))
    a.text(.3,.3,tr('蓝色：激发路径；绿色：被收集的发射路径\n只有一小部分各向发射的光进入物镜',
        'Blue: excitation path; green: collected emission\nOnly a fraction of emitted light enters the objective'),fontsize=10)
    save(fig, 'optics')

    wavelength_um, na, camera_pixel_um, magnification = .520, 1.3, 6.5, 60
    rayleigh_um = .61 * wavelength_um / na
    sampling_um = camera_pixel_um / magnification
    x = np.linspace(-1,1,1001)
    sigma = .21 * wavelength_um / na
    sep = .30
    profiles = {}
    fig, axes = plt.subplots(2,2,figsize=(11,8),layout='constrained')
    for aperture, color in [(.65, red),(1.3,green)]:
        s=.21*wavelength_um/aperture
        y=np.exp(-.5*((x-sep/2)/s)**2)+np.exp(-.5*((x+sep/2)/s)**2)
        profiles[str(aperture)]=y
        axes[0,0].plot(x,y,lw=2.4,color=color,label=f'NA={aperture:.2f}')
    axes[0,0].set(xlim=(-.7,.7),xlabel=tr('横向位置 / μm','Lateral position / μm'),ylabel=tr('相对强度','Relative intensity'),title=tr('A  两个点源相距 0.30 μm','A  Two emitters separated by 0.30 μm'))
    axes[0,0].legend(frameon=False)
    fine=profiles['1.3']
    axes[0,1].plot(x,fine,color=gray,lw=1.5,label=tr('连续模型','Continuous model'))
    for pitch,marker,color in [(.1083,'o',green),(.325,'s',red)]:
        xp=np.arange(-.65,.66,pitch)
        yp=np.exp(-.5*((xp-sep/2)/sigma)**2)+np.exp(-.5*((xp+sep/2)/sigma)**2)
        axes[0,1].plot(xp,yp,marker=marker,color=color,ls='--',label=f'{pitch:.3f} μm / pixel')
    axes[0,1].set(xlim=(-.7,.7),xlabel=tr('横向位置 / μm','Lateral position / μm'),ylabel=tr('相对强度','Relative intensity'),title=tr('B  采样太稀会丢掉峰间结构','B  Coarse sampling loses the valley'))
    axes[0,1].legend(frameon=False,fontsize=9)
    photons=np.logspace(0,4,180)
    axes[1,0].loglog(photons,np.sqrt(photons),color=green,lw=2.4,label=tr('纯光子噪声','Photon noise only'))
    axes[1,0].loglog(photons,photons/np.sqrt(photons+100+3**2),color=blue,lw=2.4,label=tr('背景100电子，读出噪声3电子','Background 100; read noise SD 3 electrons'))
    axes[1,0].set(xlabel=tr('平均信号电子数','Mean signal electrons'),ylabel='SNR',title=tr('C  多收集光子怎样改善信噪比','C  How collected photons improve SNR'))
    axes[1,0].legend(frameon=False,fontsize=9)
    rng=np.random.default_rng(612)
    counts=rng.poisson(100,10000)
    axes[1,1].hist(counts,bins=np.arange(60,141,2),color=blue,alpha=.8)
    axes[1,1].axvline(100,color=red,ls='--')
    axes[1,1].set(xlabel=tr('一次曝光的光子数','Photon count in one exposure'),ylabel=tr('模拟次数','Number of simulations'),title=tr('D  同样亮的光源仍会波动','D  A constant source still fluctuates'))
    save(fig,'resolution')

    image=np.asarray(Image.open(Path(__file__).parent/'data/mitosis.tif')).astype(float)
    if image.shape != (512,512): raise ValueError(f'Unexpected image shape {image.shape}')
    smooth=ndimage.gaussian_filter(image,.8)
    threshold=45
    def objects(t):
        mask=smooth>t
        labels,n=ndimage.label(mask)
        sizes=np.bincount(labels.ravel())
        keep=sizes>=40;keep[0]=False
        return keep[labels],int(np.sum(keep))
    mask,nobjects=objects(threshold)
    thresholds=np.arange(20,101,5)
    values=np.array([objects(t)[1] for t in thresholds])
    fig,axes=plt.subplots(2,2,figsize=(11,9),layout='constrained')
    axes[0,0].imshow(image,cmap='gray',vmin=0,vmax=180)
    axes[0,0].set(title=tr('A  真实DNA荧光图像 / CC0','A  Real DNA fluorescence image / CC0'),xlabel=tr('x / 像素','x / pixel'),ylabel=tr('y / 像素','y / pixel'))
    axes[0,1].imshow(image,cmap='gray',vmin=0,vmax=180)
    axes[0,1].contour(mask,levels=[.5],colors=[green],linewidths=.6)
    axes[0,1].set(title=tr(f'B  阈值45：{nobjects}个连通区域',f'B  Threshold 45: {nobjects} connected regions'),xlabel=tr('x / 像素','x / pixel'),ylabel=tr('y / 像素','y / pixel'))
    axes[1,0].hist(image.ravel(),bins=np.arange(257),color=gray)
    axes[1,0].set(yscale='log',xlabel=tr('原始灰度 / 数字量','Raw intensity / digital number'),ylabel=tr('像素数','Pixel count'),title=tr('C  保留原始灰度分布','C  Preserve the raw intensity distribution'))
    axes[1,0].axvline(threshold,color=red,ls='--')
    axes[1,1].plot(thresholds,values,'o-',color=green,lw=2)
    axes[1,1].axvline(threshold,color=red,ls='--')
    axes[1,1].set(xlabel=tr('分割阈值 / 数字量','Segmentation threshold / digital number'),ylabel=tr('面积≥40像素的区域数','Regions with area ≥40 pixels'),title=tr('D  参数敏感性：区域数不等于真细胞数','D  Sensitivity: regions are not ground-truth cells'))
    save(fig,'measurement')
    np.savez_compressed(output/'image_analysis.npz',raw=image,smoothed=smooth,mask=mask)
    with (output/'data.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['threshold_digital_number','connected_regions_area_ge40px']);w.writerows(zip(thresholds,values))
    summary={'rayleigh_um':rayleigh_um,'sample_pixel_um':sampling_um,
        'snr_100_signal_100_background_3_read':100/np.sqrt(209),
        'image_height_px':image.shape[0],'image_width_px':image.shape[1],
        'connected_regions_threshold45':nobjects,'mask_fraction_threshold45':float(mask.mean()),
        'poisson_sample_mean':float(counts.mean()),'poisson_sample_sd':float(counts.std(ddof=1)),
        'data_origin':'Real microscopy: David Root / CellProfiler, CC0; point profiles and photon draws: constructed teaching models'}
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False))


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='zh')
    args=parser.parse_args();main(args.output,args.language)
