"""Flow cytometry: constructed events, FCS round trip, compensation and gates.

The event cloud is simulated. The separately reproduced Figure 2 from White
et al. (2021) contains published experimental distributions; see NOTICE.txt.
Run offline: python main.py --output results --language en
"""
from pathlib import Path
import argparse, csv, json, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Polygon
from PIL import Image

# Unmodified BSD-3-Clause FlowIO is bundled for portable FCS reading/writing.
sys.path.insert(0, str(Path(__file__).resolve().parent / 'data' / 'vendor'))
import flowio

BLUE='#186e83'; AMBER='#cd803f'; PURPLE='#8160a1'; GREEN='#3c8a6a'
MATRIX=np.array([[1., .05], [.25, 1.]])  # rows: detectors; columns: fluorophores
BACKGROUND=np.array([80., 100.])

def compensate(measured, matrix=MATRIX, background=BACKGROUND):
    """Solve the linear signal mixture before applying a display transform."""
    return np.linalg.solve(matrix, (np.asarray(measured)-background).T).T

def gate_events(events, corrected):
    time,area,height,width,side,dead=events[:,:6].T
    stable=(time<45)|(time>=48)
    cells=stable&(area>50)&(area<300)&(side>20)&(side<140)
    singlets=cells&(area/height>.85)&(area/height<1.15)
    live=singlets&(dead<200)
    positive=live&(corrected[:,0]>200)&(corrected[:,1]>200)
    return dict(all=np.ones(len(events),dtype=bool),stable=stable,cells=cells,singlets=singlets,live=live,double_positive=positive)

def main(output,language='zh'):
    out=Path(output);out.mkdir(parents=True,exist_ok=True);zh=language=='zh';T=lambda z,e:z if zh else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5'})
    def save(fig,name):
        fig.savefig(out/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    def table(name,header,rows):
        with(out/name).open('w',newline='',encoding='utf8')as f:
            writer=csv.writer(f);writer.writerow(header);writer.writerows(rows)
    rng=np.random.default_rng(909);N=12000
    kinds=np.repeat(['debris','doublet','dead','live'],[1200,800,1000,9000]);rng.shuffle(kinds)
    time=np.arange(N)/100.;height=rng.lognormal(np.log(100),.17,N);side=rng.normal(60,13,N)
    height[kinds=='debris']=rng.uniform(15,35,(kinds=='debris').sum());side[kinds=='debris']=rng.uniform(5,18,(kinds=='debris').sum())
    width=rng.normal(1,.035,N);width[kinds=='doublet']=rng.normal(1.8,.06,(kinds=='doublet').sum())
    area=height*width;artifact=(time>=45)&(time<48);area[artifact]*=.45
    viability=rng.normal(50,15,N);viability[kinds=='dead']=rng.lognormal(np.log(900),.25,(kinds=='dead').sum())
    phenotype=rng.choice(4,N,p=[.35,.35,.20,.10]);truth=rng.exponential(12,(N,2))+15
    for channel,groups in [(0,[1,3]),(1,[2,3])]:
        mask=np.isin(phenotype,groups);truth[mask,channel]=rng.lognormal(np.log(800),.3,mask.sum())
    truth[kinds=='debris']*=.1;truth[kinds=='dead']+=500
    ideal=truth@MATRIX.T;measured=ideal+BACKGROUND+rng.normal(size=(N,2))*(18+.5*np.sqrt(ideal))
    original=np.column_stack([time,area,height,width,side,viability,measured])
    labels=['Time','FSC-A','FSC-H','FSC-W','SSC-A','Viability-A','FL1-A','FL2-A']
    with(out/'constructed-events.fcs').open('wb')as handle:
        flowio.create_fcs(handle,original.ravel().tolist(),labels,metadata_dict={'timestep':'1','comment':'Constructed teaching events; linear signals; external compensation matrix'})
    fcs=flowio.FlowData(out/'constructed-events.fcs');events=fcs.as_array(preprocess=True)
    assert fcs.event_count==N and fcs.channel_count==8 and fcs.pnn_labels==labels
    assert np.allclose(events,original,rtol=1e-6,atol=1e-5)
    corrected=compensate(events[:,6:8]);gates=gate_events(events,corrected);live=gates['live']
    table('events.csv',labels+['X_compensated','Y_compensated','simulated_kind','selected_double_positive'],[list(row)+list(c)+[kind,int(gates['double_positive'][i])]for i,(row,c,kind)in enumerate(zip(events,corrected,kinds))])
    table('gate_counts.csv',['gate','parent','events','percent_parent','percent_all'],[[name,'none'if j==0 else list(gates)[j-1],int(mask.sum()),100*mask.sum()/(N if j==0 else list(gates.values())[j-1].sum()),100*mask.mean()]for j,(name,mask)in enumerate(gates.items())])
    table('mixing_matrix.csv',['detector','X_coefficient','Y_coefficient'],[['FL1-A',1,.05],['FL2-A',.25,1]])
    np.savez_compressed(out/'flow_data.npz',events=events,corrected=corrected,truth=truth,kind=kinds,**{f'gate_{k}':v for k,v in gates.items()})
    # Independent single-stain controls estimate spillover on a linear scale.
    negative=BACKGROUND+rng.normal(0,12,(1000,2));controls=[];estimates=[]
    for ch in [0,1]:
        x=np.zeros((1000,2));x[:,ch]=rng.lognormal(np.log(1800),.28,1000)
        y=x@MATRIX.T+BACKGROUND+rng.normal(0,15,(1000,2));controls.append(y)
        delta=np.median(y,axis=0)-np.median(negative,axis=0);estimates.append(delta[1-ch]/delta[ch])
    table('single_stain_controls.csv',['control','FL1_A','FL2_A'],[[name,*row]for name,data in zip(['unstained','X_only','Y_only'],[negative,*controls])for row in data])
    # Same X-positive control gives the Y-FMO spreading example, after compensation.
    fmo=compensate(controls[0]);unstained=compensate(negative)
    cofactor=50.;transform=lambda x:np.arcsinh(x/cofactor)
    t=np.linspace(-15,15,1201);pulse=np.exp(-t*t/(2*2**2));double=np.exp(-(t-3)**2/8)+np.exp(-(t+3)**2/8)
    fig,axs=plt.subplots(1,2,figsize=(12,5.6));ax=axs[0];ax.set(xlim=(0,10),ylim=(0,9));ax.axis('off')
    ax.add_patch(Polygon([[3,8],[7,8],[5.7,5],[5.7,3],[4.3,3],[4.3,5]],closed=True,fc=BLUE,alpha=.12))
    ax.plot([5,5],[8,3],color=BLUE,lw=1)
    for y in [7.5,6.5,5.5,4.5,3.5]:ax.add_patch(Circle((5,y),.18,fc=BLUE))
    ax.annotate('',xy=(6.4,4.5),xytext=(1,4.5),arrowprops={'arrowstyle':'->','color':AMBER,'lw':2})
    ax.text(.8,5,T('激光','Laser'),color=AMBER);ax.text(7,4.5,T('散射与荧光\n成为同一行记录','Scatter and fluorescence\nbecome one event row'),fontsize=10,va='center')
    for x,y in [(5,2.6),(4.5,1.8),(4,1),(5.5,1.8),(6,1)]:ax.add_patch(Circle((x,y),.16,fc=PURPLE if x<5 else GREEN))
    ax.text(.3,8.7,T('1960年代：从逐个检测到按信号分选','1960s: from individual detection to signal-based sorting'),fontsize=11)
    ax.text(.3,.1,T('原创原理图；分选需另有液滴识别与偏转。','Original principle; sorting adds timed droplet deflection.'),fontsize=9)
    ax=axs[1];ax.plot(t,pulse,color=BLUE,label=T('一个高斯脉冲','One Gaussian pulse'));ax.plot(t,double,color=AMBER,label=T('相邻两脉冲','Two adjacent pulses'));ax.fill_between(t,0,pulse,color=BLUE,alpha=.12)
    ax.set(xlabel=T('经过光束的时间 / μs','Transit time / μs'),ylabel=T('扣基线信号 / a.u.','Baseline-corrected signal / a.u.'),title=T('高度接近，积分面积明显不同','Similar height, different integrated area'));ax.legend(frameon=False,fontsize=9);fig.tight_layout();save(fig,'history-pulses')
    fig,axs=plt.subplots(2,2,figsize=(11.5,8.7));sample=np.flatnonzero(live)[::3]
    for ax,data,title in [(axs[0,0],events[:,6:8]-BACKGROUND,T('A  扣基线后仍混有串色','A  Baseline subtraction leaves spillover')),(axs[0,1],corrected,T('B  线性补偿后，再用asinh显示','B  Linear compensation, then asinh display'))]:
        v=transform(data[sample]);ax.scatter(v[:,0],v[:,1],s=3,alpha=.22,color=BLUE,rasterized=True);ax.axvline(transform(200),color=AMBER,ls='--');ax.axhline(transform(200),color=AMBER,ls='--');ax.set(xlim=(-2,5),ylim=(-2,5),xlabel='asinh(detector 1 / 50)' if ax is axs[0,0] else 'asinh(X / 50)',ylabel='asinh(detector 2 / 50)' if ax is axs[0,0] else 'asinh(Y / 50)',title=title)
    ax=axs[1,0];ax.scatter(controls[0][:,0]-80,controls[0][:,1]-100,s=3,alpha=.2,color=AMBER);xx=np.array([0,4500]);ax.plot(xx,.25*xx,color=BLUE);ax.set(xlabel=T('X单染：主通道 / a.u.','X-only: primary detector / a.u.'),ylabel=T('次通道 / a.u.','Secondary detector / a.u.'),title=T('C  单染斜率给出串色比例','C  Single stain estimates spillover'))
    ax=axs[1,1];bins=np.linspace(-70,70,50);ax.hist(unstained[:,1],bins=bins,density=True,histtype='step',lw=2,color=GREEN,label=T('未染色对照','Unstained'));ax.hist(fmo[:,1],bins=bins,density=True,histtype='step',lw=2,color=PURPLE,label=T('X单染，Y缺失','X stained, Y omitted'));ax.axvline(0,color='gray',lw=.7);ax.set(xlabel=T('补偿Y / a.u.','Compensated Y / a.u.'),ylabel=T('概率密度 / (a.u.)⁻¹','Probability density / (a.u.)⁻¹'),title=T('D  负值保留，噪声仍存在','D  Retain negative values and noise'));ax.legend(frameon=False,fontsize=9)
    fig.tight_layout();save(fig,'compensation')
    fig,axs=plt.subplots(2,3,figsize=(13,8.1));idx=np.arange(0,N,4)
    axs[0,0].scatter(events[idx,0],events[idx,1],s=2,color=BLUE,alpha=.2);axs[0,0].axvspan(45,48,color=AMBER,alpha=.2);axs[0,0].set(xlabel=T('采集时间 / s','Acquisition time / s'),ylabel='FSC-A / a.u.',title=T('A  先检查时间稳定性','A  Check stability over time'))
    ids=np.flatnonzero(gates['stable'])[::3];axs[0,1].scatter(events[ids,1],events[ids,4],s=2,color=BLUE,alpha=.2);axs[0,1].add_patch(Rectangle((50,20),250,120,fill=False,ec=AMBER,lw=1.5));axs[0,1].set(xlabel='FSC-A / a.u.',ylabel='SSC-A / a.u.',title=T('B  散射门定义候选事件','B  Scatter gate defines candidates'))
    ids=np.flatnonzero(gates['cells'])[::3];axs[0,2].scatter(events[ids,2],events[ids,1],s=2,color=BLUE,alpha=.2);xx=np.array([40,200]);axs[0,2].plot(xx,.85*xx,color=AMBER);axs[0,2].plot(xx,1.15*xx,color=AMBER);axs[0,2].set(xlabel='FSC-H / a.u.',ylabel='FSC-A / a.u.',title=T('C  单事件脉冲几何','C  Singlet pulse geometry'))
    ids=np.flatnonzero(gates['singlets']);axs[1,0].hist(events[ids,5],bins=np.linspace(0,1600,70),color=BLUE,alpha=.7);axs[1,0].axvline(200,color=AMBER);axs[1,0].set(xlabel=T('死亡染料 / a.u.','Viability-dye signal / a.u.'),ylabel=T('事件数','Events'),title=T('D  选定存活状态','D  Select the live population'))
    axs[1,1].scatter(transform(corrected[sample,0]),transform(corrected[sample,1]),s=2,alpha=.2,color=BLUE);axs[1,1].axvline(transform(200),color=AMBER);axs[1,1].axhline(transform(200),color=AMBER);axs[1,1].set(xlabel='asinh(X / 50)',ylabel='asinh(Y / 50)',title=T('E  活单细胞中读取表型','E  Phenotype within live singlets'))
    names=[T(z,e)for z,e in [('全部','All'),('稳定','Stable'),('候选','Cells'),('单细胞','Singlets'),('活细胞','Live'),('双阳性','X+Y+')]];counts=[int(v.sum())for v in gates.values()];axs[1,2].barh(np.arange(6),counts,color=[BLUE]*5+[AMBER]);axs[1,2].set_yticks(np.arange(6),names);axs[1,2].invert_yaxis();axs[1,2].set(xlabel=T('通过事件数','Passing events'),title=T('F  每一步保留数量与分母','F  Preserve counts and denominators'))
    for i,c in enumerate(counts):axs[1,2].text(c+100,i,str(c),va='center',fontsize=9)
    axs[1,2].set_xlim(0,15000);fig.tight_layout();save(fig,'gating')
    fig,axs=plt.subplots(1,3,figsize=(13,4.7));denoms=[10000,6000,3000];numerator=900
    axs[0].bar(T(['全部事件','活单细胞','X阳性'],['All events','Live singlets','X-positive']),[100*numerator/d for d in denoms],color=[BLUE,GREEN,AMBER]);axs[0].set(ylabel=T('同一900事件所占比例 / %','Fraction of the same 900 events / %'),title=T('A  分母改变，问题改变','A  Denominators change the question'))
    k=np.logspace(0,4,200);axs[1].loglog(k,100/np.sqrt(k),color=PURPLE);axs[1].scatter([25,100,400],[20,10,5],color=AMBER);axs[1].set(xlabel=T('稀有目标事件数 k','Rare-target count k'),ylabel=T('泊松计数近似CV / %','Poisson counting CV / %'),title=T('B  多采集改善抽样精度','B  More events improve sampling precision'))
    beads=np.array([500,1000,2000]);cells=6*beads;concentration=cells/beads*1000*20/100
    axs[2].plot(beads,concentration,'o-',color=GREEN);axs[2].set(xlabel=T('采到的计数珠数','Acquired bead events'),ylabel=T('原样目标浓度 / cells μL⁻¹','Original target concentration / cells μL⁻¹'),ylim=(0,1600),title=T('C  采集份额消去','C  Sampling fraction cancels'));fig.tight_layout();save(fig,'counts')
    fig,ax=plt.subplots(figsize=(13,8.2));ax.imshow(Image.open(Path(__file__).resolve().parent/'flowkit2021-figure2.webp').convert('RGB'));ax.axis('off');ax.set_title(T('真实测量分布：在同一标记内比较两群细胞','Measured distributions: compare two populations within each marker'),fontsize=12);fig.text(.5,.015,T('White等，2021，图2；CC BY 4.0，完整转载。原图横轴是变换坐标。','White et al., 2021, Figure 2; CC BY 4.0, reproduced in full. Original x-axis shows transformed coordinates.'),ha='center',fontsize=9);fig.tight_layout(rect=[0,.04,1,1]);save(fig,'published')
    exact=compensate(np.array([[1010.,450.]])+BACKGROUND)
    wrong=compensate(transform(np.array([[1010.,450.]])),background=np.zeros(2))
    summary={'fcs':{'events':fcs.event_count,'channels':fcs.channel_count,'maximum_absolute_roundtrip_error':float(abs(events-original).max())},'compensation':{'example_X':float(exact[0,0]),'example_Y':float(exact[0,1]),'estimated_X_to_Y':float(estimates[0]),'estimated_Y_to_X':float(estimates[1]),'negative_Y_live_events':int((corrected[live,1]<0).sum()),'transform_then_compensate_Y':float(wrong[0,1]),'compensate_then_transform_Y':float(transform(exact)[0,1])},'pulse':{'single_area':float(np.trapezoid(pulse,t)),'double_area':float(np.trapezoid(double,t)),'area_ratio':float(np.trapezoid(double,t)/np.trapezoid(pulse,t))},'gates':dict(zip(gates,counts)),'fractions':{'double_positive_percent_live':100*counts[-1]/counts[-2],'double_positive_percent_all':100*counts[-1]/N},'counting':{'conditional_percent':900/3000*100,'all_percent':900/10000*100,'bead_based_cells_per_uL':6000/1000*1000*20/100,'binomial_se_at_p025_N1000':float(np.sqrt(.25*.75/1000)),'rare_cv_at25':1/np.sqrt(25),'rare_cv_at100':1/np.sqrt(100)}}
    assert np.allclose(exact,[[1000,200]])
    assert abs(estimates[0]-.25)<.01 and abs(estimates[1]-.05)<.01
    assert summary['compensation']['negative_Y_live_events']>0
    assert all(a>=b for a,b in zip(counts,counts[1:]))
    assert abs(summary['pulse']['area_ratio']-2)<1e-7
    assert not np.isclose(wrong[0,1],transform(exact)[0,1])
    (out/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False),encoding='utf8');print(json.dumps(summary,allow_nan=False))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);parser.add_argument('--language',choices=['zh','en'],default='zh');args=parser.parse_args();main(args.output,args.language)
