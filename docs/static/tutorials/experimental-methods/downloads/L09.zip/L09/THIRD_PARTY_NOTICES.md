# Public sources and third-party materials

- Herzenberg et al. (2002). The History and Future of the Fluorescence Activated Cell Sorter and Flow Cytometry: https://herzenberglab.stanford.edu/sites/g/files/sbiybj27506/files/media/file/lah490.pdf
  Historical reference; no artwork reproduced.
- Cossarizza et al. (2019). Guidelines for the use of flow cytometry and cell sorting in immunological studies, second edition: https://pmc.ncbi.nlm.nih.gov/articles/PMC7350392/
  Technical reference; no material reproduced from this source.
- FlowKit tutorial 1: Sample class: https://flowkit.readthedocs.io/en/latest/notebooks/flowkit-tutorial-part01-sample-class.html
  Technical documentation; independently written example.
- FlowKit tutorial 2: transforms and Matrix: https://flowkit.readthedocs.io/en/latest/notebooks/flowkit-tutorial-part02-transforms-module-matrix-class.html
  Technical documentation; no tutorial code copied.
- FlowKit tutorial 3: GatingStrategy and GatingResults: https://flowkit.readthedocs.io/en/latest/notebooks/flowkit-tutorial-part03-gating-strategy-and-gating-results-classes.html
  Technical documentation.
- FlowIO API and source: https://flowio.readthedocs.io/en/latest/api.html
  FlowIO 1.4.0 source bundled under BSD-3-Clause; full license included.
- CountBright Plus Absolute Counting Beads User Guide, MAN0018850 B.0: https://documents.thermofisher.com/TFS-Assets/LSG/manuals/MAN0018850_CountBrightPlus_UG.pdf
  Technical reference; no proprietary figure reproduced.
- White et al. (2021). FlowKit: A Python Toolkit for Integrated Manual and Automated Cytometry Analysis Workflows: https://www.frontiersin.org/journals/immunology/articles/10.3389/fimmu.2021.768541/full
  Figure 2: CC BY 4.0, credited and reproduced in full; code license separately BSD-3-Clause.
