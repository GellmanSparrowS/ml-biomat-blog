# Public sources and third-party materials

- SASBDB SASDAC2 — Lysozyme in sodium acetate: https://www.sasbdb.org/data/SASDAC2/
  SASBDB unrestricted reuse policy; attribution required by community guidance.
- SASBDB — About and data-use policy: https://www.sasbdb.org/about/
  Data and models free of copyright restrictions, with original-author attribution requested.
- BioXTAS RAW — Guinier analysis: https://bioxtas-raw.readthedocs.io/en/latest/saxs/saxs_guinier.html
  Public technical reference; no figure reproduced.
- SSRL — SAXS data analysis primer: https://www-ssrl.slac.stanford.edu/smb-saxs/content/data-analysis-primer
  Public facility educational reference; no figure reproduced.
- Trewhella et al. — 2017 biomolecular SAS reporting guidelines: https://journals.iucr.org/d/issues/2017/09/00/jc5010/index.html
  Open scientific reference; no paper figure reproduced.
- André Guinier — Personal reminiscences: https://www.iucr.org/what-we-do/publications/books/Fifty-Years-of-X-ray-Diffraction/guinier
  Historical primary account; original explanatory illustration used.
