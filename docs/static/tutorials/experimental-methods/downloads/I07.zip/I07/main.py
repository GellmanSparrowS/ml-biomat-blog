"""Read the openly reusable SASBDB SASDAC2 profile and teach SAXS inference.

python main.py --output results --language en
Data credit: Darja Ruskule, SASBDB SASDAC2 (lysozyme in sodium acetate).
https://www.sasbdb.org/data/SASDAC2/ ; https://www.sasbdb.org/about/
The archive permits unrestricted reuse with attribution. The archived profile
is processed solution-minus-buffer intensity, not a raw detector exposure.
"""
from pathlib import Path
import argparse, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
from scipy.optimize import curve_fit

def fit_guinier(q, intensity, sigma, lo=.087, hi=.8):
    m=(q>=lo)&(q<=hi)&(intensity>0)&(sigma>0)
    x=q[m]**2; y=np.log(intensity[m]); weights=intensity[m]/sigma[m]
    X=np.column_stack([np.ones(m.sum()),x])
    coeff=np.linalg.lstsq(X*weights[:,None],y*weights,rcond=None)[0]
    rg=np.sqrt(-3*coeff[1]) if coeff[1]<0 else np.nan
    return {'rg_nm':float(rg),'i0':float(np.exp(coeff[0])),
            'points':int(m.sum()),'slope_nm2':float(coeff[1]),
            'intercept':float(coeff[0]),'qmax_rg':float(hi*rg)},m

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args()
    out=args.output;out.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
    tr=lambda a,b:a if zh else b
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,
        'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#18344a',
        'text.color':'#18344a','axes.edgecolor':'#8295a2','svg.fonttype':'none',
        'savefig.facecolor':'#fbfcfc','figure.facecolor':'#fbfcfc'})
    blue='#186c94';green='#188777';orange='#d27839';gray='#a1abb2'
    def save(fig,name):
        fig.savefig(out/f'{name}-{args.language}.svg',bbox_inches='tight')
        fig.savefig(out/f'{name}-{args.language}.png',bbox_inches='tight',dpi=150);plt.close(fig)
    # The historical ATSAS file has four header lines, 2168 rows, then a footer.
    data=np.loadtxt(Path(__file__).parent/'data'/'SASDAC2.dat',skiprows=4,max_rows=2168)
    q,I,sigma=data.T
    result,mask=fit_guinier(q,I,sigma)
    nonlinear,_=curve_fit(lambda x,i0,rg:i0*np.exp(-x*x*rg*rg/3),q[mask],I[mask],
                         sigma=sigma[mask],p0=[12,1.4],absolute_sigma=True)
    windows=np.arange(.4,1.201,.025)
    sensitivity=np.array([fit_guinier(q,I,sigma,hi=h)[0]['rg_nm'] for h in windows])
    testq=np.linspace(.1,.8,80);testI=10*np.exp(-testq**2*1.5**2/3)
    reference,_=fit_guinier(testq,testI,np.ones(80)*.1)
    summary={**result,'nonlinear_rg_nm':float(nonlinear[1]),'nonlinear_i0':float(nonlinear[0]),
       'rows':len(q),'nonpositive_rows':int(np.sum(I<=0)),
       'noiseless_rg_nm':reference['rg_nm'],'noiseless_i0':reference['i0'],
       'q_for_1deg_invnm':float(4*np.pi*np.sin(np.deg2rad(.5))/.15),
       'equivalent_sphere_radius_nm':float(np.sqrt(5/3)*result['rg_nm']),
       'intensity_units':'archived intensity units; absolute calibration not asserted',
       'data_credit':'Darja Ruskule; SASBDB SASDAC2'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    predicted=result['i0']*np.exp(-q*q*result['rg_nm']**2/3)
    np.savetxt(out/'data.csv',np.column_stack([q,I,sigma,mask.astype(int),predicted]),delimiter=',',
         header='q_invnm,intensity,reported_sigma,guinier_selected,guinier_prediction',comments='')
    np.savetxt(out/'window_sensitivity.csv',np.column_stack([windows,sensitivity]),delimiter=',',
         header='qmax_invnm,rg_nm',comments='')
    # Original apparatus illustration; not a replica of a historical camera.
    fig,axs=plt.subplots(1,2,figsize=(12,4.5),gridspec_kw={'width_ratios':[1.55,1]})
    a=axs[0];a.set_xlim(0,10);a.set_ylim(-2,2);a.axis('off')
    a.plot([.3,8.45],[0,0],color=blue,lw=2)
    for x in [1.5,2.4]:
        a.add_patch(Rectangle((x,-.8),.16,.72,color=gray));a.add_patch(Rectangle((x,.08),.16,.72,color=gray))
    a.add_patch(Rectangle((3.8,-.6),.3,1.2,facecolor='#b5dddb',edgecolor=green))
    a.plot([8.8,8.8],[-1.8,1.8],color=blue,lw=5)
    a.add_patch(Rectangle((8.45,-.18),.3,.36,color='#394d5c'))
    for s in [-1,1]:a.plot([4,8.8],[0,s*1.3],color=orange,lw=2)
    for x,y,z,e in [(1.9,1.25,'准直狭缝','Collimation'),(4,-1.2,'溶液样品','Solution'),(8.4,-.7,'挡光片','Beamstop'),(8.7,1.6,'探测器','Detector')]:a.text(x,y,tr(z,e),ha='center',fontsize=10)
    a.annotate('',xy=(8.8,-1.65),xytext=(4,-1.65),arrowprops={'arrowstyle':'<->','color':blue})
    a.text(6.3,-1.95,tr('较长距离：分开很小的角度','Long distance resolves small angles'),ha='center',fontsize=10)
    a.set_title(tr('A  1930年代的小角问题 → 现代几何','A  A 1930s question → modern geometry'),loc='left')
    b=axs[1];b.set_xlim(-3,3);b.set_ylim(-2.1,2.1);b.set_aspect('equal');b.axis('off')
    b.add_patch(Circle((-1.5,0),1,facecolor='#b5dddb',edgecolor=green))
    theta=np.linspace(0,2*np.pi,10,endpoint=False)
    b.scatter(1.5+.775*np.cos(theta),.775*np.sin(theta),s=35,color=orange)
    b.plot([-1.5,-.5],[0,0],color=green);b.text(-1.5,-1.45,tr('均匀实心圆球','Uniform solid sphere'),ha='center',fontsize=10)
    b.text(1.5,-1.45,tr('分散散射单元','Separated scatterers'),ha='center',fontsize=10)
    b.set_title(tr('B  相同均方距离，不同内部排列','B  Same mean-square distance, different structure'),loc='left',fontsize=11)
    save(fig,'geometry')
    fig,ax=plt.subplots(2,2,figsize=(12,9));a,b,c,d=ax.ravel()
    positive=I>0
    a.errorbar(q[positive][::8],I[positive][::8],yerr=sigma[positive][::8],fmt='.',ms=3,lw=.5,color=blue,alpha=.65)
    a.set_yscale('log');a.set_ylim(.01,30);a.set_xlabel('q / nm⁻¹');a.set_ylabel(tr('归档强度','Archived intensity'))
    a.set_title(tr('A  真实溶菌酶溶液曲线','A  Measured lysozyme solution profile'),loc='left')
    a.text(.97,.96,tr('非正强度见下一幅线性坐标图','Nonpositive intensities shown on linear axis next'),transform=a.transAxes,ha='right',va='top',fontsize=9)
    low=(q<=1.2)&positive
    b.errorbar(q[low]**2,np.log(I[low]),yerr=sigma[low]/I[low],fmt='o',ms=2,mfc='white',mec=gray,color=gray,lw=.5,alpha=.6)
    b.scatter(q[mask]**2,np.log(I[mask]),s=8,color=blue)
    x=np.linspace(0,.8**2,100);b.plot(x,result['intercept']+result['slope_nm2']*x,color=orange,lw=2)
    b.set_ylim(1.65,2.7);b.set_xlabel('q² / nm⁻²');b.set_ylabel('ln I');b.set_title(tr('B  Guinier区域：实心点参与拟合','B  Guinier region: filled points fitted'),loc='left')
    c.scatter(q[mask],(I[mask]-predicted[mask])/sigma[mask],s=10,color=blue)
    c.axhline(0,color=gray);c.set_xlabel('q / nm⁻¹');c.set_ylabel(tr('(观测−预测) / σ','(Observed − predicted) / σ'))
    c.set_title(tr('C  以归档误差为单位的残差','C  Residuals in reported-error units'),loc='left')
    d.plot(windows,sensitivity,color=green,lw=2);d.axvline(.8,color=orange,ls='--')
    d.axhline(1.5,color=gray,ls=':',label=tr('归档页面报告值1.5 nm','Entry-reported value 1.5 nm'))
    d.set_xlabel('qmax / nm⁻¹');d.set_ylabel('Rg / nm');d.set_title(tr('D  改变上限，检查估计稳定性','D  Change upper bound; inspect stability'),loc='left');d.legend(fontsize=9)
    fig.suptitle(tr('真实数据：Darja Ruskule · SASBDB SASDAC2','Measured data: Darja Ruskule · SASBDB SASDAC2'),fontsize=13)
    fig.tight_layout();save(fig,'guinier')
    fig,axs=plt.subplots(1,2,figsize=(12,4.8));a,b=axs
    x=np.linspace(.001,7,900);u=np.sqrt(5/3)*x
    sphere=(3*(np.sin(u)-u*np.cos(u))/u**3)**2
    chain=2*(np.exp(-x*x)-1+x*x)/x**4
    a.plot(x,x*x*sphere,color=green,label=tr('均匀圆球模型','Uniform sphere model'))
    a.plot(x,x*x*chain,color=orange,label=tr('理想高斯链模型','Ideal Gaussian-chain model'))
    a.set_xlabel('q Rg');a.set_ylabel('(q Rg)² I(q) / I(0)');a.legend();a.set_title(tr('A  同一Rg下的模型形状','A  Model shapes at the same Rg'),loc='left')
    high=np.unique(np.r_[np.flatnonzero(q>4.5)[::3],np.flatnonzero((q>4.5)&(I<=0))])
    b.errorbar(q[high],I[high],yerr=sigma[high],fmt='.',color=blue,lw=.5,alpha=.65)
    b.axhline(0,color=gray);b.set_xlabel('q / nm⁻¹');b.set_ylabel(tr('归档强度，线性坐标','Archived intensity, linear scale'))
    b.set_title(tr('B  高q端：负值也属于测量结果','B  High q: negative values remain data'),loc='left')
    fig.tight_layout();save(fig,'shape')
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':main()
