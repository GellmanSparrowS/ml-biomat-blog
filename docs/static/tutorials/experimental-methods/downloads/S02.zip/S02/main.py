"""Raman measurement and processing with explicitly constructed teaching data.

Run: python main.py --output output --language en
No experimental material or chemical identity is assigned to the model bands.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch
from scipy.optimize import curve_fit

BLUE, TEAL, ORANGE, INK = '#245ca6', '#087f80', '#ce6b35', '#233446'


def band(x, area, center, sigma):
    """Area-normalized Gaussian; x, center and sigma are in cm^-1."""
    return area / (sigma * np.sqrt(2 * np.pi)) * np.exp(-.5 * ((x-center)/sigma)**2)


def two_bands(x, a1, c1, w1, a2, c2, w2):
    return band(x, a1, c1, w1) + band(x, a2, c2, w2)


def signal_to_noise(power, time, background=1):
    signal = 40 * power * time
    baseline = 160 * background * power * time
    return signal / np.sqrt(signal + baseline + 25)


def main(output, language):
    output.mkdir(parents=True, exist_ok=True)
    zh = language == 'zh'
    tr = lambda a, b: a if zh else b
    plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif':
        ['Microsoft YaHei', 'Noto Sans CJK SC', 'DejaVu Sans'], 'font.size': 11,
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.labelcolor': INK, 'text.color': INK, 'svg.fonttype': 'none',
        'axes.unicode_minus': False, 'figure.facecolor': '#fbfaf6',
        'axes.facecolor': '#fbfaf6', 'savefig.facecolor': '#fbfaf6'})
    def save(fig, name):
        fig.savefig(output / f'{name}-{language}.svg', bbox_inches='tight')
        fig.savefig(output / f'{name}-{language}.png', bbox_inches='tight', dpi=140)
        plt.close(fig)
    def arrow(ax, a, b, color=INK):
        ax.add_patch(FancyArrowPatch(a, b, arrowstyle='-|>', mutation_scale=14,
                     lw=2, color=color))

    # Figure 1: an original conceptual comparison of optical functions.
    fig, axes = plt.subplots(2, 1, figsize=(11.8, 7.2), layout='constrained')
    for ax in axes:
        ax.set(xlim=(0, 11), ylim=(-.4, 3.4)); ax.axis('off')
    ax=axes[0]; ax.set_title(tr('1928：选择入射颜色，抑制强背景',
        '1928: Select incident color and reject the dominant light'), loc='left', pad=12)
    ax.add_patch(Circle((.8,1.25),.22,color='#dfae56'))
    for angle in np.arange(0,2*np.pi,.52):
        ax.plot([.8+.3*np.cos(angle),.8+.48*np.cos(angle)],
                [1.25+.3*np.sin(angle),1.25+.48*np.sin(angle)],color='#dfae56')
    for dy,color in [(-.08,BLUE),(0,'#7850a2'),(.08,TEAL)]:arrow(ax,(1.3,1.25+dy),(2.35,1.25+dy),color)
    ax.add_patch(Rectangle((2.45,.8),.15,.9,facecolor='#7850a2',alpha=.7))
    arrow(ax,(2.65,1.25),(4.05,1.25),'#7850a2')
    ax.add_patch(Rectangle((4.1,.65),.8,1.2,facecolor='#e1efef',edgecolor=INK))
    for sx,sy in [(4.3,.85),(4.6,1.15),(4.3,1.5),(4.65,1.65)]:ax.add_patch(Circle((sx,sy),.04,color=TEAL))
    arrow(ax,(4.5,1.3),(4.5,2.25),'#7850a2')
    arrow(ax,(4.65,1.3),(4.65,2.25),TEAL)
    ax.add_patch(Rectangle((4.1,2.3),.9,.12,facecolor=TEAL,alpha=.6))
    arrow(ax,(4.65,2.5),(4.65,3.1),TEAL)
    ax.text(.8,.35,tr('光源','Light source'),ha='center',fontsize=10)
    ax.text(2.5,.35,tr('选色滤光片','Incident filter'),ha='center',fontsize=10)
    ax.text(4.5,.35,tr('液体样品','Liquid specimen'),ha='center',fontsize=10)
    ax.text(5.2,2.35,tr('抑制原色，观察弱散射','Reject original color; observe shifted light'),fontsize=10,color=TEAL)
    ax.text(6.1,1.25,tr('入射与收集方向分开\n先选光，再辨认变化',
        'Separate illumination and collection\nSelect light before comparing its color'),fontsize=12,linespacing=1.8)
    ax=axes[1];ax.set_title(tr('现代：聚焦、滤光、分光、计数','Modern: Focus, reject, disperse and count'),loc='left',pad=12)
    ax.add_patch(Rectangle((.35,1.6),1.1,.6,facecolor='#e8eff2',edgecolor=INK))
    ax.text(.9,1.9,tr('激光','Laser'),ha='center',va='center')
    arrow(ax,(1.5,1.9),(3.7,1.9),BLUE)
    ax.plot([3.7,4.15],[2.1,1.65],color=INK,lw=3)
    arrow(ax,(3.92,1.7),(3.92,.9),BLUE)
    ax.add_patch(Rectangle((3.55,.65),.8,.25,facecolor='#d5e2e8',edgecolor=INK))
    ax.plot([3.55,3.75,4.15,4.35],[.65,.42,.42,.65],color=INK)
    ax.add_patch(Rectangle((3.5,.05),1,.12,facecolor=TEAL))
    arrow(ax,(4.15,.3),(4.15,2.48),TEAL)
    ax.plot([3.95,4.35],[2.35,2.75],color=INK,lw=2)
    arrow(ax,(4.35,2.55),(5.65,2.55),TEAL)
    ax.add_patch(Rectangle((5.75,2.1),.15,.9,facecolor=TEAL,alpha=.65))
    arrow(ax,(6,2.55),(7.8,2.55),TEAL)
    ax.plot([8,8.3],[2.15,2.95],color=INK,lw=4)
    for k in range(5):ax.plot([7.96+.06*k,8.08+.06*k],[2.17+.15*k,2.15+.15*k],color='#8895a5')
    for y,col in [(2.,ORANGE),(2.5,TEAL),(3.,BLUE)]:arrow(ax,(8.35,2.55),(9.85,y),col)
    ax.add_patch(Rectangle((9.9,1.75),.24,1.5,facecolor='#e8eff2',edgecolor=INK))
    for y in np.linspace(1.8,3.2,11):ax.plot([9.9,10.14],[y,y],color='#8b98a5',lw=.7)
    ax.text(3.35,.65,tr('物镜','Objective'),ha='right',fontsize=10)
    ax.text(3.98,-.2,tr('样品','Specimen'),ha='center',fontsize=10)
    ax.text(5.82,1.7,tr('瑞利抑制','Rayleigh rejection'),ha='center',fontsize=10)
    ax.text(8.1,1.7,tr('光栅','Grating'),ha='center',fontsize=10)
    ax.text(10.02,1.3,tr('像素阵列','Pixel array'),ha='center',fontsize=10)
    ax.text(7.3,.5,tr('像素 → 波长 → 拉曼位移','Pixels → wavelength → Raman shift'),ha='center')
    save(fig,'optics')

    # Figure 2: energy bookkeeping, not a molecular potential-energy curve.
    fig,axes=plt.subplots(1,3,figsize=(11.8,4.5),layout='constrained')
    for ax,name,start,end in zip(axes,[tr('瑞利','Rayleigh'),tr('斯托克斯','Stokes'),tr('反斯托克斯','Anti-Stokes')],[0,0,1],[0,1,0]):
        ax.set(xlim=(0,3),ylim=(-.5,4.9));ax.axis('off');ax.set_title(name)
        for y in [0,1]:ax.plot([.2,2.8],[y,y],color=INK,lw=1.6)
        virtual=3+start
        ax.plot([.2,2.8],[virtual,virtual],color='#8b93a0',ls='--',lw=1.4)
        arrow(ax,(.85,start),(.85,virtual),BLUE);arrow(ax,(2.1,virtual),(2.1,end),TEAL)
        ax.text(1.5,virtual+.28,tr('虚能级（过程表示）','Virtual level (process representation)'),ha='center',fontsize=9)
        ax.text(2.7,-.32,'v = 0',ha='right',fontsize=9)
        ax.text(2.7,1.16,'v = 1',ha='right',fontsize=9)
        ax.text(.4,2.05,tr('入射','In'),color=BLUE);ax.text(2.25,2.05,tr('散射','Out'),color=TEAL)
    save(fig,'energy')

    # Independent photon counts; all generating parameters remain inspectable.
    rng=np.random.default_rng(248)
    x=np.arange(600.,1801.)
    base=110+.035*(x-600)+.000045*(x-1200)**2
    truth=two_bands(x,6000,1000,9,3600,1040,14)+band(x,12000,1450,28)
    raw=rng.poisson(base+truth).astype(float)
    anchors=(x<950)|((x>1120)&(x<1320))|(x>1560)
    contaminated=anchors|((x>1380)&(x<1520))
    fit_base=lambda m:np.polyval(np.polyfit((x[m]-1200)/600,raw[m],2),(x-1200)/600)
    good,bad=fit_base(anchors),fit_base(contaminated)
    region=(x>=950)&(x<=1120)
    def fit(background):
        return curve_fit(two_bands,x[region],(raw-background)[region],
           p0=[6000,1000,9,3600,1040,14],
           bounds=([0,990,3,0,1025,3],[20000,1010,25,20000,1055,35]),maxfev=20000)[0]
    params,biased=fit(good),fit(bad)
    model=two_bands(x[region],*params)
    residual=(raw-good)[region]-model
    np.savetxt(output/'spectrum.csv',np.column_stack([x,raw,base,truth,good,bad]),delimiter=',',
       header='shift_cm-1,raw_counts,true_background,true_bands,estimated_background,contaminated_background',comments='')
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    ax=axes[0,0];ax.plot(x,raw,color='#8895a5',lw=.7,label=tr('原始计数','Raw counts'))
    ax.plot(x,good,color=TEAL,lw=2,label=tr('无峰区估计','Clean anchors'))
    ax.plot(x,bad,color=ORANGE,lw=2,label=tr('含峰区估计','Contaminated anchors'))
    ax.set(title=tr('A · 原始信号与两种基线','A · Raw signal and two baselines'),ylabel=tr('计数','Counts'));ax.legend(fontsize=9)
    ax=axes[0,1];ax.plot(x[region],(raw-good)[region],'.',ms=3,color='#8a95a5',label=tr('扣除基线','Corrected'))
    ax.plot(x[region],model,color=INK,label=tr('双峰拟合','Two-band fit'))
    ax.fill_between(x[region],band(x[region],*params[:3]),alpha=.2,color=BLUE)
    ax.fill_between(x[region],band(x[region],*params[3:]),alpha=.2,color=TEAL)
    ax.set(title=tr('B · 相邻峰分别贡献多少','B · Contributions of neighboring bands'),ylabel=tr('计数','Counts'));ax.legend(fontsize=9)
    ax=axes[1,0];ax.plot(x[region],residual,color=BLUE,lw=.9);ax.axhline(0,color=INK,lw=1)
    ax.set(title=tr('C · 残差保留处理线索','C · Residuals retain diagnostic evidence'),ylabel=tr('数据 − 拟合 / 计数','Data − fit / counts'))
    ax=axes[1,1];ratios=[.6,params[3]/params[0],biased[3]/biased[0]]
    ax.bar([0,1,2],ratios,color=['#8b98a5',TEAL,ORANGE],width=.55)
    ax.axhline(.6,color=INK,ls='--',lw=1)
    ax.set(xticks=[0,1,2],xticklabels=[tr('真值','Truth'),tr('无峰区','Clean anchors'),tr('含峰区','Contaminated')],
       ylabel=tr('第二峰面积 / 第一峰面积','Second / first band area'),title=tr('D · 基线选择改变面积比','D · Baseline choice changes the area ratio'),ylim=(0,max(.9,max(ratios)*1.2)))
    for i,v in enumerate(ratios):ax.text(i,v+.025,f'{v:.3f}',ha='center')
    for ax in [axes[0,0],axes[0,1],axes[1,0]]:ax.set_xlabel(tr('拉曼位移 / cm$^{-1}$','Raman shift / cm$^{-1}$'))
    save(fig,'processing')

    fig,axes=plt.subplots(1,2,figsize=(11.8,4.8),layout='constrained')
    t=np.linspace(.1,20,300)
    for b,color in [(1,BLUE),(.25,TEAL)]:axes[0].plot(t,signal_to_noise(1,t,b),color=color,label=tr('背景系数','Background factor')+f' {b:g}')
    axes[0].set(xlabel=tr('曝光时间 / s','Exposure time / s'),ylabel=tr('信噪比','Signal-to-noise ratio'),title=tr('A · 收集更久或降低背景','A · Collect longer or reduce background'));axes[0].legend()
    power=np.linspace(.1,5,150);time=np.linspace(.1,20,180);pp,tt=np.meshgrid(power,time)
    im=axes[1].pcolormesh(pp,tt,signal_to_noise(pp,tt),shading='auto',cmap='viridis')
    cs=axes[1].contour(pp,tt,200*pp*tt,levels=[3000],colors='white',linewidths=1.8)
    axes[1].clabel(cs,fmt={3000:tr('计数上限','Count limit')},fontsize=9)
    axes[1].set(xlabel=tr('功率系数','Power factor'),ylabel=tr('曝光时间 / s','Exposure time / s'),title=tr('B · 先确认线性记录范围','B · Identify the linear recording range'))
    fig.colorbar(im,ax=axes[1],label=tr('理想信噪比','Ideal signal-to-noise ratio'))
    save(fig,'acquisition')
    summary={'data_kind':'constructed teaching spectrum','seed':248,
      'stokes_532_nm':1/(1/532-1000/1e7),'stokes_785_nm':1/(1/785-1000/1e7),
      'energy_1000_eV':6.62607015e-34*299792458*1000*100/1.602176634e-19,
      'true_area_ratio':.6,'fitted_area_ratio':float(params[3]/params[0]),
      'contaminated_area_ratio':float(biased[3]/biased[0]),'parameters':params.tolist(),
      'snr_example_without_read_noise':float(200/np.sqrt(1000)),
      'lab_snr_default':float(signal_to_noise(1,5)),
      'residual_rms':float(np.sqrt(np.mean(residual**2)))}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en')
    args=parser.parse_args();main(args.output,args.language)
