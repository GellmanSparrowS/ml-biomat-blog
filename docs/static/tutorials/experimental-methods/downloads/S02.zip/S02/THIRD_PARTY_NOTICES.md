# Public sources and third-party materials

- C. V. Raman and the Raman Effect — ACS: https://www.acs.org/education/whatischemistry/landmarks/ramaneffect.html
  Technical reference; original course illustrations.
- Raja and Barron: Raman Spectroscopy: https://chem.libretexts.org/Bookshelves/Analytical_Chemistry/Physical_Methods_in_Chemistry_and_Nano_Science_(Barron)/04%3A_Chemical_Speciation/4.03%3A_Raman_Spectroscopy
  CC BY 4.0 page; cited as open reading.
- NIST: Raman Intensity Calibration With Glass Luminescence Standards: https://www.nist.gov/publications/raman-intensity-calibration-glass-luminescence-standards
  Technical reference.
- RamanSPy: Preprocessing: https://ramanspy.readthedocs.io/en/latest/preprocessing.html
  Technical reference; no software code copied.
- SciPy: curve_fit: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html
  Technical reference; original example code.
