"""Constructed XPS experiments: surface weighting, composition and peak models."""
from pathlib import Path
import argparse, json
import numpy as np
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch, Arc

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en')
    args=parser.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True)
    zh=args.language=='zh';T=lambda z,e:z if zh else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,
        'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold',
        'axes.labelcolor':'#243c49','text.color':'#243c49','axes.edgecolor':'#8da0a6',
        'figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','svg.fonttype':'path'})
    blue,green,red,gold='#286488','#008b7b','#dc604d','#c39227'
    def save(fig,name):
        fig.tight_layout(pad=1.6)
        for ext in ['svg','png']:fig.savefig(out/f'{name}-{args.language}.{ext}',dpi=155,bbox_inches='tight')
        plt.close(fig)
    def gaussian(x,mu,sigma):return np.exp(-.5*((x-mu)/sigma)**2)/(sigma*np.sqrt(2*np.pi))

    fig,ax=plt.subplots(1,3,figsize=(14,4.8),gridspec_kw={'width_ratios':[1.1,1,1]})
    a=ax[0];a.set(xlim=(0,10),ylim=(0,10));a.axis('off')
    a.add_patch(Rectangle((.5,.5),9,3.8,color='#dbe5e7'));a.plot([.5,9.5],[4.3,4.3],color=blue,lw=2)
    a.annotate(T('X 射线','X-rays'),xy=(4.3,4.2),xytext=(.6,8.8),arrowprops={'arrowstyle':'->','color':gold,'lw':3},fontsize=13)
    a.add_patch(FancyArrowPatch((4.4,3.8),(7.1,8.3),arrowstyle='->',mutation_scale=15,color=green,lw=3))
    a.text(7.5,7.5,T('电子\n至分析器','Electron\nto analyzer'),fontsize=9,ha='left')
    a.plot([4.4,4.4],[3.8,9],ls=':',color='#7b929a');a.text(4.4,9.4,T('表面法线','Surface normal'),fontsize=10,ha='center')
    a.add_patch(Arc((4.4,3.8),4,4,theta1=58,theta2=90,color=blue));a.text(4.8,6.1,r'$\theta$')
    a.plot([2,2.7,2.2,3.1],[1.5,2.3,2.9,3.6],color=red,lw=2);a.text(.8,.8,T('碰撞损能 → 背景','Energy loss → background'),fontsize=10)
    a.set_title(T('A  从光子到电子','A  From photon to electron'),loc='left')
    z=np.linspace(0,15,400);L=2.5
    for angle,c in [(0,green),(60,blue)]:
        weight=np.exp(-z/(L*np.cos(np.deg2rad(angle))))/(L*np.cos(np.deg2rad(angle)))
        ax[1].plot(z,weight,color=c,label=f'{angle}°')
    ax[1].set(xlabel=T('深度 / nm','Depth / nm'),ylabel=T('归一化信号权重 / 每 nm','Normalized signal weight / per nm'))
    ax[1].legend(title=T('相对法线角度','Angle from normal'));ax[1].set_title(T('B  表面贡献更大','B  Surface-weighted signal'),loc='left')
    ax[2].barh([0,1,2],[284.8,4.5,1197.3],color=[blue,gold,green]);ax[2].set_yticks([0,1,2],[T('结合能','Binding energy'),T('分析器功函数','Analyzer work function'),T('测得动能','Measured kinetic energy')]);ax[2].set_xlabel('eV');ax[2].set_xlim(0,1400)
    for y,v in enumerate([284.8,4.5,1197.3]):ax[2].text(v+25,y,str(v),va='center',fontsize=10)
    ax[2].set_title(T('C  1486.6 eV 的能量账本','C  A 1486.6 eV energy budget'),loc='left')
    save(fig,'photoemission')

    e=np.linspace(0,800,4001);areas=np.array([5000.,1200.,9000.]);rsf=np.array([1.,1.8,3.]);centers=[284.8,400,532];labels=['C 1s','N 1s','O 1s']
    base=50+.035*e;survey=base+sum(a*gaussian(e,m,2.2) for a,m in zip(areas,centers));fractions=(areas/rsf)/sum(areas/rsf)
    fig,ax=plt.subplots(1,2,figsize=(12,4.8),gridspec_kw={'width_ratios':[1.55,1]})
    ax[0].plot(e,survey,color=blue);ax[0].invert_xaxis();ax[0].set(xlabel=T('结合能 / eV','Binding energy / eV'),ylabel=T('教学信号 / counts s⁻¹','Teaching signal / counts per second'))
    for m,l in zip(centers,labels):ax[0].annotate(l,(m,np.interp(m,e,survey)),xytext=(m+40,np.interp(m,e,survey)+100),arrowprops={'arrowstyle':'-','color':blue})
    ax[0].set_ylim(0,2100);ax[0].set_title(T('A  全谱先找到元素','A  Survey identifies elements'),loc='left')
    x=np.arange(3);ax[1].bar(x-.18,areas/areas.sum()*100,.36,label=T('直接按面积','Raw area fraction'),color=gold);ax[1].bar(x+.18,fractions*100,.36,label=T('灵敏度校正后','Sensitivity-corrected'),color=green);ax[1].set_xticks(x,labels);ax[1].set_ylabel('%');ax[1].set_ylim(0,80);ax[1].legend(fontsize=9);ax[1].set_title(T('B  不同元素的响应不同','B  Unequal elemental response'),loc='left')
    save(fig,'composition');np.savetxt(out/'survey.csv',np.c_[e,survey,base],delimiter=',',header='binding_energy_eV,signal_counts_per_s,background_counts_per_s',comments='')
    np.savetxt(out/'composition.csv',np.c_[areas,rsf,fractions],delimiter=',',header='area_counts_per_s_eV,teaching_RSF,atomic_fraction',comments='')

    rng=np.random.default_rng(570);x=np.linspace(282,292,501);mu=np.array([284.8,286.4,288.8]);trueA=np.array([6500,2200,1300]);sigma=.48;dwell=.4
    baseline=110+3*(x-282);true=baseline+sum(a*gaussian(x,m,sigma) for a,m in zip(trueA,mu));observed=rng.poisson(true*dwell)/dwell
    def model(x,a,b,c,w,p,q):return p+q*(x-282)+sum(A*gaussian(x,m,w) for A,m in zip([a,b,c],mu))
    p,cov=curve_fit(model,x,observed,p0=[6000,2000,1000,.5,100,2],sigma=np.sqrt(np.maximum(observed*dwell,1))/dwell,absolute_sigma=True,bounds=([0,0,0,.2,0,-10],[20000,20000,20000,1.2,500,20]))
    def incomplete(x,a,b,w,p,q):return p+q*(x-282)+a*gaussian(x,mu[0],w)+b*gaussian(x,mu[1],w)
    q,_=curve_fit(incomplete,x,observed,p0=[6500,2200,.5,100,2],bounds=([0,0,.2,0,-10],[20000,20000,1.2,1500,100]))
    fitted=model(x,*p);wrong=incomplete(x,*q);fitbase=p[4]+p[5]*(x-282)
    fig,ax=plt.subplots(2,2,figsize=(12,7.4),gridspec_kw={'height_ratios':[2,1]})
    for col,(fit,title) in enumerate([(fitted,T('A  三个已知教学环境','A  Three specified teaching environments')),(wrong,T('B  漏掉一个环境','B  One environment omitted'))]):
        ax[0,col].plot(x,observed,color='#9aa9ac',lw=.8,label=T('计数噪声数据','Count-noise data'));ax[0,col].plot(x,fit,color=green if col==0 else red,lw=2,label=T('拟合','Fit'));ax[0,col].set_title(title,loc='left');ax[0,col].legend(fontsize=9)
        ax[1,col].axhline(0,color='#8b9b9e',lw=1);ax[1,col].plot(x,observed-fit,color=blue if col==0 else red,lw=.9);ax[1,col].set_xlabel(T('结合能 / eV','Binding energy / eV'));ax[1,col].set_ylabel(T('残差 / counts s⁻¹','Residual / counts per second'))
        for row in [0,1]:ax[row,col].invert_xaxis()
    for a,m,c in zip(p[:3],mu,[blue,gold,red]):ax[0,0].fill_between(x,fitbase,fitbase+a*gaussian(x,m,p[3]),color=c,alpha=.2)
    ax[0,0].set_ylabel(T('信号 / counts s⁻¹','Signal / counts per second'));save(fig,'peak-model')
    np.savetxt(out/'carbon_region.csv',np.c_[x,observed,baseline,fitted,wrong,observed-fitted],delimiter=',',header='binding_energy_eV,observed_counts_per_s,true_background,three_component_fit,two_component_fit,residual',comments='')

    fig,ax=plt.subplots(1,3,figsize=(14,4.8));d=np.linspace(0,10,300)
    for ang,c in [(0,green),(30,gold),(60,blue)]:ax[0].plot(d,np.exp(-d/(L*np.cos(np.deg2rad(ang)))),color=c,label=f'{ang}°')
    ax[0].legend();ax[0].set(xlabel=T('均匀覆盖层厚度 / nm','Uniform overlayer thickness / nm'),ylabel=T('基底峰 / 裸基底峰','Substrate peak / bare-substrate peak'));ax[0].set_title(T('A  倾斜使基底更难看见','A  Tilt suppresses the substrate'),loc='left')
    xx=np.linspace(281,290,700);normal=gaussian(xx,284.8,.45);uniform=gaussian(xx,286.3,.45);differential=.6*gaussian(xx,284.8,.45)+.4*gaussian(xx,286.3,.45)
    ax[1].plot(xx,normal,color=green,label=T('无偏移','Unshifted'));ax[1].plot(xx,uniform,color=gold,label=T('整体 +1.5 eV','Uniform +1.5 eV'));ax[1].plot(xx,differential,color=red,label=T('不同区域带电不同','Differential charging'));ax[1].invert_xaxis();ax[1].set(xlabel=T('表观结合能 / eV','Apparent binding energy / eV'),ylabel=T('等面积信号 / 每 eV','Equal-area signal / per eV'));ax[1].legend(fontsize=8);ax[1].set_title(T('B  电势也会移动峰','B  Potential also shifts peaks'),loc='left')
    samples=np.array([8.,9.,7.,18.,20.,17.]);ax[2].scatter([0,0,0,1,1,1],samples,color=[blue]*3+[green]*3,s=45);ax[2].errorbar([0,1],[samples[:3].mean(),samples[3:].mean()],yerr=[samples[:3].std(ddof=1),samples[3:].std(ddof=1)],fmt='_',ms=22,color='#243c49',capsize=5);ax[2].set_xticks([0,1],[T('处理前','Before'),T('处理后','After')]);ax[2].set(xlim=(-.5,1.5),ylim=(0,25),ylabel=T('氧原子百分比 / at.%','Oxygen atomic percentage / at.%'));ax[2].set_title(T('C  三个独立试样','C  Three independent specimens'),loc='left');save(fig,'decisions')
    summary={'example_kinetic_energy_eV':1486.6-284.8-4.5,'information_depth_95_normal_nm':-L*np.log(.05),'information_depth_95_60deg_nm':-L*.5*np.log(.05),'substrate_ratio_2nm_normal':float(np.exp(-2/L)),'substrate_ratio_2nm_60deg':float(np.exp(-2/(L*.5))),'oxygen_atomic_fraction':float(fractions[2]),'fitted_oxygenated_carbon_fraction':float(sum(p[1:3])/sum(p[:3])),'true_oxygenated_carbon_fraction':.35,'fit_rms_counts_per_s':float(np.sqrt(np.mean((observed-fitted)**2))),'incomplete_fit_rms_counts_per_s':float(np.sqrt(np.mean((observed-wrong)**2))),'teaching_data':True}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
