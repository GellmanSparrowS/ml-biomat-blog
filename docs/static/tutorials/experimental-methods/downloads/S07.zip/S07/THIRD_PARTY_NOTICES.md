# Public sources and third-party materials

- Introduction to X-ray photoelectron spectroscopy: https://mmrc.caltech.edu/XPS%20Info/Practical%20Guides%20to%20XPS/Intro%20to%20XPS.pdf
  Technical or historical reference; no source figures reproduced. Original diagrams and explicitly constructed teaching data.
- Practical guides: First steps in planning, conducting and reporting XPS: https://mmrc.caltech.edu/XPS%20Info/XPS%20practical%20guide.pdf
  Technical or historical reference; no source figures reproduced. Original diagrams and explicitly constructed teaching data.
- XPS guide: Charge neutralization and binding energy referencing: https://mmrc.caltech.edu/XPS%20Info/Practical%20Guides%20to%20XPS/XPS%20guide%20charge%20neutralization.pdf
  Technical or historical reference; no source figures reproduced. Original diagrams and explicitly constructed teaching data.
- Practical guides: Quantitative XPS: https://ywcmatsci.yale.edu/sites/default/files/files/Practical%20guides%20for%20x-ray%20photoelectron%20spectroscopy%20-%20Quantitative%20XPS.pdf
  Technical or historical reference; no source figures reproduced. Original diagrams and explicitly constructed teaching data.
- NIST: Inelastic mean free paths, effective attenuation lengths and information depths: https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=929257
  Technical or historical reference; no source figures reproduced. Original diagrams and explicitly constructed teaching data.
- Kai Siegbahn: Electron spectroscopy for atoms, molecules and condensed matter: https://wiki.epfl.ch/mep/documents/MEP%5B09-10%5D_DOWNLOAD/siegbahn_nobellecture.pdf
  Technical or historical reference; no source figures reproduced. Original diagrams and explicitly constructed teaching data.
- Thermo Fisher: XPS quick guide: https://documents.thermofisher.com/TFS-Assets/MSD/Flyers/xps-quick-guide-fl0163.pdf
  Technical or historical reference; no source figures reproduced. Original diagrams and explicitly constructed teaching data.
