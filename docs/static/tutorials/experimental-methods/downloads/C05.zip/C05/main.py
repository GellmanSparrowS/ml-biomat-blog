"""Constructed ITC experiment with explicit discrete withdrawal/replacement mixing."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Rectangle

def titration(kd=1.,enthalpy=-40.,sites=1.,protein=20.,ligand=300.,cell=200.,injection=2.,number=25):
 """uM, kJ/mol, uL -> microjoules. Remove a mixed aliquot, then replace it."""
 retain=1-injection/cell;M=protein;L=0.;bound=0.;rows=[]
 for j in range(number):
  M*=retain;L=L*retain+ligand*injection/cell;S=sites*M
  # Stable quadratic root; avoids subtraction cancellation at weak binding.
  B=2*S*L/(S+L+kd+np.sqrt((S+L+kd)**2-4*S*L))
  q=cell*.001*enthalpy*(B-retain*bound)
  rows.append([j+1,M,L,B,q,L/M]);bound=B
 return np.array(rows)

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);zh=a.language=='zh';T=lambda z,e:z if zh else e
 plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.titlesize':12,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fcfbf7','axes.facecolor':'#fcfbf7','savefig.facecolor':'#fcfbf7'})
 B,R,G,Y='#167d9a','#d35f47','#37967d','#c49b35'
 def save(f,n):f.savefig(a.output/f'{n}-{a.language}.svg');f.savefig(a.output/f'{n}-{a.language}.png',dpi=145);plt.close(f)
 truth=titration();q=truth[:,4];ratio=truth[:,5];rng=np.random.default_rng(650);time=np.arange(26*180,dtype=float);baseline=.08+.000015*time
 power=baseline.copy();blank=baseline.copy();pulse_t=np.arange(180,dtype=float);kernel=pulse_t/12**2*np.exp(-pulse_t/12);kernel/=np.trapezoid(kernel,pulse_t)
 dil=2+.02*np.arange(25)
 for i in range(25):
  sl=slice((i+1)*180,(i+2)*180);power[sl]+=(q[i]+dil[i])*kernel;blank[sl]+=dil[i]*kernel
 power+=rng.normal(0,.004,time.size);blank+=rng.normal(0,.004,time.size)
 quiet=(time<170)|((time%180)>=150);basefit=np.polyval(np.polyfit(time[quiet],power[quiet],1),time);blankfit=np.polyval(np.polyfit(time[quiet],blank[quiet],1),time)
 measured=[];control=[]
 for i in range(25):
  sl=slice((i+1)*180,(i+2)*180);measured.append(np.trapezoid(power[sl]-basefit[sl],time[sl]));control.append(np.trapezoid(blank[sl]-blankfit[sl],time[sl]))
 measured=np.array(measured);control=np.array(control);corrected=measured-control
 def fit(data):
  fun=lambda v:titration(np.exp(v[0]),v[1],v[2])[:,4]-data
  out=least_squares(fun,[0,-40,1],bounds=([-6,-150,.4],[5,-1,2]),xtol=1e-12,ftol=1e-12,gtol=1e-12)
  return np.array([np.exp(out.x[0]),out.x[1],out.x[2]])
 fitted=fit(corrected);pred=titration(*fitted)[:,4];wrong=fit(measured);rms=float(np.sqrt(np.mean((pred-corrected)**2)))
 # Independent parametric noise exercise, not variation among biological specimens.
 boots=np.array([fit(pred+rng.normal(0,.08,25)) for _ in range(80)]);ci=np.percentile(boots,[2.5,97.5],axis=0)
 f,ax=plt.subplots(1,2,figsize=(13.5,5.4),layout='constrained')
 ax[0].set(xlim=(0,10),ylim=(0,8));ax[0].axis('off');ax[0].set_title(T('A  1989：配对量热池与功率反馈','A  1989: Matched cells and power feedback'),loc='left')
 ax[0].add_patch(Rectangle((.6,1.4),8.8,4.3,fc='#e6edf0',ec=B,lw=2))
 for x,c,label in [(2.5,B,T('参比池','Reference')),(7,R,T('样品池','Sample'))]:
  ax[0].add_patch(Circle((x,3.4),1.25,fc='#fcfbf7',ec=c,lw=2));ax[0].text(x,3.4,label,ha='center',va='center');ax[0].plot([x-.6,x+.6],[2.8,2.8],c=Y,lw=4)
 ax[0].plot([7,7],[4.7,7.2],c=R,lw=3);ax[0].add_patch(Rectangle((6.6,6.3),.8,.9,fc='#f4d5cb',ec=R));ax[0].annotate('',xy=(7,4.8),xytext=(7,6),arrowprops={'arrowstyle':'->','color':R})
 ax[0].text(5,7.5,T('逐针加入结合伙伴','Inject binding partner'),ha='center');ax[0].annotate('',xy=(5.7,3.4),xytext=(3.8,3.4),arrowprops={'arrowstyle':'<->','color':G});ax[0].text(4.75,4,T('温差','ΔT'),ha='center');ax[0].text(5,.6,T('放热 → 补偿加热减少；积分得到热量','Heat release → less heater power; integrate for heat'),ha='center',fontsize=10)
 ax[1].set_title(T('B  加入的分子：先占位，后积累','B  Added molecules: Occupy, then accumulate'),loc='left');ax[1].plot(ratio,truth[:,3]/truth[:,1],c=R,lw=2,label=T('位点占据比例','Fraction of sites occupied'));ax[1].plot(ratio,(truth[:,2]-truth[:,3])/truth[:,2],c=B,lw=2,label=T('配体中游离的比例','Fraction of ligand free'));ax[1].set(xlabel=T('池内总配体 / 总蛋白质','Cell total ligand / total protein'),ylabel=T('比例','Fraction'),ylim=(0,1.05));ax[1].legend(loc='lower right');ax[1].text(.48,.35,T('Kᴅ = 1 μM；初始蛋白质 20 μM\n构造的一类独立位点模型','Kᴅ = 1 μM; initial protein 20 μM\nConstructed independent-site model'),transform=ax[1].transAxes,fontsize=10)
 save(f,'feedback-binding')
 f,axes=plt.subplots(2,2,figsize=(13.7,8.2),layout='constrained');ax=axes[0,0];ax.plot(time/60,power,c=B,lw=.8,label=T('样品','Sample'));ax.plot(time/60,blank,c=Y,lw=.7,label=T('配体 → 缓冲液','Ligand → buffer'));ax.plot(time/60,basefit,c='#60717c',ls='--',lw=1,label=T('拟合基线','Fitted baseline'));ax.set(xlabel=T('时间 / min','Time / min'),ylabel=T('差分功率 / μW','Differential power / μW'),title=T('A  原始功率：放热向下','A  Raw power: Exothermic downward'));ax.legend(fontsize=9)
 ax=axes[0,1];sl=slice(180,360);ax.plot(pulse_t,power[sl],c=B,label=T('第一针','First injection'));ax.plot(pulse_t,basefit[sl],c='#60717c',ls='--');ax.fill_between(pulse_t,power[sl],basefit[sl],color=B,alpha=.18);ax.plot(pulse_t,blank[sl],c=Y,label=T('空白','Blank'));ax.set(xlabel=T('注射后时间 / s','Time after injection / s'),ylabel=T('差分功率 / μW','Differential power / μW'),title=T('B  面积是热量；峰高还受响应时间影响','B  Area gives heat; height also depends on response'));ax.legend()
 ax=axes[1,0];mol_in=.6;ax.scatter(ratio,measured/mol_in,s=19,color=Y,label=T('未扣除空白','Before blank correction'));ax.scatter(ratio,corrected/mol_in,s=19,color=B,label=T('已扣除空白','Blank-corrected'));ax.plot(ratio,pred/mol_in,c=R,label=T('拟合','Fit'));ax.set(xlabel=T('池内总配体 / 总蛋白质','Cell total ligand / total protein'),ylabel=T('每摩尔加入配体的热量 / kJ/mol','Heat per mole of injected ligand / kJ/mol'),title=T('C  校正、归一化、拟合','C  Correct, normalize and fit'));ax.legend(fontsize=9)
 ax=axes[1,1];ax.axhline(0,c='#60717c',lw=1);ax.plot(np.arange(1,26),corrected-pred,'o-',c=G);ax.set(xlabel=T('针次','Injection'),ylabel=T('数据 − 模型 / μJ','Data − model / μJ'),title=T('D  残差是否留下系统形状','D  Does a systematic pattern remain?'))
 save(f,'thermogram-analysis')
 f,axes=plt.subplots(1,2,figsize=(13.4,5.4),layout='constrained');ax=axes[0]
 for kd,c in [(100,Y),(1,B),(.01,R)]:
  row=titration(kd);ax.plot(row[:,5],row[:,4]/.6,color=c,label=f'c = {20/kd:g}')
 ax.set(xlabel=T('池内总配体 / 总蛋白质','Cell total ligand / total protein'),ylabel=T('热量 / 加入配体量 / kJ/mol','Heat / injected ligand amount / kJ/mol'),title=T('A  平缓、可弯曲、近似阶跃','A  Shallow, curved and nearly step-like'));ax.legend();ax.text(.48,.45,T('所有曲线：ΔH = −40 kJ/mol\n位点数 n = 1','All curves: ΔH = −40 kJ/mol\nSite number n = 1'),transform=ax.transAxes,fontsize=10)
 kds=np.geomspace(.5,2,61);hs=np.linspace(-44,-36,61);err=np.array([[np.sqrt(np.mean((titration(k,h,1)[:,4]-corrected)**2)) for k in kds] for h in hs]);ax=axes[1];im=ax.pcolormesh(kds,hs,err,cmap='viridis_r',shading='auto');ax.set_xscale('log');ij=np.unravel_index(np.argmin(err),err.shape);ax.scatter(kds[ij[1]],hs[ij[0]],marker='x',c='white',s=80);ax.set(xlabel=T('解离常数 Kᴅ / μM','Dissociation constant Kᴅ / μM'),ylabel=T('焓变 ΔH / kJ/mol','Enthalpy ΔH / kJ/mol'),title=T('B  固定 n=1 的条件误差地形','B  Conditional error landscape with n=1'));f.colorbar(im,ax=ax,label=T('均方根残差 / μJ','RMS residual / μJ'))
 save(f,'design-diagnostics')
 gas=.00831446261815324;temperature=298.15;dg=gas*temperature*np.log(1e-6);f,axes=plt.subplots(1,2,figsize=(13.4,5.4),layout='constrained');ax=axes[0];positions=np.arange(3)
 for j,h in enumerate([-40,-20]):ax.bar(positions+(j-.5)*.32,[dg,h,dg-h],.30,color=[B,R][j],label=T(f'体系 {j+1}',f'System {j+1}'))
 ax.set_xticks(positions,['ΔG°','ΔH°','−TΔS°']);ax.axhline(0,c='#61758a',lw=1);ax.set(ylabel=T('摩尔能量 / kJ/mol','Molar energy / kJ/mol'),title=T('A  同一亲和力，可以有不同的热量','A  Same affinity, different heat'));ax.legend();ax.text(.04,.92,T('Kᴅ = 1 μM；T = 298.15 K','Kᴅ = 1 μM; T = 298.15 K'),transform=ax.transAxes,fontsize=10)
 ax=axes[1];L=np.geomspace(.01,200,250);M=20.;bound=2*M*L/(M+L+1+np.sqrt((M+L+1)**2-4*M*L));ax.semilogx(L,L/(1+L),c=B,label=T('横轴作为游离浓度','Axis interpreted as free concentration'));ax.semilogx(L,bound/M,c=R,label=T('横轴作为总浓度，蛋白质20 μM','Axis is total concentration; protein 20 μM'));ax.axhline(.5,c='#61758a',ls='--');ax.scatter([1,11],[.5,.5],c=[B,R],zorder=3);ax.set(xlabel=T('所采用的配体浓度 / μM','Specified ligand concentration / μM'),ylabel=T('位点占据比例','Fraction occupied'),title=T('B  游离配体与总配体是不同的横轴','B  Free ligand and total ligand differ'));ax.legend(fontsize=9,loc='upper left')
 save(f,'thermodynamics')
 np.savetxt(a.output/'thermogram.csv',np.c_[time,power,blank,basefit,blankfit],delimiter=',',header='time_s,sample_power_uW,blank_power_uW,sample_baseline_uW,blank_baseline_uW',comments='')
 np.savetxt(a.output/'injections.csv',np.c_[truth,measured,control,corrected,pred],delimiter=',',header='injection,protein_total_uM,ligand_total_uM,bound_uM,true_heat_uJ,molar_ratio,measured_heat_uJ,blank_heat_uJ,corrected_heat_uJ,fitted_heat_uJ',comments='')
 np.savetxt(a.output/'noise_refits.csv',boots,delimiter=',',header='Kd_uM,enthalpy_kJ_per_mol,site_number',comments='')
 summary={'fitted_Kd_uM':float(fitted[0]),'fitted_enthalpy_kJ_per_mol':float(fitted[1]),'fitted_site_number':float(fitted[2]),'RMS_residual_uJ':rms,'uncorrected_fit_Kd_uM':float(wrong[0]),'uncorrected_fit_enthalpy_kJ_per_mol':float(wrong[1]),'initial_c_value':20.,'standard_free_energy_kJ_per_mol':float(dg),'entropy_J_per_mol_K':float((-40-dg)/temperature*1000),'final_protein_uM':float(truth[-1,1]),'first_binding_heat_uJ':float(q[0]),'last_binding_heat_uJ':float(q[-1]),'injected_ligand_nmol':.6,'half_occupancy_free_ligand_uM':1.,'half_occupancy_total_ligand_uM_at_20uM_protein':11.,'noise_refit_95_percentile_interval':{'Kd_uM':ci[:,0].tolist(),'enthalpy_kJ_per_mol':ci[:,1].tolist(),'site_number':ci[:,2].tolist()}}
 (a.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
