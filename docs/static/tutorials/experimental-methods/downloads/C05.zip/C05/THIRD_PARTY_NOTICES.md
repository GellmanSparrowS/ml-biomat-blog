# Public sources and third-party materials

- Wiseman et al. (1989): Rapid measurement of binding constants and heats of binding: https://web.iitd.ac.in/~nkurur/2012-13/Isem/cyl501/analbiochem179_131.pdf
  Technical/historical reference; original figures and constructed data, no source artwork reproduced.
- Harvard CMI: Isothermal titration calorimetry: https://cmi.hms.harvard.edu/isothermal-titration-calorimetry
  Technical/historical reference; original figures and constructed data, no source artwork reproduced.
- TA Instruments: Quick Start ITC, MCAPN-2016-1: https://www.tainstruments.com/pdf/literature/MCAPN-2016-1.pdf
  Technical/historical reference; original figures and constructed data, no source artwork reproduced.
- Malvern: Best practices for ITC, Part 1: https://www.malvernpanalytical.com/en/learn/knowledge-center/insights/best-practices-for-isothermal-titration-calorimetry-to-study-binding-interactions-part-1
  Technical/historical reference; original figures and constructed data, no source artwork reproduced.
- TA Instruments: Protein-protein interactions by ITC, MC176: https://www.tainstruments.com/applications-notes/characterizing-protein-protein-interactions-by-itc-mc176/
  Technical/historical reference; original figures and constructed data, no source artwork reproduced.
- Brautigam et al. (2016): Integration and Global Analysis of ITC Data: https://pmc.ncbi.nlm.nih.gov/articles/PMC7466939/
  Technical/historical reference; original figures and constructed data, no source artwork reproduced.
