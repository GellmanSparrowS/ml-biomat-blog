"""Offline qPCR teaching experiment; constructed arrays and a licensed measured figure."""
from pathlib import Path
import argparse,csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from PIL import Image
BLUE='#186e83';AMBER='#cd803f';PURPLE='#8160a1';GREEN='#3c8a6a'

def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def cq(n0,factor=1.9,threshold=1e6):return np.log(threshold/n0)/np.log(factor)
def crossing(cycles,signal,threshold):
    j=np.flatnonzero(signal>=threshold)[0]
    return float(cycles[j-1]+(np.log(threshold)-np.log(signal[j-1]))/(np.log(signal[j])-np.log(signal[j-1])))
def main(output,language='zh'):
    out=Path(output);out.mkdir(parents=True,exist_ok=True);zh=language=='zh';T=lambda a,b:a if zh else _label(b)
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5'})
    def save(fig,n):fig.savefig(out/f'{n}-{language}.svg',bbox_inches='tight');plt.close(fig)
    rng=np.random.default_rng(808);cycles=np.arange(41);threshold=1e6;baseline=10000;standard_n=np.array([10,100,1000,10000]);standard=[];curves=[]
    for n0 in standard_n:
        for rep in range(3):
            # The cap is a drawing convention, not a biochemical plateau fit.
            raw=baseline+np.minimum(n0*1.9**cycles,2e7)+rng.normal(0,500,len(cycles));curves.append(raw)
            standard.append([n0,rep+1,crossing(cycles,raw-baseline,threshold)])
    standard=np.array(standard);slope,intercept=np.polyfit(np.log10(standard[:,0]),standard[:,2],1)
    with(out/'standards.csv').open('w',newline='',encoding='utf8')as f:
        w=csv.writer(f);w.writerow(['initial_target_units','technical_replicate','Cq']);w.writerows(standard)
    rows=[];sample_curves=[];truth=np.array([1,1.1,.9,4,4.4,3.6]);loads=np.array([.85,1,1.2,.9,1.1,1.25])
    for i in range(6):
        for gene,factor,n0 in [('target',1.9,100*loads[i]*truth[i]),('reference',1.95,1000*loads[i])]:
            for rep in range(3):
                raw=baseline+np.minimum(n0*factor**cycles,2e7)+rng.normal(0,500,len(cycles));sample_curves.append(raw);c=crossing(cycles,raw-baseline,threshold)
                rows.append([i+1,'control'if i<3 else'treated',gene,rep+1,factor,c,threshold/factor**c])
    with(out/'samples.csv').open('w',newline='',encoding='utf8')as f:
        w=csv.writer(f);w.writerow(['sample','group','assay','technical_replicate','amplification_factor','Cq','inferred_initial_units']);w.writerows(rows)
    ratios=[];naive=[]
    for i in range(6):
        target=[r for r in rows if r[0]==i+1 and r[2]=='target'];ref=[r for r in rows if r[0]==i+1 and r[2]=='reference']
        # Geometric mean summarizes multiplicative quantities within technical replicates.
        ratios.append(np.exp(np.mean(np.log([r[-1]for r in target]))-np.mean(np.log([r[-1]for r in ref]))))
        naive.append(2**(-np.mean([r[-2]for r in target])+np.mean([r[-2]for r in ref])))
    ratios=np.array(ratios);naive=np.array(naive);normalized=ratios/np.exp(np.mean(np.log(ratios[:3])));naive/=np.exp(np.mean(np.log(naive[:3])))
    np.savez_compressed(out/'amplification.npz',cycles=cycles,standard_raw=np.array(curves),sample_raw=np.array(sample_curves),known_baseline=baseline,threshold=threshold)
    temperature=np.linspace(65,95,301);single=1/(1+np.exp((temperature-82)/.65));mixed=.75*single+.25/(1+np.exp((temperature-73)/.6))
    with(out/'melting.csv').open('w',newline='',encoding='utf8')as f:
        w=csv.writer(f);w.writerow(['temperature_C','single_normalized','mixed_normalized','single_negative_derivative_per_C','mixed_negative_derivative_per_C']);w.writerows(zip(temperature,single,mixed,-np.gradient(single,temperature),-np.gradient(mixed,temperature)))
    fig,ax=plt.subplots(figsize=(11,5));ax.axis('off');ax.set(xlim=(0,12),ylim=(0,6))
    labels=[T('分开双链','Separate strands'),T('引物定位','Primers locate target'),T('酶延伸复制','Polymerase extends')]
    for j,label in enumerate(labels):
        x=1+j*3.6;ax.add_patch(FancyBboxPatch((x,.9),2.7,3.5,boxstyle='round,pad=.1',fc=[BLUE,PURPLE,GREEN][j],alpha=.12));ax.text(x+1.35,3.9,label,ha='center')
        for y in [2,2.7]:ax.plot([x+.3,x+2.4],[y,y],color=BLUE,lw=3)
        if j:ax.plot([x+.3,x+.8],[2.7,2.7],color=AMBER,lw=6);ax.plot([x+1.9,x+2.4],[2,2],color=AMBER,lw=6)
        if j==2:
            ax.plot([x+.8,x+2.4],[2.7,2.7],color=GREEN,lw=3);ax.plot([x+.3,x+1.9],[2,2],color=GREEN,lw=3)
        if j<2:ax.annotate('',xy=(x+3.4,2.6),xytext=(x+2.9,2.6),arrowprops={'arrowstyle':'->','lw':2})
    ax.text(6,5.3,T('1985：特定DNA扩增 → 1992：在封闭反应管中观察荧光','1985: specific DNA amplification →1992: fluorescence in closed reaction tubes'),ha='center',fontsize=12)
    ax.text(6,.2,T('原创机制图；每轮的复制比例决定达到同一亮度要多久。','Original mechanism: per-cycle multiplication controls time to a shared fluorescence threshold.'),ha='center');save(fig,'history')
    fig,ax=plt.subplots(2,2,figsize=(11,8.5))
    for j,n0 in enumerate(standard_n):
        color=[BLUE,AMBER,PURPLE,GREEN][j];raw=curves[3*j]
        ax[0,0].plot(cycles,raw,color=color,label=str(n0));ax[0,1].plot(cycles,np.maximum(raw-baseline,1),color=color)
    ax[0,0].set(xlabel=T('循环数','Cycle'),ylabel=T('原始荧光 / a.u.','Raw fluorescence / a.u.'),title=T('A  构造原始扩增曲线','A  Constructed raw amplification'));ax[0,0].legend(title=T('初始单位','Initial units'),fontsize=8)
    ax[0,1].set_yscale('log');ax[0,1].set_ylim(1e3,3e7);ax[0,1].axhline(threshold,color='gray',ls='--');ax[0,1].set(xlabel=T('循环数','Cycle'),ylabel=T('扣基线荧光 / a.u.','Baseline-corrected fluorescence / a.u.'),title=T('B  对数轴显出指数增长段','B  Log axes reveal exponential growth'))
    x=np.log10(standard[:,0]);ax[1,0].scatter(x,standard[:,2],color=BLUE);ax[1,0].plot([1,4],np.polyval([slope,intercept],[1,4]),color=AMBER);ax[1,0].set(xlabel=T('初始量的log10','log10(initial units)'),ylabel=T('Cq / 循环','Cq / cycle'),title=T('C  三个技术复孔的校准','C  Calibration with3technical replicates'))
    ax[1,1].scatter(x,standard[:,2]-np.polyval([slope,intercept],x),color=PURPLE);ax[1,1].axhline(0,color='gray',lw=1);ax[1,1].set(xlabel=T('初始量的log10','log10(initial units)'),ylabel=T('Cq残差 / 循环','Cq residual / cycle'),title=T('D  检查拟合剩下的结构','D  Examine residual structure'))
    for a in ax.flat:a.grid(alpha=.18)
    fig.tight_layout();save(fig,'amplification')
    fig,ax=plt.subplots(2,2,figsize=(11,8.4));x=np.arange(6)
    ax[0,0].bar(x-.18,normalized,.36,color=BLUE,label=T('各自效率校正','Assay-specific correction'));ax[0,0].bar(x+.18,naive,.36,color=AMBER,label=T('统一假设每轮2倍','Assume2×per cycle'));ax[0,0].set_xticks(x,range(1,7));ax[0,0].set(xlabel=T('样品1–3对照，4–6处理','Samples1–3control;4–6treated'),ylabel=T('归一化倍数','Normalized fold'),title=T('A  保留独立样品的差异','A  Preserve individual-sample differences'));ax[0,0].legend(fontsize=8)
    ax[0,1].plot(temperature,-np.gradient(single,temperature),color=BLUE,label=T('一种构造产物','One constructed product'));ax[0,1].plot(temperature,-np.gradient(mixed,temperature),color=AMBER,label=T('两种构造产物','Two constructed products'));ax[0,1].set(xlabel=T('温度 / °C','Temperature / °C'),ylabel=T('负导数 / °C⁻¹','Negative derivative / °C⁻¹'),title=T('B  熔解曲线提供产物线索','B  Melting informs product interpretation'));ax[0,1].legend(fontsize=8)
    lam=np.linspace(.01,8,200);ax[1,0].plot(lam,np.exp(-lam)*100,color=PURPLE);ax[1,0].scatter([1,3],[100/np.e,100*np.exp(-3)],color=AMBER);ax[1,0].set(xlabel=T('每孔平均进入拷贝数','Mean input copies per well'),ylabel=T('没有拷贝的孔 / %','Wells with zero copies / %'),title=T('C  少量分子如何分配到小体积','C  Low-copy sampling into small volumes'))
    eff=np.linspace(1.6,2,100);cqcontrol=cq(100);cqtreat=cq(400,eff);ax[1,1].plot(eff,2**(cqcontrol-cqtreat),color=AMBER);ax[1,1].axhline(4,color=BLUE,ls='--');ax[1,1].set(xlabel=T('处理样品每轮扩增倍数','Treated-sample multiplication per cycle'),ylabel=T('直接用2的幂得到的倍数','Fold inferred with powers of2'),title=T('D  真实4倍遇到不同扩增效率','D  True4×change with changing efficiency'));ax[1,1].set_ylim(0,10)
    for a in ax.flat:a.grid(alpha=.18)
    fig.tight_layout();save(fig,'diagnostics')
    fig,ax=plt.subplots(figsize=(11,10.7));ax.imshow(Image.open(Path(__file__).resolve().parent/'linreg2021-figure1.jpg').convert('RGB'));ax.axis('off');ax.set_title(T('真实反应D8：把扩增与熔解结果一起读','Measured reactionD8: read amplification and melting together'),fontsize=12);fig.text(.5,.015,T('Untergasser等2021，图1；CC BY4.0。完整转载，外加双语标题。','Untergasser et al.2021,Fig1; CC BY4.0. Full reproduction with an added external title.'),ha='center',fontsize=9);fig.tight_layout(rect=[0,.04,1,1]);save(fig,'published')
    ideal_slope=-1/np.log10(1.9);summary={'growth':{'hundred_after_ten_doublings':100*2**10,'tenfold_delay_at_two':np.log(10)/np.log(2),'fourfold_delay_at_19':float(cq(100)-cq(400))},'calibration':{'ideal_slope':float(ideal_slope),'factor_from_ideal_slope':float(10**(-1/ideal_slope)),'fitted_slope':float(slope),'fitted_factor':float(10**(-1/slope))},'normalization':{'ideal_ddcq_fold':2**(-(23-20-(25-20))),'efficiency_example':1.8**2/1.9,'reference_doubled_fold':4/2,'observed_control_mean':float(normalized[:3].mean()),'observed_treated_mean':float(normalized[3:].mean())},'sampling':{'empty_at_one':float(np.exp(-1)),'empty_at_three':float(np.exp(-3))}}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
