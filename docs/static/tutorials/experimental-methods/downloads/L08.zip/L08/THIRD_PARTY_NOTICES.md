# Public sources and third-party materials

- Saiki et al. (1985): Enzymatic amplification of beta-globin genomic sequences: https://pubmed.ncbi.nlm.nih.gov/2999980/
  Abstract and bibliographic reference
- Higuchi et al. (1992): Simultaneous amplification and detection of specific DNA sequences: https://pubmed.ncbi.nlm.nih.gov/1368485/
  Abstract and bibliographic reference
- Bustin et al. (2010): MIQE precis: https://pmc.ncbi.nlm.nih.gov/articles/PMC2955025/
  Technical reference; no figure reused
- Bustin et al. (2025): MIQE 2.0: https://doi.org/10.1093/clinchem/hvaf043
  Technical reference; no copyrighted figure/text reproduced
- Untergasser et al. (2021): Web-based LinRegPCR: https://link.springer.com/article/10.1186/s12859-021-04306-1
  CC BY 4.0; Fig. 1 reproduced in full
