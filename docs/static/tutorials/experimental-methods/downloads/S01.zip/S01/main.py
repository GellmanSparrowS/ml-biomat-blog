"""FTIR: measured OpenSpecy LDPE-in-soil spectrum and a constructed calibration.

Run: python main.py --output output --language en
The bundled LDPE-in-soil signal retains its published ordinate; acquisition units were
not fully documented in that ASP file. Calibration data below are a controlled simulation.
"""
from pathlib import Path
import argparse
import json
import numpy as np
from scipy.signal import savgol_filter
from scipy.stats import linregress
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, Rectangle

BLUE, RED, GOLD, GREY = '#12687b', '#be6047', '#a87d22', '#71828c'


def configure():
    plt.rcParams.update({'font.family': 'sans-serif',
        'font.sans-serif': ['Microsoft YaHei', 'Noto Sans CJK SC', 'DejaVu Sans'],
        'font.size': 11, 'axes.titlesize': 13, 'axes.labelsize': 11,
        'axes.spines.top': False, 'axes.spines.right': False,
        'svg.fonttype': 'none', 'axes.unicode_minus': False,
        'savefig.facecolor': 'white', 'axes.edgecolor': '#c6d0d5'})


def penetration(wavenumber_cm, angle_deg, n_crystal=2.4, n_sample=1.5):
    """Amplitude 1/e depth in micrometres, nonabsorbing-index approximation."""
    term = np.sin(np.deg2rad(angle_deg))**2 - (n_sample/n_crystal)**2
    if np.any(term <= 0):
        raise ValueError('Use an angle above the critical angle.')
    wavelength_um = 10000 / np.asarray(wavenumber_cm)
    return wavelength_um / (2*np.pi*n_crystal*np.sqrt(term))


def main(output, language):
    output.mkdir(parents=True, exist_ok=True)
    configure()
    tr = lambda zh, en: zh if language == 'zh' else en
    def save(fig, name):
        fig.savefig(output/f'{name}-{language}.svg', bbox_inches='tight')
        plt.close(fig)
    def arrow(ax, x1, y1, x2, y2, color=BLUE, lw=2):
        ax.annotate('', (x2,y2), (x1,y1), arrowprops={'arrowstyle':'->','color':color,'lw':lw})

    # A history/optics diagram, not a reconstructed historical measurement.
    fig, axes = plt.subplots(1, 2, figsize=(12.8,5.3), layout='constrained')
    for ax in axes:
        ax.set(xlim=(0,10), ylim=(0,7)); ax.axis('off')
    ax=axes[0]
    ax.set_title(tr('A  从“看不见”到可测量：赫歇尔，1800','A  Making invisible radiation measurable: Herschel, 1800'),loc='left',pad=20)
    arrow(ax,.3,4.5,3.2,4.5,GOLD)
    ax.add_patch(Polygon([[3,3.7],[3.8,5.4],[4.6,3.7]],fc='#dceaf0',ec=BLUE))
    for j,col in enumerate(['#7164a0','#3b8fa5','#5d9c61','#c1a23f','#bd5c47']):
        ax.plot([4.1,7.1],[4.4,5.8-j*.5],color=col,lw=4)
    ax.plot([4.1,7.1],[4.4,2.8],color=RED,lw=2,ls='--')
    ax.text(.3,5,tr('阳光','Sunlight'),color=GOLD)
    ax.text(2.8,3.1,tr('棱镜分光','Prism'),color=BLUE)
    ax.text(7.3,5.7,tr('可见光','Visible light'),va='center')
    ax.text(7.3,3.8,tr('红光','Red light'),va='center')
    ax.text(7.3,2.8,tr('红外区域','Infrared'),va='center',color=RED)
    for j in range(3):
        x=6.8+j*.65; y=1.3
        ax.add_patch(Circle((x,y),.18,fc=RED,ec='none'))
        ax.add_patch(Rectangle((x-.06,y),.12,.9,fc='#f1d7cf',ec=GREY))
        ax.plot([x,x],[y,y+.35+j*.15],color=RED,lw=3)
    ax.text(.3,1.2,tr('温度计比较不同位置的升温\n图示的是实验思路，不是历史数据','Thermometers compare heating at different positions\nConceptual reconstruction, not historical data'),fontsize=10,va='center')
    ax=axes[1]
    ax.set_title(tr('B  FTIR：改变光程差，记录干涉信号','B  FTIR: vary path difference and record interference'),loc='left',pad=20)
    arrow(ax,.3,3.8,3.6,3.8,GOLD)
    ax.plot([3.5,4.2],[3.4,4.2],color=GREY,lw=5)
    arrow(ax,3.85,3.8,3.85,6,BLUE);arrow(ax,4.05,6,4.05,3.8,RED)
    ax.plot([3.1,4.8],[6.2,6.2],color=GREY,lw=5)
    arrow(ax,4.2,3.8,7.6,3.8,BLUE);arrow(ax,7.6,3.6,4.2,3.6,RED)
    ax.plot([7.8,7.8],[3.1,4.5],color=GREY,lw=5)
    arrow(ax,7.6,5,8.7,5,GREY)
    arrow(ax,3.9,3.5,3.9,1.5,RED)
    ax.add_patch(Rectangle((3.3,1.35),1.3,.45,fc='#b6d6d1',ec=BLUE))
    ax.add_patch(Rectangle((3.2,.3),1.5,.6,fc='#e7edf0',ec=GREY))
    arrow(ax,3.9,1.3,3.9,.9,RED)
    labels=[(.3,4.3,'红外源','IR source'),(.4,2.8,'分束器','Beam splitter'),(4.9,6.1,'固定镜','Fixed mirror'),(6.3,5.5,'移动镜','Moving mirror'),(5,1.5,'样品或ATR附件','Sample / ATR accessory'),(5,.55,'探测器','Detector')]
    for x,y,z,e in labels:ax.text(x,y,tr(z,e),fontsize=10)
    save(fig,'history-optics')

    fig=plt.figure(figsize=(12.8,6.8),layout='constrained')
    gs=fig.add_gridspec(2,2,width_ratios=[1,1.15])
    ax=fig.add_subplot(gs[0,0]);ax.set(xlim=(0,10),ylim=(0,5));ax.axis('off')
    ax.set_title(tr('A  键：弹性恢复力与运动质量','A  A bond: restoring force and moving masses'),loc='left')
    for x,r,col,label in [(2,.65,BLUE,'C'),(8,.45,RED,'H')]:
        ax.add_patch(Circle((x,2.6),r,fc=col));ax.text(x,2.6,label,color='white',ha='center',va='center',fontsize=17)
    x=np.linspace(2.7,7.5,120);ax.plot(x,2.6+.23*np.sin(np.linspace(0,16*np.pi,120)),color=GREY,lw=2)
    arrow(ax,1.3,1.3,2.5,1.3);arrow(ax,8.8,1.3,7.6,1.3,RED)
    ax.text(5,.2,tr('运动时电荷分布的变化决定红外活性','Changing charge distribution determines IR activity'),ha='center',fontsize=10)
    ax=fig.add_subplot(gs[1,0]);ax.set(xlim=(0,10),ylim=(0,5));ax.axis('off')
    ax.set_title(tr('B  ATR：在界面附近取样','B  ATR: sampling near an interface'),loc='left')
    ax.add_patch(Rectangle((.4,.4),9,2,fc='#dceaf0',ec='none'))
    ax.add_patch(Rectangle((.4,2.4),9,1.5,fc='#dcece3',ec='none'))
    arrow(ax,1,.6,4,2.4,GOLD);arrow(ax,4,2.4,7,.6,GOLD)
    ax.plot([4,4],[.5,4.3],ls='--',color=GREY,lw=1)
    ax.text(.7,3.3,tr('样品 n2 = 1.5','Sample n2 = 1.5'),fontsize=10)
    ax.text(.7,.1,tr('晶体 n1 = 2.4','Crystal n1 = 2.4'),fontsize=10)
    for z in np.linspace(.05,1.3,16):ax.plot([3,5],[2.4+z]*2,color=RED,alpha=float(np.exp(-z*2)),lw=3)
    ax.text(5.5,3,tr('强度随距离衰减','Intensity decays with distance'),fontsize=10)
    ax=fig.add_subplot(gs[:,1]);z=np.linspace(0,8,300)
    for wn,col in [(1000,BLUE),(2000,RED),(3000,GOLD)]:
        dp=float(penetration(wn,45));ax.plot(z,np.exp(-2*z/dp),color=col,lw=2.5,label=f'{wn} cm$^{-1}$; dp={dp:.2f} μm')
    ax.set(xlabel=tr('距晶体表面的距离 / μm','Distance from crystal surface / μm'),ylabel=tr('归一化强度 |E/E0|²','Normalized intensity |E/E0|²'),title=tr('C  同一入射角下，波长改变取样权重','C  Wavelength changes the depth weighting'),ylim=(0,1.04))
    ax.legend(fontsize=10);ax.grid(alpha=.18)
    save(fig,'vibration-atr')

    asp=np.loadtxt(Path(__file__).parent/'data/openspecy-ldpe-soil.asp')
    assert len(asp)-6 == int(asp[0])
    raw=np.c_[np.linspace(asp[1],asp[2],int(asp[0])),asp[6:]]
    raw=raw[np.argsort(raw[:,0])];wn,signal=raw.T
    smooth=savgol_filter(signal,11,2)
    fig=plt.figure(figsize=(12.8,8.0),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1.5,1])
    ax=fig.add_subplot(gs[0,:]);ax.plot(wn,signal,color=GREY,lw=1.5,label=tr('公开LDPE光谱原始数值','Published LDPE-in-soil values'));ax.plot(wn,smooth,color=BLUE,lw=1,label=tr('11点二阶平滑','11-point quadratic smoothing'))
    for lo,hi,txt,col in [(2800,3000,'C–H',RED),(1350,1500,'CH2',GOLD),(680,780,'CH2',BLUE)]:
        ax.axvspan(lo,hi,color=col,alpha=.08);ax.text((lo+hi)/2,.59,txt,color=col,ha='center',fontsize=10)
    ax.set(xlim=(4000,650),ylim=(0,.64),xlabel=tr('波数 / cm$^{-1}$','Wavenumber / cm$^{-1}$'),ylabel=tr('原文件信号 / 相对单位','Original-file signal / relative units'),title=tr('A  土壤中LDPE的实测光谱（OpenSpecy）','A  A published measured spectrum: LDPE-in-soil (OpenSpecy)'))
    ax.legend(loc='upper right',bbox_to_anchor=(1,.84),fontsize=10)
    ax=fig.add_subplot(gs[1,0]);keep=(wn>=2800)&(wn<=3000)
    ax.plot(wn[keep],signal[keep],'.-',color=GREY,label=tr('原数值','Original'))
    for window,col in [(11,BLUE),(41,RED)]:ax.plot(wn[keep],savgol_filter(signal,window,2)[keep],color=col,label=tr(f'{window}点窗口',f'{window}-point window'))
    ax.set(xlim=(3000,2800),xlabel=tr('波数 / cm$^{-1}$','Wavenumber / cm$^{-1}$'),ylabel=tr('相对信号','Relative signal'),title=tr('B  窗口变大，也会改变峰形','B  Wider smoothing changes the peak shape'));ax.legend(fontsize=9)
    ax=fig.add_subplot(gs[1,1]);ax.plot(wn,signal-smooth,color=RED,lw=1);ax.axhline(0,color=GREY,lw=1)
    ax.set(xlim=(4000,650),xlabel=tr('波数 / cm$^{-1}$','Wavenumber / cm$^{-1}$'),ylabel=tr('原始值 − 平滑值','Original − smoothed'),title=tr('C  检查被平滑去掉的结构','C  Inspect what smoothing removes'))
    save(fig,'ldpe-measured')

    rng=np.random.default_rng(26)
    x=np.linspace(1580,1880,601);g=np.exp(-.5*((x-1730)/18)**2)
    c=np.repeat(np.arange(6)*.2,3)
    base=.025+.00002*(x-1730)
    y=.6*c[:,None]*g+base+rng.normal(0,.003,(len(c),len(x)))
    anchors=(x<1620)|(x>1840);band=(x>=1660)&(x<=1800)
    baselines=np.array([np.polyval(np.polyfit(x[anchors],row[anchors],1),x) for row in y])
    corrected=y-baselines
    # Integrating a fixed window is less sensitive to a single noisy maximum.
    areas=np.trapezoid(corrected[:,band],x[band],axis=1)
    slope,intercept,r,p,se=linregress(c,areas)
    unknown_c=.65
    unknown=.6*unknown_c*g+base+rng.normal(0,.003,len(x))
    unknown_base=np.polyval(np.polyfit(x[anchors],unknown[anchors],1),x)
    unknown_area=float(np.trapezoid((unknown-unknown_base)[band],x[band]))
    recovered=(unknown_area-intercept)/slope
    residual=areas-(intercept+slope*c)
    # Repeated calibration specimens are independent simulated measurements.
    fig,axs=plt.subplots(2,2,figsize=(12.8,8.4),layout='constrained')
    ax=axs[0,0]
    for i,col in [(0,GREY),(9,BLUE),(15,RED)]:ax.plot(x,y[i],color=col,label=f'c = {c[i]:.1f} mol/L')
    ax.fill_between(x,0,.7,where=anchors,color=GOLD,alpha=.10)
    ax.set(xlim=(1880,1580),ylim=(0,.7),xlabel=tr('波数 / cm$^{-1}$','Wavenumber / cm$^{-1}$'),ylabel=tr('吸光度','Absorbance'),title=tr('A  构造实验：共同的背景与不同浓度','A  Constructed experiment: background and concentration'));ax.legend(fontsize=9)
    ax=axs[0,1];ax.scatter(c,areas,color=BLUE,s=22,label=tr('独立重复测量','Independent simulated repeats'));ax.plot([0,1],[intercept,intercept+slope],color=BLUE,lw=1.4)
    ax.scatter([recovered],[unknown_area],marker='D',s=55,color=RED,label=tr(f'未知样品估计：{recovered:.3f} mol/L',f'Unknown estimate: {recovered:.3f} mol/L'))
    ax.set(xlabel=tr('浓度 / mol/L','Concentration / mol/L'),ylabel=tr('校正后的峰面积 / cm$^{-1}$','Corrected band area / cm$^{-1}$'),title=tr('B  固定窗口的面积校准','B  Calibration using a fixed integration window'));ax.legend(fontsize=9)
    ax=axs[1,0];ax.scatter(c,residual,color=RED,s=26);ax.axhline(0,color=GREY,lw=1)
    ax.set(xlabel=tr('浓度 / mol/L','Concentration / mol/L'),ylabel=tr('面积残差 / cm$^{-1}$','Area residual / cm$^{-1}$'),title=tr('C  残差揭示直线遗漏了什么','C  Residuals inspect what the line misses'))
    ax=axs[1,1];absorb=np.linspace(0,3,200);ax.plot(absorb,100*10**(-absorb),color=BLUE,lw=2.4)
    ax.scatter([0,.30103,1,2],[100,50,10,1],color=RED,zorder=4)
    ax.set(xlabel=tr('吸光度 A','Absorbance A'),ylabel=tr('透过率 / %','Transmittance / %'),title=tr('D  高吸光度意味着探测器收到更少光','D  High absorbance leaves less light at the detector'));ax.grid(alpha=.15)
    save(fig,'calibration')
    np.savetxt(output/'ldpe-processed.csv',np.c_[wn,signal,smooth,signal-smooth],delimiter=',',header='wavenumber_cm-1,published_signal,smoothed_signal,residual',comments='')
    np.savetxt(output/'calibration.csv',np.c_[c,areas,residual],delimiter=',',header='concentration_mol_L,band_area_cm-1,residual_cm-1',comments='')
    np.savez_compressed(output/'spectra.npz',wavenumber_cm=x,absorbance=y,baseline=baselines,unknown=unknown)
    summary={'data_origin':'Measured LDPE-in-soil: OpenSpecy CC BY 4.0; calibration: constructed with seed 26',
        'ldpe_rows':int(len(wn)), 'ldpe_max_wavenumber_cm':float(wn.max()),
        'absorbance_at_half_transmission':float(-np.log10(.5)),
        'penetration_um_1000_45':float(penetration(1000,45)),
        'penetration_ratio_1000_to_2000':float(penetration(1000,45)/penetration(2000,45)),
        'calibration':{'slope':float(slope),'intercept':float(intercept),'r_squared':float(r*r),
        'unknown_true_mol_L':unknown_c,'unknown_estimated_mol_L':float(recovered),
        'residual_sd_cm-1':float(np.std(residual,ddof=2))}}
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    assert len(wn)==1798 and np.all(np.diff(wn)>0)
    assert abs(recovered-unknown_c)<.01
    assert abs(summary['penetration_ratio_1000_to_2000']-2)<1e-12
    print(json.dumps(summary,ensure_ascii=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en')
    args=parser.parse_args()
    main(args.output,args.language)
