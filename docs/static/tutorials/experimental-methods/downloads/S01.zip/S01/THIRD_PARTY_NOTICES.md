# Public sources and third-party materials

- ESA: Space infrared astronomy comes of age: https://www.esa.int/Science_Exploration/Space_Science/Exploring_space/Space_infrared_astronomy_comes_of_age
  Technical reference; original explanatory diagram.
- OpenSpecy: package tutorial: https://www.openspecy.org/pkgdown/articles/sop.html
  CC BY 4.0
- OpenSpecy: LDPE-in-soil example data: https://github.com/wincowgerDEV/OpenSpecy-package/blob/main/inst/extdata/ftir_ldpe_soil.asp
  OpenSpecy contributors; CC BY 4.0; replotted and smoothed. https://github.com/wincowgerDEV/OpenSpecy-package/blob/main/LICENSE.md
- OpenSpecy: Build a Mini Reference Library: https://www.openspecy.org/pkgdown/articles/library-builder.html
  CC BY 4.0
- Chemistry LibreTexts: The Harmonic Oscillator and Infrared Spectra: https://chem.libretexts.org/Courses/University_of_California_Davis/UCD_Chem_110A%3A_Physical_Chemistry__I/UCD_Chem_110A%3A_Physical_Chemistry_I_%28Larsen%29/Text/05%3A_The_Harmonic_Oscillator_and_the_Rigid_Rotor/5.05%3A_The_Harmonic_Oscillator_and_Infrared_Spectra
  Technical reference
- Shimadzu: ATR penetration depth: https://www.shimadzu.co.uk/service-support/technical-support/ftir/faq/atr.html
  Technical reference
- Bruker: Attenuated Total Reflectance: https://www.bruker.com/en/products-and-solutions/infrared-and-raman/ft-ir-routine-spectrometer/what-is-ft-ir-spectroscopy/atr-attenuated-total-reflectance.html
  Technical reference
- Coblentz Society: Attenuated Total Reflection Spectroscopy: https://www.coblentz.org/field-guide/chapter9/
  Technical reference
- SciPy: savgol_filter: https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.savgol_filter.html
  Technical reference
