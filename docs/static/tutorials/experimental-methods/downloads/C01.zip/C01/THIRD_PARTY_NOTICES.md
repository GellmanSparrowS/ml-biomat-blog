# Public sources and third-party materials

- Martin: The development of partition chromatography: https://www.nobelprize.org/uploads/2018/06/martin-lecture.pdf
  Technical or historical reference; original figures and constructed data, no source illustrations copied.
- Thermo Fisher: HPLC basics: https://www.thermofisher.com/dk/en/home/industrial/chromatography/chromatography-learning-center/liquid-chromatography-information/hplc-basics.html?erpType=Global_E1
  Technical or historical reference; original figures and constructed data, no source illustrations copied.
- Agilent: Essentials of good HPLC method development: https://www.agilent.com/cs/library/slidepresentation/public/essentials_of_good_hplc_method_development_july_27_2022.pdf
  Technical or historical reference; original figures and constructed data, no source illustrations copied.
- Agilent: A guide to HPLC column selection: https://www.agilent.com/cs/library/eseminars/public/how-do-i-choose-a-guide-to-hplc-column-selection.pdf
  Technical or historical reference; original figures and constructed data, no source illustrations copied.
- JASCO: Qualitative and quantitative HPLC analysis: https://www.jasco-global.com/principle/principles-of-hplc-5-qualitative-and-quantitative-analysis/
  Technical or historical reference; original figures and constructed data, no source illustrations copied.
- Shimadzu: Quantitation error factors in sample preparation: https://www.shimadzu.com/an/service-support/technical-support/liquid-chromatography/essential_knowledge/error.html
  Technical or historical reference; original figures and constructed data, no source illustrations copied.
