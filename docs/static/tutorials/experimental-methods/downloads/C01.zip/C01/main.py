"""Reproducible constructed HPLC separation, calibration and sampling examples."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,FancyArrowPatch

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();out=a.output;out.mkdir(parents=True,exist_ok=True);zh=a.language=='zh';T=lambda z,e:z if zh else e
 plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','text.color':'#243c49','axes.labelcolor':'#243c49','axes.edgecolor':'#8ea1a8','figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','svg.fonttype':'path'})
 blue,green,red,gold='#286488','#008b7b','#dc604d','#c39227';rng=np.random.default_rng(610)
 def save(fig,n):
  fig.tight_layout(pad=1.6)
  for ext in ['svg','png']:fig.savefig(out/f'{n}-{a.language}.{ext}',dpi=155,bbox_inches='tight')
  plt.close(fig)
 def g(t,mu,s):return np.exp(-.5*((t-mu)/s)**2)/(s*np.sqrt(2*np.pi))
 fig,ax=plt.subplots(1,2,figsize=(13,5),gridspec_kw={'width_ratios':[1,1.55]});x=ax[0];x.set(xlim=(0,10),ylim=(0,10));x.axis('off')
 x.add_patch(Rectangle((3,1.1),3,7.7,fill=False,lw=2,color=blue))
 for yy in np.arange(1.6,8.6,.55):
  for xx in [3.45,4.25,5.05,5.65]:x.add_patch(Circle((xx,yy),.13,color='#b9c9cb'))
 for yy,c,label in [(6.5,gold,T('停留较久','More retained')),(3.1,green,T('前进较快','Faster migration'))]:x.add_patch(Rectangle((3.1,yy),2.8,.55,color=c,alpha=.65));x.text(6.4,yy+.27,label,va='center',fontsize=10)
 x.annotate('',xy=(4.5,9),xytext=(4.5,10),arrowprops={'arrowstyle':'->','color':blue,'lw':2});x.annotate('',xy=(4.5,.15),xytext=(4.5,1),arrowprops={'arrowstyle':'->','color':blue,'lw':2});x.text(.1,.15,T('流动相不断向下移动','Mobile phase keeps moving'),fontsize=10);x.set_title(T('A  分配差异累积为分离','A  Repeated partition creates separation'),loc='left')
 x=ax[1];x.set(xlim=(0,14),ylim=(0,10));x.axis('off');items=[(.3,6.5,2,1.4,T('溶剂瓶','Solvents')), (3.3,6.5,2,1.4,T('泵与混合','Pump / mix')), (6.3,6.5,2,1.4,T('定量进样','Injection')), (6.3,2.8,2,1.4,T('色谱柱','Column')), (10,2.8,2.7,1.4,T('检测器','Detector'))]
 for xx,yy,w,h,label in items:x.add_patch(Rectangle((xx,yy),w,h,facecolor='#e6eeee',edgecolor=blue,lw=1.7));x.text(xx+w/2,yy+h/2,label,ha='center',va='center')
 for start,end in [((2.3,7.2),(3.3,7.2)),((5.3,7.2),(6.3,7.2)),((7.3,6.5),(7.3,4.2)),((8.3,3.5),(10,3.5)),((12.7,3.5),(13.7,3.5))]:x.add_patch(FancyArrowPatch(start,end,arrowstyle='->',mutation_scale=14,color=green,lw=2))
 x.text(10,1.2,T('固定波长下的信号随时间记录','Signal recorded over time at a fixed wavelength'),fontsize=10,ha='center');x.text(1,2.2,T('分离发生在柱内\n检测发生在出口','Separation inside the column\nDetection after the column'),fontsize=12,color=green);x.set_title(T('B  用稳定流动读取时间顺序','B  Controlled flow reveals elution order'),loc='left');save(fig,'instrument')

 t=np.linspace(0,10,4001);t0=1.;k1=3.;alpha=1.12;N=2500.
 def peaks(N,alpha):
  tr=np.array([t0*(1+k1),t0*(1+alpha*k1)]);s=tr/np.sqrt(N);ys=np.array([g(t,m,w) for m,w in zip(tr,s)]);rs=(tr[1]-tr[0])/(2*sum(s));return tr,s,ys,rs
 fig,ax=plt.subplots(2,2,figsize=(12,7.6));records=[]
 for axis,(n,al,label) in zip(ax.flat[:3],[(2500,1.12,T('A  原条件','A  Initial conditions')),(10000,1.12,T('B  柱效提高四倍','B  Fourfold plate count')),(2500,1.30,T('C  改变选择性','C  Change selectivity'))]):
  tr,s,y,rs=peaks(n,al);axis.plot(t,y.sum(axis=0),color=blue,lw=2);axis.fill_between(t,0,y[0],alpha=.2,color=green);axis.fill_between(t,0,y[1],alpha=.2,color=gold);axis.set(xlim=(3.4,5.6),xlabel=T('时间 / min','Time / min'),ylabel=T('归一化信号 / 每 min','Normalized signal / per min'));axis.set_title(label+f' · Rs={rs:.2f}',loc='left');records.append([n,al,*tr,*s,rs])
 ns=np.linspace(1000,12000,100);als=np.linspace(1.01,1.4,100);nn,aa=np.meshgrid(ns,als);rsgrid=3*(aa-1)*np.sqrt(nn)/(2*(4+1+3*aa));im=ax[1,1].pcolormesh(ns,als,rsgrid,shading='auto',cmap='viridis');ax[1,1].contour(ns,als,rsgrid,levels=[1.5],colors=['white'],linewidths=1.5);ax[1,1].set(xlabel=T('理论塔板数 N','Theoretical plates N'),ylabel=T('选择性 α','Selectivity α'));ax[1,1].set_title(T('D  两种改进各有作用','D  Two distinct routes to separation'),loc='left');fig.colorbar(im,ax=ax[1,1],label='Rs');save(fig,'resolution');np.savetxt(out/'separation_cases.csv',records,delimiter=',',header='N,alpha,tR1_min,tR2_min,sigma1_min,sigma2_min,Rs',comments='')

 concentrations=np.repeat([0,2,5,10,20,40],3);calarea=6*concentrations+.8+rng.normal(0,.6,len(concentrations));slope,intercept=np.polyfit(concentrations,calarea,1)
 trace_t=np.linspace(4,7,1501);baseline=2+.3*(trace_t-4);truearea=6*13+.8;trace=baseline+truearea*g(trace_t,5.2,.12)+40*g(trace_t,6.25,.14)+rng.normal(0,.3,len(trace_t));baseline_mask=(trace_t<4.5)|(trace_t>6.85);bp=np.polyfit(trace_t[baseline_mask],trace[baseline_mask],1);estimated_base=np.polyval(bp,trace_t);region=(trace_t>=4.65)&(trace_t<=5.7);area=np.trapezoid((trace-estimated_base)[region],trace_t[region]);conc=(area-intercept)/slope;stock=conc*4
 fig,ax=plt.subplots(2,2,figsize=(12,7.5));ax[0,0].plot(trace_t,trace,color=blue,label=T('进样信号','Injected signal'));ax[0,0].plot(trace_t,estimated_base,color=gold,label=T('估计基线','Estimated baseline'));ax[0,0].fill_between(trace_t[region],estimated_base[region],trace[region],alpha=.25,color=green);ax[0,0].set(xlabel=T('时间 / min','Time / min'),ylabel='mAU');ax[0,0].legend(fontsize=9);ax[0,0].set_title(T('A  面积包括整个目标峰','A  Integrate the target peak'),loc='left')
 ax[0,1].scatter(concentrations,calarea,color=blue,s=22);xx=np.linspace(0,42,100);ax[0,1].plot(xx,slope*xx+intercept,color=green);ax[0,1].scatter([conc],[area],color=red,marker='D',s=55,label=T('未知样','Unknown'));ax[0,1].legend();ax[0,1].set(xlabel=T('浓度 / μg mL⁻¹','Concentration / micrograms per mL'),ylabel=T('峰面积 / mAU·min','Peak area / mAU min'));ax[0,1].set_title(T('B  同一目标物的校准','B  Analyte-specific calibration'),loc='left')
 ax[1,0].axhline(0,color='#8da0a8');ax[1,0].scatter(concentrations,calarea-(slope*concentrations+intercept),color=blue,s=25);ax[1,0].set(xlabel=T('浓度 / μg mL⁻¹','Concentration / micrograms per mL'),ylabel=T('面积残差 / mAU·min','Area residual / mAU min'));ax[1,0].set_title(T('C  校准残差保留误差信息','C  Calibration residuals reveal error'),loc='left')
 windows=[.12,.24,.36,.48,.6];captured=[]
 for half in windows:
  sel=np.abs(trace_t-5.2)<=half;captured.append(np.trapezoid((trace-estimated_base)[sel],trace_t[sel])/truearea*100)
 ax[1,1].plot(windows,captured,'o-',color=green);ax[1,1].axhline(100,color='#8da0a8',ls=':');ax[1,1].set(xlabel=T('积分窗口半宽 / min','Integration half-width / min'),ylabel=T('目标面积回收 / %','Target area recovered / %'),ylim=(60,105));ax[1,1].set_title(T('D  太窄的窗口遗漏峰翼','D  Narrow windows lose peak tails'),loc='left');save(fig,'quantification')
 np.savetxt(out/'calibration.csv',np.c_[concentrations,calarea,calarea-(slope*concentrations+intercept)],delimiter=',',header='concentration_ug_per_mL,area_mAU_min,residual_mAU_min',comments='');np.savetxt(out/'unknown_chromatogram.csv',np.c_[trace_t,trace,estimated_base],delimiter=',',header='time_min,signal_mAU,estimated_baseline_mAU',comments='')

 fig,ax=plt.subplots(1,3,figsize=(14,4.7));tt=np.linspace(0,16,500);program=np.clip(10+8*tt,10,90);arrival=np.clip(10+8*(tt-1.5),10,90);ax[0].plot(tt,program,color=blue,label=T('泵设定','Pump program'));ax[0].plot(tt,arrival,color=green,label=T('到达柱入口','At column inlet'));ax[0].set(xlabel=T('时间 / min','Time / min'),ylabel=T('有机相 B / %','Organic B / %'));ax[0].legend(fontsize=9);ax[0].set_title(T('A  梯度有到达延迟','A  Gradients have a delay'),loc='left')
 spikes=[0,5,10,20];recovered=np.array(spikes)*.85;ax[1].plot(spikes,spikes,ls=':',color='#8da0a8',label='100%');ax[1].plot(spikes,recovered,'o-',color=green,label='85%');ax[1].set(xlabel=T('提取前加入 / μg','Spike before extraction / micrograms'),ylabel=T('测得增加量 / μg','Measured increase / micrograms'));ax[1].legend();ax[1].set_title(T('B  加标追踪样品回收','B  Spikes track recovery'),loc='left')
 c=np.array([2.,5.,8.]);V=10.;v=1.;cumulative=V*c+v*np.r_[0,np.cumsum(c[:-1])];ax[2].plot([1,2,3],V*c,'o-',color=gold,label=T('当前容器内','Currently in vessel'));ax[2].plot([1,2,3],cumulative,'o-',color=green,label=T('累计释放','Cumulative released'));ax[2].set(xlabel=T('取样序号','Sampling event'),ylabel=T('目标物质量 / μg','Analyte mass / micrograms'));ax[2].set_xticks([1,2,3]);ax[2].legend(fontsize=9);ax[2].set_title(T('C  已取走的质量也要算','C  Include previously removed mass'),loc='left');save(fig,'method-decisions');np.savetxt(out/'release_sampling.csv',np.c_[c,V*c,cumulative],delimiter=',',header='concentration_ug_per_mL,current_mass_ug,cumulative_mass_ug',comments='')
 _,_,_,rs=peaks(2500,1.12)
 summary={'retention_factor_example':3.,'initial_resolution':float(rs),'fourfold_N_resolution':float(peaks(10000,1.12)[3]),'changed_selectivity_resolution':float(peaks(2500,1.3)[3]),'calibration_slope':float(slope),'calibration_intercept':float(intercept),'unknown_area_mAU_min':float(area),'unknown_diluted_ug_per_mL':float(conc),'unknown_original_ug_per_mL':float(stock),'dwell_delay_min':.75/.5,'spike_recovery_fraction':.85,'cumulative_release_final_ug':float(cumulative[-1]),'constructed_data':True}
 (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
