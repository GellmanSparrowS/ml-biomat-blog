"""Stress relaxation with measured finite ramps and a generalized Maxwell model.
All numerical records are constructed teaching data, with fixed random seed.
python main.py --output results --language en
"""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import least_squares
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,FancyArrowPatch

PARAM=np.array([20.,40.,30.,2.,40.])  # kPa,kPa,kPa,s,s
EPS=.02
def response(t,ramp,q=PARAM,eps=EPS):
    """Uniaxial stress in kPa from initially unstressed material, t in seconds."""
    t=np.asarray(t,dtype=float);Ein,E1,E2,tau1,tau2=q
    u=np.minimum(np.maximum(t,0),ramp);hold=np.maximum(t-ramp,0)
    strain=eps*u/ramp;stress=Ein*strain
    for modulus,tau in [(E1,tau1),(E2,tau2)]:
        stress=stress+modulus*eps*tau/ramp*(-np.expm1(-u/tau))*np.exp(-hold/tau)
    return stress
def step(t,q=PARAM):
    Ein,E1,E2,tau1,tau2=q;t=np.asarray(t)
    return Ein+E1*np.exp(-t/tau1)+E2*np.exp(-t/tau2)
def apparent(q,ramp):
    Ein,E1,E2,t1,t2=q
    return np.array([Ein,E1*t1/ramp*(-np.expm1(-ramp/t1)),E2*t2/ramp*(-np.expm1(-ramp/t2)),t1,t2])

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();o=a.output;o.mkdir(parents=True,exist_ok=True);tr=lambda z,e:z if a.language=='zh' else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fbfcfc','savefig.facecolor':'#fbfcfc','text.color':'#18344a'})
    B='#186c94';G='#188777';O='#d27839';P='#8a5d92';K='#18344a'
    def save(f,n):
        f.savefig(o/f'{n}-{a.language}.svg',bbox_inches='tight');f.savefig(o/f'{n}-{a.language}.png',bbox_inches='tight',dpi=150);plt.close(f)
    rng=np.random.default_rng(1905);records=[]
    for ramp in [1.,20.]:
        t=np.unique(np.r_[np.linspace(0,ramp,51),ramp+np.geomspace(.05,400,180)])
        true=response(t,ramp);obs=true+rng.normal(0,.003,len(t));records.append((ramp,t,true,obs))
    def residual(q):return np.concatenate([response(t,r,q)-y for r,t,truth,y in records])
    fit=least_squares(residual,[18,35,33,3,35],bounds=([.1,.1,.1,.1,10],[100,200,200,10,200]),xtol=1e-13,ftol=1e-13,gtol=1e-13);assert fit.success
    q=fit.x
    r,t,true,y=records[1];mask=t>=r;h=t[mask]-r
    naive=least_squares(lambda v:EPS*step(h,v)-y[mask],[20,4,24,2,40],bounds=([.1,.01,.01,.1,10],[100,200,200,10,200]),xtol=1e-13,ftol=1e-13,gtol=1e-13);assert naive.success
    tt=np.linspace(0,20,401)
    sol=solve_ivp(lambda time,s:np.array([40.,30.])*EPS/20-s/np.array([2.,40.]),[0,20],[0,0],t_eval=tt,rtol=1e-11,atol=1e-13)
    ode=20*EPS*tt/20+sol.y.sum(axis=0);ode_error=float(np.max(np.abs(ode-response(tt,20))))
    # F1: original conceptual history and a matched mechanical network.
    f,ax=plt.subplots(1,3,figsize=(14,5),layout='constrained')
    for aa in ax:aa.set(xlim=(0,10),ylim=(0,10));aa.axis('off')
    ax[0].set_title(tr('a  1867：响应需要时间','a  1867: response takes time'))
    ax[0].add_patch(Rectangle((1,3),8,4,fill=False,ec=B,lw=2))
    for x,y,dx,dy in [(2,4,.8,.4),(4,5,-.7,.8),(6,4.3,.6,-.5),(8,6,-.8,-.4),(3,6,.6,.4),(7,5.8,-.7,-.8)]:
        ax[0].add_patch(Circle((x,y),.19,color=G));ax[0].annotate('',(x+dx,y+dy),(x,y),arrowprops={'arrowstyle':'->','color':G})
    ax[0].text(5,2,tr('Maxwell的气体动力学问题','Maxwell’s gas-dynamics question'),ha='center',fontsize=11)
    ax[0].text(5,1.2,tr('分子运动与宏观应力的联系','Molecular motion and macroscopic stress'),ha='center',fontsize=10)
    def spring(aa,x0,x1,y,color=B):
        x=np.linspace(x0+.18,x1-.18,13);ys=y+np.r_[0,np.tile([.35,-.35],5),.35,0]
        aa.plot([x0,x0+.18],[y,y],color=color,lw=2);aa.plot(x,ys,color=color,lw=2);aa.plot([x1-.18,x1],[y,y],color=color,lw=2)
    def dash(aa,x0,x1,y):
        aa.plot([x0,x0+.3],[y,y],color=G,lw=2)
        aa.plot([x1-.3,x0+.3,x0+.3,x1-.3],[y+.4,y+.4,y-.4,y-.4],color=G,lw=2)
        aa.plot([x1-.8,x1-.8],[y-.3,y+.3],color=G,lw=2);aa.plot([x1-.8,x1],[y,y],color=G,lw=2)
    ax[1].set_title(tr('b  串联：形变可以重新分配','b  Series: deformation can redistribute'))
    spring(ax[1],1,4,5);dash(ax[1],4,8.5,5)
    ax[1].text(2.5,6.2,'E',ha='center');ax[1].text(6.2,6.2,'η',ha='center')
    ax[1].text(5,3.5,tr('总伸长固定，弹簧逐渐回缩','Fixed total extension; spring recoils'),ha='center',fontsize=10)
    ax[1].text(5,2.5,'τ = η / E',ha='center',fontsize=15)
    ax[2].set_title(tr('c  并联：不同时间尺度分担载荷','c  Parallel: several load-bearing timescales'))
    ax[2].plot([1,1],[2.5,7.5],color=K,lw=2);ax[2].plot([9,9],[2.5,7.5],color=K,lw=2)
    spring(ax[2],1,9,7.5);spring(ax[2],1,4,5);dash(ax[2],4,9,5);spring(ax[2],1,4,2.5);dash(ax[2],4,9,2.5)
    ax[2].text(5,8.4,'E∞ = 20 kPa',ha='center');ax[2].text(5,5.9,'E₁ = 40 kPa, τ₁ = 2 s',ha='center',fontsize=10);ax[2].text(5,3.4,'E₂ = 30 kPa, τ₂ = 40 s',ha='center',fontsize=10)
    ax[2].text(5,.9,tr('现代力学类比；不是分子结构图','Modern mechanical analogy, not molecular structure'),ha='center',fontsize=9)
    save(f,'history')
    # F2: measured input and resulting load are inseparable.
    f,ax=plt.subplots(3,1,figsize=(11,10),layout='constrained');ts=np.linspace(0,100,1501)
    for ramp,c in [(1,B),(20,O)]:
        lab=tr('加载','Ramp')+f' {ramp:g} s';ax[0].plot(ts,100*EPS*np.minimum(ts/ramp,1),color=c,label=lab)
        ax[1].plot(ts,response(ts,ramp),color=c,label=lab)
    ax[0].set(xlabel=tr('从加载开始的时间 / s','Time from ramp start / s'),ylabel=tr('应变 / %','Strain / %'),xlim=(0,30));ax[0].legend()
    ax[1].plot(ts,EPS*step(ts),'--',color=G,label=tr('理想瞬时阶跃','Ideal instantaneous step'));ax[1].axhline(.4,color='#81939e',ls=':');ax[1].set(xlabel=tr('从加载开始的时间 / s','Time from ramp start / s'),ylabel=tr('应力 / kPa','Stress / kPa'));ax[1].legend()
    hold=np.linspace(0,120,600);app=apparent(PARAM,20)
    ax[2].stackplot(hold,np.full_like(hold,.4),EPS*app[1]*np.exp(-hold/2),EPS*app[2]*np.exp(-hold/40),colors=[G,B,O],alpha=.8,labels=[tr('长期分支','Equilibrium'),tr('快分支','Fast arm'),tr('慢分支','Slow arm')]);ax[2].set(xlabel=tr('20 s加载结束后的保持时间 / s','Hold time after the 20 s ramp / s'),ylabel=tr('应力分担 / kPa','Stress contributions / kPa'));ax[2].legend(loc='upper right',ncol=3)
    for aa,title in zip(ax,[tr('a  两次实验达到相同2%应变','a  Both experiments reach 2% strain'),tr('b  加载期间已经发生松弛','b  Relaxation starts during loading'),tr('c  保持阶段的不同承载路径','c  Load-bearing paths during the hold')]):aa.set_title(title,loc='left')
    save(f,'ramp')
    # F3: fitted results, residuals, and an exact explanation of apparent amplitudes.
    f,ax=plt.subplots(2,2,figsize=(13,9),layout='constrained')
    for r,t,true,y in records:
        c=B if r==1 else O;h=t-r;sel=h>=0;ax[0,0].scatter(h[sel],y[sel],s=9,color=c,alpha=.45);ax[0,0].plot(h[sel],response(t[sel],r,q),color=c,label=f'{r:g} s '+tr('加载','ramp'));ax[0,1].scatter(h[sel],(y-response(t,r,q))[sel]*1000,s=8,color=c,alpha=.55)
    ax[0,0].set_xscale('symlog',linthresh=.1);ax[0,1].set_xscale('symlog',linthresh=.1)
    ax[0,0].set(xlabel=tr('保持时间 / s','Hold time / s'),ylabel=tr('应力 / kPa','Stress / kPa'));ax[0,0].legend();ax[0,1].axhline(0,color=K,lw=1);ax[0,1].set(xlabel=tr('保持时间 / s','Hold time / s'),ylabel=tr('观测−拟合 / Pa','Observed − fitted / Pa'))
    ix=np.arange(3);ax[1,0].bar(ix-.24,PARAM[:3],.24,color=G,label=tr('指定模型','Specified'));ax[1,0].bar(ix,q[:3],.24,color=B,label=tr('有限加载联合拟合','Joint finite-ramp fit'));ax[1,0].bar(ix+.24,naive.x[:3],.24,color=O,label=tr('20 s保持段当作阶跃','20 s hold treated as a step'));ax[1,0].set(xticks=ix,xticklabels=['E∞','E₁','E₂'],ylabel=tr('分支模量 / kPa','Arm modulus / kPa'));ax[1,0].legend(fontsize=8.7)
    window=np.linspace(0,300,601);alt=np.array([5,40,45,2,60]);ax[1,1].plot(window,step(window),color=B,label='E∞=20, E₂=30, τ₂=40');ax[1,1].plot(window,step(window,alt),'--',color=P,label='E∞=5, E₂=45, τ₂=60');ax[1,1].axvspan(0,5,color=O,alpha=.2,label=tr('只观察前5 s','Only the first 5 s'));ax[1,1].set(xlabel=tr('理想阶跃后的时间 / s','Time after ideal step / s'),ylabel=tr('松弛模量 / kPa','Relaxation modulus / kPa'));ax[1,1].legend(fontsize=8.7)
    for aa,title in zip(ax.flat,[tr('a  两条输入历史共同识别模型','a  Joint fit to two input histories'),tr('b  残差保留时间结构供检查','b  Residuals reveal time structure'),tr('c  忽略加载会低估分支幅值','c  Ignoring the ramp suppresses amplitudes'),tr('d  短窗口看不清长期平台','d  A short window misses the plateau')]):aa.set_title(title,loc='left')
    save(f,'fit')
    # F4: an independent one-arm solid compares two controlled experiments.
    time=np.linspace(0,25,501);Er=20+40*np.exp(-time/2);J=(1-2/3*np.exp(-time/6))/20
    f,ax=plt.subplots(1,2,figsize=(12,4.8),layout='constrained');ax[0].plot(time,Er,color=B);ax[0].axhline(20,color=G,ls=':');ax[0].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('松弛模量 / kPa','Relaxation modulus / kPa'),title=tr('a  保持应变：应力逐渐减小','a  Fixed strain: stress decreases'))
    ax[1].plot(time,J,color=G,label=tr('蠕变柔量 J(t)','Creep compliance J(t)'));ax[1].plot(time,1/Er,'--',color=O,label='1 / E(t)');ax[1].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('柔量 / kPa⁻¹','Compliance / kPa⁻¹'),title=tr('b  保持应力：时间尺度也改变','b  Fixed stress: the timescale changes'));ax[1].legend();save(f,'creep')
    # F5: original conceptual link to time-dependent cell environments, no cell measurements.
    f,ax=plt.subplots(1,3,figsize=(14,4.6),layout='constrained');bt=np.geomspace(.05,300,400)
    for factor,c,lab in [(1,B,tr('较快','Faster')),(5,P,tr('较慢','Slower'))]:
        bq=PARAM.copy();bq[3:]*=factor;ax[0].semilogx(bt,step(bt,bq)/90,color=c,label=lab)
    ax[0].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('归一化模量 E(t)/E(0)','Normalized modulus E(t)/E(0)'),title=tr('a  相同初始模量，不同持续阻力','a  Same initial modulus, different persistence'));ax[0].legend()
    for aa,title,col in [(ax[1],tr('b  细胞通过黏附点牵拉网络','b  A cell pulls through adhesions'),B),(ax[2],tr('c  接点重排改变周围的应力','c  Junction rearrangement changes stress'),P)]:
        aa.set(xlim=(-3,3),ylim=(-3,3),aspect='equal');aa.axis('off');aa.set_title(title,fontsize=11)
        theta=np.linspace(0,2*np.pi,60);aa.fill(.9*np.cos(theta),.55*np.sin(theta),color='#e4b6a3');aa.add_patch(Circle((0,0),.24,color='#9a6d91'))
        for ang in np.linspace(0,2*np.pi,9)[:-1]:
            x,y=2.5*np.cos(ang),2.5*np.sin(ang);cx,cy=.9*np.cos(ang),.55*np.sin(ang);mx,my=(x+cx)/2,(y+cy)/2
            if aa is ax[2]:mx+=.18*np.sin(3*ang);my+=.16*np.cos(2*ang)
            aa.plot([cx,mx,x],[cy,my,y],color=col,lw=1.8);aa.add_patch(Circle((mx,my),.09,fc=O));aa.annotate('',(cx*.82,cy*.82),(cx*1.6,cy*1.6),arrowprops={'arrowstyle':'->','color':K})
        aa.text(0,-2.9,tr('机制示意，非显微观测','Mechanistic sketch, not microscopy'),ha='center',fontsize=9)
    save(f,'biology')
    arr=np.concatenate([np.c_[np.full(len(t),r),t,EPS*np.minimum(t/r,1),true,y,response(t,r,q),y*.01] for r,t,true,y in records])
    np.savetxt(o/'data.csv',arr,delimiter=',',header='ramp_s,time_s,strain,true_stress_kPa,observed_stress_kPa,fitted_stress_kPa,observed_force_N',comments='')
    np.savetxt(o/'parameters.csv',np.c_[PARAM,q,naive.x],delimiter=',',header='specified,finite_ramp_fit,hold_as_step_fit',comments='')
    np.savetxt(o/'creep.csv',np.c_[time,Er,J,1/Er],delimiter=',',header='time_s,relaxation_kPa,creep_compliance_per_kPa,inverse_relaxation_per_kPa',comments='')
    app20=apparent(PARAM,20);out={'specified_E0_kPa':90.,'specified_Einf_kPa':20.,'step_initial_stress_kPa':1.8,'equilibrium_stress_kPa':.4,'ramp1_peak_kPa':float(response(1,1)),'ramp20_peak_kPa':float(response(20,20)),'ramp20_apparent_E1_kPa':float(app20[1]),'ramp20_apparent_E2_kPa':float(app20[2]),'ramp20_apparent_E0_kPa':float(app20[:3].sum()),'fit_Einf_kPa':float(q[0]),'fit_E1_kPa':float(q[1]),'fit_E2_kPa':float(q[2]),'fit_tau1_s':float(q[3]),'fit_tau2_s':float(q[4]),'naive_E0_kPa':float(naive.x[:3].sum()),'naive_tau1_s':float(naive.x[3]),'naive_tau2_s':float(naive.x[4]),'residual_rms_Pa':float(np.sqrt(np.mean(residual(q)**2))*1000),'ode_max_error_kPa':ode_error,'one_arm_retardation_s':6.,'one_arm_J_at2_per_kPa':float((1-2/3*np.exp(-2/6))/20),'one_arm_inverseE_at2_per_kPa':float(1/(20+40*np.exp(-1))),'force_at_equilibrium_N':.004}
    (o/'summary.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(json.dumps(out))
if __name__=='__main__':main()
