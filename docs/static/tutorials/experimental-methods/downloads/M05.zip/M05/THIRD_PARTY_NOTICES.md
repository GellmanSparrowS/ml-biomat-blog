# Public sources and third-party materials

- Royal Society — Maxwell’s other equations: https://royalsociety.org/blog/2015/09/maxwells-other-equations/
  Technical/historical reference; no images reproduced.
- Roylance — Engineering Viscoelasticity: https://ocw.mit.edu/courses/3-11-mechanics-of-materials-fall-1999/d173f95347f59d59dd9b7387ab4303e7_MIT3_11F99_visco.pdf
  MIT OpenCourseWare; reference only, no text or figures reproduced.
- Bower — Small-Strain Viscoelastic Materials: https://solidmechanics.org/Text/Chapter3_6/Chapter3_6.php
  Public textbook reference; no figures reproduced.
- TA Instruments RH111 — Linear Viscoelastic Region in Creep and Stress Relaxation: https://www.tainstruments.com/applications-notes/determining-the-linear-viscoelastic-region-in-creep-and-stress-relaxation-tests/
  Instrument application note; reference only.
- Chaudhuri et al. — Hydrogels with tunable stress relaxation regulate stem cell fate and activity: https://backoffice.biblio.ugent.be/download/8692536/8692544
  Public author manuscript; technical reference, no figures/data reproduced.
- Righi and Balbi — Foundations of viscoelasticity and application to soft tissues mechanics: https://arxiv.org/abs/2108.08078
  Open preprint; reference only, no figures reproduced.
