"""Constructed two-channel cell images: background, spillover and denominators."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,FancyArrowPatch,Rectangle

def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def main(output,language):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    from matplotlib import font_manager
    fonts={f.name for f in font_manager.fontManager.ttflist};font=next((f for f in ['Microsoft YaHei','Noto Sans CJK SC','SimHei'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[font,'DejaVu Sans'] if language=='zh' else ['DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','axes.prop_cycle':plt.cycler(color=['#186e83','#cd803f','#8160a1','#3c8a6a'])})
    tr=lambda z,e:z if language=='zh' else _label(e)
    def save(fig,name):fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    rng=np.random.default_rng(303);classes=np.repeat(np.arange(4),[84,24,6,6]);rng.shuffle(classes)
    xy=np.array([(18+25*x,18+25*y) for y in range(10) for x in range(12)],float)+rng.uniform(-3,3,(120,2))
    green=np.choose(classes,[100,5,70,5])+rng.normal(0,4,120);red=np.choose(classes,[5,100,70,5])+rng.normal(0,3,120);alpha=.15;bg=np.array([25.,20.]);gobs=green+bg[0];robs=red+alpha*green+bg[1]
    gc=gobs-bg[0];rc=robs-bg[1]-alpha*gc;threshold=40.;gp=gc>=threshold;rp=rc>=threshold
    counts=np.array([np.sum(gp&~rp),np.sum(~gp&rp),np.sum(gp&rp),np.sum(~gp&~rp)]);assert list(counts)==[84,24,6,6]
    yy,xx=np.mgrid[:270,:320];G=np.full(xx.shape,bg[0]);R=np.full(xx.shape,bg[1]);labels=np.zeros(xx.shape,int)
    for i,((x,y),g,r) in enumerate(zip(xy,green,red)):
        kernel=np.exp(-((xx-x)**2+(yy-y)**2)/(2*4**2));G+=g*kernel;R+=(r+alpha*g)*kernel;labels[(xx-x)**2+(yy-y)**2<=2**2]=i+1
    G+=rng.normal(0,1.2,G.shape);R+=rng.normal(0,1.2,R.shape)
    np.savez_compressed(output/'constructed_channels.npz',green_raw=G,red_raw=R,roi_labels=labels,pixel_um=1.,class_truth=classes,centers_xy=xy)
    gobs=np.array([G[labels==i+1].mean() for i in range(120)]);robs=np.array([R[labels==i+1].mean() for i in range(120)])
    gc=gobs-bg[0];rc=robs-bg[1]-alpha*gc;gp=gc>=threshold;rp=rc>=threshold
    counts=np.array([np.sum(gp&~rp),np.sum(~gp&rp),np.sum(gp&rp),np.sum(~gp&~rp)]);assert list(counts)==[84,24,6,6]
    np.savetxt(output/'cell_signals.csv',np.column_stack([np.arange(1,121),classes,gobs,robs,gc,rc]),delimiter=',',header='id,constructed_class,green_observed_au,red_observed_au,green_corrected_au,red_unmixed_au',comments='')
    fig,ax=plt.subplots(1,2,figsize=(11.5,4.7))
    for a in ax:a.set(xlim=(0,10),ylim=(0,7));a.axis('off')
    a=ax[0];a.add_patch(Circle((6,3.5),2,facecolor='#d9eee5',edgecolor='#3c8a6a',lw=3));a.text(6,4.1,tr('胞内酯酶','Intracellular esterase'),ha='center');a.text(6,3,tr('发光产物保留','Fluorescent product retained'),ha='center',fontsize=10);a.text(1.7,4.7,tr('可进入的前体','Permeant precursor'),ha='center');a.add_patch(FancyArrowPatch((2.5,3.5),(5,3.5),arrowstyle='->',mutation_scale=18));a.set_title(tr('A  进入 → 转化 → 保留','A  Entry → conversion → retention'));a.text(5,.4,tr('1966：Rotman 与 Papermaster\n用荧光酯研究细胞膜与产物保留。','1966: Rotman and Papermaster\nconnect fluorogenic esters to membrane retention.'),ha='center',fontsize=10)
    a=ax[1];a.add_patch(Circle((6,3.5),2,facecolor='#f0e2ed',edgecolor='#8160a1',lw=3,ls='--'));a.add_patch(Circle((6,3.5),.8,facecolor='#cd803f',alpha=.6));a.text(6,3.5,tr('核酸','Nucleic acids'),ha='center');a.text(1.8,4.7,tr('膜受损后可进入','Entry after membrane damage'),ha='center',fontsize=10);a.add_patch(FancyArrowPatch((2.5,3.5),(5,3.5),arrowstyle='->',mutation_scale=18));a.set_title(tr('B  进入 → 核酸结合 → 发光','B  Entry → nucleic-acid binding → fluorescence'));a.text(5,.4,tr('现代双参数染色：\n酯酶活性与膜通透性分别提供信息。','Modern two-parameter staining:\nesterase activity and permeability provide distinct information.'),ha='center',fontsize=10);fig.tight_layout();save(fig,'mechanism')
    fig,ax=plt.subplots(2,2,figsize=(10.8,8));rgb=np.zeros((*G.shape,3));rgb[:,:,1]=np.clip((G-bg[0])/120,0,1);rgb[:,:,0]=np.clip((R-bg[1])/120,0,1);rgb[:,:,2]=rgb[:,:,0]*.65
    for a,im,title,cmap in [(ax[0,0],G,tr('A  原始绿色通道','A  Raw green channel'),'viridis'),(ax[0,1],R,tr('B  原始红色通道','B  Raw red channel'),'magma')]:
        image=a.imshow(im,cmap=cmap,vmin=0,vmax=160,origin='lower',extent=[0,320,0,270]);fig.colorbar(image,ax=a,label=tr('强度 / a.u.','Intensity / a.u.'));a.set_title(title);a.set(xlabel='x / μm',ylabel='y / μm')
    a=ax[1,0];a.imshow(rgb,origin='lower',extent=[0,320,0,270]);a.plot([240,290],[22,22],color='white',lw=3);a.text(265,32,'50 μm',color='white',ha='center',fontsize=9);a.set_title(tr('C  合并显示；紫红色帮助区分通道','C  Composite; magenta distinguishes the red channel'));a.set(xlabel='x / μm',ylabel='y / μm')
    a=ax[1,1];palette=['#3c8a6a','#cd803f','#8160a1','#7c8990'];
    for k,name in enumerate([tr('绿单阳','Green only'),tr('红单阳','Red only'),tr('双阳','Double positive'),tr('双阴','Double negative')]):a.scatter(gc[classes==k],rc[classes==k],s=23,color=palette[k],label=name)
    a.axvline(40,c='#89989d',ls='--');a.axhline(40,c='#89989d',ls='--');a.set(xlabel=tr('扣背景绿色 / a.u.','Background-corrected green / a.u.'),ylabel=tr('校正串色红色 / a.u.','Unmixed red / a.u.'),title=tr('D  每个对象保留两个信号','D  Retain both signals per object'));a.legend(fontsize=8);fig.suptitle(tr('构造的双通道教学图像；从已知对象区域提取像素均值','Constructed two-channel images; mean pixel signals extracted from known object regions'),fontsize=11);fig.tight_layout();save(fig,'channels')
    fig,ax=plt.subplots(2,2,figsize=(11.4,7.5));names=[tr('绿单阳','Green only'),tr('红单阳','Red only'),tr('双阳','Double +'),tr('双阴','Double −')];ax[0,0].bar(names,counts,color=palette);ax[0,0].set(ylabel=tr('对象数','Object count'),title=tr('A  保留四类与共同分母 120','A  Preserve four classes and denominator 120'))
    thresholds=np.linspace(20,115,96);single=[np.sum((gc>=q)&~rp)/120*100 for q in thresholds];ax[0,1].plot(thresholds,single);ax[0,1].axvline(40,c='#cd803f',ls='--');ax[0,1].set(xlabel=tr('绿色阈值 / a.u.','Green threshold / a.u.'),ylabel=tr('绿单阳占全部对象 / %','Green-only fraction of all objects / %'),title=tr('B  阈值敏感性保留分母','B  Threshold sensitivity with fixed denominator'))
    z=np.linspace(0,400,201);ax[1,0].plot(z,100*np.exp(-.006*z),label=tr('绿色 μ=0.006 μm⁻¹','Green μ=0.006 μm⁻¹'));ax[1,0].plot(z,100*np.exp(-.003*z),label=tr('红色 μ=0.003 μm⁻¹','Red μ=0.003 μm⁻¹'));ax[1,0].set(xlabel=tr('深度 / μm','Depth / μm'),ylabel=tr('保留强度 / %','Retained intensity / %'),title=tr('C  构造的深度衰减','C  Constructed depth attenuation'));ax[1,0].legend(fontsize=8)
    ax[1,1].bar([tr('100 个 × 100','100 cells × 100'),tr('100 个 × 50','100 cells × 50'),tr('50 个 × 100','50 cells × 100')],[10000,5000,5000],color=['#186e83','#cd803f','#8160a1']);ax[1,1].set(ylabel=tr('总荧光 / a.u.','Total fluorescence / a.u.'),title=tr('D  一样的总强度有不同原因','D  Equal total intensity can have different causes'));fig.tight_layout();save(fig,'diagnostics')
    fig,ax=plt.subplots(figsize=(9.2,10.5));ax.imshow(plt.imread(Path(__file__).with_name('sazonova2022-figure2.jpg')));ax.axis('off');ax.set_title(tr('真实实验：信号降低可以包含增殖停滞与细胞死亡','Measured example: reduced signal can combine growth arrest and death'),fontsize=12);fig.text(.5,.03,tr('Sazonova 等，2022，图 2，CC BY 4.0。完整原图；a、c 为 N=5，b 为 N=6，均值±标准差。','Sazonova et al., 2022, Fig. 2, CC BY 4.0. Complete original; a,c N=5; b N=6; mean ± SD.'),ha='center',fontsize=9);save(fig,'published')
    summary={'classification':{'green_only':84,'red_only':24,'double_positive':6,'double_negative':6,'total':120,'green_only_all_percent':70.,'red_positive_all_percent':25.,'resolved_viability_percent':84/108*100},'background':{'corrected_sum_example':12000-100*20},'spillover':{'green':100.,'red_true':5.,'red_measured_at_04':45.,'red_unmixed_at_04':5.},'depth':{'green_200_fraction':float(np.exp(-1.2)),'red_200_fraction':float(np.exp(-.6))},'pooling':{'pooled_percent':85/110*100,'equal_field_average_percent':65.},'sampling':{'ideal_se_fraction':float(np.sqrt(.7*.3/120))}}
    assert sum(counts)==120 and abs(rc+alpha*gc+bg[1]-robs).max()<1e-10 and 84/120==.7
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();main(a.output,a.language)
