# Public sources and third-party materials

- Rotman and Papermaster (1966): Membrane properties of living mammalian cells as studied by enzymatic hydrolysis of fluorogenic esters: https://doi.org/10.1073/pnas.55.1.134
  Technical/historical reference; no source image or text reproduced.
- Thermo Fisher: Molecular Probes Handbook, Section 15.3: https://www.thermofisher.com/us/en/home/references/molecular-probes-the-handbook/assays-for-cell-viability-proliferation-and-function/viability-and-cytotoxicity-assay-kits-for-diverse-cell-types.html
  Technical/historical reference; no source image or text reproduced.
- Thermo Fisher: LIVE/DEAD Viability/Cytotoxicity Kit for mammalian cells protocol: https://www.thermofisher.com/us/en/home/references/protocols/cell-and-tissue-analysis/protocols/live-dead-viability-cytotoxicity-kit-for-mammalian-cells.html
  Technical/historical reference; no source image or text reproduced.
- ImageJ: Principles of Scientific Imaging: https://imagej.net/imaging/principles
  Technical/historical reference; no source image or text reproduced.
- Sazonova et al. (2022): Drug toxicity assessment: cell proliferation versus cell death: https://pmc.ncbi.nlm.nih.gov/articles/PMC9568594/
  CC BY 4.0; Figure 2 reproduced intact with attribution and added outer teaching title.
