"""CD measurement and interpretation using explicit teaching models.
Run: python main.py --output results --language en
All spectra are constructed; the basis curves are not a protein reference library.
"""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import minimize,curve_fit
from scipy.special import expit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle

p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();out=a.output;out.mkdir(parents=True,exist_ok=True)
zh=a.language=='zh'
def tr(z,e):return z if zh else e
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','text.color':'#263d49','axes.labelcolor':'#263d49','axes.edgecolor':'#9bacb1','svg.fonttype':'path'})
cols=['#078579','#265f85','#d6604d'];gray='#84969b';gold='#bb9033'
def save(f,n):
 f.savefig(out/f'{n}-{a.language}.svg',bbox_inches='tight');f.savefig(out/f'{n}-{a.language}.png',dpi=155,bbox_inches='tight');plt.close(f)
def title(ax,l,z,e):ax.set_title(l+'  '+tr(z,e),loc='left',weight='bold',pad=14)

# Polarization components are schematic field amplitudes, not beam trajectories.
fig,axs=plt.subplots(1,3,figsize=(12.4,4.1))
u=np.linspace(0,2*np.pi,300)
for ax,k,heading in zip(axs[:2],[1,.65],[('等幅分量 → 直线','Equal components → line'),('不等幅分量 → 椭圆','Unequal components → ellipse')]):
 x=np.cos(u)+k*np.cos(u);y=np.sin(u)-k*np.sin(u)
 ax.plot(np.cos(u),np.sin(u),color=cols[1],alpha=.4,ls='--');ax.plot(k*np.cos(u),-k*np.sin(u),color=cols[2],alpha=.4,ls='--');ax.plot(x,y,color=cols[0],lw=3)
 ax.annotate('',xy=(np.cos(.8),np.sin(.8)),xytext=(np.cos(.55),np.sin(.55)),arrowprops={'arrowstyle':'->','color':cols[1]})
 ax.annotate('',xy=(k*np.cos(.8),-k*np.sin(.8)),xytext=(k*np.cos(.55),-k*np.sin(.55)),arrowprops={'arrowstyle':'->','color':cols[2]})
 ax.set_aspect('equal');ax.set(xlim=(-2.2,2.2),ylim=(-1.4,1.4),xlabel=tr('电场分量 x（相对）','Field x (relative)'),ylabel=tr('电场分量 y（相对）','Field y (relative)'));title(ax,'A' if k==1 else 'B',*heading)
ax=axs[2];ax.axis('off');ax.set_xlim(0,5);ax.set_ylim(0,5)
for y,z,e in [(4,'选定波长与线偏振','Selected wavelength / linear polarization'),(2.8,'调制两种旋向','Modulate opposite handedness'),(1.6,'样品产生吸收差','Specimen absorbs differently'),(.4,'同步读取光电信号','Read synchronized detector signal')]:
 ax.add_patch(Rectangle((.3,y-.28),4.3,.6,fc='#e8efed',ec=gray));ax.text(2.45,y+.02,tr(z,e),ha='center',va='center',fontsize=9)
 if y>.4:ax.annotate('',xy=(2.45,y-.88),xytext=(2.45,y-.3),arrowprops={'arrowstyle':'-|>','color':cols[1]})
title(ax,'C','光电比较','Detect the difference')
fig.text(.5,.01,tr('Cotton 的吸收差与椭圆率联系，延续到光电测量。示意图不复原某台历史仪器。','Cotton linked differential absorption to ellipticity; photoelectric methods measure the difference. Conceptual apparatus, not a historical reconstruction.'),ha='center',fontsize=9)
fig.tight_layout(rect=[0,.08,1,1]);save(fig,'polarization')

# Basis units are mean residue ellipticity, deg cm^2 dmol^-1.
w=np.arange(190.,251.)
def g(mu,sd):return np.exp(-.5*((w-mu)/sd)**2)
basis=1000*np.column_stack([35*g(193,5)-23*g(208,5)-20*g(222,6),22*g(195,6)-17*g(218,8),-30*g(198,6)+3*g(220,9)])
truth=np.array([.55,.25,.20]);mre=basis@truth
concentration=.20;path=.10;mrw=110.;factor=10*concentration*path/mrw
background=.8+.01*(w-220);rng=np.random.default_rng(550)
scans=mre[:,None]*factor+background[:,None]+rng.normal(0,.25,(len(w),5))
blanks=background[:,None]+rng.normal(0,.08,(len(w),8))
corrected=scans.mean(axis=1)-blanks.mean(axis=1);normalized=corrected/factor
def fractions(y,mask=None):
 if mask is None:mask=np.ones(len(w),bool)
 X=basis[mask]/1000;target=y[mask]/1000
 r=minimize(lambda f:np.mean((X@f-target)**2),[.4,.3,.3],method='SLSQP',bounds=[(0,1)]*3,constraints=[{'type':'eq','fun':lambda f:f.sum()-1}],options={'ftol':1e-12,'maxiter':300})
 if not r.success:raise RuntimeError(r.message)
 return r.x
fit=fractions(normalized);fitted=basis@fit
fig,axs=plt.subplots(2,2,figsize=(11.6,7.6))
axs[0,0].plot(w,scans,lw=.8,alpha=.55,color=cols[1]);axs[0,0].plot(w,scans.mean(axis=1),lw=2,color=cols[1]);axs[0,0].set_ylabel(tr('原始椭圆率 / mdeg','Raw ellipticity / mdeg'));title(axs[0,0],'A','五次样品扫描','Five specimen scans')
axs[0,1].plot(w,blanks,lw=.8,alpha=.4,color=gray);axs[0,1].plot(w,blanks.mean(axis=1),color=gray,lw=2);axs[0,1].set_ylabel(tr('空白椭圆率 / mdeg','Blank ellipticity / mdeg'));title(axs[0,1],'B','匹配缓冲空白','Matched buffer blanks')
axs[1,0].plot(w,corrected,color=cols[0],lw=2);axs[1,0].set_ylabel(tr('扣空白信号 / mdeg','Blank-corrected / mdeg'));title(axs[1,0],'C','先做光学比较','Subtract before normalization')
axs[1,1].plot(w,normalized/1000,color=cols[0],lw=2,label=tr('正确浓度 0.20 mg/mL','Correct concentration 0.20 mg/mL'));axs[1,1].plot(w,normalized*.8/1000,color=cols[2],ls='--',label=tr('误用 0.25 mg/mL','Incorrectly use 0.25 mg/mL'));axs[1,1].set_ylabel(tr('平均残基椭圆率 / 10³ 单位','Mean residue ellipticity / 10³ units'));axs[1,1].legend(fontsize=8,frameon=False);title(axs[1,1],'D','归一化也会引入系统误差','Normalization can introduce bias')
for ax in axs.flat:ax.set_xlabel(tr('波长 / nm','Wavelength / nm'));ax.axhline(0,color=gray,lw=.6)
fig.tight_layout();save(fig,'measurement')

boot=np.array([fractions(mre+rng.normal(0,.25/np.sqrt(5)/factor,len(w))) for _ in range(160)])
cuts=[190,205,220];cutfit=np.array([fractions(normalized,w>=v) for v in cuts]);cutboot=np.array([[fractions(mre+rng.normal(0,.25/np.sqrt(5)/factor,len(w)),w>=v) for _ in range(160)] for v in cuts]);cutSD=np.std(cutboot,axis=1,ddof=1);scales=np.array([.8,1.,1.2]);scalefit=np.array([fractions(normalized/v) for v in scales])
fig,axs=plt.subplots(2,2,figsize=(11.6,7.8));names=[tr('螺旋','Helix'),tr('折叠','Sheet'),tr('其他','Other')]
for k in range(3):axs[0,0].plot(w,basis[:,k]/1000,color=cols[k],label=names[k])
axs[0,0].legend(frameon=False,fontsize=9);axs[0,0].set(xlabel=tr('波长 / nm','Wavelength / nm'),ylabel=tr('平均残基椭圆率 / 10³ 单位','Mean residue ellipticity / 10³ units'));title(axs[0,0],'A','构造参考，解释组合','Constructed references explain mixing')
axs[0,1].plot(w,normalized/1000,'o',ms=3,color=gray,label=tr('测量模型','Measurement model'));axs[0,1].plot(w,fitted/1000,color=cols[0],lw=2,label=tr('约束组合','Constrained mixture'));axs[0,1].plot(w,(normalized-fitted)/1000,color=cols[2],label=tr('残差','Residual'));axs[0,1].legend(frameon=False,fontsize=9);axs[0,1].set(xlabel=tr('波长 / nm','Wavelength / nm'),ylabel=tr('平均残基椭圆率 / 10³ 单位','Mean residue ellipticity / 10³ units'));title(axs[0,1],'B','拟合之外还看残差','Inspect residuals as well as fit')
for k in range(3):
 axs[1,0].errorbar(cuts,cutfit[:,k],yerr=2*cutSD[:,k],fmt='-o',capsize=4,color=cols[k],label=names[k]);axs[1,0].axhline(truth[k],color=cols[k],ls=':',alpha=.4)
 axs[1,1].plot(scales,scalefit[:,k],'-o',color=cols[k],label=names[k]);axs[1,1].axhline(truth[k],color=cols[k],ls=':',alpha=.4)
axs[1,0].set(xlabel=tr('最低使用波长 / nm','Lowest fitted wavelength / nm'),ylabel=tr('拟合比例','Fitted fraction'),ylim=(0,.75));axs[1,0].legend(frameon=False,fontsize=9);title(axs[1,0],'C','波段改变可用信息','Wavelength coverage changes information')
axs[1,1].set(xlabel=tr('采用浓度 / 实际浓度','Assumed / actual concentration'),ylabel=tr('拟合比例','Fitted fraction'),ylim=(0,1));axs[1,1].legend(frameon=False,fontsize=9);title(axs[1,1],'D','浓度误差传到结构解释','Concentration error reaches interpretation')
fig.tight_layout();save(fig,'mixture')

T=np.linspace(20,90,71)
def thermal(temp,f0,fs,u0,us,mid,width):
 unfolded=expit((temp-mid)/width);return (f0+fs*(temp-20))*(1-unfolded)+(u0+us*(temp-20))*unfolded
thermal_true=[-25,.02,-3,.01,60,4]
heating=thermal(T,*thermal_true)+rng.normal(0,.12,len(T))
params,cov=curve_fit(thermal,T,heating,p0=thermal_true,bounds=([-50,-.5,-20,-.5,35,.5],[0,.5,20,.5,80,15]),maxfev=15000)
cooling=thermal(T,-25,.02,-3,.01,57,4)
frac=expit((T-params[4])/params[5]);baselineF=params[0]+params[1]*(T-20);baselineU=params[2]+params[3]*(T-20)
fig,axs=plt.subplots(1,2,figsize=(11.6,4.8));axs[0].scatter(T,heating,s=15,color=cols[1],alpha=.6,label=tr('构造升温读数','Constructed heating readings'));axs[0].plot(T,thermal(T,*params),color=cols[1],label=tr('升温拟合','Heating fit'));axs[0].plot(T,cooling,color=cols[2],ls='--',label=tr('示意冷却路径','Illustrative cooling path'));axs[0].plot(T,baselineF,color=gray,ls=':',lw=1);axs[0].plot(T,baselineU,color=gray,ls=':',lw=1);axs[0].set(xlabel=tr('温度 / °C','Temperature / °C'),ylabel=tr('222 nm 椭圆率 / mdeg','222 nm ellipticity / mdeg'));axs[0].legend(frameon=False,fontsize=9);title(axs[0],'A','同一信号，不同温度路径','One signal, different temperature paths')
axs[1].plot(T,frac,color=cols[0],lw=3);axs[1].axhline(.5,color=gray,ls='--');axs[1].axvline(params[4],color=gray,ls='--');axs[1].text(params[4]+2,.2,tr(f'中点 {params[4]:.2f} °C',f'Midpoint {params[4]:.2f} °C'),fontsize=10);axs[1].set(xlabel=tr('温度 / °C','Temperature / °C'),ylabel=tr('基线修正后的模型展开比例','Baseline-corrected model unfolded fraction'),ylim=(-.03,1.03));title(axs[1],'B','在同温度基线之间定位','Locate between same-temperature baselines')
fig.tight_layout();save(fig,'thermal')
np.savetxt(out/'spectra.csv',np.column_stack([w,scans,blanks.mean(axis=1),corrected,normalized,fitted]),delimiter=',',header='wavelength_nm,scan1_mdeg,scan2_mdeg,scan3_mdeg,scan4_mdeg,scan5_mdeg,blank_mean_mdeg,corrected_mdeg,mean_residue_ellipticity,fitted_mean_residue_ellipticity',comments='')
np.savetxt(out/'basis.csv',np.column_stack([w,basis]),delimiter=',',header='wavelength_nm,constructed_helix,constructed_sheet,constructed_other',comments='')
np.savetxt(out/'thermal.csv',np.column_stack([T,heating,thermal(T,*params),cooling,frac]),delimiter=',',header='temperature_C,heating_mdeg,fitted_mdeg,cooling_model_mdeg,model_unfolded_fraction',comments='')
np.savetxt(out/'fraction_resampling.csv',boot,delimiter=',',header='helix,sheet,other',comments='')
summary={'delta_absorbance_example':.5003-.4997,'ellipticity_example_mdeg':32980*.0006,'normalization_example':-20*110/(10*.20*.10),'fraction_helix':float(fit[0]),'fraction_sheet':float(fit[1]),'fraction_other':float(fit[2]),'fraction_sum':float(fit.sum()),'thermal_midpoint_C':float(params[4]),'thermal_width_C':float(params[5]),'midpoint_fraction':.5,'fraction_noise_interval':np.quantile(boot,[.025,.975],axis=0).tolist(),'data_kind':'constructed teaching spectra and thermal signals; no measured protein reference library'}
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
