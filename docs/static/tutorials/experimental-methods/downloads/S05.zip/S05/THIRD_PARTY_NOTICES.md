# Public sources and third-party materials

- Greenfield: Using circular dichroism spectra to estimate protein secondary structure: https://pmc.ncbi.nlm.nih.gov/articles/PMC2728378/
  Public author manuscript; technical reference, no figures copied.
- JASCO: Circular Dichroism Spectroscopy: https://jascoinc.com/learning-center/theory/spectroscopy/circular-dichroism-spectroscopy/
  Technical reference; original diagrams.
- JASCO: Circular Dichroism Tips & Tricks: https://jascoinc.com/learning-center/best-practices/circular-dichroism-tips-tricks/
  Technical reference; device-specific voltage thresholds not generalized.
- Harvard CMI: Circular Dichroism: https://cmi.hms.harvard.edu/circular-dichroism
  Technical reference; images not reused.
- Mitchell: A Photo-electric Method for Measuring Circular Dichroism: https://www.nature.com/articles/166434b0
  Primary historical abstract consulted; no original figures reproduced.
