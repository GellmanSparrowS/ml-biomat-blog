"""UV-visible calibration with a declared teaching dataset and optical models.

Run: python main.py --output output --language en
Concentrations are in micromoles per liter unless explicitly stated otherwise.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon, Circle, FancyArrowPatch

BLUE,TEAL,ORANGE,INK='#245ca6','#087f80','#ce6b35','#233446'


def measured_absorbance(true_absorbance,stray_fraction):
    """Equal unattenuated stray intensity enters sample and blank readings."""
    return -np.log10((10.**(-np.asarray(true_absorbance))+stray_fraction)/(1+stray_fraction))


def main(output,language):
    output.mkdir(parents=True,exist_ok=True);zh=language=='zh';tr=lambda a,b:a if zh else b
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','Noto Sans CJK SC','DejaVu Sans'],
        'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none',
        'axes.unicode_minus':False,'figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6',
        'savefig.facecolor':'#fbfaf6','text.color':INK,'axes.labelcolor':INK})
    def save(fig,name):
        for ext in ['svg','png']:fig.savefig(output/f'{name}-{language}.{ext}',bbox_inches='tight',dpi=140)
        plt.close(fig)
    def arrow(ax,start,end,color=BLUE,lw=2):
        ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=13,lw=lw,color=color))

    # Original historical-principle illustration, without copied apparatus art.
    fig,axes=plt.subplots(2,1,figsize=(11.8,6.8),layout='constrained')
    ax=axes[0];ax.axis('off');ax.set(xlim=(0,11),ylim=(0,3.2))
    ax.set_title(tr('石英让光路进入紫外：1941 年 DU 仪器的一个关键选择','Quartz opens the ultraviolet: a key choice in the 1941 DU instrument'),loc='left')
    ax.add_patch(Circle((.8,1.6),.22,color='#dfae56'));arrow(ax,(1.1,1.6),(2.5,1.6),INK)
    ax.add_patch(Polygon([[2.6,1.1],[3.3,1.1],[2.95,2.35]],closed=True,facecolor='#d9e8ec',edgecolor=INK))
    for y,color in [(1.2,ORANGE),(1.7,TEAL),(2.2,'#7850a2')]:arrow(ax,(3.1,1.65),(4.65,y),color)
    ax.plot([4.8,4.8],[.8,1.55],color=INK,lw=4);ax.plot([4.8,4.8],[1.85,2.6],color=INK,lw=4)
    arrow(ax,(4.95,1.7),(6.2,1.7),TEAL)
    ax.add_patch(Rectangle((6.3,1.1),.8,1.2,facecolor='#b9d7ce',edgecolor=INK))
    arrow(ax,(7.2,1.7),(8.7,1.7),TEAL,lw=1)
    ax.add_patch(Rectangle((8.8,1.25),.7,.9,facecolor='#e1e8ed',edgecolor=INK))
    for x,label in [( .8,tr('光源','Source')),(2.95,tr('分光','Disperse')),(4.8,tr('狭缝选色','Select band')),(6.7,tr('样品','Sample')),(9.15,tr('光电检测','Photoelectric detector'))]:ax.text(x,.5,label,ha='center',fontsize=10)
    ax.text(6.1,2.75,tr('功能示意；不按历史装置尺寸绘制','Functional illustration, not a scale drawing of the historical device'),fontsize=9,ha='center')
    ax=axes[1];ax.axis('off');ax.set(xlim=(0,11),ylim=(0,2.7));ax.set_title(tr('相同光路长度，比较空白与样品','Compare blank and specimen at the same path length'),loc='left')
    for y,label,color,width in [(1.9,tr('空白','Blank'),'#eef2f3',2.8),(.7,tr('样品','Sample'),'#a9cebf',1.3)]:
        arrow(ax,(1,y),(4.1,y),BLUE)
        ax.add_patch(Rectangle((4.2,y-.36),1.4,.72,facecolor=color,edgecolor=INK));ax.text(4.9,y,label,ha='center',va='center')
        arrow(ax,(5.7,y),(8.5,y),TEAL,lw=width)
        ax.add_patch(Rectangle((8.6,y-.3),.55,.6,facecolor='#e1e8ed',edgecolor=INK))
    ax.text(2.5,2.4,tr('相同入射条件','Same illumination'),ha='center')
    ax.text(7.1,2.4,tr('比较透过光强','Compare transmitted light'),ha='center')
    ax.text(4.9,.08,tr('光程 l','Path length l'),ha='center')
    save(fig,'optics')

    fig,axes=plt.subplots(1,2,figsize=(11.8,4.8),layout='constrained')
    ax=axes[0];ax.axis('off');ax.set(xlim=(-.4,5),ylim=(0,3.6));ax.set_title(tr('A · 相同薄层让透过比例相乘','A · Equal layers multiply transmission'),loc='left')
    for i in range(3):
        ax.add_patch(Rectangle((i*1.3+.7,.8),.4,1.7,facecolor=TEAL,alpha=.35,edgecolor=TEAL))
        ax.text(i*1.3+.9,.45,tr('一层','One layer'),ha='center')
    for i,count in enumerate([1000,500,250,125]):
        x=i*1.3+.2;arrow(ax,(x-.35,1.65),(x+.35,1.65),BLUE,lw=max(.8,count/260))
        ax.text(x,2.8,str(count),ha='center',color=BLUE)
    ax.text(2,3.25,tr('光子数比例示意','Illustrative photon-count ratios'),ha='center',fontsize=10)
    ax.text(2,.05,tr('0.5 × 0.5 × 0.5 = 0.125','0.5 × 0.5 × 0.5 = 0.125'),ha='center')
    ax=axes[1];layers=np.arange(0,7);a=-np.log10(.5)*layers
    ax.plot(layers,a,'o-',color=TEAL,label=tr('吸光度相加','Absorbances add'))
    ax.set(xlabel=tr('相同薄层数','Number of identical layers'),ylabel=tr('吸光度','Absorbance'),title=tr('B · 对数把连乘变成相加','B · Logarithms turn products into sums'))
    for n in [1,2,3]:ax.annotate(f'T={.5**n:g}',(n,a[n]),xytext=(8,-20),textcoords='offset points',fontsize=9)
    ax.legend();save(fig,'layers')

    rng=np.random.default_rng(530)
    levels=np.array([0,2,4,8,12,16.]);c=np.repeat(levels,3)
    a=.02+.05*c+rng.normal(0,.006,len(c))
    m,b=np.polyfit(c,a,1);residual=a-(m*c+b)
    sigma=float(np.sqrt(np.sum(residual**2)/(len(c)-2)))
    unknown=.02+.05*7.4+rng.normal(0,.006,3);dilution=5
    estimate=float(dilution*(unknown.mean()-b)/m)
    samples=[]
    for _ in range(3000):
        ym=m*c+b+rng.normal(0,sigma,len(c));mm,bb=np.polyfit(c,ym,1)
        yu=unknown.mean()+rng.normal(0,sigma,3).mean();samples.append(dilution*(yu-bb)/mm)
    samples=np.asarray(samples);lo,hi=np.quantile(samples,[.025,.975])
    np.savetxt(output/'calibration.csv',np.column_stack([c,a,m*c+b,residual]),delimiter=',',
       header='concentration_umol_L,absorbance,fitted_absorbance,residual',comments='')
    np.savetxt(output/'unknown.csv',unknown,delimiter=',',header='absorbance',comments='')
    np.savetxt(output/'propagated_concentration.csv',samples,delimiter=',',header='original_concentration_umol_L',comments='')
    fig,axes=plt.subplots(2,2,figsize=(12,7.8),layout='constrained')
    grid=np.linspace(0,16,200)
    axes[0,0].scatter(c,a,s=30,color=BLUE,label=tr('标准读数','Standard readings'))
    axes[0,0].plot(grid,m*grid+b,color=TEAL,label=tr('带截距拟合','Fit with intercept'))
    axes[0,0].scatter([(unknown.mean()-b)/m],[unknown.mean()],marker='D',s=60,color=ORANGE,label=tr('未知液','Unknown'))
    axes[0,0].set(title=tr('A · 标准与未知在同一量尺上','A · Standards and unknown on one scale'),xlabel=tr('浓度 / μmol L$^{-1}$','Concentration / μmol L$^{-1}$'),ylabel=tr('吸光度','Absorbance'));axes[0,0].legend(fontsize=9)
    axes[0,1].scatter(c,residual,color=BLUE);axes[0,1].axhline(0,color=INK,lw=1)
    axes[0,1].set(title=tr('B · 残差检查线性关系','B · Residuals check the linear relationship'),xlabel=tr('浓度 / μmol L$^{-1}$','Concentration / μmol L$^{-1}$'),ylabel=tr('测量 − 拟合','Observed − fitted'))
    axes[1,0].hist(samples,bins=42,color=TEAL,alpha=.8,density=True)
    axes[1,0].axvline(37,color=INK,ls='--',label=tr('设定值 37','Prescribed 37'))
    axes[1,0].axvline(estimate,color=ORANGE,label=f'{estimate:.2f}')
    axes[1,0].set(title=tr('C · 读数误差传播到原液浓度','C · Reading error propagates to stock concentration'),xlabel=tr('原液浓度 / μmol L$^{-1}$','Stock concentration / μmol L$^{-1}$'),ylabel=tr('概率密度 / (μmol L$^{-1}$)$^{-1}$','Density / (μmol L$^{-1}$)$^{-1}$'));axes[1,0].legend(fontsize=9)
    ax=axes[1,1];ax.axis('off');ax.set_title(tr('D · 逐步反算，保留单位','D · Back-calculate while retaining units'),loc='left')
    lines=[tr('未知液平均吸光度','Mean unknown absorbance')+f'  {unknown.mean():.4f}',
       tr('斜率','Slope')+f'  {m:.5f}  A / (μmol/L)',tr('截距','Intercept')+f'  {b:.5f}',
       tr('稀释液浓度','Diluted concentration')+f'  {estimate/5:.3f} μmol/L',
       tr('乘稀释倍数 5','Multiply dilution factor 5'),tr('原液浓度','Stock concentration')+f'  {estimate:.3f} μmol/L',
       tr('模型中 95% 分位区间','Model 95% quantile interval')+f'  [{lo:.2f}, {hi:.2f}]']
    for i,line in enumerate(lines):ax.text(.04,.9-i*.13,line,fontsize=10,transform=ax.transAxes)
    save(fig,'calibration')

    wave=np.linspace(350,750,801);absorption=.7*np.exp(-.5*((wave-530)/32)**2);scatter=.15*(530/wave)**4
    np.savetxt(output/'spectrum.csv',np.column_stack([wave,absorption,scatter,absorption+scatter]),delimiter=',',
       header='wavelength_nm,constructed_absorption,constructed_scattering_loss,total_apparent_absorbance',comments='')
    fig,axes=plt.subplots(1,2,figsize=(11.8,4.8),layout='constrained');true=np.linspace(0,5,301)
    axes[0].plot(true,true,color=INK,ls='--',label=tr('理想响应','Ideal response'))
    for s,col in [(.0001,BLUE),(.001,TEAL),(.01,ORANGE)]:axes[0].plot(true,measured_absorbance(true,s),color=col,label=f's = {s:g}')
    axes[0].set(xlabel=tr('真实吸光度','True absorbance'),ylabel=tr('测得吸光度','Measured absorbance'),title=tr('A · 杂散光使高吸收响应弯曲','A · Stray light bends high-absorbance response'));axes[0].legend(fontsize=9)
    axes[1].plot(wave,absorption,color=TEAL,label=tr('构造吸收峰','Constructed absorption'))
    axes[1].plot(wave,scatter,color=ORANGE,label=tr('构造散射背景','Constructed scattering loss'))
    axes[1].plot(wave,absorption+scatter,color=BLUE,label=tr('总表观响应','Total apparent response'))
    axes[1].set(xlabel=tr('波长 / nm','Wavelength / nm'),ylabel=tr('表观吸光度','Apparent absorbance'),title=tr('B · 全谱帮助发现不同贡献','B · Full spectra expose different contributions'));axes[1].legend(fontsize=9)
    save(fig,'diagnostics')
    summary={'data_kind':'constructed teaching calibration and optical models','seed':530,
       'absorbance_T05':float(-np.log10(.5)),'transmission_A05':float(10**(-.5)),
       'slope':float(m),'intercept':float(b),'unknown_diluted_estimate':estimate/5,
       'unknown_stock_estimate':estimate,'stock_true':37.,'reading_sigma':sigma,
       'stock_interval_reading_model':[float(lo),float(hi)],
       'stray_001_at_true3':float(measured_absorbance(3,.001)),
       'stray_001_plateau':float(np.log10(1001))}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args()
    main(args.output,args.language)
