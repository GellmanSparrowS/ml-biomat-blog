# Public sources and third-party materials

- Raja and Barron: UV-Visible Spectroscopy: https://chem.libretexts.org/Bookshelves/Analytical_Chemistry/Physical_Methods_in_Chemistry_and_Nano_Science_(Barron)/04%3A_Chemical_Speciation/4.04%3A_UV-Visible_Spectroscopy
  CC BY 4.0 page; open further reading.
- Agilent: Understanding Your UV-visible Spectroscopy System: https://www.agilent.com/Library/usermanuals/Public/G1115-90041_UnderstandingGP.pdf
  Technical reference; original diagrams and code.
- Shimadzu: What is stray light?: https://www.ssi.shimadzu.com/service-support/faq/uv-vis/resolution-and-stray-light/3/index.html
  Technical reference.
- Smithsonian: Beckman DU Spectrophotometer: https://americanhistory.si.edu/collections/object/nmah_378
  Technical reference; collection image not reproduced.
- Beckman Foundation: Spectrophotometer: https://www.beckman-foundation.org/about-foundation/inventions/spectrophotometer/
  Technical reference.
