"""Real BMRB peak records and separate NMR time-domain teaching models.
python main.py --output results --language en
Data: BMRB bmse000297, DOI 10.13018/BMSE000297, public-domain archive.
The generated FIDs are simulations; they are not the deposited raw experiment.
"""
from pathlib import Path
import argparse,json,re,shlex
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Ellipse

p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();out=a.output;out.mkdir(parents=True,exist_ok=True);zh=a.language=='zh'
def tr(z,e):return z if zh else e
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','text.color':'#263d49','axes.labelcolor':'#263d49','axes.edgecolor':'#9bacb1','svg.fonttype':'path'})
blue,teal,coral,gold,gray='#265f85','#078579','#d6604d','#bb9033','#84969b'
def save(f,n):
 for item in f.findobj(matplotlib.text.Text):
  value=item.get_text()
  for old,new in [('₂',r'$_2$'),('₃',r'$_3$'),('₁',r'$_1$'),('⁻¹',r'$^{-1}$')]:value=value.replace(old,new)
  item.set_text(value)
 f.savefig(out/f'{n}-{a.language}.svg',bbox_inches='tight');f.savefig(out/f'{n}-{a.language}.png',dpi=155,bbox_inches='tight');plt.close(f)
def title(ax,l,z,e):ax.set_title(l+'  '+tr(z,e),loc='left',weight='bold',pad=14)

text=(Path(__file__).parent/'data'/'bmse000297.str').read_text(encoding='utf8')
frame=text.split('save_spectral_peak_1H',1)[1].split('\nsave_',1)[0]
def table(category):
 for content in re.findall(r'loop_\s*(.*?)\s*stop_',frame,re.S):
  tokens=shlex.split(content);n=0
  while n<len(tokens) and tokens[n].startswith('_'):n+=1
  columns=tokens[:n]
  if columns and columns[0].startswith(category+'.'):
   assert (len(tokens)-n)%n==0
   return [dict(zip(columns,tokens[i:i+n])) for i in range(n,len(tokens),n)]
 raise ValueError(category)
pos={r['_Spectral_transition_char.Spectral_transition_ID']:float(r['_Spectral_transition_char.Chem_shift_val']) for r in table('_Spectral_transition_char')}
height={r['_Spectral_transition_general_char.Spectral_transition_ID']:float(r['_Spectral_transition_general_char.Intensity_val']) for r in table('_Spectral_transition_general_char')}
areas={r['_Peak_general_char.Peak_ID']:float(r['_Peak_general_char.Intensity_val']) for r in table('_Peak_general_char')}
lines=np.array([[pos[k],height[k]] for k in pos]);actual_ratio=areas['2']/areas['1']

fig,axs=plt.subplots(1,2,figsize=(11.6,5.2));ax=axs[0];ax.set_xlim(0,10);ax.set_ylim(0,7);ax.axis('off')
ax.add_patch(Rectangle((.2,.5),1.4,5.9,fc='#dce5e8',ec=gray));ax.add_patch(Rectangle((8.4,.5),1.4,5.9,fc='#dce5e8',ec=gray));ax.text(.9,3.4,'N',ha='center',fontsize=20);ax.text(9.1,3.4,'S',ha='center',fontsize=20)
for y in [1.6,3.4,5.2]:ax.annotate('',xy=(8.1,y),xytext=(1.9,y),arrowprops={'arrowstyle':'->','color':gray,'lw':1})
ax.add_patch(Rectangle((4.65,1.2),.7,4.8,fc='#e9f4f2',ec=teal,lw=2));ax.text(5,6.3,tr('样品管','Sample tube'),ha='center',fontsize=10)
for y in np.linspace(2.4,4.7,5):ax.add_patch(Ellipse((5,y),2,.35,fill=False,ec=blue,lw=1.8))
ax.plot([6,7,7],[3.5,3.5,.6],color=blue,lw=2);ax.text(6.3,.25,tr('射频脉冲 / 感应接收','RF pulse / induction receiver'),ha='center',fontsize=9)
title(ax,'A','核感应的实验关系','Nuclear-induction experiment')
ax=axs[1];B=np.linspace(0,12,100);ax.plot(B,42.577*B,color=teal,lw=3);ax.scatter([9.4],[42.577*9.4],color=coral,s=55,zorder=3);ax.annotate('9.4 T → 400.22 MHz',(9.4,42.577*9.4),xytext=(3,460),arrowprops={'arrowstyle':'->','color':gray},fontsize=10);ax.set(xlabel=tr('磁场 / T','Magnetic field / T'),ylabel=tr('质子共振频率 / MHz','Proton resonance frequency / MHz'),xlim=(0,12),ylim=(0,540));title(ax,'B','磁场决定主要频率尺度','Field sets the principal frequency scale')
fig.text(.5,.01,tr('1946 年凝聚态核磁研究连接磁场、射频与感应信号。原创功能示意，非历史设备复原。','The 1946 condensed-matter experiments connected field, radiofrequency and induction. Original functional schematic, not a historical reconstruction.'),ha='center',fontsize=9);fig.tight_layout(rect=[0,.08,1,1]);save(fig,'induction')

fig,axs=plt.subplots(1,3,figsize=(12.2,4.5),gridspec_kw={'width_ratios':[1,1,.9]})
for ax,mask,lim,z,e in [(axs[0],lines[:,0]>2,(3.70,3.58),'CH$_2$：四条分裂线','CH$_2$: four split lines'),(axs[1],lines[:,0]<2,(1.23,1.10),'CH$_3$：三条分裂线','CH$_3$: three split lines')]:
 v=lines[mask];ax.vlines(v[:,0],0,v[:,1],color=blue if mask[0] else teal,lw=3);ax.scatter(v[:,0],v[:,1],s=22,color=blue if mask[0] else teal);ax.set(xlim=lim,ylim=(0,36),xlabel=tr('化学位移 / ppm','Chemical shift / ppm'),ylabel=tr('记录的峰高 / 原条目单位','Deposited peak height / entry units'));title(ax,'A' if ax is axs[0] else 'B',z,e)
axs[2].bar([0,1],[areas['1'],areas['2']],color=[blue,teal],width=.6);axs[2].set(xticks=[0,1],xticklabels=['CH$_2$','CH$_3$'],ylabel=tr('记录的峰组积分 / 原条目单位','Deposited group integral / entry units'),ylim=(0,220));axs[2].text(0,areas['1']+4,f"{areas['1']:.2f}",ha='center');axs[2].text(1,areas['2']+4,f"{areas['2']:.2f}",ha='center');title(axs[2],'C',f'面积比 {actual_ratio:.4f}',f'Area ratio {actual_ratio:.4f}')
fig.text(.5,.01,tr('真实峰表：BMRB bmse000297 · D$_2$O，100 mM，298 K，pH 7.4，DSS 参照。竖线不表示实测线宽。','Real peak records: BMRB bmse000297 · D$_2$O, 100 mM, 298 K, pH 7.4, DSS reference. Sticks do not specify measured linewidth.'),ha='center',fontsize=9);fig.tight_layout(rect=[0,.08,1,1]);save(fig,'ethanol')

# Construct a first-order ethanol-like FID with known areas and relaxation.
mhz=400.;carrier=2.4;j=7.1;dt=1/4000;N=8192;t=np.arange(N)*dt
freq=np.r_[((1.170-carrier)*mhz)+j*np.array([-1,0,1]),((3.641-carrier)*mhz)+j*np.array([-1.5,-.5,.5,1.5])]
amplitude=np.r_[3*np.array([1,2,1])/4,2*np.array([1,3,3,1])/8];T2=.2
fid=np.sum(amplitude[:,None]*np.exp(2j*np.pi*freq[:,None]*t[None,:])*np.exp(-t[None,:]/T2),axis=0)
rng=np.random.default_rng(560);noisy=fid+.015*(rng.normal(size=N)+1j*rng.normal(size=N))
def fft(data,lb=0):
 v=data.copy()*np.exp(-np.pi*lb*t[:len(data)]);v[0]*=.5
 f=np.fft.fftshift(np.fft.fftfreq(32768,dt));s=2*dt*np.fft.fftshift(np.fft.fft(v,n=32768)).real
 return f/mhz+carrier,s
ppm,spectrum=fft(noisy);_,broadened=fft(noisy,3);_,ideal=fft(fid)
group=lambda low,high:np.trapezoid(ideal[(ppm>=low)&(ppm<=high)],x=ppm[(ppm>=low)&(ppm<=high)]*mhz)
simratio=group(.8,1.5)/group(3.3,4.0)
fig,axs=plt.subplots(2,2,figsize=(11.6,7.7))
mask=t<.06;axs[0,0].plot(t[mask]*1000,noisy.real[mask],color=blue,lw=.9);axs[0,0].set(xlabel=tr('脉冲后时间 / ms','Time after pulse / ms'),ylabel=tr('FID 实部 / 相对单位','Real FID / relative units'));title(axs[0,0],'A','先记录时间合奏','Record the time-domain ensemble')
axs[0,1].plot(ppm,spectrum,color=teal,lw=1);axs[0,1].set(xlim=(4.1,.7),xlabel=tr('化学位移 / ppm','Chemical shift / ppm'),ylabel=tr('频谱密度 / 相对单位 Hz$^{-1}$','Spectral density / relative units Hz$^{-1}$'));title(axs[0,1],'B','傅里叶变换分开频率','Fourier transform separates frequencies')
axs[1,0].plot(ppm,spectrum,color=teal,label=tr('不加窗','Unweighted'));axs[1,0].plot(ppm,broadened,color=coral,label=tr('额外展宽 3 Hz','Additional 3 Hz broadening'));axs[1,0].set(xlim=(1.23,1.11),xlabel=tr('化学位移 / ppm','Chemical shift / ppm'),ylabel=tr('频谱密度 / 相对单位 Hz$^{-1}$','Spectral density / relative units Hz$^{-1}$'));axs[1,0].legend(frameon=False,fontsize=9);title(axs[1,0],'C','光滑与分辨率一起改变','Smoothing changes resolution')
shortN=1000;_,short=fft(fid[:shortN]);axs[1,1].plot(ppm,ideal,color=teal,label=tr('2.048 s 记录','2.048 s acquisition'));axs[1,1].plot(ppm,short,color=gold,label=tr('0.250 s 记录，同样补零','0.250 s, same zero filling'));axs[1,1].set(xlim=(1.23,1.11),xlabel=tr('化学位移 / ppm','Chemical shift / ppm'),ylabel=tr('频谱密度 / 相对单位 Hz$^{-1}$','Spectral density / relative units Hz$^{-1}$'));axs[1,1].legend(frameon=False,fontsize=9);title(axs[1,1],'D','补零没有延长观察时间','Zero filling does not extend observation')
fig.tight_layout();save(fig,'processing')

TR=np.linspace(.01,18,400);rec1=1-np.exp(-TR/1);rec3=1-np.exp(-TR/3);biased=1.5*rec1/rec3
fig,axs=plt.subplots(1,2,figsize=(11.6,4.7));axs[0].plot(TR,rec1,color=teal,label='T$_1$ = 1 s');axs[0].plot(TR,rec3,color=blue,label='T$_1$ = 3 s');axs[0].axhline(1-np.exp(-5),color=gray,ls=':',label='99.326%');axs[0].set(xlabel=tr('重复间隔 / s','Repetition interval / s'),ylabel=tr('恢复磁化 / 平衡磁化','Recovered / equilibrium magnetization'),ylim=(0,1.05));axs[0].legend(frameon=False,fontsize=9);title(axs[0],'A','不同环境恢复速度不同','Environments recover at different rates')
axs[1].plot(TR,biased,color=coral,lw=3);axs[1].axhline(1.5,color=gray,ls='--',label=tr('真实核数比 3/2','True nucleus-count ratio 3/2'));axs[1].set(xlabel=tr('重复间隔 / s','Repetition interval / s'),ylabel=tr('受恢复影响的积分比','Recovery-biased integral ratio'));axs[1].legend(frameon=False,fontsize=9);title(axs[1],'B','位置正确，面积仍可偏差','Correct positions can accompany biased areas')
fig.tight_layout();save(fig,'recovery')
np.savetxt(out/'deposited_transitions.csv',lines,delimiter=',',header='chemical_shift_ppm,deposited_height',comments='')
np.savetxt(out/'deposited_integrals.csv',np.array([[3.641,areas['1'],2],[1.170,areas['2'],3]]),delimiter=',',header='group_shift_ppm,deposited_integral,assigned_proton_count',comments='')
np.savetxt(out/'simulated_fid.csv',np.column_stack([t,noisy.real,noisy.imag]),delimiter=',',header='time_s,real,imaginary',comments='')
np.savetxt(out/'simulated_spectra.csv',np.column_stack([ppm,spectrum,broadened,short]),delimiter=',',header='chemical_shift_ppm,unweighted,broadened_3Hz,short_record',comments='')
summary={'proton_frequency_at_9_4T_MHz':42.577*9.4,'deposited_transition_count':len(lines),'deposited_area_ratio':actual_ratio,'simulated_area_ratio':float(simratio),'linewidth_T2star_02_Hz':1/(np.pi*.2),'recovery_at_5T1':float(1-np.exp(-5)),'biased_ratio_TR1':float(1.5*(1-np.exp(-1))/(1-np.exp(-1/3))),'example_concentration_mM':5*(120/3)/(80/2),'raw_frequency_spacing_Hz':1/(N*dt),'data_kind':{'peak_records':'real BMRB bmse000297 data','FID_and_recovery':'constructed teaching models'}}
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
