# Public sources and third-party materials

- BMRB: Ethanol bmse000297: https://bmrb.io/metabolomics/mol_summary/show_data.php?id=bmse000297
  Public-domain archive data; DOI 10.13018/BMSE000297; Madison Metabolomics Consortium.
- BMRB: About and distribution policy: https://bmrb.io/bmrb/
  Archive data public domain; BMRB states shared wwPDB usage policy.
- Oxford NMR: Classic NMR Papers: https://nmr.chem.ox.ac.uk/classic-nmr-papers
  Historical bibliography; original figures.
- UCSB NMR: Chemical Shift Referencing: https://nmr.chem.ucsb.edu/protocols/refppm.html
  Technical reference.
- Oxford NMR: Quantitative NMR Spectroscopy: https://nmr.chem.ox.ac.uk/sites/g/files/vzsiac2831/files/nmrchem/documents/media/quantitative_nmr.pdf
  Technical reference; no source figures reproduced.
- Oxford NMR: Processing Techniques: https://nmr.chem.ox.ac.uk/sites/g/files/vzsiac2831/files/nmrchem/documents/media/processing-techniques.pdf
  Copyright author; technical reference, no source figures reproduced.
- Iowa State CIF: NMR Coupling Constants: https://www.cif.iastate.edu/nmr/nmr-tutorials/couplingconstants
  Technical reference.
