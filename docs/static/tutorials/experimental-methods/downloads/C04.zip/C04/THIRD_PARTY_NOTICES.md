# Public sources and third-party materials

- Tiselius (1937): Electrophoresis of serum globulin: https://pmc.ncbi.nlm.nih.gov/articles/PMC1267100/
  Technical/historical reference; original diagrams and constructed data, no source artwork reproduced.
- King (2022): Using T4 genetics and Laemmli’s development of high-resolution SDS gel electrophoresis: https://pmc.ncbi.nlm.nih.gov/articles/PMC9576892/
  CC BY 4.0 article; historical reference only, no article artwork reproduced.
- Thermo Fisher: Overview of electrophoresis: https://www.thermofisher.com/us/en/home/life-science/protein-biology/protein-biology-learning-center/protein-biology-resource-library/pierce-protein-methods/overview-electrophoresis.html
  Technical/historical reference; original diagrams and constructed data, no source artwork reproduced.
- Bio-Rad: A Guide to Polyacrylamide Gel Electrophoresis and Detection: https://www.bio-rad.com/webroot/web/pdf/lsr/literature/Bulletin_6040A.pdf
  Technical/historical reference; original diagrams and constructed data, no source artwork reproduced.
- QIAGEN: DNA analysis using analytical gels: https://www.qiagen.com/en-gb/knowledge-and-support/knowledge-hub/bench-guide/dna/analysing-dna/dna-analysis-using-analytical-gels
  Technical/historical reference; original diagrams and constructed data, no source artwork reproduced.
- ImageJ: Analyze menu and gel analysis: https://imagej.net/ij/docs/menus/analyze.html
  Technical/historical reference; original diagrams and constructed data, no source artwork reproduced.
