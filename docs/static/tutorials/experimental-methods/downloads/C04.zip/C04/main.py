"""Constructed electrophoresis images and quantitative diagnostics; no network needed."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,Ellipse

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 zh=a.language=='zh';T=lambda z,e:z if zh else e
 plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.titlesize':13,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fcfbf7','axes.facecolor':'#fcfbf7','savefig.facecolor':'#fcfbf7'})
 B,R,G,Y='#167d9a','#d35f47','#37967d','#c49b35'
 def save(f,n):
  f.savefig(a.output/f'{n}-{a.language}.svg');f.savefig(a.output/f'{n}-{a.language}.png',dpi=145);plt.close(f)
 def text(ax,x,y,z,e,**kw):ax.text(x,y,T(z,e),**kw)
 def arrow(ax,x1,y1,x2,y2,col=B):ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops={'arrowstyle':'->','color':col,'lw':2})
 # Original historical mechanism, not an image of an actual historical experiment.
 f,axes=plt.subplots(1,2,figsize=(13.4,5.3),layout='constrained')
 for ax in axes:ax.set(xlim=(0,10),ylim=(0,8));ax.axis('off')
 ax=axes[0];ax.set_title(T('A  1937：追踪溶液中的移动界面','A  1937: Follow a boundary in solution'),loc='left')
 ax.plot([2,2,2.4,6.6,7,7],[6.5,2,1.5,1.5,2,6.5],color='#9ac0cd',lw=30,solid_capstyle='butt');ax.plot([2,2,2.4,6.6,7,7],[6.5,2,1.5,1.5,2,6.5],color=B,lw=1)
 for y in [3.6,4.2,4.8]:ax.plot([1.62,2.38],[y,y],color=R,lw=3)
 arrow(ax,.3,4.2,3.8,4.2,G);text(ax,.15,5.1,'折射率梯度 → 光学界面','Refractive gradient → optical boundary',fontsize=10)
 text(ax,4.2,6.1,'缓冲液','Buffer',ha='center');text(ax,2,7,'−', '−',ha='center',fontsize=20);text(ax,7,7,'+', '+',ha='center',fontsize=20)
 text(ax,.3,.25,'蒂塞利乌斯：冷却至约 4°C，减小热对流\n原理图；溶液中没有凝胶筛网','Tiselius: about 4°C to suppress convection\nPrinciple diagram; no gel sieve in the liquid',fontsize=10)
 ax=axes[1];ax.set_title(T('B  现代凝胶：电驱动 + 分子筛','B  Modern gels: Electric drive + molecular sieve'),loc='left')
 ax.add_patch(Rectangle((1.6,1.4),5.8,5.3,facecolor='#e2edf0',edgecolor=B))
 for x in np.arange(1.8,7.5,.6):ax.plot([x,x],[1.4,6.7],color='#bfd3da',lw=.6)
 for y in np.arange(1.6,6.7,.5):ax.plot([1.6,7.4],[y,y],color='#bfd3da',lw=.6)
 for x in [2.7,4.5,6.3]:ax.add_patch(Rectangle((x-.45,6.2),.9,.5,fc='#fcfbf7',ec=B))
 for x,y in [(2.7,4.9),(2.7,3),(4.5,4.4),(4.5,2.1),(6.3,3.7)]:ax.plot([x-.4,x+.4],[y,y],lw=8,color=R)
 arrow(ax,8.4,6.3,8.4,2);text(ax,8.7,4,'向正极','Toward +',rotation=90,va='center')
 text(ax,1.8,.25,'SDS 改变蛋白质的电荷与形状\n还原剂另行切断二硫键','SDS changes protein charge and shape\nA reducing agent separately breaks disulfides',fontsize=10)
 save(f,'history-mechanism')
 # Constructed raw fluorescence image: all lanes share detector and dye response.
 rng=np.random.default_rng(640);yy,xx=np.mgrid[:360,:390];origin,front=25.,335.;xs=np.array([45,105,165,225,285,345]);masses=np.array([100,70,40,25,15.]);rf=(2.1-np.log10(masses))/1.25;ys=origin+(front-origin)*rf
 center=lambda m:origin+(front-origin)*(2.1-np.log10(m))/1.25
 raw=100+.03*yy+np.zeros_like(xx,dtype=float)
 def band(x,y,ng):return 20*ng*np.exp(-.5*((xx-x)/6)**2-.5*((yy-y)/3)**2)
 for y in ys:raw+=band(xs[0],y,35)
 loads=np.array([0,20,40,80,55.])
 for x,m in zip(xs[1:],loads):raw+=band(x,center(40),m)
 raw+=band(xs[-1],center(25),12);raw=np.round(np.maximum(0,raw+rng.normal(0,3,raw.shape))).astype(np.uint16)
 yc=int(round(center(40)));xhalf=20;yhalf=13
 def measure(x,y):
  cy=int(round(y));roi=raw[cy-yhalf:cy+yhalf+1,int(x)-xhalf:int(x)+xhalf+1].astype(float)
  strips=np.concatenate([raw[cy-24:cy-17,int(x)-xhalf:int(x)+xhalf+1].ravel(),raw[cy+18:cy+25,int(x)-xhalf:int(x)+xhalf+1].ravel()]);bg=float(strips.mean())
  return float(roi.sum()-roi.size*bg),bg
 results=np.array([measure(x,center(40)) for x in xs[1:]]);coef=np.polyfit(loads[:4],results[:4,0],1);estimate=(results[-1,0]-coef[1])/coef[0]
 # Locate ladder maxima from local profiles, then estimate size in the same gel.
 detected=[]
 for y in ys:
  profile=raw[:,25:66].mean(axis=1);window=np.arange(int(y)-6,int(y)+7);detected.append(window[np.argmax(profile[window])])
 detected=np.array(detected);fit=np.polyfit((detected-origin)/(front-origin),np.log10(masses),1)
 uprofile=raw[:,325:366].mean(axis=1);win=np.arange(yc-8,yc+9);uy=int(win[np.argmax(uprofile[win])]);mass_est=10**np.polyval(fit,(uy-origin)/(front-origin))
 f=plt.figure(figsize=(13.6,7.5),layout='constrained');gs=f.add_gridspec(2,2,width_ratios=[1.1,1]);ax=f.add_subplot(gs[:,0]);im=ax.imshow(raw,cmap='magma',vmin=90,vmax=1800,origin='upper');ax.set_xticks(xs,['L','0','20','40','80','U']);ax.xaxis.tick_top();ax.set_xlabel(T('标准 / ng；U = 未知样品','Standards / ng; U = unknown'));ax.xaxis.set_label_position('top');ax.set_ylabel(T('图像行 / pixel','Image row / pixel'));ax.set_title(T('A  构造的原始荧光图','A  Constructed raw fluorescence image'),loc='left',pad=48)
 ax.axhline(origin,color='white',lw=.8,ls='--');ax.axhline(front,color='white',lw=.8,ls='--');ax.add_patch(Rectangle((325,yc-yhalf),41,27,fc='none',ec='#76dccb',lw=1.6));f.colorbar(im,ax=ax,shrink=.7,label=T('探测器计数','Detector counts'))
 ax=f.add_subplot(gs[0,1]);dx=(detected-origin)/(front-origin);ax.scatter(dx,np.log10(masses),c=B);grid=np.linspace(0,.85,100);ax.plot(grid,np.polyval(fit,grid),color=B);ax.scatter((uy-origin)/(front-origin),np.log10(mass_est),c=R,zorder=4);ax.annotate(f'U: {mass_est:.1f} kDa',((uy-origin)/(front-origin),np.log10(mass_est)),xytext=(.5,1.85),arrowprops={'arrowstyle':'->','color':R});ax.set(xlabel=T('相对迁移距离 Rf','Relative migration Rf'),ylabel='log₁₀(M / kDa)',title=T('B  同一块胶的大小校准','B  Size calibration on the same gel'))
 ax=f.add_subplot(gs[1,1]);ax.plot(np.arange(360),uprofile,color=R);ax.axvspan(yc-13,yc+13,color=G,alpha=.18);ax.axvline(center(25),color=B,ls=':');ax.set(xlabel=T('图像行 / pixel','Image row / pixel'),ylabel=T('泳道平均计数','Lane-mean counts'),title=T('C  未知泳道：40 kDa 主带与 25 kDa 次带','C  Unknown lane: 40 kDa major, 25 kDa minor'))
 save(f,'gel-size')
 # Analytic integration of a clipped two-dimensional Gaussian band.
 def apparent(m,t,bg):
  amp=20*np.asarray(m)*t;cap=4095-bg;ratio=np.ones_like(amp,dtype=float);mask=amp>cap;ratio[mask]=cap/amp[mask]*(1+np.log(amp[mask]/cap));return np.asarray(m)*ratio
 f,ax=plt.subplots(2,2,figsize=(13.6,8),layout='constrained')
 crop=raw[yc-27:yc+28,320:371];ax[0,0].imshow(crop,cmap='magma',vmin=90,vmax=1800,extent=(320,371,yc+28,yc-27));ax[0,0].add_patch(Rectangle((325,yc-13),41,27,fc='none',ec=G,lw=2));
 for y in [yc-24,yc+18]:ax[0,0].add_patch(Rectangle((325,y),41,7,fc='none',ec=B,lw=2))
 ax[0,0].set(xlabel=T('图像列 / pixel','Image column / pixel'),ylabel=T('图像行 / pixel','Image row / pixel'),title=T('A  绿色积分区；蓝色背景区','A  Green integration; blue background'))
 ax[0,1].scatter(loads[:4],results[:4,0]/1000,c=B);ax[0,1].plot([0,85],np.polyval(coef,[0,85])/1000,color=B);ax[0,1].scatter(estimate,results[-1,0]/1000,c=R);ax[0,1].annotate(f'U = {estimate:.2f} ng',(estimate,results[-1,0]/1000),xytext=(12,155),arrowprops={'arrowstyle':'->','color':R});ax[0,1].set(xlabel=T('同一蛋白质的上样质量 / ng','Loaded mass of the same protein / ng'),ylabel=T('净积分 / 10³ counts','Net integral / 10³ counts'),title=T('B  背景扣除后反算质量','B  Infer mass after background subtraction'))
 ml=np.linspace(0,200,201)
 for t,c in [(1,B),(4,R),(8,Y)]:ax[1,0].plot(ml,apparent(ml,t,100),c=c,label=f'{t} s')
 ax[1,0].plot(ml,ml,'--',c='#6f7883',label=T('理想线性','Ideal linear'));ax[1,0].legend();ax[1,0].set(xlabel=T('真实上样质量 / ng','True loaded mass / ng'),ylabel=T('按曝光校正的表观质量 / ng','Exposure-corrected apparent mass / ng'),title=T('C  12 位探测器削顶造成低估','C  Clipping by a 12-bit detector causes underestimation'))
 widths=np.arange(2,23);integ=[]
 for w in widths:integ.append((raw[yc-w:yc+w+1,325:366].astype(float).sum()-(2*w+1)*41*results[-1,1]-coef[1])/coef[0])
 ax[1,1].plot(widths,integ,c=G);ax[1,1].axhline(55,c=R,ls='--');ax[1,1].set(xlabel=T('积分区域半高 / pixel','Integration half-height / pixel'),ylabel=T('未知样品估计质量 / ng','Estimated unknown mass / ng'),title=T('D  积分区太窄会漏掉带的两侧','D  A narrow region misses band tails'))
 save(f,'quantitation')
 f,axs=plt.subplots(1,2,figsize=(13.6,5.6),layout='constrained')
 for ax in axs:ax.set(xlim=(0,10),ylim=(0,9));ax.axis('off')
 ax=axs[0];ax.set_title(T('A  二硫键连接的两个 40 kDa 亚基','A  Two 40 kDa subunits joined by a disulfide'),loc='left')
 for x in [2,7]:ax.add_patch(Circle((x,7),.8,fc='#b9dbe3',ec=B));text(ax,x,7,'40','40',ha='center',va='center')
 ax.plot([2.8,6.2],[7,7],c=Y,lw=3);text(ax,4.5,7.3,'S—S','S—S',ha='center');arrow(ax,2.5,5.6,2.5,4.7);arrow(ax,7,5.6,7,4.7)
 for x,label,y in [(2.5,T('非还原 SDS','Nonreducing SDS'),3.9),(7,T('还原 SDS','Reducing SDS'),2.1)]:
  ax.add_patch(Rectangle((x-.75,1.2),1.5,3.4,fc='#e2edf0',ec=B));ax.plot([x-.5,x+.5],[y,y],lw=9,color=R);text(ax,x,.6,label,label,ha='center',fontsize=10)
 text(ax,.2,3.9,'80 kDa','80 kDa',fontsize=10);text(ax,8,2.1,'40 kDa','40 kDa',fontsize=10);text(ax,.3,8.2,'构造关系示意；假定亚基无其他共价交联','Constructed relationship; no other covalent crosslinks',fontsize=9)
 ax=axs[1];ax.set_title(T('B  同样长度的 DNA 可以有不同形状','B  DNA of equal length can have different shapes'),loc='left')
 ax.add_patch(Ellipse((2,6.7),2.4,1.4,fill=False,ec=B,lw=2));text(ax,2,5.4,'开环','Open circular',ha='center')
 x=np.linspace(0,2*np.pi,200);ax.plot(6.8+1.2*np.cos(x),6.7+.35*np.sin(3*x),c=R,lw=2);text(ax,6.8,5.4,'超螺旋','Supercoiled',ha='center')
 ax.plot([1,8],[3.4,3.4],color=G,lw=2);text(ax,4.5,2.5,'线性化后再与线性标记比较','Linearize before comparison with a linear ladder',ha='center',fontsize=10)
 text(ax,.4,.6,'形状改变摩擦与穿孔方式\n迁移快慢还取决于胶和实验条件','Conformation changes drag and pore passage\nMigration also depends on gel and run conditions',fontsize=10)
 save(f,'molecular-forms')
 np.savez_compressed(a.output/'constructed_gel.npz',raw_counts=raw,lane_centers=xs,origin=origin,front=front)
 np.savetxt(a.output/'ladder.csv',np.c_[masses,detected,(detected-origin)/(front-origin)],delimiter=',',header='mass_kDa,image_row_px,Rf',comments='')
 np.savetxt(a.output/'quantitation.csv',np.c_[loads,results],delimiter=',',header='true_mass_ng,net_integral_counts,background_counts_per_pixel',comments='')
 np.savetxt(a.output/'unknown_profile.csv',np.c_[np.arange(360),uprofile],delimiter=',',header='image_row_px,mean_counts',comments='')
 summary={'estimated_mass_kDa':float(mass_est),'estimated_load_ng':float(estimate),'calibration_slope_counts_per_ng':float(coef[0]),'calibration_intercept_counts':float(coef[1]),'image_max_counts':int(raw.max()),'ideal_Rf_40kDa':float((2.1-np.log10(40))/1.25),'field_V_per_m':1000.,'speed_um_per_s':20.,'distance_30min_mm':36.,'clipped_100ng_4s_apparent_ng':float(apparent(100.,4.,100.)),'target_mass_fraction_equal_response':55/67,'roi_pixels':41*27,'unknown_background_counts_per_pixel':float(results[-1,1])}
 (a.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
