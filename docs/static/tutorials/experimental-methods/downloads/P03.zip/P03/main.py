"""Contact-angle geometry, contour fitting and an explicit pinning model.
All droplet observations are constructed teaching data. Historical excerpt:
Thomas Young (1805), An Essay on the Cohesion of Fluids, p. 66; public domain.
Run: python main.py --output results --language en
"""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import brentq
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Arc,Rectangle

def cap(volume_ul,angle_deg):
    theta=np.deg2rad(angle_deg);R=(3*volume_ul/(np.pi*(1-np.cos(theta))**2*(2+np.cos(theta))))**(1/3)
    return R,R*np.sin(theta),R*(1-np.cos(theta))

def contour(volume_ul,angle_deg,n=180):
    R,a,h=cap(volume_ul,angle_deg);u=np.linspace(-np.deg2rad(angle_deg),np.deg2rad(angle_deg),n)
    return R*np.sin(u),R*np.cos(u)-R*np.cos(np.deg2rad(angle_deg))

def circle_fit(x,y):
    b=np.linalg.lstsq(np.column_stack([2*x,2*y,np.ones(len(x))]),x*x+y*y,rcond=None)[0]
    return b[0],b[1],np.sqrt(b[2]+b[0]**2+b[1]**2)

def apparent_angle(R,cy,baseline):return float(np.rad2deg(np.arccos(np.clip((baseline-cy)/R,-1,1))))

def pinned_volume(a,theta):
    t=np.deg2rad(theta);h=a*np.tan(t/2);return np.pi*h*(3*a*a+h*h)/6

def hysteresis():
    Vup=np.linspace(.5,2,101);Vdown=np.linspace(2,.15,151);initial_a=cap(.5,85)[1]
    up_angles=[];up_a=[]
    for v in Vup:
        if v<=pinned_volume(initial_a,100):theta=brentq(lambda t:pinned_volume(initial_a,t)-v,1,179);a=initial_a
        else:theta=100;a=cap(v,theta)[1]
        up_angles.append(theta);up_a.append(a)
    final_a=up_a[-1];down_angles=[];down_a=[]
    for v in Vdown:
        if v>=pinned_volume(final_a,70):theta=brentq(lambda t:pinned_volume(final_a,t)-v,1,179);a=final_a
        else:theta=70;a=cap(v,theta)[1]
        down_angles.append(theta);down_a.append(a)
    return np.r_[Vup,Vdown],np.r_[up_angles,down_angles],np.r_[up_a,down_a],len(Vup)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args()
    out=args.output;out.mkdir(parents=True,exist_ok=True);tr=lambda z,e:z if args.language=='zh' else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fbfcfc','savefig.facecolor':'#fbfcfc','text.color':'#18344a'})
    blue='#186c94';green='#188777';orange='#d27839'
    def save(f,n):f.savefig(out/f'{n}-{args.language}.svg',bbox_inches='tight');f.savefig(out/f'{n}-{args.language}.png',bbox_inches='tight',dpi=150);plt.close(f)
    volume=.5;angle=70.;R,a,h=cap(volume,angle);x,y=contour(volume,angle)
    rng=np.random.default_rng(1803);xn=x+rng.normal(0,.002,len(x));yn=y+rng.normal(0,.002,len(y))
    cx,cy,rf=circle_fit(xn,yn);fitted=apparent_angle(rf,cy,0)
    residual=np.sqrt((xn-cx)**2+(yn-cy)**2)-rf
    offsets=np.linspace(-.03,.03,121);sensitivity=np.array([apparent_angle(rf,cy,b) for b in offsets])
    monte=[]
    for k in range(300):
        ccx,ccy,rr=circle_fit(x+rng.normal(0,.002,len(x)),y+rng.normal(0,.002,len(y)));monte.append(apparent_angle(rr,ccy,0))
    vols,angles,radii,split=hysteresis()
    summary={'specified_angle_deg':angle,'fitted_angle_deg':fitted,'cap_radius_mm':float(R),'base_radius_mm':float(a),'height_mm':float(h),
       'recovered_volume_ul':float(np.pi*h*(3*a*a+h*h)/6),'height_base_angle_deg':float(np.rad2deg(2*np.arctan(h/a))),
       'baseline_plus20um_angle_deg':apparent_angle(rf,cy,.02),'monte_carlo_sd_deg':float(np.std(monte,ddof=1)),
       'young_angle_deg':float(np.rad2deg(np.arccos(36/72))),'wenzel_60_r15_deg':float(np.rad2deg(np.arccos(1.5*np.cos(np.deg2rad(60))))),
       'cassie_110_f02_deg':float(np.rad2deg(np.arccos(.2*(1+np.cos(np.deg2rad(110)))-1))),
       'hysteresis_deg':30,'bond_R':float(1000*9.81*(R*.001)**2/.072),
       'data_kind':'Constructed spherical-cap observations and prescribed pinning model'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    np.savetxt(out/'data.csv',np.column_stack([xn,yn,residual]),delimiter=',',header='x_mm,y_mm,radial_residual_mm',comments='')
    np.savetxt(out/'hysteresis.csv',np.column_stack([vols,angles,radii]),delimiter=',',header='volume_ul,angle_deg,base_radius_mm',comments='')
    np.savetxt(out/'baseline_sensitivity.csv',np.column_stack([offsets,sensitivity]),delimiter=',',header='baseline_mm,angle_deg',comments='')
    fig,axs=plt.subplots(1,2,figsize=(12,5),gridspec_kw={'width_ratios':[1.1,1]});left,right=axs
    left.imshow(Image.open(Path(__file__).parent/'data/young1805-excerpt.png'));left.axis('off');left.set_title(tr('A  Young，1805年原文第66页','A  Young, 1805, original page 66'),loc='left')
    xx,yy=contour(.5,60);aa=cap(.5,60)[1];right.fill_between(xx,yy,0,color='#c8e4e7');right.plot(xx,yy,color=blue,lw=2);right.axhline(0,color='#576d7b')
    px=aa
    right.annotate('',xy=(px+.35,0),xytext=(px,0),arrowprops={'arrowstyle':'->','color':orange,'lw':2});right.text(px+.12,-.1,'γSV',color=orange)
    right.annotate('',xy=(px-.35,0),xytext=(px,0),arrowprops={'arrowstyle':'->','color':green,'lw':2});right.text(px-.37,-.1,'γSL',color=green)
    right.annotate('',xy=(px-.2,.346),xytext=(px,0),arrowprops={'arrowstyle':'->','color':blue,'lw':2});right.text(px-.14,.38,'γLV',color=blue)
    right.add_patch(Arc((px,0),.35,.35,theta1=120,theta2=180,color=orange,lw=2));right.text(px-.23,.09,'θ')
    right.set_aspect('equal');right.set_xlim(-.9,1.15);right.set_ylim(-.22,.85);right.axis('off');right.set_title(tr('B  在液体一侧读角度','B  Read the angle through the liquid'),loc='left');save(fig,'history')
    fig,axs=plt.subplots(2,2,figsize=(11.5,8.7));p1,p2,p3,p4=axs.ravel()
    p1.scatter(xn,yn,s=7,color=blue,label=tr('构造轮廓点','Constructed contour points'));tt=np.linspace(-np.deg2rad(fitted),np.deg2rad(fitted),300);p1.plot(cx+rf*np.sin(tt),cy+rf*np.cos(tt),color=orange,label=tr('圆拟合','Circle fit'))
    p1.axhline(0,color=green,label=tr('真实基线','True baseline'));p1.axhline(.02,color='#a14e6d',ls='--',label=tr('上移20 μm','Raised by 20 μm'));p1.set_aspect('equal');p1.set_xlabel('x / mm');p1.set_ylabel('y / mm');p1.legend(fontsize=8);p1.set_title(tr('A  轮廓与基线','A  Contour and baseline'),loc='left')
    p2.scatter(np.arange(len(residual)),residual*1000,s=9,color=blue);p2.axhline(0,color='#a1abb2');p2.set_xlabel(tr('轮廓点索引','Contour index'));p2.set_ylabel(tr('径向残差 / μm','Radial residual / μm'));p2.set_title(tr('B  模型与观测的差','B  Model-to-observation differences'),loc='left')
    p3.plot(offsets*1000,sensitivity,color=orange);p3.axhline(70,color=green,ls=':');p3.axvline(0,color='#a1abb2');p3.set_xlabel(tr('基线偏移 / μm','Baseline offset / μm'));p3.set_ylabel(tr('测得接触角 / °','Estimated angle / °'));p3.set_title(tr('C  基线误差的系统影响','C  Systematic effect of baseline error'),loc='left')
    p4.hist(monte,bins=20,color=blue,alpha=.8);p4.axvline(70,color=orange);p4.set_xlabel(tr('重复噪声模拟的角度 / °','Angles across repeated noise simulations / °'));p4.set_ylabel(tr('次数','Count'));p4.set_title(tr('D  300次固定真值重复','D  300 repeats at fixed true geometry'),loc='left')
    fig.tight_layout();save(fig,'measurement')
    fig,axs=plt.subplots(2,2,figsize=(11.5,8));p1,p2,p3,p4=axs.ravel()
    for v,t,aa,col,lab in [(vols[:split],angles[:split],radii[:split],blue,tr('加液','Add liquid')),(vols[split:],angles[split:],radii[split:],orange,tr('抽液','Withdraw liquid'))]:
        p1.plot(v,t,color=col,label=lab);p2.plot(v,aa,color=col,label=lab)
    p1.set_ylabel(tr('角度 / °','Angle / °'));p2.set_ylabel(tr('接触底面半径 / mm','Contact-base radius / mm'))
    for p in [p1,p2]:p.set_xlabel(tr('体积 / μL','Volume / μL'));p.legend()
    p1.set_title(tr('A  规定阈值的钉扎模型','A  Pinning model with prescribed thresholds'),loc='left');p2.set_title(tr('B  角度变化时接触线可不移动','B  The contact line can remain fixed'),loc='left')
    for p,title,filled in [(p3,tr('C  Wenzel：液体填满纹理','C  Wenzel: liquid fills texture'),True),(p4,tr('D  Cassie：纹理间保留气体','D  Cassie: gas remains in the texture'),False)]:
        p.set_xlim(0,6);p.set_ylim(-.3,1.6);p.axis('off');p.add_patch(Rectangle((0,-.3),6,.3,color='#576d7b'))
        if filled:p.add_patch(Rectangle((0,0),6,1.1,color='#c8e4e7'))
        else:p.add_patch(Rectangle((0,.65),6,.45,color='#c8e4e7'))
        for start in np.arange(.3,6,1.2):p.add_patch(Rectangle((start,0),.5,.65,color='#576d7b'))
        p.plot([0,6],[1.1,1.1],color=blue,lw=2);p.set_title(title,loc='left');p.text(3,1.3,tr('局部接触状态示意，非整滴轮廓','Local contact states, not whole-drop outlines'),ha='center',fontsize=9)
    fig.tight_layout();save(fig,'hysteresis')
    print(json.dumps(summary))

if __name__=='__main__':main()
