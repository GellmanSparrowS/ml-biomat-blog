# Public sources and third-party materials

- Thomas Young — An Essay on the Cohesion of Fluids (1805): https://upload.wikimedia.org/wikipedia/commons/8/85/Thomas_Young-An_Essay_on_the_Cohesion_of_Fluids.pdf
  Public domain; p. 66 excerpt reproduced.
- Wikimedia Commons — Young paper rights and bibliographic record: https://commons.wikimedia.org/wiki/File:Thomas_Young-An_Essay_on_the_Cohesion_of_Fluids.pdf
  Public Domain Mark 1.0 for the historical scan.
- KRÜSS — Contact angle and measurement methods: https://www.kruss-scientific.com/en/know-how/glossary/contact-angle
  Public manufacturer reference; no illustration copied.
- KRÜSS — Young equation: https://www.kruss-scientific.com/en/know-how/glossary/youngs-equation
  Public manufacturer reference; no illustration copied.
- KRÜSS — Hysteresis of contact angle: https://www.kruss-scientific.com/en/know-how/glossary/hysteresis-of-the-contact-angle
  Public manufacturer reference; original model used.
- KRÜSS — Young–Laplace fit: https://www.kruss-scientific.com/en/know-how/glossary/young-laplace-fit
  Public manufacturer reference; no illustration copied.
- KRÜSS — Surface roughness and wetting: https://www.kruss-scientific.com/en/know-how/glossary/roughness
  Public manufacturer reference; original diagrams used.
- KRÜSS — Height-width method: https://www.kruss-scientific.com/en/know-how/glossary/height-width-method
  Public manufacturer reference; no code copied.
