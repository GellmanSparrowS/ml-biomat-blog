"""Constructed SPR sensorgrams, double referencing and kinetic/transport diagnostics."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import least_squares,curve_fit
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Polygon,Circle

def response(t,concentration,kon=2e5,koff=.002,capacity=120.,contact=180.):
 t=np.asarray(t);c=concentration*1e-9;rate=kon*c+koff;equilibrium=capacity*kon*c/rate
 assoc=equilibrium*(-np.expm1(-rate*np.maximum(t,0)));end=equilibrium*(-np.expm1(-rate*contact))
 return np.where(t<0,0,np.where(t<=contact,assoc,end*np.exp(-koff*np.maximum(t-contact,0))))

def transport(exchange,site_equivalent,concentration=30.,contact=180.,stop=600.):
 """exchange: s^-1; site_equivalent: mol/L of near-surface compartment."""
 def rhs(bulk):
  def f(t,y):
   theta,cs=y;binding=2e5*cs*(1-theta)-.002*theta
   return [binding,exchange*(bulk-cs)-site_equivalent*binding]
  return f
 a=solve_ivp(rhs(concentration*1e-9),(0,contact),[0,0],t_eval=np.arange(contact+1),rtol=1e-9,atol=[1e-11,1e-16])
 b=solve_ivp(rhs(0),(contact,stop),a.y[:,-1],t_eval=np.arange(contact,stop+1),rtol=1e-9,atol=[1e-11,1e-16])
 return np.r_[a.t,b.t[1:]],np.c_[a.y,b.y[:,1:]]

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);T=lambda z,e:z if a.language=='zh' else e
 plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.titlesize':12,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fcfbf7','axes.facecolor':'#fcfbf7','savefig.facecolor':'#fcfbf7'})
 B,R,G,Y='#167d9a','#d35f47','#37967d','#c49b35';cols=[B,G,Y,R,'#775f91']
 def save(f,n):f.savefig(a.output/f'{n}-{a.language}.svg');f.savefig(a.output/f'{n}-{a.language}.png',dpi=145);plt.close(f)
 rng=np.random.default_rng(660);t=np.arange(-30,601,dtype=float);cs=np.array([1,3,10,30,100.]);binding=np.array([response(t,c) for c in cs]);on=(t>=0)&(t<180);bulk=12*on;drift=.5+.005*(t+30)
 artifact=np.where(t>=0,1.5*np.exp(-np.maximum(t,0)/8),0)-np.where(t>=180,1.2*np.exp(-np.maximum(t-180,0)/8),0)
 active=binding+bulk+drift+artifact+rng.normal(0,.2,binding.shape);reference=np.broadcast_to(bulk+drift,binding.shape)+rng.normal(0,.2,binding.shape)
 blankactive=np.broadcast_to(drift+artifact,binding.shape)+rng.normal(0,.2,binding.shape);blankref=np.broadcast_to(drift,binding.shape)+rng.normal(0,.2,binding.shape)
 single=active-reference;corrected=single-(blankactive-blankref);corrected-=corrected[:,t<0].mean(axis=1,keepdims=True)
 def residual(p):return (np.array([response(t,c,*np.exp(p)) for c in cs])-corrected).ravel()
 fitted=least_squares(residual,np.log([2e5,.002,120]),bounds=(np.log([1e3,1e-5,10]),np.log([1e8,1,1000])),xtol=1e-12,ftol=1e-12,gtol=1e-12)
 kon,koff,cap=np.exp(fitted.x);prediction=np.array([response(t,c,kon,koff,cap) for c in cs]);kd=koff/kon*1e9
 endpoint=binding[:,t==180].ravel();eqfun=lambda c,k,r:r*c/(k+c);wrong,_=curve_fit(eqfun,cs,endpoint,p0=[20,130],bounds=(0,np.inf));earlyfixed,_=curve_fit(lambda c,k:eqfun(c,k,120),cs,endpoint,p0=[20],bounds=(0,np.inf))
 # Optical curves below are conceptual Lorentzian sketches, not Maxwell solutions.
 f,axes=plt.subplots(1,2,figsize=(13.5,5.5),layout='constrained');ax=axes[0];ax.set(xlim=(0,10),ylim=(0,8));ax.axis('off');ax.set_title(T('A  1983：薄金属膜把结合变成光学变化','A  1983: Thin metal films turn binding into an optical change'),loc='left')
 ax.add_patch(Polygon([[1,4.5],[9,4.5],[5,.8]],fc='#dce9ed',ec=B));ax.add_patch(Rectangle((1,4.5),8,.2,fc=Y));ax.add_patch(Rectangle((1,4.7),8,2,fc='#e6f0ee',ec=G));ax.annotate('',xy=(8.5,6.3),xytext=(1.5,6.3),arrowprops={'arrowstyle':'->','color':G,'lw':2});ax.text(5,7.1,T('溶液流动；表面附近折射率改变','Flowing solution; refractive index changes near the surface'),ha='center',fontsize=10)
 for x in [2,3.5,5,6.5,8]:
  ax.plot([x,x],[4.7,5.1],c=B,lw=2);ax.add_patch(Circle((x,5.3),.22,fc=B))
 for x in [3.5,6.5]:ax.add_patch(Circle((x,5.67),.18,fc=R))
 ax.annotate('',xy=(5,4.5),xytext=(2,1.7),arrowprops={'arrowstyle':'->','color':R,'lw':2});ax.annotate('',xy=(8,1.7),xytext=(5,4.5),arrowprops={'arrowstyle':'->','color':R,'lw':2});ax.plot([5,5],[2.5,4.5],ls=':',c='#657785');ax.text(2,1.1,T('入射光','Incident light'),ha='center');ax.text(8,1.1,T('反射光','Reflected light'),ha='center');ax.text(5,.05,T('棱镜耦合原理图；尺寸不按比例','Prism-coupling principle; not to scale'),ha='center',fontsize=10)
 ax=axes[1];angle=np.linspace(69.5,71,500)
 for center,c,l in [(70.2,B,T('结合前','Before binding')),(70.35,R,T('近表面环境变化后','After near-surface change'))]:ax.plot(angle,1-.75*.12**2/((angle-center)**2+.12**2),c=c,label=l)
 ax.annotate('',xy=(70.35,.2),xytext=(70.2,.2),arrowprops={'arrowstyle':'->','color':G,'lw':2});ax.set(xlabel=T('入射角 / degree','Incidence angle / degree'),ylabel=T('相对反射强度','Relative reflected intensity'),title=T('B  共振谷的位置移动','B  The resonance minimum shifts'),ylim=(.1,1.05));ax.legend(fontsize=9);ax.text(.04,.025,T('示意轮廓；非实测角谱','Conceptual profiles; not measured angle spectra'),transform=ax.transAxes,fontsize=9)
 save(f,'optics-history')
 f,axes=plt.subplots(2,2,figsize=(13.7,8.3),layout='constrained');j=2;ax=axes[0,0];ax.plot(t,active[j],c=B,label=T('活性表面','Active surface'));ax.plot(t,reference[j],c=Y,label=T('参照表面','Reference surface'));ax.plot(t,binding[j],c=R,ls='--',label=T('构造结合真值','Constructed binding truth'));ax.set(xlabel=T('时间 / s','Time / s'),ylabel=T('响应 / RU','Response / RU'),title=T('A  10 nM：结合与溶剂阶跃叠在一起','A  10 nM: Binding plus solvent steps'));ax.legend(fontsize=9)
 ax=axes[0,1];sl=(t>=-10)&(t<=45);ax.plot(t[sl],single[j,sl]-binding[j,sl],c=Y,label=T('参照相减后 − 真值','Reference-subtracted minus truth'));ax.plot(t[sl],corrected[j,sl]-binding[j,sl],c=B,label=T('再扣空白后 − 真值','Double-referenced minus truth'));ax.axhline(0,c='#647681',lw=1);ax.set(xlabel=T('时间 / s','Time / s'),ylabel=T('剩余偏差 / RU','Remaining deviation / RU'),title=T('B  空白周期去除重复进样扰动','B  Blank cycles remove repeatable injection artifacts'));ax.legend(fontsize=9)
 ax=axes[1,0]
 for i,c in enumerate(cs):ax.plot(t,corrected[i],c=cols[i],lw=.7,alpha=.65,label=f'{c:g} nM');ax.plot(t,prediction[i],c=cols[i],lw=1.4)
 ax.axvline(180,c='#647681',ls='--',lw=1);ax.set(xlabel=T('时间 / s','Time / s'),ylabel=T('双参照校正响应 / RU','Double-referenced response / RU'),title=T('C  多浓度共享一组动力学参数','C  Concentrations share kinetic parameters'));ax.legend(ncol=2,fontsize=9)
 ax=axes[1,1]
 for i,c in enumerate(cs):ax.plot(t,corrected[i]-prediction[i],c=cols[i],lw=.55,alpha=.55)
 ax.axhline(0,c='#647681',lw=1);ax.set(xlabel=T('时间 / s','Time / s'),ylabel=T('数据 − 模型 / RU','Data − model / RU'),title=T('D  从残差检查遗漏的时间结构','D  Inspect residuals for missing time structure'))
 save(f,'reference-kinetics')
 f,axes=plt.subplots(1,2,figsize=(13.6,5.5),layout='constrained');ax=axes[0]
 for rate,c in [(1,B),(10,R)]:ax.plot(t,response(t,10,2e5*rate,.002*rate),c=c,label=T(f'速率 ×{rate}',f'Rates ×{rate}'))
 ax.axhline(60,c='#647681',ls=':',label=T('平衡响应 60 RU','Equilibrium: 60 RU'));ax.axvline(180,c='#647681',ls='--');ax.set(xlabel=T('时间 / s','Time / s'),ylabel=T('结合响应 / RU','Binding response / RU'),title=T('A  同为 Kᴅ=10 nM，不同的到达与离开','A  Both Kᴅ=10 nM, different arrival and departure'));ax.legend(fontsize=9)
 ax=axes[1];grid=np.geomspace(.3,300,200);ax.semilogx(grid,eqfun(grid,10,120),c=B,label=T('真正的平衡关系','True equilibrium'));ax.scatter(cs,endpoint,c=R,label=T('180 s 时的端点','Endpoints at 180 s'));ax.semilogx(grid,eqfun(grid,*wrong),c=R,ls='--',label=T('将端点误作平衡拟合','Premature equilibrium fit'));ax.set(xlabel=T('分析物浓度 / nM','Analyte concentration / nM'),ylabel=T('响应 / RU','Response / RU'),title=T('B  停止进样不等于达到平衡','B  Injection end is not equilibrium'));ax.legend(fontsize=9);ax.text(.04,.53,T(f'端点拟合 Kᴅ = {wrong[0]:.1f} nM\nRmax = {wrong[1]:.1f} RU',f'Endpoint fit Kᴅ = {wrong[0]:.1f} nM\nRmax = {wrong[1]:.1f} RU'),transform=ax.transAxes,fontsize=10)
 save(f,'affinity-versus-time')
 cases=[(.005,2e-7,R,T('高容量，慢交换','High capacity, slow exchange')),(.5,2e-7,B,T('高容量，快交换','High capacity, fast exchange')),(.005,2e-9,G,T('低容量，慢交换','Low capacity, slow exchange'))];traces=[];f,axes=plt.subplots(2,2,figsize=(13.6,8.1),layout='constrained')
 for k,g,c,l in cases:
  tt,yy=transport(k,g);traces.append((tt,yy));axes[0,0].plot(tt,yy[0],c=c,label=l);axes[0,1].plot(tt,yy[1]*1e9,c=c);axes[1,0].semilogy(tt[180:]-180,yy[0,180:]/yy[0,180],c=c)
 for ax in axes[0]:ax.axvline(180,c='#647681',ls='--',lw=1);ax.set_xlabel(T('时间 / s','Time / s'))
 axes[0,0].set(ylabel=T('位点占据比例','Fraction occupied'),title=T('A  固定内在速率，改变运输条件','A  Same intrinsic rates, different transport'));axes[0,0].legend(fontsize=9)
 axes[0,1].plot([0,180,180,600],[30,30,0,0],c='#647681',ls=':',label=T('主体溶液','Bulk solution'));axes[0,1].set(ylabel=T('近表面游离浓度 / nM','Near-surface free concentration / nM'),title=T('B  消耗与释放改变近表面浓度','B  Uptake and release alter local concentration'));axes[0,1].legend(fontsize=9)
 axes[1,0].plot(np.arange(421),np.exp(-.002*np.arange(421)),c='#647681',ls='--',label=T('没有再结合的指数解离','Exponential decay without rebinding'));axes[1,0].set(xlabel=T('洗脱开始后时间 / s','Time after wash begins / s'),ylabel=T('相对于洗脱起点的占据','Occupancy relative to start of wash'),title=T('C  邻近分析物再结合会拖慢下降','C  Rebinding slows the apparent decay'));axes[1,0].legend(fontsize=8)
 ax=axes[1,1];ax.axis('off');ax.set(xlim=(0,10),ylim=(0,7));ax.add_patch(Rectangle((1,4.4),8,1.5,fc='#deebe6',ec=G));ax.add_patch(Rectangle((1,2.2),8,1.5,fc='#dce9ee',ec=B));ax.text(5,5.15,T('主体浓度 Cb：进样 30 nM，洗脱 0','Bulk Cb: 30 nM during injection, 0 during wash'),ha='center',fontsize=10);ax.text(5,2.95,T('近表面浓度 Cs：运输与结合共同决定','Near-surface Cs: exchange plus binding'),ha='center',fontsize=10);ax.annotate('',xy=(5,4.35),xytext=(5,3.75),arrowprops={'arrowstyle':'<->','color':R,'lw':2});ax.text(5,.6,T('容量：200 或 2 nM 的等效位点浓度\n交换速率：0.005 或 0.5 s⁻¹；非直接流速','Capacity: 200 or 2 nM equivalent sites\nExchange: 0.005 or 0.5 s⁻¹; not a direct flow rate'),ha='center',fontsize=10);ax.set_title(T('D  两区域教学模型','D  Two-compartment teaching model'),loc='left')
 save(f,'transport-rebinding')
 np.savez_compressed(a.output/'constructed_sensorgrams.npz',time_s=t,concentration_nM=cs,binding_truth_RU=binding,active_RU=active,reference_RU=reference,blank_active_RU=blankactive,blank_reference_RU=blankref,corrected_RU=corrected,fitted_RU=prediction)
 for i,c in enumerate(cs):np.savetxt(a.output/f'sensorgram_{c:g}nM.csv',np.c_[t,active[i],reference[i],blankactive[i],blankref[i],corrected[i],prediction[i]],delimiter=',',header='time_s,active_RU,reference_RU,blank_active_RU,blank_reference_RU,corrected_RU,fitted_RU',comments='')
 np.savetxt(a.output/'transport.csv',np.c_[traces[0][0],*[arr for tt,yy in traces for arr in [yy[0],yy[1]*1e9]]],delimiter=',',header='time_s,high_slow_theta,high_slow_Cs_nM,high_fast_theta,high_fast_Cs_nM,low_slow_theta,low_slow_Cs_nM',comments='')
 summary={'fitted_kon_M_inv_s_inv':float(kon),'fitted_koff_s_inv':float(koff),'fitted_Kd_nM':float(kd),'fitted_capacity_RU':float(cap),'residual_RMS_RU':float(np.sqrt(np.mean((prediction-corrected)**2))),'half_life_s':float(np.log(2)/.002),'fast_half_life_s':float(np.log(2)/.02),'equilibrium_at_10nM_RU':60.,'response_at_180s_10nM_RU':float(response(180,10)),'premature_endpoint_Kd_nM':float(wrong[0]),'premature_endpoint_capacity_RU':float(wrong[1]),'premature_fixed_capacity_Kd_nM':float(earlyfixed[0]),'high_slow_retained_after_420s':float(traces[0][1][0,-1]/traces[0][1][0,180]),'no_rebinding_retained_after_420s':float(np.exp(-.002*420)),'high_slow_Cs_at_180s_nM':float(traces[0][1][1,180]*1e9)}
 (a.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
