# Public sources and third-party materials

- Harvard CMI: Surface plasmon resonance: https://cmi.hms.harvard.edu/surface-plasmon-resonance
  Technical/historical reference; no original artwork or measured data reproduced.
- Liedberg, Nylander & Lundström (1983): Surface plasmon resonance for gas detection and biosensing: https://bdt.semi.ac.cn/download/0.143812733726721.pdf
  Technical/historical reference; no original artwork or measured data reproduced.
- Biacore T200 Getting Started Handbook: https://cmi.hms.harvard.edu/sites/g/files/omnuum4016/files/cmi/files/biacoret200_gettingstarted_handbook.pdf
  Technical/historical reference; no original artwork or measured data reproduced.
- Cytiva: Kinetics and affinity measurements with Biacore systems: https://cdn.cytivalifesciences.com/api/public/content/digi-33041-pdf
  Technical/historical reference; no original artwork or measured data reproduced.
- Biacore Insight Evaluation Software User Manual, 29287248 AH: https://d3.cytivalifesciences.com/prod/IFU/29287248.pdf
  Technical/historical reference; no original artwork or measured data reproduced.
