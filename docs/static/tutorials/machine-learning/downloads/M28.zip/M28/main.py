"""A paired, controlled study of translation augmentation on public digits.

Dataset: E. Alpaydin and C. Kaynak, UCI Optical Recognition of Handwritten
Digits, DOI 10.24432/C50P49, CC BY 4.0. load_digits contains 1,797 images.
This study uses a new image-level split, not the original writer-level split.
"""
import argparse, csv, hashlib, json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC

SHIFTS=[(0,0),(0,-1),(0,1),(-1,0),(1,0)]
FAMILIES=['original','copies','shifted']

def canvases(images,shifts):
    """Pad to 10x10, translate at most one pixel, never crop ink."""
    result=[]
    for dy,dx in shifts:
        a=np.zeros((len(images),10,10))
        a[:,1+dy:9+dy,1+dx:9+dx]=images/16.0
        result.append(a.reshape(len(images),100))
    return np.concatenate(result)

def training_data(images,labels,family):
    shifts=SHIFTS if family=='shifted' else [(0,0)]*(5 if family=='copies' else 1)
    return canvases(images,shifts),np.tile(labels,len(shifts)),len(shifts)

def score(pred,y):return float(np.mean(pred==y))

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args()
    out=args.output;out.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'] if zh else ['DejaVu Sans'], 'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','axes.unicode_minus':False,'figure.facecolor':'white'})
    labels={'original':'原样本' if zh else 'Original','copies':'原样本复制5份' if zh else 'Five identical copies','shifted':'5种位置增广' if zh else 'Five translated views'}
    colors={'original':'#286d90','copies':'#a6afb4','shifted':'#bc6b31'}
    ds=load_digits();images=ds.images;y=ds.target;indices=np.arange(len(y))
    development,test=train_test_split(indices,test_size=450,random_state=2801,stratify=y)
    test_views=canvases(images[test],SHIFTS);test_y=np.tile(y[test],5)
    # Fixed gamma depends on input dimensions, not on an examined test distribution.
    # C/replicas keeps the sum-loss weight per original observation unchanged.
    candidates=[1.0,3.0,10.0];seeds=[11,29,47];records=[];predictions={};split_records=[];selection=[]
    for seed in seeds:
        train,valid=train_test_split(development,test_size=270,random_state=seed,stratify=y[development])
        split_records.append({'seed':seed,'train':train.tolist(),'validation':valid.tolist(),'test':test.tolist()})
        valid_x=canvases(images[valid],SHIFTS);valid_y=np.tile(y[valid],5)
        for family in FAMILIES:
            xtr,ytr,k=training_data(images[train],y[train],family)
            chosen=None
            for c in candidates:
                model=SVC(C=c/k,kernel='rbf',gamma=.05,tol=1e-5,cache_size=180)
                model.fit(xtr,ytr);acc=score(model.predict(valid_x),valid_y)
                selection.append({'seed':seed,'family':family,'C_base':c,'validation_accuracy':acc})
                if chosen is None or acc>chosen[0]:chosen=(acc,c)
            xdev,ydev,k=training_data(images[development],y[development],family)
            model=SVC(C=chosen[1]/k,kernel='rbf',gamma=.05,tol=1e-5,cache_size=180).fit(xdev,ydev)
            pred=model.predict(test_views).reshape(5,len(test));predictions[(seed,family)]=pred
            view_accuracy=(pred==y[test]).mean(axis=1)
            records.append({'seed':seed,'family':family,'C_base':chosen[1],'validation_accuracy':chosen[0],'center_accuracy':float(view_accuracy[0]),'five_view_accuracy':float(view_accuracy.mean()),'view_accuracy':view_accuracy.tolist(),'support_vectors':int(model.n_support_.sum())})
    base=predictions[(11,'original')]==y[test];aug=predictions[(11,'shifted')]==y[test]
    difference=aug.mean(axis=0)-base.mean(axis=0)
    rng=np.random.default_rng(2802);boot=difference[rng.integers(0,len(test),(3000,len(test)))].mean(axis=1)
    interval=np.quantile(boot,[.025,.975])
    right=2;a=base[right];b=aug[right]
    paired={'both_correct':int(np.sum(a&b)),'base_only':int(np.sum(a&~b)),'aug_only':int(np.sum(~a&b)),'both_wrong':int(np.sum(~a&~b))}
    summary={'n_images':len(y),'development':len(development),'test':len(test),'inner_train':1077,'inner_validation':270,'seeds':seeds,'candidates':candidates,'gamma':.05,'records':records,'selection':selection,'paired_right_shift_seed11':paired,'bootstrap_unit':'original test image, carrying all five views','delta_five_views_seed11':float(difference.mean()),'bootstrap_interval_seed11':interval.tolist(),'bootstrap_replicates':3000,'views_per_image':5,'ink_sum_error':float(np.max(np.abs(test_views.sum(axis=1)-np.tile(images[test].sum(axis=(1,2))/16,5)))),'development_test_overlap':len(set(development)&set(test)),'duplicate_prediction_disagreements':int(sum(np.sum(predictions[(s,'original')]!=predictions[(s,'copies')]) for s in seeds))}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    (out/'splits.json').write_text(json.dumps(split_records),encoding='utf8')
    np.savez_compressed(out/'predictions.npz',test_indices=test,labels=y[test],**{f'{s}_{f}':v for (s,f),v in predictions.items()})
    with (out/'results.csv').open('w',newline='',encoding='utf8') as f:
        keys=['seed','family','C_base','validation_accuracy','center_accuracy','five_view_accuracy','support_vectors'];writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader();writer.writerows({k:r[k] for k in keys} for r in records)
    (out/'data_fingerprint.txt').write_text(hashlib.sha256(images.astype('<f8').tobytes()+y.astype('<i8').tobytes()).hexdigest()+'\n',encoding='ascii')
    def save(fig,name):
        fig.savefig(out/f'{name}-{args.language}.svg',bbox_inches='tight');plt.close(fig)
    # Original images make the controlled intervention visible.
    fig,ax=plt.subplots(3,5,figsize=(11,6.6),layout='constrained')
    names=['中心','左移','右移','上移','下移'] if zh else ['Centered','Left','Right','Up','Down']
    chosen_images=[test[np.where(y[test]==label)[0][0]] for label in [3,6,8]]
    for row,index in enumerate(chosen_images):
        views=canvases(images[index:index+1],SHIFTS).reshape(5,10,10)
        for j in range(5):
            ax[row,j].imshow(views[j],cmap='gray_r',vmin=0,vmax=1,interpolation='nearest');ax[row,j].set_xticks([]);ax[row,j].set_yticks([])
            for sp in ax[row,j].spines.values():sp.set_visible(False)
            if row==0:ax[row,j].set_title(names[j])
            if j==0:ax[row,j].set_ylabel(('真值 ' if zh else 'Label ')+str(y[index]),fontsize=11)
    save(fig,'views')
    fig,axs=plt.subplots(1,3,figsize=(14,4.3),layout='constrained',gridspec_kw={'width_ratios':[1.3,1,1]})
    matrix=np.array([next(r for r in records if r['seed']==11 and r['family']==f)['view_accuracy'] for f in FAMILIES])
    im=axs[0].imshow(matrix,vmin=0,vmax=1,cmap='YlGnBu',aspect='auto');axs[0].set_xticks(range(5),names,rotation=25);axs[0].set_yticks(range(3),[labels[f] for f in FAMILIES]);axs[0].set_title('各位置正确率：选择划分11' if zh else 'Accuracy by view: selection split 11')
    for i in range(3):
        for j in range(5):axs[0].text(j,i,f'{matrix[i,j]*100:.1f}',ha='center',va='center',color='white' if matrix[i,j]>.65 else '#173d4c',fontsize=9)
    fig.colorbar(im,ax=axs[0],fraction=.045,pad=.02,label='正确率' if zh else 'Accuracy')
    for panel,metric,title in [(axs[1],'center_accuracy','中心图像' if zh else 'Centered images'),(axs[2],'five_view_accuracy','五位置平均' if zh else 'Average over five views')]:
        for s in seeds:
            values=[next(r for r in records if r['seed']==s and r['family']==f)[metric]*100 for f in FAMILIES]
            panel.plot(range(3),values,color='#bac5c9',linewidth=1,zorder=1)
        for i,f in enumerate(FAMILIES):
            values=[r[metric]*100 for r in records if r['family']==f];panel.scatter(np.full(3,i)+np.array([-.06,0,.06]),values,color=colors[f],s=35,zorder=2)
        panel.set_xticks(range(3),[labels[f] for f in FAMILIES],rotation=22,ha='right');panel.set_ylabel('正确率 / %' if zh else 'Accuracy / %');panel.set_ylim(0,102);panel.grid(axis='y',alpha=.15);panel.set_title(title)
    save(fig,'comparison')
    fig=plt.figure(figsize=(13,6.5),layout='constrained');gs=fig.add_gridspec(2,4,height_ratios=[1.1,1])
    ax=fig.add_subplot(gs[0,:2]);ax.hist(boot*100,bins=35,color='#468596',edgecolor='white');ax.axvline(difference.mean()*100,color='#bb6736',linewidth=2);ax.axvline(interval[0]*100,color='#546870',ls='--');ax.axvline(interval[1]*100,color='#546870',ls='--');ax.set_xlabel('增广 − 原样本 / 百分点' if zh else 'Augmented − original / percentage points');ax.set_ylabel('重采样次数' if zh else 'Bootstrap draws');ax.set_title('以原始图像为重采样单位' if zh else 'Resample original images with their five views')
    ax=fig.add_subplot(gs[0,2:]);counts=np.array([[paired['both_correct'],paired['base_only']],[paired['aug_only'],paired['both_wrong']]])
    ax.imshow(counts,cmap='Blues',vmin=0,vmax=450);ax.set_xticks([0,1],['增广正确','增广错误'] if zh else ['Augmented correct','Augmented wrong']);ax.set_yticks([0,1],['基线正确','基线错误'] if zh else ['Baseline correct','Baseline wrong'])
    for i in range(2):
        for j in range(2):ax.text(j,i,str(counts[i,j]),ha='center',va='center',fontsize=20,color='white' if counts[i,j]>225 else '#18384a')
    ax.set_title('同450张右移图像的成对结果' if zh else 'Paired outcomes on the same 450 right-shifted images')
    groups=[np.where(~a&b)[0],np.where(a&~b)[0],np.where(~a&~b)[0],np.where(a&b)[0]]
    names2=['增广修复','增广新错','共同错误','共同正确'] if zh else ['Corrected by augmentation','New augmentation error','Both wrong','Both correct']
    for j,group in enumerate(groups):
        ax=fig.add_subplot(gs[1,j]);ax.set_xticks([]);ax.set_yticks([])
        if len(group):
            idx=group[0];ax.imshow(test_views[right*len(test)+idx].reshape(10,10),cmap='gray_r',vmin=0,vmax=1);ax.set_xlabel(('真值 / 基线 / 增广 = ' if zh else 'True / baseline / augmented = ')+f'{y[test[idx]]} / {predictions[(11,"original")][right,idx]} / {predictions[(11,"shifted")][right,idx]}',fontsize=9)
        else:ax.text(.5,.5,'本组0张' if zh else 'No images in this group',ha='center',va='center',transform=ax.transAxes)
        ax.set_title(names2[j],fontsize=10)
    save(fig,'paired')
    print(json.dumps({'records':records,'delta':summary['delta_five_views_seed11'],'interval':interval.tolist(),'paired':paired,'copies_disagree':summary['duplicate_prediction_disagreements']},ensure_ascii=False))
if __name__=='__main__':main()
