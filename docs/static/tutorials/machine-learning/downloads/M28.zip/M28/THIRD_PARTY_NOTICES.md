# Public sources and third-party materials

- Improving Reproducibility in Machine Learning Research: https://jmlr.org/papers/v22/20-303.html
  Public technical reference; explanatory text and experiment independently written.
- Dive into Deep Learning — Image Augmentation: https://d2l.ai/chapter_computer-vision/image-augmentation.html
  Public technical reference; explanatory text and experiment independently written.
- Optical Recognition of Handwritten Digits: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits
  Data CC BY 4.0; original digit attribution retained.
- scikit-learn — load_digits: https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html
  Public technical reference; explanatory text and experiment independently written.
- scikit-learn — Support Vector Machines: https://scikit-learn.org/stable/modules/svm.html
  Public technical reference; explanatory text and experiment independently written.
- scikit-learn — Common Pitfalls: https://scikit-learn.org/stable/common_pitfalls.html
  Public technical reference; explanatory text and experiment independently written.
- NeurIPS Paper Checklist: https://neurips.cc/public/guides/PaperChecklist
  Public technical reference; explanatory text and experiment independently written.
