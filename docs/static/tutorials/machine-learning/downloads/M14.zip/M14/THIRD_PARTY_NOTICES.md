# Public sources and third-party materials

- OpenCV Camera Calibration and 3D Reconstruction: https://docs.opencv.org/4.x/d9/d0c/group__calib3d.html
  Technical reference; source figures linked, not reproduced.
- Structure-from-Motion Revisited: https://demuc.de/papers/schoenberger2016sfm.pdf
  Technical reference; source figures linked, not reproduced.
- NeRF: Representing Scenes as Neural Radiance Fields for View Synthesis: https://arxiv.org/abs/2003.08934
  Technical reference; source figures linked, not reproduced.
- Nerfstudio — Nerfacto: https://docs.nerf.studio/nerfology/methods/nerfacto.html
  Technical reference; source figures linked, not reproduced.
- 3D Gaussian Splatting for Real-Time Radiance Field Rendering: https://repo-sam.inria.fr/fungraph/3d-gaussian-splatting/
  Technical reference; source figures linked, not reproduced.
- PointNet: Deep Learning on Point Sets for 3D Classification and Segmentation: https://arxiv.org/abs/1612.00593
  Technical reference; source figures linked, not reproduced.
