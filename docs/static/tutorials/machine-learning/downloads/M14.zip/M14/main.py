"""Camera geometry, volume compositing, and a PointNet-style classifier."""
import argparse
import copy
import json
from pathlib import Path
import numpy as np
import torch
from torch import nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

torch.set_num_threads(2)


def clouds(count, seed):
    rng=np.random.default_rng(seed);points=[];labels=np.arange(count)%2
    for label in labels:
        if label==0:
            p=rng.normal(size=(64,3));p/=np.linalg.norm(p,axis=1,keepdims=True)
        else:
            p=rng.uniform(-1,1,(64,3));axes=rng.integers(0,3,64)
            p[np.arange(64),axes]=rng.choice([-1,1],64)
        rotation,_=np.linalg.qr(rng.normal(size=(3,3)))
        p=p@rotation;p-=p.mean(0);p/=np.linalg.norm(p,axis=1).max()
        points.append(p)
    return np.array(points,dtype=np.float32),labels


class PointModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.point=nn.Sequential(nn.Linear(3,32),nn.ReLU(),nn.Linear(32,64),nn.ReLU())
        self.readout=nn.Sequential(nn.Linear(64,32),nn.ReLU(),nn.Linear(32,2))
    def forward(self,x):
        return self.readout(self.point(x).amax(dim=1))


def scene(points):
    centers=np.array([[-.35,0,0],[.35,.12,.08]])
    sizes=np.array([.23,.19]);colors=np.array([[.82,.25,.18],[.12,.42,.75]])
    components=16*np.exp(-.5*np.square((points[...,None,:]-centers)/sizes[:,None]).sum(-1))
    sigma=components.sum(-1)
    color=(components[...,None]*colors).sum(-2)/(sigma[...,None]+1e-15)
    return sigma,color


def render(angle, samples, resolution=48):
    origin=np.array([2.8*np.cos(angle),1.,2.8*np.sin(angle)])
    forward=-origin/np.linalg.norm(origin)
    right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right)
    up=np.cross(right,forward)
    q=(np.arange(resolution)+.5-resolution/2)/(resolution/2)
    xx,yy=np.meshgrid(q,-q)
    direction=1.8*forward+xx[...,None]*right+yy[...,None]*up
    direction/=np.linalg.norm(direction,axis=-1,keepdims=True)
    edges=np.linspace(1,5,samples+1);t=(edges[:-1]+edges[1:])/2;delta=np.diff(edges)
    points=origin+direction[:,:,None,:]*t[None,None,:,None]
    sigma,color=scene(points);alpha=-np.expm1(-sigma*delta)
    trans=np.concatenate([np.ones((*alpha.shape[:2],1)),np.cumprod(1-alpha,axis=-1)[...,:-1]],axis=-1)
    weights=trans*alpha;remaining=np.prod(1-alpha,axis=-1)
    rgb=(weights[...,None]*color).sum(-2)+remaining[...,None]
    opacity=weights.sum(-1)
    depth=(weights*t).sum(-1)/(opacity+1e-12)
    conservation=float(np.max(np.abs(opacity+remaining-1)))
    return rgb,depth,opacity,conservation


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
    def txt(ch,en):return ch if zh else en
    plt.rcParams.update({'font.family':'Microsoft YaHei' if zh else 'Arial','font.size':10,
                         'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg',bbox_inches='tight')
        fig.savefig(args.output/f'{name}-{args.language}.png',dpi=140,bbox_inches='tight');plt.close(fig)
    torch.manual_seed(14)
    tx,ty=clouds(160,10);vx,vy=clouds(40,20);ex,ey=clouds(60,30)
    tx,ty,vx,vy=map(torch.tensor,[tx,ty,vx,vy]);model=PointModel()
    optimizer=torch.optim.Adam(model.parameters(),lr=.003);history=[];best=float('inf')
    for epoch in range(80):
        model.train();losses=[]
        for ids in torch.randperm(160).split(20):
            optimizer.zero_grad();loss=nn.functional.cross_entropy(model(tx[ids]),ty[ids])
            loss.backward();optimizer.step();losses.append(loss.item())
        model.eval()
        with torch.no_grad():val=nn.functional.cross_entropy(model(vx),vy).item()
        history.append([np.mean(losses),val])
        if val<best:best=val;checkpoint=copy.deepcopy(model.state_dict())
    model.load_state_dict(checkpoint);model.eval()
    with torch.no_grad():
        test=torch.tensor(ex);logits=model(test);prediction=logits.argmax(1).numpy()
        permutation=torch.tensor(np.random.default_rng(17).permutation(64))
        permutation_error=float((model(test[:,permutation])-logits).abs().max())
    angles=[0,.8,1.6];renders=[render(a,96) for a in angles]
    reference=render(.8,256)[0];sample_counts=[8,16,32,64,96]
    errors=[float(np.sqrt(np.mean((render(.8,n)[0]-reference)**2))) for n in sample_counts]
    conservation=max(r[3] for r in renders)
    focal,baseline,depth=800.,.12,3.
    disparity=focal*baseline/depth
    recovered=focal*baseline/disparity
    # Front-to-back red and blue layers, both with opacity one half.
    red=np.array([1.,0,0]);blue=np.array([0.,0,1]);white=np.ones(3)
    red_first=.5*red+.5*.5*blue+.25*white
    blue_first=.5*blue+.5*.5*red+.25*white
    summary={'test_pointclouds':60,'test_accuracy':float(np.mean(prediction==ey)),
             'permutation_max_error':permutation_error,'selected_epoch':int(np.argmin(np.array(history)[:,1])+1),
             'compositing_conservation_error':conservation,'stereo_disparity_px':disparity,
             'recovered_depth_m':recovered,'sample_counts':sample_counts,'rgb_rmse_to_256_samples':errors,
             'red_front_rgb':red_first.tolist(),'blue_front_rgb':blue_first.tolist()}
    assert permutation_error<1e-6 and conservation<1e-12
    assert abs(recovered-3)<1e-12
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    np.savez(args.output/'data.npz',test_clouds=ex,test_labels=ey,prediction=prediction,history=history,
             view_rgb=np.array([r[0] for r in renders]),view_depth=np.array([r[1] for r in renders]),
             view_opacity=np.array([r[2] for r in renders]),samples=sample_counts,rmse=errors)
    fig=plt.figure(figsize=(12,4.3));gs=fig.add_gridspec(1,3,width_ratios=[1.1,1,1])
    ax=fig.add_subplot(gs[0]);zs=np.linspace(.8,8,150);ds=focal*baseline/zs
    ax.plot(zs,ds,color='#176b91');ax.scatter([3],[32],color='#bb554d',zorder=3)
    ax.annotate('3 m → 32 px',(3,32),xytext=(3.4,65),arrowprops={'arrowstyle':'->'})
    ax.set(xlabel=txt('深度 / m','Depth / m'),ylabel=txt('视差 / px','Disparity / px'),title=txt('固定焦距800 px，基线0.12 m','Focal length 800 px; baseline 0.12 m'))
    for k in range(2):
        ax=fig.add_subplot(gs[k+1],projection='3d');p=ex[k]
        ax.scatter(*p.T,c=p[:,2],cmap='viridis',s=15,vmin=-1,vmax=1)
        ax.set(xlim=(-1,1),ylim=(-1,1),zlim=(-1,1),xlabel='x',ylabel='y',zlabel='z',title=txt(['球面点集','立方体表面点集'][k],['Sphere points','Cube-surface points'][k]))
        ax.set_box_aspect((1,1,1));ax.view_init(22,35)
        ax.set_xticks([-1,0,1]);ax.set_yticks([-1,0,1]);ax.set_zticks([-1,0,1])
    fig.tight_layout();save(fig,'geometry')
    fig,axs=plt.subplots(2,3,figsize=(12,7))
    for j,angle in enumerate(angles):
        rgb,dep,opacity,_=renders[j]
        axs[0,j].imshow(rgb);axs[0,j].set_title(txt(f'相机方位 {angle:.1f} rad',f'Camera azimuth {angle:.1f} rad'))
        masked=np.ma.masked_where(opacity<.05,dep)
        im=axs[1,j].imshow(masked,cmap='viridis',vmin=2,vmax=4)
        axs[1,j].set_title(txt('条件加权射线距离 / 单位长度','Conditional ray distance / length units'))
        for i in range(2):axs[i,j].set_xticks([]);axs[i,j].set_yticks([])
    fig.colorbar(im,ax=axs[1,:],shrink=.65,label=txt('射线距离','Ray distance'))
    save(fig,'views')
    fig=plt.figure(figsize=(12,6));gs=fig.add_gridspec(2,3,width_ratios=[1.3,1,1])
    ax=fig.add_subplot(gs[:,0]);hist=np.array(history)
    ax.plot(np.arange(1,81),hist[:,0],label=txt('训练','Training'),color='#176b91')
    ax.plot(np.arange(1,81),hist[:,1],label=txt('验证','Validation'),color='#bb554d')
    ax.set(xlabel=txt('轮数','Epoch'),ylabel=txt('交叉熵','Cross-entropy'),title=txt('共享逐点网络与最大值读出','Shared point network and max readout'));ax.legend()
    ax=fig.add_subplot(gs[0,1]);conf=np.zeros((2,2),int)
    for y,p in zip(ey,prediction):conf[y,p]+=1
    ax.imshow(conf,cmap='Blues',vmin=0,vmax=30)
    for i in range(2):
        for j in range(2):ax.text(j,i,str(conf[i,j]),ha='center',va='center',color='white' if conf[i,j]>15 else 'black')
    ax.set(xticks=[0,1],yticks=[0,1],xlabel=txt('预测类别','Predicted class'),ylabel=txt('真实类别','True class'))
    ax=fig.add_subplot(gs[1,1]);ax.semilogy(sample_counts,errors,'o-',color='#176b91')
    ax.set(xlabel=txt('每射线采样数','Samples per ray'),ylabel='RGB RMSE',title=txt('对照256采样','Reference: 256 samples'))
    ax=fig.add_subplot(gs[0,2]);ax.imshow(np.tile(red_first,(30,30,1)));ax.set_title(txt('红在前，蓝在后','Red in front of blue'));ax.axis('off')
    ax=fig.add_subplot(gs[1,2]);ax.imshow(np.tile(blue_first,(30,30,1)));ax.set_title(txt('蓝在前，红在后','Blue in front of red'));ax.axis('off')
    fig.tight_layout();save(fig,'results')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
