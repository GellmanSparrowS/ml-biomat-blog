"""Neural energies, positive/negative phases, and honest sampling diagnostics."""
from pathlib import Path
import argparse,json,math,copy,platform
import numpy as np
import torch
from torch import nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
def tr(z,e):return z if zh else e
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','svg.fonttype':'none'})
def save(fig,name):fig.savefig(out/f'{name}-{args.language}.svg',bbox_inches='tight');plt.close(fig)
centers=np.array([[-1.2,-1.2],[1.2,-1.2],[1.2,1.2],[-1.2,1.2]]);weights=np.array([.55,.25,.15,.05]);sigma=.32;variance=sigma*sigma
signs=np.array([[-1,-1],[1,-1],[1,1],[-1,1]]);quadrant_weights=np.array([sum(w*math.prod(.5*(1+math.erf(float(sign[j]*mu[j])/(sigma*math.sqrt(2)))) for j in range(2)) for w,mu in zip(weights,centers)) for sign in signs])
def sample_data(n,seed):
 r=np.random.default_rng(seed);labels=r.choice(4,n,p=weights);return (centers[labels]+r.normal(0,sigma,(n,2))).astype('float32'),labels
def true_energy_gradient(x):
 delta=x[:,None]-centers[None];logterms=np.log(weights)[None]-np.sum(delta*delta,2)/(2*variance)-math.log(2*math.pi*variance);maximum=logterms.max(1,keepdims=True);responsibility=np.exp(logterms-maximum);total=responsibility.sum(1,keepdims=True);e=-maximum[:,0]-np.log(total[:,0]);responsibility/=total;gradient=(responsibility[:,:,None]*delta).sum(1)/variance;return e,gradient
train,train_labels=sample_data(4096,400);valid,valid_labels=sample_data(1024,401);test,test_labels=sample_data(1024,402);xt=torch.tensor(train)
class Energy(nn.Module):
 def __init__(self):
  super().__init__();self.net=nn.Sequential(nn.Linear(2,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,1))
 def forward(self,x):return self.net(x).flatten()+.5*x.square().sum(1)
def midpoint_grid(limit,n):
 a=-limit+(np.arange(n)+.5)*(2*limit/n);xx,yy=np.meshgrid(a,a);return np.c_[xx.ravel(),yy.ravel()].astype('float32'),(2*limit/n)**2
grid_train,cell_train=midpoint_grid(4,48);grid_eval,cell_eval=midpoint_grid(4,160);gt=torch.tensor(grid_train);ge=torch.tensor(grid_eval)
def logZ(m,g,cell):return torch.logsumexp(-m(g),0)+math.log(cell)
def langevin_torch(m,x,steps,h,rng):
 for _ in range(steps):
  x=x.detach().requires_grad_(True);gradient=torch.autograd.grad(m(x).sum(),x)[0];x=(x-h*gradient+math.sqrt(2*h)*torch.randn(x.shape,generator=rng)).detach()
 return x
models={};histories={};training={}
for name,seed in [('GridMLE',403),('PCD20',404)]:
 torch.manual_seed(seed);m=Energy();opt=torch.optim.Adam(m.parameters(),lr=.001);rng=torch.Generator().manual_seed(seed+100);buffer=1.5*torch.randn((1024,2),generator=rng);history=[];best=float('inf');best_state=None
 for step in range(1,2001):
  idx=torch.randint(len(xt),(128,),generator=rng);positive=m(xt[idx]);negative_mean=0.
  if name=='GridMLE':loss=positive.mean()+logZ(m,gt,cell_train)
  else:
   ids=torch.randperm(len(buffer),generator=rng)[:128];negative=buffer[ids].clone();restart=torch.rand((128,),generator=rng)<.05;negative[restart]=1.5*torch.randn((int(restart.sum()),2),generator=rng);negative=langevin_torch(m,negative,20,.02,rng);buffer[ids]=negative;negative_energy=m(negative.detach());negative_mean=negative_energy.mean().item();loss=positive.mean()-negative_energy.mean()
  opt.zero_grad();loss.backward();opt.step()
  if step%100==0:
   with torch.no_grad():z=logZ(m,ge,cell_eval);validation_nll=(m(torch.tensor(valid)).mean()+z).item()
   history.append([step,loss.item(),validation_nll,positive.mean().item(),negative_mean])
   if validation_nll<best:best=validation_nll;best_step=step;best_state=copy.deepcopy(m.state_dict())
 m.load_state_dict(best_state);m.eval();models[name]=m;histories[name]=history;training[name]=dict(updates=2000,best_step=best_step,validation_window_nll=best,parameters=sum(p.numel() for p in m.parameters()),seed=seed);torch.save(dict(model=m.state_dict(),best_step=best_step),out/f'{name.lower()}.pt')
def model_eg(m,x):
 a=torch.tensor(x,dtype=torch.float32,requires_grad=True);e=m(a);g=torch.autograd.grad(e.sum(),a)[0];return e.detach().numpy().astype('float64'),g.detach().numpy().astype('float64')
def quadrants(x):return np.where(x[:,1]<0,np.where(x[:,0]<0,0,1),np.where(x[:,0]>0,2,3))
def chain(eg,h,steps,initial,seed,method='ULA',record_every=10):
 rng=np.random.default_rng(seed);x=np.array(initial,dtype='float64');path=[x.copy()];accepted=0;switches=np.zeros(len(x),dtype=int);counts=np.zeros(4,dtype='int64');occupancies=[];e,g=eg(x)
 for step in range(1,steps+1):
  proposal=x-h*g+math.sqrt(2*h)*rng.normal(size=x.shape);pe,pg=eg(proposal)
  if method=='MALA':
   forward=np.sum((proposal-x+h*g)**2,1)/(4*h);backward=np.sum((x-proposal+h*pg)**2,1)/(4*h);logratio=-pe+e+forward-backward;accept=np.log(rng.uniform(size=len(x)))<np.minimum(0,logratio)
  else:accept=np.ones(len(x),dtype=bool)
  previous=quadrants(x);x[accept]=proposal[accept];e[accept]=pe[accept];g[accept]=pg[accept];accepted+=int(accept.sum());switches+=(previous!=quadrants(x))
  if step>steps//2:counts+=np.bincount(quadrants(x),minlength=4)
  if step%record_every==0:path.append(x.copy());occupancies.append(np.bincount(quadrants(x),minlength=4)/len(x))
 return x,np.array(path),dict(acceptance=accepted/(steps*len(x)),final_weights=(np.bincount(quadrants(x),minlength=4)/len(x)).tolist(),second_half_weights=(counts/counts.sum()).tolist(),total_variation=float(.5*np.abs(counts/counts.sum()-quadrant_weights).sum()),chains_ever_switched=float((switches>0).mean()),mean_switches=float(switches.mean()),steps=steps,h=h,method=method),np.array(occupancies)
initials=dict(one=np.repeat(centers[:1],128,axis=0),spread=centers[np.arange(128)%4].copy());runs={};paths={};occupancies={}
for name,h,initial,method in [('small_one',.005,'one','ULA'),('small_spread',.005,'spread','ULA'),('medium_spread',.04,'spread','ULA'),('large_spread',.16,'spread','ULA'),('mala_spread',.16,'spread','MALA')]:
 x,path,stat,occ=chain(true_energy_gradient,h,2000,initials[initial],405,method);runs[name]=stat;paths[name]=path;occupancies[name]=occ
model_stats={};densities={};neural_paths={};neural_samples={};initial_rng=np.random.default_rng(406);neural_initial=initial_rng.normal(0,1.5,(512,2))
for name,m in models.items():
 with torch.no_grad():eg=m(ge).numpy().astype('float64');z=logZ(m,ge,cell_eval).item();density=np.exp(-eg-z);test_nll=float(m(torch.tensor(test)).mean()+z)
 density_weights=np.array([density[quadrants(grid_eval)==c].sum()*cell_eval for c in range(4)]);densities[name]=dict(energy=eg,density=density)
 x,path,stat,_=chain(lambda a:model_eg(m,a),.03,1000,neural_initial,407,'MALA',20);neural_paths[name]=path;neural_samples[name]=x
 extended,extended_cell=midpoint_grid(6,240)
 with torch.no_grad():extended_logz=logZ(m,torch.tensor(extended),extended_cell).item();fine,fc=midpoint_grid(4,240);fine_logz=logZ(m,torch.tensor(fine),fc).item()
 stat['TV_from_model_quadrature']=float(.5*np.abs(np.array(stat['second_half_weights'])-density_weights).sum())
 model_stats[name]=dict(window_test_nll=test_nll,logZ_window=z,normalization_sum=float(density.sum()*cell_eval),quadrant_mass=density_weights.tolist(),quadrant_mass_TV=float(.5*np.abs(density_weights-quadrant_weights).sum()),window_logZ_refinement=abs(fine_logz-z),extended_logZ_difference=extended_logz-z,sampling=stat)
# Analytic CD1 fixed point for a Gaussian energy, and sampled denoising-score regression.
r=np.random.default_rng(408);clean=r.normal(size=200000);eps=r.normal(size=len(clean));noise_sigma=.5;noisy=clean+noise_sigma*eps;dsm_a=float(np.dot(noisy,eps/noise_sigma)/np.dot(noisy,noisy));h=.1;cd_precision=(1-math.sqrt(1-2*h))/h;cd_step=(1-h*cd_precision)*clean+math.sqrt(2*h)*r.normal(size=len(clean));gpoints=np.array([[.3,.7],[-.2,-1.1],[1.3,.9]]);analytic=true_energy_gradient(gpoints)[1];finite=np.empty_like(analytic)
for j in range(2):
 offset=np.zeros_like(gpoints);offset[:,j]=1e-5;finite[:,j]=(true_energy_gradient(gpoints+offset)[0]-true_energy_gradient(gpoints-offset)[0])/(2e-5)
single=np.array([[.5,-.25]]);neural_energy,neural_grad=model_eg(models['GridMLE'],single)
summary=dict(versions=dict(python=platform.python_version(),torch=torch.__version__,numpy=np.__version__),data=dict(train=4096,validation=1024,test=1024,weights=weights.tolist(),quadrant_weights=quadrant_weights.tolist(),sigma=sigma,seeds=[400,401,402]),training=training,models=model_stats,known_target_chains=runs,score_matching=dict(noise_sigma=noise_sigma,fit_precision=dsm_a,true_smoothed_precision=.8,samples=len(clean)),hand=dict(two_state_probability=[2/3,1/3],probability_ratio=2.,constant_shift=7.,cd1_precision=cd_precision,cd1_model_variance=1/cd_precision,cd1_actual_step_variance=float(cd_step.var()),true_gradient_max_error=float(np.max(np.abs(analytic-finite))),neural_probe_energy=float(neural_energy[0]),neural_probe_gradient=neural_grad[0].tolist()),domain=dict(training_window=[-4,4],training_grid=48,evaluation_grid=160,refinement_grid=240,extended_window=[-6,6]))
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');np.savez_compressed(out/'experiment.npz',train=train,train_labels=train_labels,validation=valid,test=test,grid=grid_eval,true_density=np.exp(-true_energy_gradient(grid_eval)[0]),clean_score_samples=clean,noisy_score_samples=noisy,score_noise=eps,cd1_samples=cd_step,neural_initial=neural_initial,**{n+'_history':np.array(v) for n,v in histories.items()},**{n+'_energy':d['energy'] for n,d in densities.items()},**{n+'_density':d['density'] for n,d in densities.items()},**{n+'_samples':v for n,v in neural_samples.items()},**{n+'_chain':v for n,v in paths.items()},**{n+'_occupancy':v for n,v in occupancies.items()},**{n+'_neural_chain':v for n,v in neural_paths.items()})
lab_grid,lab_cell=midpoint_grid(4,60);known_e=true_energy_gradient(lab_grid)[0];learned_e=model_eg(models['GridMLE'],lab_grid)[0];lab=dict(centers=centers.tolist(),weights=weights.tolist(),variance=variance,grid=lab_grid.tolist(),cell=lab_cell,quadrant_weights=quadrant_weights.tolist(),learned_quadrant_weights=model_stats['GridMLE']['quadrant_mass'],energies={'True':known_e.tolist(),'Learned':learned_e.tolist()},logZ={'True':0.,'Learned':model_stats['GridMLE']['logZ_window']},network={k:v.detach().numpy().tolist() for k,v in models['GridMLE'].state_dict().items()});(out/'lab-data.json').write_text(json.dumps(lab,separators=(',',':')),encoding='utf-8')
fig=plt.figure(figsize=(13,4.8),layout='constrained');ax=fig.add_subplot(131,projection='3d');small,_=midpoint_grid(3,70);truee=true_energy_gradient(small)[0];xx=small[:,0].reshape(70,70);yy=small[:,1].reshape(70,70);ax.plot_surface(xx,yy,(truee-truee.min()).reshape(70,70),cmap='viridis',linewidth=0,rasterized=True);ax.set(xlabel='x1',ylabel='x2',zlabel='',title=tr('A  已知目标：相对能量','A  Target: relative energy'));ax.view_init(35,-55)
for j,name in enumerate(['GridMLE','PCD20']):
 ax=fig.add_subplot(1,3,j+2);im=ax.imshow(densities[name]['density'].reshape(160,160),origin='lower',extent=(-4,4,-4,4),cmap='YlGnBu',vmin=0,vmax=1);ax.scatter(test[:150,0],test[:150,1],s=3,color='#b96f3b',alpha=.35);ax.set(xlabel='x1',ylabel='x2',title=name+tr('：窗口归一化密度',': window-normalized density'));fig.colorbar(im,ax=ax,label=tr('每单位面积密度','Density per unit area'),shrink=.65)
save(fig,'landscape')
fig,axs=plt.subplots(1,3,figsize=(13,4.3),layout='constrained')
for name,color in [('GridMLE','#125f82'),('PCD20','#bf7139')]:
 hh=np.array(histories[name]);axs[0].plot(hh[:,0],hh[:,2],label=name,color=color)
axs[0].set(xlabel=tr('参数更新次数','Parameter updates'),ylabel=tr('验证窗口负对数密度','Validation window NLL'),title=tr('A  统一验证尺度','A  Shared validation measure'));axs[0].legend(fontsize=9)
ind=np.arange(4);axs[1].bar(ind-.25,quadrant_weights,.25,label=tr('目标','Target'),color='#526b59');axs[1].bar(ind,model_stats['GridMLE']['quadrant_mass'],.25,label='GridMLE',color='#125f82');axs[1].bar(ind+.25,model_stats['PCD20']['quadrant_mass'],.25,label='PCD20',color='#bf7139');axs[1].set(xticks=ind,xlabel=tr('象限类别','Quadrant class'),ylabel=tr('概率质量','Probability mass'),title=tr('B  网格积分得到的质量','B  Mass from quadrature'));axs[1].legend(fontsize=8)
axs[2].scatter(*neural_samples['GridMLE'].T,s=5,alpha=.45,color='#125f82');axs[2].set(xlim=(-4,4),ylim=(-4,4),xlabel='x1',ylabel='x2',title=tr('C  GridMLE的512条MALA终点','C  512 MALA endpoints for GridMLE'));axs[2].set_aspect('equal');save(fig,'learning')
labels={'small_one':tr('ULA h=0.005，单谷起点','ULA h=0.005, one valley'),'small_spread':tr('ULA h=0.005，四谷均分','ULA h=0.005, spread'),'medium_spread':tr('ULA h=0.04，四谷均分','ULA h=0.04, spread'),'large_spread':tr('ULA h=0.16，四谷均分','ULA h=0.16, spread'),'mala_spread':tr('MALA h=0.16，四谷均分','MALA h=0.16, spread')}
fig,axs=plt.subplots(2,3,figsize=(13,7.4),layout='constrained');names=list(runs)
for ax,name in zip(axs.flat,names):
 pp=paths[name];ax.plot(pp[:,0,0],pp[:,0,1],lw=.8,color='#bf7139',alpha=.8);ax.scatter(*pp[-1].T,s=6,color='#125f82',alpha=.6);ax.scatter(*centers.T,marker='+',color='#111',s=55);ax.set(xlim=(-4,4),ylim=(-4,4),xlabel='x1',ylabel='x2',title=f"{labels[name]}\nTV={runs[name]['total_variation']:.3f}");ax.set_aspect('equal')
axs[1,2].axis('off');axs[1,2].bar(np.arange(4),quadrant_weights,color=['#125f82','#bf7139','#63864b','#755c8b']);axs[1,2].axis('on');axs[1,2].set(xticks=range(4),xlabel=tr('象限类别','Quadrant class'),ylabel=tr('真实概率质量','True mass'),title=tr('已知目标：0.55 / 0.25 / 0.15 / 0.05','Known target: 0.55 / 0.25 / 0.15 / 0.05'));save(fig,'mixing')
fig,axs=plt.subplots(1,3,figsize=(13,4.2),layout='constrained')
for name,color in [('small_one','#125f82'),('small_spread','#bf7139'),('mala_spread','#63864b')]:
 occ=occupancies[name];axs[0].plot(np.arange(1,len(occ)+1)*10,occ[:,0],label=labels[name],color=color)
axs[0].axhline(quadrant_weights[0],color='#333',ls='--');axs[0].set(xlabel=tr('采样步数','Sampling steps'),ylabel=tr('最重象限的链比例','Fraction of chains in heaviest quadrant'),title=tr('A  初始化影响多久','A  Persistence of initialization'));axs[0].legend(fontsize=8)
for name,color in [('small_spread','#bf7139'),('mala_spread','#63864b')]:
 values=paths[name][:,0,0].copy();values-=values.mean();denom=np.dot(values,values);corr=[np.dot(values[:len(values)-lag],values[lag:])/denom if denom else float('nan') for lag in range(41)];axs[1].plot(np.arange(41)*10,corr,color=color,label=labels[name])
axs[1].set(xlabel=tr('间隔 / 采样步','Lag / sampling steps'),ylabel=tr('首链x1自相关','First-chain x1 autocorrelation'),title=tr('B  相邻样本的依赖','B  Dependence of successive samples'));axs[1].legend(fontsize=8)
q=np.linspace(-3,3,200);axs[2].plot(q,-q,label=tr('干净N(0,1) score','Clean N(0,1) score'),color='#bf7139');axs[2].plot(q,-.8*q,label=tr('加噪真实score','True noisy score'),color='#333');axs[2].plot(q,-dsm_a*q,'--',label=tr('DSM回归','DSM regression'),color='#125f82');axs[2].set(xlabel='x',ylabel='score',title=tr('C  去噪学习的是平滑密度','C  Denoising learns a smoothed density'));axs[2].legend(fontsize=8);save(fig,'diagnostics');print(json.dumps(summary,indent=2))
