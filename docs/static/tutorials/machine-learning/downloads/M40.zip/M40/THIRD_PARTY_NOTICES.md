# Public sources and third-party materials

- UvA Deep Learning Tutorials: Deep Energy-Based Models: https://uvadlc-notebooks.readthedocs.io/en/latest/tutorial_notebooks/tutorial8/Deep_Energy_Models.html
  MIT, Copyright 2020 Phillip Lippe; original notebook output; external attributed figures excluded
- Estimation of Non-Normalized Statistical Models by Score Matching: https://jmlr.org/papers/v6/hyvarinen05a.html
  Primary paper reference; no copied figures
- A Connection Between Score Matching and Denoising Autoencoders: https://www-labs.iro.umontreal.ca/~vincentp/Publications/DenoisingScoreMatching_NeuralComp2011.pdf
  Author-hosted primary paper; no copied figures
- Training Products of Experts by Minimizing Contrastive Divergence: https://www.cs.toronto.edu/~hinton/absps/tr00-004.pdf
  Author-hosted technical report; no copied figures
- Implicit Generation and Generalization in Energy-Based Models: https://arxiv.org/html/1903.08689v2
  Primary paper reference; independent experiment
- Exponential Convergence of Langevin Distributions and Their Discrete Approximations: https://stat.duke.edu/~scs/Courses/Stat376/Papers/ConvergeRates/GeneralState/RobertsTweedie1996.pdf
  Primary paper reference; no copied figures
- Your Classifier is Secretly an Energy Based Model and You Should Treat it Like One: https://arxiv.org/abs/1912.03263
  Primary paper reference; no copied figures
