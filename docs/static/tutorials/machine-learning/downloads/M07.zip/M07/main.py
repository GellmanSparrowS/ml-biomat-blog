"""Bayesian updates, hierarchy, exact messages, sampling, variational inference and GP."""
from pathlib import Path
import argparse,json,itertools
import numpy as np
from scipy.stats import beta,betabinom,binom,norm,multivariate_normal
from scipy.special import betaln,logsumexp,expit
from scipy.optimize import minimize
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF

def hmm(observations,A,B,pi):
 n=len(observations);forward=np.zeros((n,2));scale=np.zeros(n);forward[0]=pi*B[:,observations[0]];scale[0]=forward[0].sum();forward[0]/=scale[0]
 for t in range(1,n):forward[t]=(forward[t-1]@A)*B[:,observations[t]];scale[t]=forward[t].sum();forward[t]/=scale[t]
 backward=np.ones((n,2))
 for t in range(n-2,-1,-1):backward[t]=A@(B[:,observations[t+1]]*backward[t+1])/scale[t+1]
 smooth=forward*backward;smooth/=smooth.sum(1,keepdims=True)
 return forward,smooth,float(np.prod(scale))

def ess_one(x):
 x=x-x.mean();n=len(x);f=np.fft.rfft(x,n=2*n);ac=np.fft.irfft(f*f.conj())[:n];ac/=ac[0];positive=0.;last=np.inf
 for lag in range(1,n-1,2):
  pair=ac[lag]+ac[lag+1]
  if pair<=0:break
  pair=min(pair,last);positive+=pair;last=pair
 return float(n/(1+2*positive)),ac

def sample_beta(step,seed,draws=4000,burn=500):
 rng=np.random.default_rng(seed);chains=[];rates=[]
 def logtarget(u):return 9*(-np.logaddexp(0,-u))+5*(-np.logaddexp(0,u)) # Beta(9,5) plus logit Jacobian
 for start in [-2,-.7,.7,2]:
  u=start;lp=logtarget(u);vals=[];accepted=0
  for t in range(draws+burn):
   v=u+rng.normal(scale=step);lv=logtarget(v)
   if np.log(rng.random())<lv-lp:u=v;lp=lv;accepted+=1
   if t>=burn:vals.append(expit(u))
  chains.append(vals);rates.append(accepted/(draws+burn))
 chains=np.array(chains);split=np.concatenate([chains[:,:draws//2],chains[:,draws//2:]]);n=split.shape[1];W=np.var(split,axis=1,ddof=1).mean();B=n*np.var(split.mean(1),ddof=1);rhat=np.sqrt(((n-1)/n*W+B/n)/W);esses=[ess_one(c)[0] for c in chains]
 return chains,{'step':step,'mean':float(chains.mean()),'acceptance':rates,'classical_split_rhat':float(rhat),'per_chain_ess':esses,'minimum_chain_ess':min(esses)}

def main(out,lang):
 out=Path(out);out.mkdir(parents=True,exist_ok=True);zh=lang=='zh';T=lambda z,e:z if zh else e;rng=np.random.default_rng(7)
 plt.rcParams.update({'font.family':'Microsoft YaHei' if zh else 'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','axes.unicode_minus':False})
 def save(fig,n):fig.savefig(out/f'{n}-{lang}.svg',bbox_inches='tight');plt.close(fig)
 a,b=9,5;grid=np.linspace(.001,.999,1000);k=np.arange(11);pred=betabinom.pmf(k,10,a,b);plug=binom.pmf(k,10,a/(a+b));ci=beta.ppf([.025,.975],a,b)
 fig,axs=plt.subplots(1,3,figsize=(14,4.3),layout='constrained');axs[0].plot(grid,beta.pdf(grid,2,2),label=T('先验 Beta(2,2)','Prior Beta(2,2)'),color='#83949e');axs[0].plot(grid,beta.pdf(grid,a,b),label=T('后验 Beta(9,5)','Posterior Beta(9,5)'),color='#237b94');axs[0].fill_between(grid,0,beta.pdf(grid,a,b),where=(grid>=ci[0])&(grid<=ci[1]),alpha=.17,color='#237b94');axs[0].set(xlabel=T('成功概率','Success probability'),ylabel=T('概率密度','Density'));axs[0].legend(fontsize=9)
 axs[1].bar(k-.18,pred,width=.36,color='#237b94',label=T('后验预测','Posterior predictive'));axs[1].bar(k+.18,plug,width=.36,color='#d87430',label=T('固定均值概率','Fixed mean probability'));axs[1].set(xlabel=T('未来10次的成功数','Successes in ten future trials'),ylabel=T('概率','Probability'));axs[1].legend(fontsize=9)
 for n in [10,40,200]:axs[2].plot(grid,beta.pdf(grid,2+.7*n,2+.3*n),label=f'n={n}')
 axs[2].set(xlabel=T('成功概率','Success probability'),ylabel=T('后验密度','Posterior density'),title=T('成功比例均为70%','Same observed success fraction: 70%'));axs[2].legend();save(fig,'update_predictive')
 # Integrate uncertain population mean and concentration on a quadrature grid.
 ns=np.array([5,20,50,200]);success=np.array([4,10,30,110]);mu=np.linspace(.002,.998,240);kappa=np.geomspace(.05,150,220);M,K=np.meshgrid(mu,kappa);aa=M*K;bb=(1-M)*K;logw=-K/10+np.log(K) # Exp(mean=10) prior and log-kappa Jacobian; mu uniform
 for n,s in zip(ns,success):logw+=betaln(s+aa,n-s+bb)-betaln(aa,bb)
 weights=np.exp(logw-logsumexp(logw));hiermean=np.array([np.sum(weights*(s+aa)/(n+K)) for n,s in zip(ns,success)]);independent=(success+1)/(ns+2);population_mu=float(np.sum(weights*M));edge_mass=float(weights[:3].sum()+weights[-3:].sum()+weights[:,:3].sum()+weights[:,-3:].sum())
 fig,axs=plt.subplots(1,2,figsize=(12,4.7),layout='constrained');xs=np.arange(4);axs[0].plot(xs,success/ns,'o--',label=T('观测比例','Observed fraction'),color='#d87430');axs[0].plot(xs,independent,'s--',label=T('各自Beta(1,1)','Separate Beta(1,1)'),color='#83949e');axs[0].plot(xs,hiermean,'o-',label=T('层次后验均值','Hierarchical posterior mean'),color='#237b94');axs[0].axhline(population_mu,ls=':',color='#237b94');axs[0].set(xticks=xs,xticklabels=[f'{i+1} (n={n})' for i,n in enumerate(ns)],xlabel=T('群组与样本量','Group and sample count'),ylabel=T('成功概率估计','Estimated success probability'),ylim=(.35,.9));axs[0].legend(fontsize=9)
 im=axs[1].pcolormesh(mu,kappa,weights,shading='auto',cmap='Blues',rasterized=True);axs[1].set(yscale='log',xlabel=T('总体均值','Population mean'),ylabel=T('集中程度 kappa','Concentration kappa'),title=T('超参数联合后验网格质量','Hyperparameter joint posterior grid mass'));fig.colorbar(im,ax=axs[1],label=T('网格概率质量','Grid probability mass'));save(fig,'hierarchy')
 # Transparent EM for a one-dimensional Gaussian mixture.
 latent=rng.random(300)>.4;data=rng.normal(np.where(latent,2.,-2.),np.where(latent,1.,.7));means=np.array([-1.,1.]);variances=np.ones(2);mix=np.ones(2)/2;history=[]
 for iteration in range(21):
  logjoint=np.array([np.log(mix[j])+norm.logpdf(data,means[j],np.sqrt(variances[j])) for j in range(2)]).T;den=logsumexp(logjoint,axis=1);history.append(float(den.sum()));resp=np.exp(logjoint-den[:,None]);mass=resp.sum(0)
  if iteration<20:mix=mass/len(data);means=(resp*data[:,None]).sum(0)/mass;variances=np.maximum((resp*(data[:,None]-means)**2).sum(0)/mass,1e-6)
 obs=np.array([0,0,1,1,1,0,1,0]);A=np.array([[.9,.1],[.2,.8]]);B=np.array([[.85,.15],[.2,.8]]);pi=np.array([.6,.4]);filtered,smoothed,likelihood=hmm(obs,A,B,pi);brute=0.;pathbest=None;maxprob=-1
 for path in itertools.product(range(2),repeat=len(obs)):
  prob=pi[path[0]]*B[path[0],obs[0]]
  for t in range(1,len(obs)):prob*=A[path[t-1],path[t]]*B[path[t],obs[t]]
  brute+=prob
  if prob>maxprob:maxprob=prob;pathbest=path
 fig,axs=plt.subplots(1,3,figsize=(15,4.5),layout='constrained');u=np.linspace(-5,5,500);axs[0].hist(data,bins=30,density=True,color='#d8e3e8');axs[0].plot(u,sum(mix[j]*norm.pdf(u,means[j],np.sqrt(variances[j])) for j in range(2)),color='#237b94');axs[0].set(xlabel=T('观测值','Observation'),ylabel=T('密度','Density'),title=T('EM拟合混合密度','EM mixture fit'));axs[1].plot(range(21),history,'o-',ms=3,color='#237b94');axs[1].set(xlabel=T('EM更新次数','EM updates'),ylabel=T('训练对数似然','Training log likelihood'));axs[2].plot(range(1,9),filtered[:,1],'o-',label=T('过滤：截至当前','Filtering: observations so far'));axs[2].plot(range(1,9),smoothed[:,1],'s--',label=T('平滑：完整序列','Smoothing: full sequence'));axs[2].set(xticks=range(1,9),xticklabels=[f'{i+1}\n{o}' for i,o in enumerate(obs)],xlabel=T('时刻 / 报警观测','Time / observed alarm'),ylabel=T('状态1的后验概率','Posterior probability of state 1'),ylim=(0,1));axs[2].legend(fontsize=8);save(fig,'latent_messages')
 good,gd=sample_beta(.7,7);slow,sd=sample_beta(.03,17);fig,axs=plt.subplots(2,3,figsize=(14,8),layout='constrained')
 for row,(chains,dg) in enumerate([(good,gd),(slow,sd)]):
  for i,c in enumerate(chains):axs[row,0].plot(c[::5],lw=.6,alpha=.7,label=str(i+1))
  axs[row,0].set(xlabel=T('每5步显示一次','Displayed every fifth draw'),ylabel=T('成功概率','Success probability'),title=f'step={dg["step"]}, split R-hat={dg["classical_split_rhat"]:.3f}')
  for c in chains:axs[row,1].plot(ess_one(c)[1][:100],alpha=.8)
  axs[row,1].set(xlabel=T('滞后步数','Lag'),ylabel=T('自相关','Autocorrelation'),title=f'min ESS={dg["minimum_chain_ess"]:.0f}')
  axs[row,2].hist(chains.ravel(),bins=45,density=True,alpha=.6,color='#237b94');axs[row,2].plot(grid,beta.pdf(grid,a,b),color='#d87430');axs[row,2].set(xlabel=T('成功概率','Success probability'),ylabel=T('密度','Density'),title=T('采样与解析后验','Samples and analytic posterior'))
 save(fig,'sampling')
 # Actual optimization of reverse KL for an independent Gaussian approximation.
 target_mean=np.array([1.,-1.]);cov=np.array([[1,.9],[.9,1.]]);precision=np.linalg.inv(cov)
 def kl(p):
  delta=p[:2]-target_mean;v=np.exp(2*p[2:]);return .5*(np.dot(np.diag(precision),v)+delta@precision@delta-2+np.linalg.slogdet(cov)[1]-np.log(v).sum())
 fit=minimize(kl,[0,0,0,0],method='BFGS');qm=fit.x[:2];qv=np.exp(2*fit.x[2:]);gx,gy=np.meshgrid(np.linspace(-2,4,160),np.linspace(-4,2,160));pts=np.dstack([gx,gy]);fig,axs=plt.subplots(1,2,figsize=(11,4.6),layout='constrained');axs[0].contour(gx,gy,multivariate_normal.pdf(pts,target_mean,cov),levels=[.02,.08,.2],colors=['#d87430']);axs[0].contour(gx,gy,multivariate_normal.pdf(pts,qm,np.diag(qv)),levels=[.02,.08,.2],colors=['#237b94'],linestyles='--');axs[0].set(xlabel='theta 1',ylabel='theta 2',title=T('橙：目标；蓝虚线：独立近似','Orange: target; blue dashed: independent approximation'));axs[0].set_aspect('equal');u=np.linspace(-2,4,500);axs[1].plot(u,norm.pdf(u,1,1),label=T('目标边缘','Target marginal'),color='#d87430');axs[1].plot(u,norm.pdf(u,qm[0],np.sqrt(qv[0])),label=T('变分边缘','Variational marginal'),color='#237b94');axs[1].set(xlabel='theta 1',ylabel=T('概率密度','Density'));axs[1].legend();save(fig,'variational')
 xx=np.array([-2,-1.6,-.5,.2,.7,1.8])[:,None];yy=np.sin(xx[:,0])+rng.normal(0,.15,len(xx));query=np.linspace(-4,4,400)[:,None];gps={};fig,axs=plt.subplots(1,3,figsize=(15,4.7),layout='constrained')
 for ax,length in zip(axs,[.4,1.2,3.]):
  gp=GaussianProcessRegressor(kernel=RBF(length,length_scale_bounds='fixed'),alpha=.15**2,optimizer=None).fit(xx,yy);mean,std=gp.predict(query,return_std=True);obs_std=np.sqrt(std**2+.15**2);ax.fill_between(query[:,0],mean-1.96*obs_std,mean+1.96*obs_std,color='#d87430',alpha=.15,label=T('未来观测95%区间','Future-observation 95% interval'));ax.fill_between(query[:,0],mean-1.96*std,mean+1.96*std,color='#237b94',alpha=.25,label=T('潜在函数95%区间','Latent-function 95% interval'));ax.plot(query,mean,color='#237b94');ax.scatter(xx,yy,c='#263744',s=24);ax.plot(query,np.sin(query),':',color='#83949e');ax.set(title=f'RBF length={length}',xlabel=T('输入x（无量纲）','Input x (unitless)'),ylabel=T('响应（无量纲）','Response (unitless)'),ylim=(-2.8,2.8));gps[str(length)]={'latent_std_at_zero':float(gp.predict([[0]],return_std=True)[1][0]),'latent_std_at_four':float(gp.predict([[4]],return_std=True)[1][0])}
 axs[1].legend(fontsize=8,loc='upper center');save(fig,'gaussian_process')
 one=GaussianProcessRegressor(kernel=RBF(1,length_scale_bounds='fixed'),alpha=.25,optimizer=None).fit([[0]],[1]);one_m,one_s=one.predict([[0]],return_std=True)
 summary={'prior_alpha':2,'prior_beta':2,'successes':7,'failures':3,'posterior_alpha':a,'posterior_beta':b,'posterior_mean':a/(a+b),'posterior_map':(a-1)/(a+b-2),'posterior_ci95':ci.tolist(),'predictive_mean':float(betabinom.mean(10,a,b)),'predictive_variance':float(betabinom.var(10,a,b)),'predictive_mass_sum':float(pred.sum()),'hierarchical_group_means':hiermean.tolist(),'hierarchical_population_mean':population_mu,'hyper_grid_edge_mass':edge_mass,'em_final_means':means.tolist(),'em_log_likelihood':history,'em_min_improvement':float(np.diff(history).min()),'hmm_likelihood':likelihood,'hmm_brute_likelihood':brute,'hmm_likelihood_error':abs(likelihood-brute),'hmm_filtered':filtered[:,1].tolist(),'hmm_smoothed':smoothed[:,1].tolist(),'hmm_most_probable_path':list(pathbest),'mcmc_good':gd,'mcmc_slow':sd,'variational_mean':qm.tolist(),'variational_variances':qv.tolist(),'variational_kl':float(fit.fun),'variational_optimizer_success':bool(fit.success),'gp':gps,'gp_one_observation_mean':float(one_m[0]),'gp_one_observation_latent_variance':float(one_s[0]**2)}
 np.savez_compressed(out/'experiment_data.npz',beta_grid=grid,predictive=pred,hierarchy_mu=mu,hierarchy_kappa=kappa,hierarchy_weights=weights,em_data=data,hmm_observations=obs,hmm_transitions=A,hmm_emissions=B,good_chains=good,slow_chains=slow,gp_x=xx,gp_y=yy);(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();main(a.output,a.language)
