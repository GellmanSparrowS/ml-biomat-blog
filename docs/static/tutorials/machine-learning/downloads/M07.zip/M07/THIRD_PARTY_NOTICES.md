# Public sources and third-party materials

- Bayes (1763), An Essay towards Solving a Problem in the Doctrine of Chances: https://www.jstor.org/stable/105741
  Historical reference
- PyMC — General API quickstart: https://www.pymc.io/projects/examples/en/latest/introductory/api_quickstart.html
  MIT example project; reference
- Gelman et al., Bayesian Workflow: https://arxiv.org/abs/2011.01808
  Reference
- Stan — Latent Discrete Parameters: https://mc-stan.org/docs/stan-users-guide/latent-discrete.html
  Technical reference
- hmmlearn — Tutorial: https://hmmlearn.readthedocs.io/en/latest/tutorial.html
  BSD-3-Clause project
- Metropolis et al. (1953), Equation of State Calculations by Fast Computing Machines: https://www.osti.gov/biblio/4390578
  Primary bibliographic reference
- Stan — Posterior Analysis: https://mc-stan.org/docs/reference-manual/analysis.html
  Technical reference
- Blei, Kucukelbir & McAuliffe (2017), Variational Inference: A Review for Statisticians: https://www.cs.columbia.edu/~blei/papers/BleiKucukelbirMcAuliffe2017.pdf
  Reference
- scikit-learn — Gaussian Processes regression: basic introductory example: https://scikit-learn.org/stable/auto_examples/gaussian_process/plot_gpr_noisy_targets.html
  BSD-3-Clause
