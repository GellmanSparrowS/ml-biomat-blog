# Public sources and third-party materials

- Generative Adversarial Networks: https://arxiv.org/abs/1406.2661
  Primary paper; no figure copied
- GAN Lab: https://poloclub.github.io/ganlab/
  Apache 2.0; license retained; repository root has no NOTICE file
- DCGAN: https://arxiv.org/abs/1511.06434
  Primary paper; no figure copied
- Wasserstein GAN: https://arxiv.org/abs/1701.07875
  Primary paper; no figure copied
- Improved Training of Wasserstein GANs: https://arxiv.org/abs/1704.00028
  Primary paper; no figure copied
- Conditional Generative Adversarial Nets: https://arxiv.org/abs/1411.1784
  Primary paper; no figure copied
- Image-to-Image Translation with Conditional Adversarial Networks: https://arxiv.org/abs/1611.07004
  Primary paper; no figure copied
- Deconvolution and Checkerboard Artifacts: https://distill.pub/2016/deconv-checkerboard/
  CC BY 4.0 reference; original images not copied
- GANs Trained by a Two Time-Scale Update Rule: https://arxiv.org/abs/1706.08500
  Primary paper; no figure copied
- UCI Optical Recognition of Handwritten Digits: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits
  CC BY 4.0; E. Alpaydin and C. Kaynak
