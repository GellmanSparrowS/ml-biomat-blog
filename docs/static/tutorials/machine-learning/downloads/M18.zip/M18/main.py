"""Train ordinary GAN, WGAN-GP, a conditional GAN, and a tiny image DCGAN.
Synthetic mixture samples are generated here; images are sklearn's UCI digits.
"""
from pathlib import Path
import argparse,json,platform,copy,time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();out=a.output;out.mkdir(parents=True,exist_ok=True);zh=a.language=='zh'
def tr(z,e):return z if zh else e
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','svg.fonttype':'none','axes.titleweight':'bold'})
def save(fig,name):fig.savefig(out/f'{name}-{a.language}.svg',bbox_inches='tight');plt.close(fig)
angles=np.arange(8)*np.pi/4;centers=np.c_[2*np.cos(angles),2*np.sin(angles)].astype('float32')
def mixture(n,seed):
 r=np.random.default_rng(seed);labels=r.integers(0,8,n);return (centers[labels]+r.normal(0,.08,(n,2))).astype('float32'),labels
train,labels=mixture(4096,180);test,testlabels=mixture(2048,181);xt=torch.tensor(train);lab=torch.tensor(labels)
zg=torch.Generator().manual_seed(182);fixed=torch.randn((2048,2),generator=zg);tracez=fixed[:128]
class Generator(nn.Module):
 def __init__(self,conditional=False):
  super().__init__();self.conditional=conditional;self.net=nn.Sequential(nn.Linear(10 if conditional else 2,64),nn.ReLU(),nn.Linear(64,64),nn.ReLU(),nn.Linear(64,2))
 def forward(self,z,c=None):return 3*torch.tanh(self.net(torch.cat([z,F.one_hot(c,8).float()],1) if self.conditional else z)/3)
class Critic(nn.Module):
 def __init__(self,conditional=False):
  super().__init__();self.conditional=conditional;self.net=nn.Sequential(nn.Linear(10 if conditional else 2,64),nn.LeakyReLU(.2),nn.Linear(64,64),nn.LeakyReLU(.2),nn.Linear(64,1))
 def forward(self,x,c=None):return self.net(torch.cat([x,F.one_hot(c,8).float()],1) if self.conditional else x).squeeze(1)
def measures(fake):
 dist=np.linalg.norm(fake[:,None]-centers[None],axis=2);nearest=dist.argmin(1);valid=dist.min(1)<.24;counts=np.bincount(nearest[valid],minlength=8);prob=counts/max(1,counts.sum())
 directions=np.c_[np.cos(np.linspace(0,np.pi,32,endpoint=False)),np.sin(np.linspace(0,np.pi,32,endpoint=False))]
 sliced=float(np.mean(np.abs(np.sort(fake@directions.T,axis=0)-np.sort(test@directions.T,axis=0))))
 return dict(valid_fraction=float(valid.mean()),covered_modes=int((counts>=.01*len(fake)).sum()),mode_counts=counts.tolist(),mode_entropy=float(-(prob[prob>0]*np.log(prob[prob>0])).sum()),sliced_w1=sliced)
gridx=np.linspace(-3,3,31);gx,gy=np.meshgrid(gridx,gridx);grid=torch.tensor(np.c_[gx.ravel(),gy.ravel()],dtype=torch.float32)
models={};metrics={};histories={};snapshots={};times={};final_samples={}
for name in ['gan','wgan','conditional']:
 start=time.perf_counter();cond=name=='conditional';torch.manual_seed(183);g=Generator(cond);d=Critic(cond)
 lr=.0002 if name in ['wgan','conditional'] else .0005;betas=(0.,.9) if name=='wgan' else (.5,.9)
 go=torch.optim.Adam(g.parameters(),lr=lr,betas=betas);do=torch.optim.Adam(d.parameters(),lr=lr,betas=betas);rng=torch.Generator().manual_seed(184);history=[];frames=[]
 def snapshot(step):
  with torch.no_grad():
   c=torch.arange(len(fixed))%8 if cond else None;fake=g(fixed,c).numpy();m=measures(fake)
   values=d(grid,torch.zeros(len(grid),dtype=torch.long) if cond else None)
   if name!='wgan':values=values.sigmoid()
   frames.append(dict(step=step,samples=fake[:128].tolist(),field=values.numpy().reshape(31,31).tolist(),metrics=m));return m
 snapshot(0)
 for step in range(1,1501):
  ncritic=5 if name=='wgan' else 1
  for _ in range(ncritic):
   ids=torch.randint(len(xt),(128,),generator=rng);real=xt[ids];c=lab[ids] if cond else None
   fake=g(torch.randn((128,2),generator=rng),c).detach()
   if name=='wgan':
    t=torch.rand((128,1),generator=rng);mix=(t*real+(1-t)*fake).requires_grad_();s=d(mix);grad=torch.autograd.grad(s.sum(),mix,create_graph=True)[0];penalty=(grad.norm(dim=1)-1).square().mean();dl=d(fake).mean()-d(real).mean()+10*penalty
   else:dl=F.softplus(-d(real,c)).mean()+F.softplus(d(fake,c)).mean();penalty=torch.tensor(0.)
   do.zero_grad();dl.backward();do.step()
  for par in d.parameters():par.requires_grad_(False)
  pair_ids=torch.randint(len(xt),(128,),generator=rng) if cond else None
  c=lab[pair_ids] if cond else None;fake=g(torch.randn((128,2),generator=rng),c)
  gl=-d(fake).mean() if name=='wgan' else F.softplus(-d(fake,c)).mean()
  if cond:gl=gl+10*F.l1_loss(fake,xt[pair_ids])
  go.zero_grad();gl.backward();go.step()
  for par in d.parameters():par.requires_grad_(True)
  if step%50==0:
   m=snapshot(step);history.append([step,dl.item(),gl.item(),penalty.item(),m['valid_fraction'],m['sliced_w1']])
 with torch.no_grad():
  c=torch.arange(len(fixed))%8 if cond else None;fake=g(fixed,c).numpy();metrics[name]=measures(fake);final_samples[name]=fake.copy()
  if cond:
   metrics[name]['condition_match']=float((np.linalg.norm(fake[:,None]-centers[None],axis=2).argmin(1)==c.numpy()).mean())
   metrics[name]['within_class_std']=float(np.sqrt(np.mean([np.var(fake[c.numpy()==k],axis=0).mean() for k in range(8)])))
   metrics[name]['paired_l1_weight']=10
 metrics[name].update(generator_updates=1500,critic_updates=1500*(5 if name=='wgan' else 1),generator_parameters=sum(p.numel() for p in g.parameters()),critic_parameters=sum(p.numel() for p in d.parameters()),final_gradient_penalty=history[-1][3])
 models[name]=(g,d);histories[name]=np.array(history);snapshots[name]=frames;times[name]=time.perf_counter()-start
 torch.save(dict(generator=g.state_dict(),critic=d.state_dict()),out/f'{name}.pt')

# Tiny DCGAN: latent8 -> (32,2,2) -> (16,4,4) -> (1,8,8).
digits=load_digits();images=torch.tensor((digits.images/8-1).astype('float32'))[:,None]
image_train,image_test=train_test_split(np.arange(len(images)),test_size=360,stratify=digits.target,random_state=185)
class ImageGenerator(nn.Module):
 def __init__(self):
  super().__init__();self.net=nn.Sequential(nn.Linear(8,128),nn.Unflatten(1,(32,2,2)),nn.BatchNorm2d(32),nn.ReLU(),nn.ConvTranspose2d(32,16,4,2,1,bias=False),nn.BatchNorm2d(16),nn.ReLU(),nn.ConvTranspose2d(16,1,4,2,1),nn.Tanh())
 def forward(self,z):return self.net(z)
class ImageDiscriminator(nn.Module):
 def __init__(self):
  super().__init__();self.net=nn.Sequential(nn.Conv2d(1,16,4,2,1),nn.LeakyReLU(.2),nn.Conv2d(16,32,4,2,1),nn.LeakyReLU(.2),nn.Flatten(),nn.Linear(128,1))
 def forward(self,x):return self.net(x).squeeze(1)
torch.manual_seed(186);ig=ImageGenerator();idd=ImageDiscriminator();igo=torch.optim.Adam(ig.parameters(),lr=.0002,betas=(.5,.999));ido=torch.optim.Adam(idd.parameters(),lr=.0002,betas=(.5,.999));rng=torch.Generator().manual_seed(187);igfixed=torch.randn((60,8),generator=rng);image_history=[]
for step in range(1,1201):
 ids=torch.randint(len(image_train),(64,),generator=rng);real=images[image_train[ids]];fake=ig(torch.randn((64,8),generator=rng)).detach();dl=F.softplus(-idd(real)).mean()+F.softplus(idd(fake)).mean();ido.zero_grad();dl.backward();ido.step()
 for par in idd.parameters():par.requires_grad_(False)
 fake=ig(torch.randn((64,8),generator=rng));gl=F.softplus(-idd(fake)).mean();igo.zero_grad();gl.backward();igo.step()
 for par in idd.parameters():par.requires_grad_(True)
 if step%50==0:image_history.append([step,dl.item(),gl.item()])
ig.eval()
with torch.no_grad(): generated=((ig(igfixed)+1)/2).numpy()[:,0]
torch.save(dict(generator=ig.state_dict(),discriminator=idd.state_dict()),out/'dcgan.pt')
# A transposed convolution with all-one input/kernel makes overlap counts explicit.
overlap3=F.conv_transpose2d(torch.ones(1,1,4,4),torch.ones(1,1,3,3),stride=2).numpy()[0,0]
overlap4=F.conv_transpose2d(torch.ones(1,1,4,4),torch.ones(1,1,4,4),stride=2).numpy()[0,0]
fig,axs=plt.subplots(2,3,figsize=(12,7.6),layout='constrained')
for col,name in enumerate(['gan','wgan','conditional']):
 fake=np.array(snapshots[name][-1]['samples']);field=np.array(snapshots[name][-1]['field']);ax=axs[0,col]
 if name!='conditional':im=ax.contourf(gx,gy,field,levels=15,cmap='PuBuGn',alpha=.5);fig.colorbar(im,ax=ax,fraction=.045,label=tr('评分','Score') if name=='wgan' else 'P(real)')
 ax.scatter(test[:300,0],test[:300,1],s=6,c='#ba783f',alpha=.45,label=tr('目标','Target'));ax.scatter(fake[:,0],fake[:,1],s=8,c='#125f82',label=tr('生成','Generated'));ax.set(xlim=(-3,3),ylim=(-3,3),xlabel='x1',ylabel='x2',title='cGAN + L1' if name=='conditional' else name.upper());ax.set_aspect('equal');ax.legend(fontsize=8)
 axs[1,col].bar(np.arange(8),metrics[name]['mode_counts'],color='#125f82');axs[1,col].axhline(2048/8,color='#b85d30',ls='--',label=tr('均匀期望','Uniform expectation'));axs[1,col].set(xlabel=tr('模式编号','Mode index'),ylabel=tr('有效生成点数','Valid generated count'),title=tr('覆盖 ','Coverage ')+f"{metrics[name]['covered_modes']}/8; "+tr('有效 ','valid ')+f"{metrics[name]['valid_fraction']:.1%}");axs[1,col].set_xticks(range(8))
save(fig,'distribution')
fig,axs=plt.subplots(2,4,figsize=(13,6.8),layout='constrained')
for row,name in enumerate(['gan','wgan']):
 for col,step in enumerate([0,300,750,1500]):
  frame=snapshots[name][step//50];fake=np.array(frame['samples']);ax=axs[row,col];ax.scatter(test[:300,0],test[:300,1],s=4,c='#b87941',alpha=.4);ax.scatter(fake[:,0],fake[:,1],s=7,c='#125f82');ax.set(xlim=(-3,3),ylim=(-3,3),title=f'{name.upper()} / {step}',xlabel='x1',ylabel='x2');ax.set_aspect('equal')
save(fig,'training')
fig,axs=plt.subplots(1,3,figsize=(13,4),layout='constrained')
for name,color in [('gan','#125f82'),('wgan','#b85d30'),('conditional','#658248')]:
 h=histories[name];label='cGAN + L1' if name=='conditional' else name;axs[0].plot(h[:,0],h[:,4],color=color,label=label);axs[1].plot(h[:,0],h[:,5],color=color,label=label)
axs[0].set(xlabel=tr('生成器更新数','Generator updates'),ylabel=tr('有效样本比例','Valid fraction'),ylim=(0,1),title=tr('A  落在目标邻域内','A  Within target neighborhoods'));axs[0].legend(fontsize=9)
axs[1].set(xlabel=tr('生成器更新数','Generator updates'),ylabel=tr('32方向平均投影W1','Mean projected W1, 32 directions'),title=tr('B  同时观察位置与质量分配','B  Position and mass distribution'))
for name,color in [('gan','#125f82'),('wgan','#b85d30')]:
 h=histories[name];axs[2].plot(h[:,0],h[:,2],color=color,label=name)
axs[2].set(xlabel=tr('生成器更新数','Generator updates'),ylabel=tr('各自定义的G损失','G loss under its own objective'),title=tr('C  两种损失具有不同含义','C  Losses have different meanings'));axs[2].legend(fontsize=9);save(fig,'metrics')
fig=plt.figure(figsize=(13,8));gs=fig.add_gridspec(2,1,height_ratios=[1,1.25],hspace=.27)
top=gs[0].subgridspec(2,10,wspace=.05,hspace=.1)
for i in range(20):
 ax=fig.add_subplot(top[i//10,i%10]);ax.imshow((images[image_test[i],0]+1)/2,cmap='gray_r',vmin=0,vmax=1);ax.set_xticks([]);ax.set_yticks([])
 if i==0:ax.set_title(tr('独立保留图像','Held-out images'),loc='left',fontsize=12)
bottom=gs[1].subgridspec(5,12,wspace=.04,hspace=.08)
for i,img in enumerate(generated):
 ax=fig.add_subplot(bottom[i//12,i%12]);ax.imshow(img,cmap='gray_r',vmin=0,vmax=1);ax.set_xticks([]);ax.set_yticks([])
 if i==0:ax.set_title(tr('DCGAN：固定60个噪声，1200次更新','DCGAN: 60 fixed inputs after 1,200 updates'),loc='left',fontsize=12)
save(fig,'dcgan')
fig,axs=plt.subplots(1,2,figsize=(10,4.5),layout='constrained')
for ax,img,k in zip(axs,[overlap3,overlap4],[3,4]):
 im=ax.imshow(img,vmin=0,vmax=4,cmap='YlGnBu');ax.set_title(f'kernel={k}, stride=2');ax.set(xlabel=tr('输出列','Output column'),ylabel=tr('输出行','Output row'));fig.colorbar(im,ax=ax,ticks=range(5),label=tr('覆盖次数','Overlap count'))
 for r in range(len(img)):
  for c in range(len(img)):ax.text(c,r,int(img[r,c]),ha='center',va='center',fontsize=9,color='white' if img[r,c]>2 else '#152d3a')
save(fig,'overlap')
logit=torch.tensor(np.log(.01/.99),dtype=torch.float64,requires_grad=True);saturating=F.logsigmoid(-logit);nonsaturating=F.softplus(-logit)
gsat=torch.autograd.grad(saturating,logit,retain_graph=True)[0].item();gnon=torch.autograd.grad(nonsaturating,logit)[0].item()
moment_error=float(np.max(np.abs(np.cov(centers.T,bias=True)-np.cov(centers[::2].T,bias=True))))
summary=dict(versions=dict(python=platform.python_version(),torch=torch.__version__,numpy=np.__version__),data=dict(train=4096,test=2048,modes=8,radius=2,std=.08,valid_radius=.24,generator_bound=3),metrics=metrics,
 dcgan=dict(train=len(image_train),test=len(image_test),updates=1200,generated=60,generator_parameters=sum(p.numel() for p in ig.parameters()),discriminator_parameters=sum(p.numel() for p in idd.parameters())),
 hand=dict(discriminator_loss=float(-2*np.log(.8)),saturating_gradient=gsat,nonsaturating_gradient=gnon,gradient_norm=float(np.linalg.norm([3,4])),gradient_penalty=float((np.linalg.norm([3,4])-1)**2),transpose_size_k3=int(overlap3.shape[0]),transpose_size_k4=int(overlap4.shape[0]),eight_vs_four_covariance_error=moment_error),runtime_seconds=times)
(out/'replay.json').write_text(json.dumps(dict(centers=centers.tolist(),real=test[:160].tolist(),grid=gridx.tolist(),models={n:snapshots[n] for n in ['gan','wgan']}),separators=(',',':')),encoding='utf-8')
np.savez_compressed(out/'experiment.npz',train=train,test=test,labels=labels,fixed_latents=fixed.numpy(),conditional_requests=np.arange(len(fixed))%8,image_train_indices=image_train,image_test_indices=image_test,generated_images=generated,image_history=image_history,overlap3=overlap3,overlap4=overlap4,**{n+'_final':v for n,v in final_samples.items()},**{n+'_history':h for n,h in histories.items()})
with np.load(out/'experiment.npz') as saved:
 summary['saved_data']={}
 for name in ['gan','wgan','conditional']:
  restored=saved[name+'_final'];recomputed=measures(restored)
  summary['saved_data'][name]=dict(rows=len(restored),coordinate_max_error=float(np.max(np.abs(restored-final_samples[name]))),valid_error=abs(recomputed['valid_fraction']-metrics[name]['valid_fraction']),mode_counts_match=recomputed['mode_counts']==metrics[name]['mode_counts'],sliced_w1_error=abs(recomputed['sliced_w1']-metrics[name]['sliced_w1']))
 requests=saved['conditional_requests'];restored=saved['conditional_final'];std=float(np.sqrt(np.mean([np.var(restored[requests==k],axis=0).mean() for k in range(8)])))
 summary['saved_data']['conditional'].update(request_counts=np.bincount(requests,minlength=8).tolist(),within_class_std_error=abs(std-metrics['conditional']['within_class_std']))
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
