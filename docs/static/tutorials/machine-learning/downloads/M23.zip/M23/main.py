"""Inspectable lexical retrieval, IVF, BPR, two towers and chronological reranking."""
from pathlib import Path
import argparse,json,re
from collections import Counter,defaultdict
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from threadpoolctl import threadpool_limits
from xgboost import XGBRanker
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
DOCS=['bike repair wheel brake guide','bicycle maintenance tire repair workshop','bread baking flour yeast oven','sourdough bread starter fermentation guide','city bicycle route bike travel map','train travel ticket station guide','python data matrix vector tutorial','search vector index ranking retrieval']
def tokens(s):return re.findall('[a-z]+',s.lower())
def bm25(docs,query,k1=1.2,b=.75):
 cs=[Counter(tokens(d)) for d in docs];length=np.array([sum(c.values()) for c in cs]);N=len(docs);score=np.zeros(N);parts={}
 for t in sorted(set(tokens(query))):
  tf=np.array([c[t] for c in cs]);df=np.count_nonzero(tf);idf=np.log(1+(N-df+.5)/(df+.5));v=idf*tf*(k1+1)/(tf+k1*(1-b+b*length/length.mean()));score+=v;parts[t]=v
 return score,parts
def metrics(scores,truth,k=10):
 order=np.argsort(-scores,axis=1,kind='stable')[:,:k];hit=np.take_along_axis(truth,order,axis=1);den=truth.sum(1);rec=hit.sum(1)/np.maximum(den,1);discount=1/np.log2(np.arange(k)+2);ideal=np.array([discount[:min(int(n),k)].sum() for n in den]);ndcg=(hit*discount).sum(1)/np.maximum(ideal,1e-12);return {'recall':float(rec[den>0].mean()),'ndcg':float(ndcg[den>0].mean()),'coverage':float(len(np.unique(order))/scores.shape[1])},order
class MF(nn.Module):
 def __init__(self,nuser,nitem):
  super().__init__();self.u=nn.Embedding(nuser,12);self.v=nn.Embedding(nitem,12);nn.init.normal_(self.u.weight,std=.1);nn.init.normal_(self.v.weight,std=.1)
 def all_scores(self,uf,it):return self.u.weight@self.v.weight.T
class Towers(nn.Module):
 def __init__(self):
  super().__init__();self.u=nn.Sequential(nn.Linear(8,24),nn.Tanh(),nn.Linear(24,12));self.v=nn.Sequential(nn.Linear(8,24),nn.Tanh(),nn.Linear(24,12))
 def all_scores(self,uf,it):return self.u(uf)@self.v(it).T
def main(output,language):
 out=Path(output);out.mkdir(parents=True,exist_ok=True);zh=language=='zh';L=lambda a,b:a if zh else b;rng=np.random.default_rng(23);torch.manual_seed(23);torch.set_num_threads(1)
 plt.rcParams.update({'font.family':'Microsoft YaHei' if zh else 'DejaVu Sans','font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
 def save(fig,name):fig.savefig(out/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
 postings=defaultdict(list)
 for i,doc in enumerate(DOCS):
  for term,tf in Counter(tokens(doc)).items():postings[term].append([i,tf])
 lexical,parts=bm25(DOCS,'bike repair');vec=TfidfVectorizer();A=vec.fit_transform(DOCS).toarray();q=vec.transform(['bike repair']).toarray()[0];cos=A@q;U,S,Vt=np.linalg.svd(A,full_matrices=False);latent=A@Vt[:4].T;ql=q@Vt[:4].T;dense=latent@ql/np.maximum(np.linalg.norm(latent,axis=1)*np.linalg.norm(ql),1e-12)
 ranks1=np.argsort(np.argsort(-lexical,kind='stable'),kind='stable')+1;ranks2=np.argsort(np.argsort(-dense,kind='stable'),kind='stable')+1;rrf=1/(60+ranks1)+1/(60+ranks2)
 fig,axs=plt.subplots(1,2,figsize=(12,5),layout='constrained');terms=list(parts);base=np.zeros(8)
 for t in terms:axs[0].barh(np.arange(8),parts[t],left=base,label=t);base+=parts[t]
 axs[0].set(yticks=range(8),yticklabels=[f'D{i+1}' for i in range(8)],xlabel='BM25',title=L('查询 bike repair：逐词贡献','Query bike repair: term contributions'));axs[0].invert_yaxis();axs[0].legend();im=axs[1].imshow(np.c_[ranks1,np.argsort(np.argsort(-cos))+1,ranks2,np.argsort(np.argsort(-rrf))+1],cmap='Blues_r',vmin=1,vmax=8);axs[1].set(yticks=range(8),yticklabels=[f'D{i+1}' for i in range(8)],xticks=range(4),xticklabels=['BM25','TF-IDF','LSA','RRF'],title=L('同一语料的排名（1最好）','Ranks on the same corpus (1 is best)'))
 for i in range(8):
  for j,v in enumerate([ranks1[i],(np.argsort(np.argsort(-cos))+1)[i],ranks2[i],(np.argsort(np.argsort(-rrf))+1)[i]]):axs[1].text(j,i,str(v),ha='center',va='center',color='white' if v<=3 else '#20394a')
 save(fig,'lexical')
 # IVF uses Euclidean partitions; exact top10 provides retrieval ground truth.
 xb=rng.normal(size=(5000,16));xq=rng.normal(size=(100,16));km=KMeans(64,n_init=3,random_state=23).fit(xb);exact=np.argsort(((xq[:,None]-xb[None])**2).sum(2),axis=1)[:,:10];centers=np.argsort(((xq[:,None]-km.cluster_centers_[None])**2).sum(2),axis=1);trade=[]
 for probe in [1,2,4,8,16,32,64]:
  recalls=[];cost=[]
  for qi in range(100):
   ids=np.flatnonzero(np.isin(km.labels_,centers[qi,:probe]));chosen=ids[np.argsort(((xb[ids]-xq[qi])**2).sum(1))[:10]];recalls.append(len(set(chosen)&set(exact[qi]))/10);cost.append(len(ids))
  trade.append({'nprobe':probe,'recall10':float(np.mean(recalls)),'distance_evaluations':float(np.mean(cost))})
 fig,axs=plt.subplots(1,2,figsize=(11,4.5),layout='constrained');axs[0].plot([d['distance_evaluations'] for d in trade],[d['recall10'] for d in trade],'o-',color='#247b94')
 for d in trade:axs[0].annotate(str(d['nprobe']),(d['distance_evaluations'],d['recall10']),xytext=(4,5),textcoords='offset points')
 axs[0].set(xlabel=L('每查询候选向量距离计算数','Candidate-vector distances per query'),ylabel='Recall@10',ylim=(0,1.06),title=L('5000向量，100查询，64分区','5,000 vectors, 100 queries, 64 cells'));axs[1].hist(np.bincount(km.labels_),bins=15,color='#d97b36');axs[1].set(xlabel=L('每分区向量数','Vectors per cell'),ylabel=L('分区数','Number of cells'),title=L('相同nprobe也会扫描不同数量','The same nprobe can scan different counts'));save(fig,'ivf')
 # Known synthetic preference plus exposure generates chronological unique interactions.
 nu,ni,warm=80,140,120;item=rng.normal(size=(ni,8));item/=np.linalg.norm(item,axis=1,keepdims=True);preference=rng.normal(size=(nu,8));preference/=np.linalg.norm(preference,axis=1,keepdims=True);utility=preference@item.T;exposure=np.linspace(1.5,.5,ni);log=[];seen=np.zeros((nu,ni),bool)
 for day in range(24):
  available=warm if day<20 else ni
  for u in range(nu):
   prob=np.exp(5*utility[u,:available])*exposure[:available];prob[seen[u,:available]]=0;prob/=prob.sum();i=int(rng.choice(available,p=prob));seen[u,i]=True;log.append((u,i,day))
 log=np.array(log);train=np.zeros((nu,ni),bool);stage2=train.copy();test=train.copy()
 for u,i,t in log:(train if t<16 else stage2 if t<20 else test)[u,i]=True
 uf=train@item/16;uft=torch.tensor(uf,dtype=torch.float32);it=torch.tensor(item,dtype=torch.float32);users,pos=np.where(train);users_t=torch.tensor(users);pos_t=torch.tensor(pos);available_neg=[np.flatnonzero(~train[u,:warm]) for u in range(nu)];models={};traces={};rawscores={}
 for name,model in [('BPR-MF',MF(nu,ni)),('Two-tower',Towers())]:
  opt=torch.optim.Adam(model.parameters(),lr=.025,weight_decay=.001);losses=[]
  for epoch in range(160):
   neg=torch.tensor([rng.choice(available_neg[u]) for u in users]);scores=model.all_scores(uft,it);loss=F.softplus(-(scores[users_t,pos_t]-scores[users_t,neg])).mean();opt.zero_grad();loss.backward();opt.step();losses.append(float(loss.detach()))
  models[name]=model;traces[name]=losses;rawscores[name]=model.all_scores(uft,it).detach().numpy();torch.save(model.state_dict(),out/(name.lower().replace('-','_')+'.pt'))
 popularity=train.sum(0);norm=train/np.maximum(np.sqrt(train.sum(0)),1);sim=norm.T@norm;np.fill_diagonal(sim,0);keep=np.zeros_like(sim,bool);top=np.argsort(-sim,axis=0,kind='stable')[:10];np.put_along_axis(keep,top,True,axis=0);sim*=keep;rawscores['Item-kNN']=train@sim;rawscores['Popularity']=np.tile(popularity,(nu,1));rawscores['Content']=uf@item.T
 def features(u,ids):return np.c_[rawscores['Two-tower'][u,ids],rawscores['BPR-MF'][u,ids],rawscores['Content'][u,ids],np.log1p(popularity[ids])]
 xx=[];yy=[];qid=[]
 for u in range(nu):
  ids=np.flatnonzero(~train[u,:warm]);xx.append(features(u,ids));yy.extend(stage2[u,ids].astype(int));qid.extend([u]*len(ids))
 ranker=XGBRanker(n_estimators=100,max_depth=3,learning_rate=.05,objective='rank:ndcg',tree_method='hist',n_jobs=1,random_state=23,lambdarank_num_pair_per_sample=10);ranker.fit(np.vstack(xx),np.array(yy),qid=np.array(qid));ranker.save_model(out/'reranker.json')
 history=train|stage2;results={};rankings={};candidate_recall=[];rerank=np.full((nu,ni),-1e12)
 for name,s in rawscores.items():
  masked=s.copy();masked[history]=-1e12;results[name],rankings[name]=metrics(masked,test)
 for u in range(nu):
  s=rawscores['Two-tower'][u].copy();s[history[u]]=-1e12;ids=np.argsort(-s,kind='stable')[:30];candidate_recall.append(test[u,ids].sum()/4);rerank[u,ids]=ranker.predict(features(u,ids))
 results['Tower+rerank'],rankings['Tower+rerank']=metrics(rerank,test);cold={}
 for name,ranking in rankings.items():cold[name]=float(sum(test[u,ranking[u][ranking[u]>=warm]].sum() for u in range(nu))/test[:,warm:].sum())
 fig,axs=plt.subplots(1,3,figsize=(15,4.8),layout='constrained');axs[0].imshow(train[:24],aspect='auto',cmap='Blues',interpolation='nearest');axs[0].axvline(warm-.5,color='#d97b36');axs[0].set(xlabel=L('物品ID','Item ID'),ylabel=L('用户ID（前24人）','User ID (first 24)'),title=L('前16天的交互矩阵','First 16 days: interaction matrix'))
 for name,loss in traces.items():axs[1].plot(loss,label=name)
 axs[1].set(xlabel=L('训练轮数','Training epoch'),ylabel=L('成对softplus损失','Pairwise softplus loss'));axs[1].legend(fontsize=9);names=list(results);ix=np.arange(len(names));axs[2].barh(ix-.16,[results[n]['recall'] for n in names],height=.3,label='Recall@10');axs[2].barh(ix+.16,[results[n]['ndcg'] for n in names],height=.3,label='NDCG@10');axs[2].set(yticks=ix,yticklabels=names,xlabel=L('后四天，全候选评价','Last four days, full eligible catalog'));axs[2].legend(fontsize=8);save(fig,'recommendation')
 fig,axs=plt.subplots(1,2,figsize=(11,4.5),layout='constrained');axs[0].barh(names,[cold[n] for n in names],color='#247b94');axs[0].set(xlabel=L('冷启动交互Recall@10','Cold-item interaction Recall@10'),title=L('20件物品从第21天才可见','20 items become available on day 21'));axs[1].scatter(exposure[:warm],popularity[:warm],color='#d97b36',s=28,alpha=.7);axs[1].set(xlabel=L('生成曝光权重','Generating exposure weight'),ylabel=L('训练交互次数','Training interaction count'),title=L('点击同时受偏好与曝光影响','Interactions mix preference and exposure'));save(fig,'cold_exposure')
 summary={'documents':DOCS,'query':'bike repair','bm25_scores':lexical.tolist(),'tfidf_scores':cos.tolist(),'lsa_scores':dense.tolist(),'rrf_scores':rrf.tolist(),'lexical_order':np.argsort(-lexical,kind='stable').tolist(),'ivf':trade,'users':nu,'items':ni,'warm_items':warm,'log_count':len(log),'train_count':int(train.sum()),'stage2_count':int(stage2.sum()),'test_count':int(test.sum()),'cold_test_count':int(test[:,warm:].sum()),'train_test_overlap':int((train&test).sum()),'results':results,'cold_recall':cold,'candidate_recall30':float(np.mean(candidate_recall)),'loss_initial':{k:v[0] for k,v in traces.items()},'loss_final':{k:v[-1] for k,v in traces.items()},'train_last_day':int(log[log[:,2]<16,2].max()),'test_first_day':int(log[log[:,2]>=20,2].min())}
 summary.update({'postings':dict(postings),'item_neighbors':10,'ivf_full_recall':trade[-1]['recall10'],'ivf_full_distance_count':trade[-1]['distance_evaluations']})
 np.savez_compressed(out/'experiment_data.npz',log=log,item_features=item,user_preferences=preference,exposure=exposure,train=train,stage2=stage2,test=test,user_features=uf,ivf_database=xb,ivf_queries=xq,ivf_labels=km.labels_,ivf_centers=km.cluster_centers_,exact_neighbors=exact,**{k.replace('-','_').replace('+','_'):v for k,v in rawscores.items()});(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args()
 with threadpool_limits(limits=1):main(a.output,a.language)
