# Public sources and third-party materials

- Robertson et al., Okapi at TREC-3 (1994): https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/okapi_trec3.pdf
  Primary paper; no figure copied
- Introduction to Information Retrieval: https://nlp.stanford.edu/IR-book/
  Authors’ public text; reference
- Faiss — Getting started: https://github.com/facebookresearch/faiss/wiki/Getting-started
  MIT project
- Dive into Deep Learning — Matrix Factorization: https://d2l.ai/chapter_recommender-systems/mf.html
  Figure CC BY-SA 4.0, unmodified
- Rendle et al. (2009), Bayesian Personalized Ranking: https://proceedings.mlr.press/r7/rendle09a.html
  Primary reference
- TensorFlow Recommenders — Basic retrieval: https://www.tensorflow.org/recommenders/examples/basic_retrieval
  Official tutorial; independent PyTorch experiment
- XGBoost — Learning to rank: https://xgboost.readthedocs.io/en/stable/tutorials/learning_to_rank.html
  Apache-2.0 project
