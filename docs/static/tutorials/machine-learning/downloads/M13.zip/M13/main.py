"""Pixel segmentation, component boxes, NMS, and temporal association."""
import argparse
import copy
import json
from pathlib import Path
import numpy as np
import torch
from torch import nn
from scipy import ndimage
from scipy.optimize import linear_sum_assignment
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

torch.set_num_threads(2)


def make_images(n, seed):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[:48, :48]
    images, masks = [], []
    for _ in range(n):
        mask = np.zeros((48,48), bool)
        for obj in range(rng.integers(1,4)):
            x,y=rng.integers(9,39,2); size=rng.integers(4,9)
            if obj%2: shape=(abs(xx-x)<size)&(abs(yy-y)<size)
            else: shape=(xx-x)**2+(yy-y)**2<size**2
            mask |= shape
        background=.15+.08*xx/48
        image=np.clip(background+mask*rng.uniform(.35,.65)+rng.normal(0,.14,(48,48)),0,1)
        images.append(image);masks.append(mask)
    return np.array(images,dtype=np.float32)[:,None], np.array(masks,dtype=np.float32)[:,None]


class SmallUNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.high=nn.Sequential(nn.Conv2d(1,8,3,padding=1),nn.ReLU(),nn.Conv2d(8,8,3,padding=1),nn.ReLU())
        self.low=nn.Sequential(nn.MaxPool2d(2),nn.Conv2d(8,16,3,padding=1),nn.ReLU(),nn.Conv2d(16,16,3,padding=1),nn.ReLU())
        self.output=nn.Sequential(nn.Conv2d(24,8,3,padding=1),nn.ReLU(),nn.Conv2d(8,1,1))

    def forward(self,x):
        high=self.high(x);low=self.low(high)
        up=nn.functional.interpolate(low,size=high.shape[-2:],mode='bilinear',align_corners=False)
        return self.output(torch.cat([high,up],dim=1))


def iou(box1,box2):
    x1,y1=np.maximum(box1[:2],box2[:2]);x2,y2=np.minimum(box1[2:],box2[2:])
    intersection=max(0,x2-x1)*max(0,y2-y1)
    area1=np.prod(np.array(box1[2:])-box1[:2]);area2=np.prod(np.array(box2[2:])-box2[:2])
    return intersection/(area1+area2-intersection)


def nms(boxes,scores,threshold):
    order=np.argsort(-np.asarray(scores));keep=[]
    while len(order):
        selected=int(order[0]);keep.append(selected)
        order=np.array([i for i in order[1:] if iou(boxes[selected],boxes[i])<=threshold],dtype=int)
    return keep


def box_components(mask):
    labels,n=ndimage.label(mask)
    boxes=[]
    for i in range(1,n+1):
        y,x=np.where(labels==i)
        if len(x)>=12:boxes.append([int(x.min()),int(y.min()),int(x.max()+1),int(y.max()+1)])
    return boxes


def track(use_velocity):
    frames=np.arange(21)
    truth=np.stack([np.column_stack([8+2*frames,24+0*frames]),np.column_stack([46-2*frames,25+0*frames])],axis=1)
    rng=np.random.default_rng(9);observed=truth+rng.normal(0,.12,truth.shape)
    previous=observed[0].copy();velocity=np.zeros((2,2));history=[previous.copy()];identities=[np.array([0,1])]
    for obs in observed[1:]:
        predicted=previous+velocity if use_velocity else previous
        cost=np.square(predicted[:,None,:]-obs[None,:,:]).sum(2)
        _,col=linear_sum_assignment(cost)
        current=obs[col];velocity=current-previous;previous=current
        history.append(current.copy());identities.append(col)
    identities=np.array(identities)
    switches=int(np.sum(identities[1:]!=identities[:-1]))
    return truth,np.array(history),switches


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
    def text(ch,en):return ch if zh else en
    plt.rcParams.update({'font.family':'Microsoft YaHei' if zh else 'Arial','font.size':10,
                         'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg',bbox_inches='tight')
        fig.savefig(args.output/f'{name}-{args.language}.png',dpi=140,bbox_inches='tight');plt.close(fig)
    torch.manual_seed(12)
    xt,yt=map(torch.tensor,make_images(160,100));xv,yv=map(torch.tensor,make_images(40,200))
    test_x,test_y=make_images(40,300);model=SmallUNet();optimizer=torch.optim.Adam(model.parameters(),lr=.003)
    best=float('inf');history=[]
    for epoch in range(25):
        model.train();losses=[]
        for indices in torch.randperm(160).split(20):
            optimizer.zero_grad();loss=nn.functional.binary_cross_entropy_with_logits(model(xt[indices]),yt[indices])
            loss.backward();optimizer.step();losses.append(loss.item())
        model.eval()
        with torch.no_grad(): val=nn.functional.binary_cross_entropy_with_logits(model(xv),yv).item()
        history.append([float(np.mean(losses)),val])
        if val<best:best=val;checkpoint=copy.deepcopy(model.state_dict())
    model.load_state_dict(checkpoint);model.eval()
    with torch.no_grad():probability=torch.sigmoid(model(torch.tensor(test_x))).numpy()[:,0]
    truth=test_y[:,0].astype(bool);predicted=probability>=.5;baseline=test_x[:,0]>=.45
    def overlap(pred):
        inter=(pred&truth).sum((1,2));union=(pred|truth).sum((1,2))
        return inter/union,2*inter/(pred.sum((1,2))+truth.sum((1,2)))
    score,dice=overlap(predicted);base_score,_=overlap(baseline)
    boxes=[[5,5,25,25],[7,6,27,26],[30,10,44,25]];scores=[.9,.8,.7]
    assert abs(iou([0,0,10,10],[5,0,15,10])-1/3)<1e-12
    assert nms(boxes,scores,.5)==[0,2]
    trajectories={}
    for method in ['position','velocity']:
        true_track,estimated,switches=track(method=='velocity')
        trajectories[method]=(estimated,switches)
    summary={'test_images':40,'mean_foreground_iou':float(score.mean()),'mean_dice':float(dice.mean()),
             'intensity_baseline_iou':float(base_score.mean()),'selected_epoch':int(np.argmin(np.array(history)[:,1])+1),
             'nms_kept':nms(boxes,scores,.5),'position_identity_switches':trajectories['position'][1],
             'velocity_identity_switches':trajectories['velocity'][1]}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    np.savez(args.output/'data.npz',test_images=test_x,test_masks=test_y,probability=probability,
             history=history,iou=score,dice=dice,baseline_iou=base_score,true_track=true_track,
             position_track=trajectories['position'][0],velocity_track=trajectories['velocity'][0])
    selected=[0,1,int(np.argmin(score))];fig,axs=plt.subplots(3,4,figsize=(12,8))
    titles=[text('带噪输入','Noisy input'),text('真实前景','Ground-truth foreground'),text('预测概率','Predicted probability'),text('错误与连通域框','Errors and component boxes')]
    for row,index in enumerate(selected):
        axs[row,0].imshow(test_x[index,0],cmap='gray',vmin=0,vmax=1)
        axs[row,1].imshow(truth[index],cmap='gray',vmin=0,vmax=1)
        im=axs[row,2].imshow(probability[index],cmap='viridis',vmin=0,vmax=1)
        rgb=np.stack([truth[index]*.2]*3,axis=-1);rgb[predicted[index]&~truth[index]]=[.8,.3,.2];rgb[~predicted[index]&truth[index]]=[.1,.6,.8]
        axs[row,3].imshow(rgb)
        for x1,y1,x2,y2 in box_components(predicted[index]):axs[row,3].add_patch(Rectangle((x1-.5,y1-.5),x2-x1,y2-y1,fill=False,edgecolor='#e8bd52',lw=1))
        axs[row,0].set_ylabel(f'#{index} | IoU={score[index]:.3f}')
        for col in range(4):
            axs[row,col].set_xticks([]);axs[row,col].set_yticks([])
            if row==0:axs[row,col].set_title(titles[col])
    fig.tight_layout(rect=(0,.075,1,1))
    color_axis=fig.add_axes([.535,.035,.17,.012])
    fig.colorbar(im,cax=color_axis,orientation='horizontal',ticks=[0,.5,1],label=text('前景概率','Foreground probability'))
    save(fig,'segmentation')
    fig,axs=plt.subplots(1,3,figsize=(12,3.7),gridspec_kw={'width_ratios':[1.1,1,.9]})
    history=np.array(history)
    axs[0].plot(np.arange(1,26),history[:,0],label=text('训练','Training'),color='#176b91')
    axs[0].plot(np.arange(1,26),history[:,1],label=text('验证','Validation'),color='#bb554d')
    axs[0].set(xlabel=text('轮数','Epoch'),ylabel=text('像素二元交叉熵','Pixel binary cross-entropy'));axs[0].legend()
    axs[1].scatter(base_score,score,c='#176b91',s=24);axs[1].plot([0,1],[0,1],'--',c='#999')
    axs[1].set(xlim=(0,1),ylim=(0,1),xlabel=text('强度阈值基线IoU','Intensity-threshold IoU'),ylabel=text('小型U形网络IoU','Small U-shaped network IoU'),aspect='equal')
    for i,b in enumerate(boxes):
        axs[2].add_patch(Rectangle((b[0],b[1]),b[2]-b[0],b[3]-b[1],fill=False,lw=2,ls='--' if i==1 else '-',edgecolor=['#176b91','#bb554d','#8f711b'][i]))
        axs[2].text(b[0],b[3]+3 if i==1 else b[1]-1,f'{i}: {scores[i]}',fontsize=9)
    axs[2].set(xlim=(0,48),ylim=(35,0),aspect='equal',xlabel=text('横坐标 / px','Horizontal / px'),ylabel=text('纵坐标 / px','Vertical / px'),title=text('NMS保留0、2','NMS retains 0 and 2'))
    fig.tight_layout();save(fig,'metrics')
    fig,axs=plt.subplots(2,2,figsize=(12,4.2),gridspec_kw={'height_ratios':[1,.35]})
    for j,method in enumerate(['position','velocity']):
        estimated,switches=trajectories[method]
        for k,c in enumerate(['#176b91','#bb554d']):
            axs[0,j].plot(np.arange(21),true_track[:,k,0],'--',color='#adb6bc',lw=3)
            axs[0,j].plot(np.arange(21),estimated[:,k,0],color=c,label=f'ID {k+1}')
        method_name={'position':'位置关联','velocity':'速度预测关联'}[method]
        axs[0,j].set(xlabel=text('帧编号','Frame'),ylabel=text('横坐标 / px','Horizontal / px'),xticks=np.arange(0,21,5),title=text(f'{method_name}：身份切换{switches}次',f'{method}: {switches} identity switches'));axs[0,j].legend()
        axs[1,j].axis('off')
        for a,t in enumerate([0,7,10,13,20]):
            inset=axs[1,j].inset_axes([a*.2,0,.18,.9]);inset.set(xlim=(0,58),ylim=(34,16),aspect='equal')
            for k,c in enumerate(['#176b91','#bb554d']):
                px,py=estimated[t,k];inset.add_patch(Rectangle((px-3,py-3),6,6,fill=False,edgecolor=c,lw=2));inset.text(px,py-5,str(k+1),color=c,ha='center')
            inset.set_title(f't={t}',fontsize=9);inset.set_xticks([]);inset.set_yticks([])
    fig.tight_layout();save(fig,'tracking')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
