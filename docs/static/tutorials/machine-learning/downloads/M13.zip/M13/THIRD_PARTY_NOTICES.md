# Public sources and third-party materials

- Single Shot Multibox Detection: https://d2l.ai/chapter_computer-vision/ssd.html
  Original diagram CC BY-SA 4.0.
- U-Net: Convolutional Networks for Biomedical Image Segmentation: https://arxiv.org/abs/1505.04597
  Technical reference; paper images not reproduced.
- You Only Look Once: Unified, Real-Time Object Detection: https://arxiv.org/abs/1506.02640
  Technical reference.
- End-to-End Object Detection with Transformers: https://arxiv.org/abs/2005.12872
  Technical reference.
- Segment Anything: https://arxiv.org/abs/2304.02643
  Technical reference.
- SAM 2: Segment Anything in Images and Videos: https://arxiv.org/abs/2408.00714
  Technical reference.
- ByteTrack: Multi-Object Tracking by Associating Every Detection Box: https://arxiv.org/abs/2110.06864
  Technical reference.
- PP-OCR: A Practical Ultra Lightweight OCR System: https://arxiv.org/abs/2009.09941
  Technical reference.
- OpenCV Optical Flow Tutorial: https://docs.opencv.org/4.x/d4/dee/tutorial_optical_flow.html
  Technical reference; external example images not reused.
- Faster R-CNN: Towards Real-Time Object Detection with Region Proposal Networks: https://arxiv.org/abs/1506.01497
  Technical reference
- Connectionist Temporal Classification: https://www.cs.toronto.edu/~graves/icml_2006.pdf
  Technical reference; no figures reproduced
- MMPose Overview: https://mmpose.readthedocs.io/en/latest/overview.html
  Technical reference
