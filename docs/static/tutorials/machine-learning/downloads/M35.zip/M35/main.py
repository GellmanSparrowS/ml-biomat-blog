"""Eight affine coupling layers learn a known curved density.
Also compute rational-quadratic splines and a continuous linear flow.
"""
from pathlib import Path
import argparse,json,math,copy,platform
import numpy as np
import torch
from torch import nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
def tr(z,e):return z if zh else e
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','svg.fonttype':'none'})
def save(fig,name):fig.savefig(out/f'{name}-{args.language}.svg',bbox_inches='tight');plt.close(fig)
def banana(n,seed):
 z=np.random.default_rng(seed).normal(size=(n,2));return np.c_[1.2*z[:,0],.35*z[:,1]+.55*(z[:,0]**2-1)].astype('float32')
def true_logp(x):
 z=np.c_[x[:,0]/1.2,(x[:,1]-.55*((x[:,0]/1.2)**2-1))/.35];return -.5*(z*z).sum(1)-math.log(2*math.pi)-math.log(.42)
train,valid,test=banana(4096,350),banana(1024,351),banana(2048,352);xt=torch.tensor(train);xv=torch.tensor(valid);xe=torch.tensor(test)
class Coupling(nn.Module):
 def __init__(self,keep):
  super().__init__();self.keep=keep;self.change=1-keep;self.net=nn.Sequential(nn.Linear(1,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,2));nn.init.zeros_(self.net[-1].weight);nn.init.zeros_(self.net[-1].bias)
 def forward(self,x,inverse=False):
  coeff=self.net(x[:,self.keep:self.keep+1]);s=.8*torch.tanh(coeff[:,0]);t=coeff[:,1];y=x.clone()
  if inverse:y[:,self.change]=x[:,self.change]*torch.exp(s)+t;ld=s
  else:y[:,self.change]=(x[:,self.change]-t)*torch.exp(-s);ld=-s
  return y,ld
class Flow(nn.Module):
 def __init__(self):super().__init__();self.layers=nn.ModuleList([Coupling(i%2) for i in range(8)])
 def forward(self,x,inverse=False):
  ld=x.new_zeros(len(x));layers=reversed(self.layers) if inverse else self.layers
  for layer in layers:x,delta=layer(x,inverse);ld=ld+delta
  return x,ld
 def logp(self,x):
  z,ld=self(x);return -.5*(z*z).sum(1)-math.log(2*math.pi)+ld
torch.manual_seed(355);model=Flow();optimizer=torch.optim.Adam(model.parameters(),lr=.001);rng=torch.Generator().manual_seed(356);history=[];best=float('inf');best_state=None;best_epoch=0
for epoch in range(1,201):
 order=torch.randperm(len(xt),generator=rng);total=0.
 for idx in order.split(256):
  loss=-model.logp(xt[idx]).mean();optimizer.zero_grad();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),5);optimizer.step();total+=loss.item()*len(idx)
 with torch.no_grad():val=-model.logp(xv).mean().item()
 history.append([epoch,total/len(xt),val])
 if val<best:best=val;best_state=copy.deepcopy(model.state_dict());best_epoch=epoch
model.load_state_dict(best_state);model.eval();torch.save(dict(model=model.state_dict(),best_epoch=best_epoch),out/'realnvp.pt')
with torch.no_grad():
 test_lp=model.logp(xe).numpy();val_lp=model.logp(xv).numpy();latents=np.random.default_rng(357).normal(size=(2048,2)).astype('float32');generated=model(torch.tensor(latents),True)[0].numpy();encoded,forward_ld=model(xe);restored,inverse_ld=model(encoded,True);roundtrip=float((restored-xe).abs().max());logdet_cancel=float((forward_ld+inverse_ld).abs().max())
mean=train.mean(0);cov=np.cov(train.T);inv_cov=np.linalg.inv(cov)
def gaussian_logp(x):return -.5*np.einsum('ni,ij,nj->n',x-mean,inv_cov,x-mean)-math.log(2*math.pi)-.5*np.linalg.slogdet(cov)[1]
anomalies=banana(2048,353);anomalies[:,1]+=1.5;threshold=float(np.quantile(val_lp,.05))
with torch.no_grad():anomaly_lp=model.logp(torch.tensor(anomalies)).numpy()
# Verify the learned triangular Jacobian against a full autograd Jacobian.
double_model=copy.deepcopy(model).double();point=torch.tensor([.4,-.2],dtype=torch.float64,requires_grad=True)
jac=torch.autograd.functional.jacobian(lambda x:double_model(x[None])[0][0],point);jac_logdet=torch.linalg.slogdet(jac)[1].item();analytic_ld=double_model(point[None])[1].item()
# One-dimensional rational-quadratic spline, identity tails and endpoint derivatives one.
xknots=np.array([-3.,-1.,0.,1.,3.]);yknots=np.array([-3.,-2.,.5,2.,3.]);derivatives=np.array([1.,.5,2.,.5,1.])
def spline(values,inverse=False):
 values=np.asarray(values,dtype=float);bins=np.clip(np.searchsorted(yknots if inverse else xknots,values,side='right')-1,0,len(xknots)-2);x0=xknots[bins];y0=yknots[bins];w=np.diff(xknots)[bins];h=np.diff(yknots)[bins];delta=h/w;d0=derivatives[bins];d1=derivatives[bins+1]
 if inverse:
  rel=values-y0;a=rel*(d0+d1-2*delta)+h*(delta-d0);b=h*d0-rel*(d0+d1-2*delta);c=-delta*rel;disc=np.maximum(b*b-4*a*c,0);linear=np.abs(a)<1e-12;xi=np.zeros_like(values);np.divide(2*c,-b-np.sqrt(disc),out=xi,where=~linear);np.divide(-c,b,out=xi,where=linear);result=x0+w*xi
 else:xi=(values-x0)/w;den=delta+(d0+d1-2*delta)*xi*(1-xi);result=y0+h*(delta*xi*xi+d0*xi*(1-xi))/den
 den=delta+(d0+d1-2*delta)*xi*(1-xi);deriv=delta**2*(d1*xi**2+2*delta*xi*(1-xi)+d0*(1-xi)**2)/den**2;outside=(values<=-3)|(values>=3);result=np.where(outside,values,result);deriv=np.where(outside,1,deriv)
 return result,(-np.log(deriv) if inverse else np.log(deriv))
sx=np.linspace(-3.5,3.5,1401);sy,sld=spline(sx);sback,_=spline(sy,True);finite=(spline(sx+1e-5)[0]-spline(sx-1e-5)[0])/2e-5
interior=np.min(np.abs(sx[:,None]-xknots[None]),axis=1)>.001;spline_derivative_error=float(np.max(np.abs(finite[interior]-np.exp(sld[interior]))));spline_inverse_error=float(np.max(np.abs(sx-sback)))
sz=np.random.default_rng(358).normal(size=5000);sgen=spline(sz)[0];grid1=np.linspace(-4,4,1000);latent1,invld=spline(grid1,True);spline_pdf=np.exp(-.5*latent1**2)/math.sqrt(2*math.pi)*np.exp(invld)
# A continuous flow with analytic solution and a separately implemented RK4 solver.
A=np.diag([.4,-.2]);z0=np.array([1.,1.]);exact=z0*np.exp(np.diag(A));ode=[]
def rhs(state):return A@state
for n in [1,2,4,8,16]:
 x=z0.copy();dt=1/n
 for _ in range(n):
  k1=rhs(x);k2=rhs(x+.5*dt*k1);k3=rhs(x+.5*dt*k2);k4=rhs(x+dt*k3);x+=dt*(k1+2*k2+2*k3+k4)/6
 ode.append(dict(steps=n,x=x.tolist(),max_error=float(np.max(np.abs(x-exact))),logdensity_change=-float(np.trace(A))))
# Layer-by-layer grids and samples are computed by the actual learned inverse.
lines=[]
for fixed in np.linspace(-2,2,9):
 t=np.linspace(-2,2,41);lines.extend([np.c_[np.full(len(t),fixed),t],np.c_[t,np.full(len(t),fixed)]])
gridlines=np.array(lines).astype('float32');frames=[];cur=torch.tensor(gridlines.reshape(-1,2));points=torch.tensor(latents[:160]);probe=torch.tensor([[.5,-.5]],dtype=torch.float32);ld_probe=0.
with torch.no_grad():
 for layer_index,layer in enumerate([None]+list(reversed(model.layers))):
  if layer is not None:cur,_=layer(cur,True);points,_=layer(points,True);probe,dl=layer(probe,True);ld_probe+=dl.item()
  frames.append(dict(layer=layer_index,grid=cur.reshape(gridlines.shape).numpy().tolist(),points=points.numpy().tolist(),probe=probe[0].tolist(),probe_logdet=ld_probe))
hand_spline_y,hand_spline_ld=spline(np.array([-.5]));weights=[]
for layer in model.layers:
 weights.append(dict(keep=layer.keep,layers=[dict(weight=m.weight.detach().numpy().tolist(),bias=m.bias.detach().numpy().tolist()) for m in layer.net if isinstance(m,nn.Linear)]))
(out/'flow-lab.json').write_text(json.dumps(dict(frames=frames,weights=weights),separators=(',',':')),encoding='utf-8')
summary=dict(versions=dict(python=platform.python_version(),torch=torch.__version__,numpy=np.__version__),data=dict(train=4096,validation=1024,test=2048,seed=[350,351,352],true_logdet=math.log(.42)),training=dict(epochs=200,best_epoch=best_epoch,parameters=sum(p.numel() for p in model.parameters()),layers=8,batch=256,lr=.001,scale_bound=.8),density=dict(flow_test_nll=float(-test_lp.mean()),gaussian_test_nll=float(-gaussian_logp(test).mean()),true_test_nll=float(-true_logp(test).mean()),roundtrip_max_error=roundtrip,logdet_cancel_error=logdet_cancel,jacobian_logdet=jac_logdet,analytic_logdet=analytic_ld,jacobian_error=abs(jac_logdet-analytic_ld)),anomaly=dict(logdensity_threshold=threshold,false_positive=float((test_lp<threshold).mean()),shifted_detection=float((anomaly_lp<threshold).mean()),vertical_shift=1.5),spline=dict(inverse_max_error=spline_inverse_error,derivative_max_error=spline_derivative_error,min_derivative=float(np.exp(sld).min())),ode=ode,hand=dict(affine_scale=2,affine_point_density=1/(2*math.sqrt(2*math.pi)),coupling_logdet=math.log(2),spline_midpoint=float(hand_spline_y[0]),spline_midpoint_derivative=float(np.exp(hand_spline_ld[0])),ode_logdensity_change=-.2,ode_final_x1=float(exact[0]),ode_final_x2=float(exact[1])))
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');np.savez_compressed(out/'experiment.npz',train=train,validation=valid,test=test,latents=latents,generated=generated,encoded=encoded.numpy(),test_logdensity=test_lp,anomalies=anomalies,anomaly_logdensity=anomaly_lp,history=history,spline_x=sx,spline_y=sy,spline_logderivative=sld,spline_generated=sgen,ode=np.array([[r['steps'],r['max_error']] for r in ode]))
# Density is shown on one common coordinate grid and color scale.
gx,gy=np.meshgrid(np.linspace(-4,4,180),np.linspace(-2,5,160));mesh=np.c_[gx.ravel(),gy.ravel()].astype('float32')
with torch.no_grad():density=np.exp(model.logp(torch.tensor(mesh)).numpy()).reshape(gx.shape)
true_density=np.exp(true_logp(mesh)).reshape(gx.shape);fig,axs=plt.subplots(1,3,figsize=(13,4),layout='constrained')
axs[0].scatter(test[:700,0],test[:700,1],s=5,alpha=.5,color='#b97d43');axs[0].scatter(generated[:700,0],generated[:700,1],s=4,alpha=.4,color='#125f82');axs[0].set_title(tr('A  目标与生成：各700点','A  Target and generated: 700 each'))
for ax,img,title in zip(axs[1:],[true_density,density],[tr('B  已知目标密度','B  Known target density'),tr('C  可逆网络密度','C  Learned flow density')]):
 im=ax.pcolormesh(gx,gy,img,vmin=0,vmax=max(true_density.max(),density.max()),cmap='YlGnBu',shading='auto',rasterized=True);ax.set_title(title);fig.colorbar(im,ax=ax,label=tr('每单位面积概率密度','Density per unit area'))
for ax in axs:ax.set(xlim=(-4,4),ylim=(-2,5),xlabel='x1',ylabel='x2');ax.set_aspect('equal')
save(fig,'density')
fig,axs=plt.subplots(1,4,figsize=(14,4),layout='constrained')
for ax,i in zip(axs,[0,2,4,8]):
 frame=frames[i]
 for line in frame['grid']:line=np.array(line);ax.plot(line[:,0],line[:,1],color='#125f82',lw=.7,alpha=.8)
 pt=np.array(frame['points']);ax.scatter(pt[:,0],pt[:,1],s=3,color='#c17a3a',alpha=.5);ax.set(xlim=(-5,5),ylim=(-3,7),xlabel=tr('坐标1','Coordinate 1'),ylabel=tr('坐标2','Coordinate 2'),title=tr('逆向层数 ','Inverse layers ')+str(i));ax.set_aspect('equal')
save(fig,'grids')
fig,axs=plt.subplots(1,3,figsize=(13,4),layout='constrained');axs[0].plot(sx,sy,color='#125f82');axs[0].scatter(xknots,yknots,color='#bf7139',s=30);axs[0].plot(sx,sx,ls=':',color='#8c9698');axs[0].set(xlabel='z',ylabel='x = f(z)',title=tr('A  单调有理二次样条','A  Monotone rational-quadratic spline'))
axs[1].plot(sx,np.exp(sld),color='#bf7139');axs[1].axhline(0,color='#777',lw=.7);axs[1].set(xlabel='z',ylabel="f'(z)",title=tr('B  每处斜率保持为正','B  Positive slope throughout'))
axs[2].hist(sgen,bins=70,density=True,color='#8fb9c1',alpha=.7,label=tr('5000个样本','5,000 samples'));axs[2].plot(grid1,spline_pdf,color='#125f82',label=tr('变量变换密度','Change-of-variables density'));axs[2].set(xlabel='x',ylabel=tr('概率密度','Density'),title=tr('C  拉伸改变密度','C  Stretching changes density'));axs[2].legend(fontsize=9);save(fig,'spline')
fig,axs=plt.subplots(1,3,figsize=(13,4),layout='constrained');h=np.array(history);axs[0].plot(h[:,0],h[:,1],label=tr('训练','Train'));axs[0].plot(h[:,0],h[:,2],label=tr('验证','Validation'));axs[0].axhline(-true_logp(valid).mean(),ls=':',color='#555',label=tr('目标本身','True density'));axs[0].set(xlabel=tr('训练轮数','Epoch'),ylabel=tr('负对数密度 / nats','Negative log density / nats'),title=tr('A  最大似然训练','A  Maximum-likelihood training'));axs[0].legend(fontsize=9)
axs[1].hist(-test_lp,bins=np.histogram_bin_edges(np.r_[-test_lp,-anomaly_lp],bins=45),density=True,alpha=.55,label=tr('目标测试集','Target test'),color='#125f82');axs[1].hist(-anomaly_lp,bins=np.histogram_bin_edges(np.r_[-test_lp,-anomaly_lp],bins=45),density=True,alpha=.45,label=tr('向上移1.5','Shifted upward 1.5'),color='#bf7139');axs[1].axvline(-threshold,ls='--',color='#222');axs[1].set(xlabel=tr('负对数密度分数','Negative log-density score'),ylabel=tr('直方图密度','Histogram density'),title=tr('B  用验证集确定阈值','B  Threshold set on validation'));axs[1].legend(fontsize=9)
r=np.linspace(.001,13,600);log_shell=(64-1)*np.log(r)-.5*r*r-(64/2-1)*math.log(2)-math.lgamma(64/2);axs[2].plot(r,np.exp(log_shell),color='#125f82',label=tr('半径概率密度','Radius density'));axs[2].set(xlabel=tr('64维标准高斯半径','Radius in a 64D standard normal'),ylabel=tr('半径概率密度','Radial density'),title=tr('C  概率质量聚集在一圈','C  Probability mass occupies a shell'));ax2=axs[2].twinx();ax2.plot(r,np.exp(-.5*r*r),ls='--',color='#bf7139');ax2.set_ylabel(tr('相对原点的点密度','Point density relative to origin'),color='#bf7139');save(fig,'diagnostics')
fig,axs=plt.subplots(1,2,figsize=(11,4.5),layout='constrained');times=np.linspace(0,1,101);path=z0[None]*np.exp(times[:,None]*np.diag(A));axs[0].plot(path[:,0],path[:,1],color='#125f82',lw=3);axs[0].scatter([1,exact[0]],[1,exact[1]],c=['#bf7139','#125f82'],s=60);axs[0].set(xlabel='x1',ylabel='x2',title=tr('A  dx/dt = diag(0.4, −0.2)x','A  dx/dt = diag(0.4, -0.2)x'));axs[0].set_aspect('equal');axs[1].loglog([x['steps'] for x in ode],[x['max_error'] for x in ode],'o-',color='#125f82');axs[1].set(xlabel=tr('RK4步数','RK4 steps'),ylabel=tr('相对解析终点的最大绝对误差','Maximum absolute endpoint error'),title=tr('B  连续可逆性与数值误差','B  Continuous invertibility and numerical error'));save(fig,'ode')
print(json.dumps(summary,indent=2))
