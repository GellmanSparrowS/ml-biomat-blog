# Public sources and third-party materials

- Density Estimation Using Real NVP: https://arxiv.org/html/1605.08803v3
  Primary paper; no copied figures
- UvA Tutorial 11: Normalizing Flows for Image Modeling: https://uvadlc-notebooks.readthedocs.io/en/latest/tutorial_notebooks/tutorial11/NF_image_modeling.html
  MIT; original notebook cell33 execution14 mask output only
- Masked Autoregressive Flow for Density Estimation: https://arxiv.org/html/1705.07057v4
  Primary paper; no copied figures
- Improved Variational Inference with Inverse Autoregressive Flow: https://arxiv.org/abs/1606.04934
  Primary paper; no copied figures
- Neural Spline Flows: https://arxiv.org/html/1906.04032v2
  Primary paper; independent numerical construction
- FFJORD: https://arxiv.org/abs/1810.01367
  Primary paper; no copied figures
- Do Deep Generative Models Know What They Don’t Know?: https://arxiv.org/abs/1810.09136
  Primary paper; own analytic Gaussian-shell illustration
