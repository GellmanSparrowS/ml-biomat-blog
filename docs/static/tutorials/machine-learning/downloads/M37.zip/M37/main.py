"""DQN and PPO on the same finite-horizon stochastic courier task."""
import argparse,copy,json,math
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
torch.set_num_threads(2)
GAMMA=.97;HORIZON=20

class Courier:
 """Position1..5, target0or6; other endpoint is failure; action flips withp=.1."""
 def __init__(self,seed,n=1):self.rng=np.random.default_rng(seed);self.n=n;self.reset(np.arange(n))
 def reset(self,indices):
  if not hasattr(self,'position'):self.position=np.zeros(self.n,dtype=int);self.goal=np.zeros(self.n,dtype=int);self.remaining=np.zeros(self.n,dtype=int)
  self.position[indices]=self.rng.integers(1,6,len(indices));self.goal[indices]=self.rng.integers(0,2,len(indices))*6;self.remaining[indices]=HORIZON
 def observe(self):return np.column_stack([np.eye(7)[self.position],np.eye(2)[self.goal//6],self.remaining/HORIZON]).astype('float32')
 def step(self,actions):
  actual=np.asarray(actions,dtype=int)^(self.rng.random(self.n)<.1);self.position+=2*actual-1;self.remaining-=1
  reached=self.position==self.goal;wrong=(self.position==0)|(self.position==6);done=wrong|(self.remaining==0);reward=np.where(reached,1,np.where(wrong,-1,-.02)).astype('float32');next_observation=self.observe();return next_observation,reward,done,reached

class QNet(nn.Module):
 def __init__(self):super().__init__();self.net=nn.Sequential(nn.Linear(10,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,2))
 def forward(self,x):return self.net(x)
class ActorCritic(nn.Module):
 def __init__(self):super().__init__();self.body=nn.Sequential(nn.Linear(10,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh());self.policy=nn.Linear(32,2);self.value=nn.Linear(32,1)
 def forward(self,x):h=self.body(x);return self.policy(h),self.value(h).squeeze(-1)

def evaluate(model,kind,seed=9001,episodes=100):
 returns=[];success=[];lengths=[]
 for episode in range(episodes):
  env=Courier(seed+episode);total=0
  for t in range(HORIZON):
   with torch.no_grad():out=model(torch.from_numpy(env.observe()));logits=out[0]if kind=='PPO'else out;action=logits.argmax(-1).numpy()
   obs,reward,done,reached=env.step(action);total+=float(reward[0])
   if done[0]:break
  returns.append(total);success.append(bool(reached[0]));lengths.append(t+1)
 return {'mean_return':float(np.mean(returns)),'success_rate':float(np.mean(success)),'mean_length':float(np.mean(lengths)),'returns':returns}

def exact_policy_value(toward_goal):
 values=np.zeros((2,7));success=np.zeros((2,7))
 for remaining in range(1,HORIZON+1):
  new=np.zeros_like(values);new_success=np.zeros_like(success)
  for target_index,goal in enumerate([0,6]):
   for position in range(1,6):
    right_probability=(.9 if goal==6 else .1)if toward_goal else .5
    for delta,probability in [(-1,1-right_probability),(1,right_probability)]:
     nxt=position+delta;end=nxt in (0,6);reward=1 if nxt==goal else -1 if end else -.02
     new[target_index,position]+=probability*(reward+(0 if end else values[target_index,nxt]))
     new_success[target_index,position]+=probability*((nxt==goal)+(0 if end else success[target_index,nxt]))
  values,success=new,new_success
 return float(values[:,1:6].mean()),float(success[:,1:6].mean())

def train_dqn(seed,steps=6144):
 torch.manual_seed(seed);rng=np.random.default_rng(seed+1);env=Courier(seed+2);net=QNet();target=copy.deepcopy(net).eval();opt=torch.optim.Adam(net.parameters(),lr=.003);buffer=[];curve=[];losses=[];obs=env.observe()[0]
 for step in range(1,steps+1):
  epsilon=max(.05,1-.95*step/(steps/2))
  with torch.no_grad():action=int(net(torch.from_numpy(obs)).argmax())
  if rng.random()<epsilon:action=int(rng.integers(2))
  nxt,reward,done,reached=env.step([action]);buffer.append((obs.copy(),action,float(reward[0]),nxt[0].copy(),bool(done[0])))
  if len(buffer)>3000:buffer.pop(0)
  obs=nxt[0]
  if done[0]:env.reset(np.array([0]));obs=env.observe()[0]
  if len(buffer)>=128 and step%4==0:
   batch=[buffer[i]for i in rng.choice(len(buffer),64,replace=False)];s,a,r,ns,d=map(np.array,zip(*batch));s=torch.tensor(s);ns=torch.tensor(ns);a=torch.tensor(a);r=torch.tensor(r,dtype=torch.float32);d=torch.tensor(d,dtype=torch.float32)
   with torch.no_grad():y=r+GAMMA*(1-d)*target(ns).max(1).values
   prediction=net(s).gather(1,a[:,None]).squeeze(1);loss=nn.functional.smooth_l1_loss(prediction,y);opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(net.parameters(),1);opt.step();losses.append(float(loss.detach()))
  if step%128==0:target.load_state_dict(net.state_dict())
  if step%512==0:curve.append([step,evaluate(net,'DQN',9001,100)['mean_return']])
 return net,curve,losses

def gae(rewards,values,next_values,dones,gamma,lam):
 advantages=np.zeros_like(rewards);last=np.zeros(rewards.shape[1],dtype=np.float32)
 for t in range(len(rewards)-1,-1,-1):
  mask=1-dones[t];delta=rewards[t]+gamma*mask*next_values[t]-values[t];last=delta+gamma*lam*mask*last;advantages[t]=last
 return advantages

def train_ppo(seed,steps=6144):
 torch.manual_seed(seed);rng=np.random.default_rng(seed+1);env=Courier(seed+2,16);net=ActorCritic();opt=torch.optim.Adam(net.parameters(),lr=.006);curve=[];diagnostics=[];horizon=32
 for update in range(steps//(16*horizon)):
  storage=[]
  for _ in range(horizon):
   obs=env.observe()
   with torch.no_grad():logits,value=net(torch.from_numpy(obs));dist=Categorical(logits=logits);action=dist.sample();oldlog=dist.log_prob(action)
   nxt,reward,done,reached=env.step(action.numpy())
   with torch.no_grad():nv=net(torch.from_numpy(nxt))[1]
   storage.append((obs,action.numpy(),oldlog.numpy(),value.numpy(),reward,done.astype('float32'),nv.numpy()));env.reset(np.flatnonzero(done))
  obs,act,oldlog,values,rewards,dones,nextvalues=[np.array(x)for x in zip(*storage)];adv=gae(rewards,values,nextvalues,dones,GAMMA,.95);returns=adv+values
  obs=torch.tensor(obs.reshape(-1,10));act=torch.tensor(act.ravel());oldlog=torch.tensor(oldlog.ravel());returns=torch.tensor(returns.ravel());adv=torch.tensor(adv.ravel());adv=(adv-adv.mean())/(adv.std(unbiased=False)+1e-8)
  for epoch in range(4):
   for ids in np.array_split(rng.permutation(len(obs)),4):
    logits,v=net(obs[ids]);dist=Categorical(logits=logits);ratio=(dist.log_prob(act[ids])-oldlog[ids]).exp();objective=torch.minimum(ratio*adv[ids],ratio.clamp(.8,1.2)*adv[ids]);vloss=(v-returns[ids]).square().mean();loss=-objective.mean()+.5*vloss-.01*dist.entropy().mean();opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(net.parameters(),.5);opt.step()
  with torch.no_grad():logits,_=net(obs);dist=Categorical(logits=logits);ratio=(dist.log_prob(act)-oldlog).exp();diagnostics.append([float(((ratio<.8)|(ratio>1.2)).float().mean()),float((oldlog-dist.log_prob(act)).mean()),float(dist.entropy().mean())])
  curve.append([(update+1)*16*horizon,evaluate(net,'PPO',9001,100)['mean_return']])
 return net,curve,diagnostics

def run(out,language):
 out.mkdir(parents=True,exist_ok=True);tr=lambda z,e:z if language=='zh'else e;plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
 def save(fig,n):fig.savefig(out/f'{n}-{language}.svg',bbox_inches='tight');fig.savefig(out/f'{n}-{language}.png',dpi=140,bbox_inches='tight');plt.close(fig)
 seeds=[37,137,237];curves={};scores={};models={};diag=[]
 for kind,train in [('DQN',train_dqn),('PPO',train_ppo)]:
  curves[kind]=[];scores[kind]=[]
  for seed in seeds:
   net,curve,detail=train(seed);curves[kind].append(curve);scores[kind].append(evaluate(net,kind,19001,500))
   if seed==37:models[kind]=net
   if kind=='PPO':diag.append(detail)
  print(kind,[x['mean_return']for x in scores[kind]],flush=True)
 # Positive max bias with independent zero-mean estimation noise.
 rng=np.random.default_rng(3700);action_counts=[2,5,10,20];bias=[];spread=[]
 for k in action_counts:
  online=rng.normal(size=(50000,k));independent=rng.normal(size=(50000,k));selected=online.argmax(1);maxima=online.max(1);double=independent[np.arange(len(online)),selected];bias.append([maxima.mean(),double.mean()]);spread.append([maxima.std()/math.sqrt(len(maxima)),double.std()/math.sqrt(len(double))])
 hand=gae(np.array([[0],[0],[1]],dtype='float32'),np.array([[.2],[.3],[.4]],dtype='float32'),np.array([[.3],[.4],[0]],dtype='float32'),np.array([[0],[0],[1]],dtype='float32'),.9,.8).ravel()
 torch.save({kind:model.state_dict()for kind,model in models.items()},out/'policies.pt');loaded=torch.load(out/'policies.pt',weights_only=True);probe=torch.eye(10);reload_errors={}
 for kind,cls in [('DQN',QNet),('PPO',ActorCritic)]:
  fresh=cls();fresh.load_state_dict(loaded[kind]);before=models[kind](probe);after=fresh(probe)
  if kind=='PPO':before,after=before[0],after[0]
  reload_errors[kind]=float((before-after).abs().max().detach())
 oracle_value,oracle_success=exact_policy_value(True);random_value,random_success=exact_policy_value(False)
 summary={'seeds':seeds,'steps_per_seed':6144,'evaluation_episodes_per_seed':500,'gamma':GAMMA,'finite_horizon':20,'slip_probability':.1,'exact_toward_goal_return':oracle_value,'exact_toward_goal_success':oracle_success,'exact_random_return':random_value,'exact_random_success':random_success,'evaluation':{kind:{'seed_mean_returns':[s['mean_return']for s in values],'seed_success_rates':[s['success_rate']for s in values],'mean_return':float(np.mean([s['mean_return']for s in values]))}for kind,values in scores.items()},'gae_hand':hand.tolist(),'dqn_hand_target':1+.9*5,'double_dqn_hand_target':1+.9*2,'dueling_hand_q':[1,3],'ppo_positive_clipped':min(1.5*2,1.2*2),'ppo_negative_clipped':min(.5*(-2),.8*(-2)),'max_bias':np.array(bias).tolist(),'action_counts':action_counts,'reload_errors':reload_errors}
 (out/'evaluation.json').write_text(json.dumps(scores,indent=2),encoding='utf-8')
 (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');(out/'configuration.json').write_text(json.dumps({'environment':'finite-horizon courier','observation':'onehotposition7,onehotgoal2,remaining/20','actions':['left','right'],'reward':'goal+1,wrong endpoint-1,otherwise-0.02','architecture':'10-32tanh-32tanh;Q2 or policy2/value1','saved_seed':37,'steps':6144,'evaluation_seed':19001},indent=2),encoding='utf-8');np.savez_compressed(out/'data.npz',dqn_curves=curves['DQN'],ppo_curves=curves['PPO'],ppo_diagnostics=diag,bias=bias,bias_standard_error=spread,gae=hand)
 fig,axs=plt.subplots(1,2,figsize=(11,4.1),layout='constrained')
 for kind,color in [('DQN','#176b91'),('PPO','#bc6945')]:
  data=np.array(curves[kind]);x=data[0,:,0];vals=data[:,:,1];axs[0].plot(x,vals.mean(0),label=kind,color=color);axs[0].fill_between(x,vals.min(0),vals.max(0),color=color,alpha=.15)
  means=[s['mean_return']for s in scores[kind]];axs[1].scatter(np.full(3,0 if kind=='DQN' else 1)+np.array([-.1,0,.1]),means,color=color,s=60,label=kind)
 axs[0].axhline(oracle_value,color='#267c6a',ls=':',label=tr('朝目标策略精确期望','Exact toward-goal expectation'));axs[0].axhline(random_value,color='#999',ls='--',label=tr('随机策略精确期望','Exact random expectation'));axs[0].set(xlabel=tr('环境交互步数 / 每个种子','Environment steps / seed'),ylabel=tr('贪心评价回报','Greedy evaluation return'),title=tr('3个种子：均值与最小—最大范围','3 seeds: mean and min–max range'));axs[0].legend(fontsize=8);axs[1].set(xticks=[0,1],xticklabels=['DQN','PPO'],ylabel=tr('独立500回合的平均回报','Mean return over 500 independent episodes'),title=tr('固定最终预算，不挑最好检查点','Fixed final budget; no best-checkpoint selection'));save(fig,'learning')
 fig,axs=plt.subplots(2,2,figsize=(11,4.8),layout='constrained')
 for row,kind in enumerate(['DQN','PPO']):
  for col,goal in enumerate([0,6]):
   ax=axs[row,col];positions=np.arange(1,6);obs=np.column_stack([np.eye(7)[positions],np.tile(np.eye(2)[goal//6],(5,1)),np.ones(5)]).astype('float32')
   with torch.no_grad():res=models[kind](torch.tensor(obs));values=res[0].softmax(-1).numpy()if kind=='PPO'else res.numpy()
   im=ax.imshow(values.T,aspect='auto',cmap='viridis',vmin=0 if kind=='PPO'else -1.1,vmax=1 if kind=='PPO'else 1.1);ax.set(xticks=range(5),xticklabels=positions,yticks=[0,1],yticklabels=tr('向左|向右','Left|Right').split('|'),xlabel=tr('初始位置','Starting position'),title=f'{kind} / '+tr('目标','target')+f'={goal}')
   for i in range(2):
    for j in range(5):ax.text(j,i,f'{values[j,i]:.2f}',ha='center',va='center',color='white'if values[j,i]<(values.max()+values.min())/2 else'#102f43')
   fig.colorbar(im,ax=ax,ticks=[0,.5,1]if kind=='PPO'else[-1,0,1],label=tr('概率'if kind=='PPO'else'Q值','Probability'if kind=='PPO'else'Q value'))
 save(fig,'policy')
 fig,axs=plt.subplots(1,3,figsize=(12,3.6),layout='constrained');bias=np.array(bias);spread=np.array(spread)
 for j,label,color in [(0,tr('同一估计取最大','Max of one estimate'),'#bc6945'),(1,tr('独立估计评价所选动作','Independent evaluation'),'#176b91')]:axs[0].errorbar(action_counts,bias[:,j],yerr=1.96*spread[:,j],fmt='o-',label=label,color=color)
 axs[0].axhline(0,color='#888',ls='--');axs[0].set(xticks=action_counts,xlabel=tr('候选动作数','Number of actions'),ylabel=tr('真实值0时的平均估计','Mean estimate when true values are 0'),title=tr('50000次噪声算例','50000 noise experiments'));axs[0].legend(fontsize=7)
 ratio=np.linspace(.3,1.7,200)
 for adv,color in [(2,'#176b91'),(-2,'#bc6945')]:axs[1].plot(ratio,np.minimum(ratio*adv,np.clip(ratio,.8,1.2)*adv),label=f'A={adv}',color=color)
 axs[1].axvspan(.8,1.2,color='#d9e4e9',alpha=.6);axs[1].set(xlabel=tr('新旧策略概率比','New/old probability ratio'),ylabel=tr('单样本代理目标','Single-sample surrogate'),title='PPO-Clip');axs[1].legend()
 axs[2].bar(range(3),hand,color='#267c6a');axs[2].set(xticks=range(3),xticklabels=['t=0','t=1','t=2'],ylabel=tr('优势估计','Advantage estimate'),title=tr('GAE手算：γ=.9，λ=.8','GAE example: γ=.9, λ=.8'));save(fig,'mechanisms');print(json.dumps(summary,indent=2))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('output'));p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();run(args.output,args.language)
