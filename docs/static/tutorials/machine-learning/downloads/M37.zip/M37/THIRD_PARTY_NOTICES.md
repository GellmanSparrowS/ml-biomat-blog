# Public sources and third-party materials

- Spinning Up — Algorithm Taxonomy: https://spinningup.openai.com/en/latest/spinningup/rl_intro2.html
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Playing Atari with Deep Reinforcement Learning: https://arxiv.org/abs/1312.5602
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- CleanRL — DQN: https://docs.cleanrl.dev/rl-algorithms/dqn/
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Deep Reinforcement Learning with Double Q-learning: https://arxiv.org/abs/1509.06461
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Dueling Network Architectures: https://arxiv.org/abs/1511.06581
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Spinning Up — Policy Optimization: https://spinningup.openai.com/en/latest/spinningup/rl_intro3.html
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Generalized Advantage Estimation: https://arxiv.org/abs/1506.02438
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Proximal Policy Optimization Algorithms: https://arxiv.org/abs/1707.06347
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Spinning Up — PPO Implementation: https://raw.githubusercontent.com/openai/spinningup/master/spinup/algos/pytorch/ppo/ppo.py
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Spinning Up — PPO: https://spinningup.openai.com/en/latest/algorithms/ppo.html
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Spinning Up — DDPG: https://spinningup.openai.com/en/latest/algorithms/ddpg.html
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Spinning Up — TD3: https://spinningup.openai.com/en/latest/algorithms/td3.html
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
- Spinning Up — SAC: https://spinningup.openai.com/en/latest/algorithms/sac.html
  Technical reference. Original teaching implementation and experiment figures; OpenAI taxonomy reproduced under MIT with full notice.
