# Public sources and third-party materials

- Optical Recognition of Handwritten Digits — UCI: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits
  Dataset CC BY 4.0; E. Alpaydin and C. Kaynak
- scikit-learn — load_digits: https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html
  scikit-learn BSD-3-Clause; dataset attribution separate
- PyTorch — Conv2d: https://docs.pytorch.org/docs/2.15/generated/torch.nn.Conv2d.html
  Technical documentation reference
- Dive into Deep Learning — LeNet: https://d2l.ai/chapter_convolutional-neural-networks/lenet.html
  CC BY-SA 4.0; original explanatory prose here
- Deep Residual Learning for Image Recognition: https://arxiv.org/abs/1512.03385
  Primary-paper link; no paper figure copied
- Feature Visualization: https://distill.pub/2017/feature-visualization/
  CC BY 4.0; Olah, Mordvintsev, Schubert
- An Image is Worth 16x16 Words: https://arxiv.org/abs/2010.11929
  Primary-paper link; no paper figure copied
