"""Small CNN, shift robustness, and transfer learning on public 8x8 digits."""
from pathlib import Path
import argparse,copy,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import torch
from torch import nn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
import sklearn

class TinyCNN(nn.Module):
    def __init__(self,classes=10):
        super().__init__();self.conv1=nn.Conv2d(1,8,3,padding=1);self.conv2=nn.Conv2d(8,16,3,padding=1)
        self.pool=nn.MaxPool2d(2);self.head=nn.Linear(16*2*2,classes)
    def features(self,x):return self.pool(torch.relu(self.conv2(self.pool(torch.relu(self.conv1(x))))))
    def forward(self,x):return self.head(self.features(x).flatten(1))

def shift(images,dy,dx):
    # Zero padding, never wrap pixels across the opposite image boundary.
    p=nn.functional.pad(images,(1,1,1,1));return p[:,:,1-dy:9-dy,1-dx:9-dx]

def train(model,tx,ty,vx,vy,epochs=50,augment=False,lr=.01):
    opt=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=lr)
    generator=torch.Generator().manual_seed(122);rng=np.random.default_rng(123)
    best=float('inf');saved=None;history=[];best_epoch=0
    for epoch in range(1,epochs+1):
        model.train()
        for ids in torch.randperm(len(tx),generator=generator).split(64):
            batch=tx[ids]
            if augment:
                dy,dx=rng.integers(-1,2,2);batch=shift(batch,int(dy),int(dx))
            opt.zero_grad(set_to_none=True);loss=nn.functional.cross_entropy(model(batch),ty[ids]);loss.backward();opt.step()
        model.eval()
        with torch.no_grad():
            logits=model(vx);vl=float(nn.functional.cross_entropy(logits,vy));accuracy=float((logits.argmax(1)==vy).float().mean())
            tl=float(nn.functional.cross_entropy(model(tx),ty))
        history.append([epoch,tl,vl,accuracy])
        if vl<best:best=vl;best_epoch=epoch;saved=copy.deepcopy(model.state_dict())
    model.load_state_dict(saved);model.eval();return np.array(history),best_epoch

def evaluate(model,x,y):
    with torch.no_grad():pred=model(x).argmax(1)
    return float((pred==y).float().mean()),pred.numpy()

def run(output,language):
    output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    zh=language=='zh';tr=lambda z,e:z if zh else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    digits=load_digits();x=torch.tensor(digits.images[:,None]/16,dtype=torch.float32);y=torch.tensor(digits.target,dtype=torch.long)
    train_ids,held_ids=train_test_split(np.arange(len(y)),test_size=720,stratify=digits.target,random_state=120)
    val_ids,test_ids=train_test_split(held_ids,test_size=360,stratify=digits.target[held_ids],random_state=121)
    tx,ty=x[train_ids],y[train_ids];vx,vy=x[val_ids],y[val_ids];ex,ey=x[test_ids],y[test_ids]
    models={};histories={};metrics={}
    for name,augmentation in [('standard',False),('augmented',True)]:
        torch.manual_seed(124);model=TinyCNN();history,best=train(model,tx,ty,vx,vy,augment=augmentation)
        acc,pred=evaluate(model,ex,ey);shift_acc,_=evaluate(model,shift(ex,0,1),ey)
        models[name]=model;histories[name]=history;metrics[name]={'test_accuracy':acc,'shift_right_accuracy':shift_acc,'best_epoch':best}
        torch.save(model.state_dict(),output/f'{name}.pt')
    model=models['standard'];acc,pred=evaluate(model,ex,ey);cm=confusion_matrix(ey,pred,labels=range(10))
    errors=np.flatnonzero(pred!=ey.numpy());correct=np.flatnonzero(pred==ey.numpy())
    gallery=np.concatenate([errors[:10],correct[:max(0,20-len(errors[:10]))]])
    fig,axes=plt.subplots(4,5,figsize=(10,8),layout='constrained')
    for ax,ix in zip(axes.flat,gallery):
        ax.imshow(ex[ix,0],cmap='gray_r',vmin=0,vmax=1,interpolation='nearest')
        color='#A65327' if pred[ix]!=int(ey[ix]) else '#147566'
        ax.set_title(tr(f'真{int(ey[ix])} → 预测{pred[ix]}',f'True {int(ey[ix])} → predicted {pred[ix]}'),color=color,fontsize=10)
        ax.set_xticks([]);ax.set_yticks([])
        for sp in ax.spines.values():sp.set_visible(True);sp.set_edgecolor(color);sp.set_linewidth(1.5)
    fig.savefig(output/f'gallery-{language}.svg');plt.close(fig)
    fig=plt.figure(figsize=(12,7.8),layout='constrained');gs=fig.add_gridspec(2,2,width_ratios=[1.1,1])
    ax=fig.add_subplot(gs[:,0]);im=ax.imshow(cm,cmap='Blues')
    for r in range(10):
        for c in range(10):
            if cm[r,c]:ax.text(c,r,str(cm[r,c]),ha='center',va='center',color='white' if cm[r,c]>20 else '#17323c')
    ax.set(xticks=range(10),yticks=range(10),xlabel=tr('预测类别','Predicted class'),ylabel=tr('真实类别','True class'));fig.colorbar(im,ax=ax,shrink=.5,label=tr('样本数','Count'))
    ax=fig.add_subplot(gs[0,1])
    for name,color in [('standard','#0072B2'),('augmented','#D58500')]:ax.plot(histories[name][:,0],histories[name][:,2],color=color,label=tr('普通训练' if name=='standard' else '平移增强',name))
    ax.set(xlabel=tr('训练轮数','Epoch'),ylabel=tr('验证交叉熵','Validation cross entropy'));ax.legend()
    ax=fig.add_subplot(gs[1,1]);positions=np.arange(2)
    for offset,(name,color) in zip([-.18,.18],[('standard','#0072B2'),('augmented','#D58500')]):
        vals=[metrics[name]['test_accuracy'],metrics[name]['shift_right_accuracy']];ax.bar(positions+offset,vals,width=.34,color=color,label=tr('普通训练' if name=='standard' else '平移增强',name))
        for j,v in enumerate(vals):ax.text(j+offset,v+.015,f'{v:.1%}',ha='center',fontsize=9)
    ax.set(xticks=positions,xticklabels=[tr('原图','Original'),tr('右移1像素','Right shift: 1 pixel')],ylim=(0,1.12),ylabel=tr('测试准确率','Test accuracy'));ax.legend(loc='lower left')
    fig.savefig(output/f'results-{language}.svg');plt.close(fig)
    # One correctly classified digit 8; all maps from its actual trained forward pass.
    ix=int(next(i for i in correct if int(ey[i])==8));sample=ex[ix:ix+1]
    with torch.no_grad():kernels=model.conv1.weight[:,0].numpy();maps=torch.relu(model.conv1(sample))[0].numpy()
    fig=plt.figure(figsize=(13,4),layout='constrained');gs=fig.add_gridspec(2,9)
    ax=fig.add_subplot(gs[:,0]);ax.imshow(sample[0,0],cmap='gray_r',vmin=0,vmax=1);ax.set_title(tr('输入8','Input 8'));ax.axis('off')
    wmax=float(np.abs(kernels).max());amax=float(maps.max())
    top=[];bottom=[]
    for j in range(8):
        ax=fig.add_subplot(gs[0,j+1]);imw=ax.imshow(kernels[j],cmap='RdBu_r',vmin=-wmax,vmax=wmax,interpolation='nearest');ax.set_title(f'{j}');ax.axis('off');top.append(ax)
        ax=fig.add_subplot(gs[1,j+1]);ima=ax.imshow(maps[j],cmap='magma',vmin=0,vmax=amax,interpolation='nearest');ax.axis('off');bottom.append(ax)
    fig.colorbar(imw,ax=top,shrink=.6,label=tr('卷积核权重','Kernel weight'));fig.colorbar(ima,ax=bottom,shrink=.6,label=tr('ReLU响应','ReLU response'))
    fig.savefig(output/f'features-{language}.svg');plt.close(fig)
    # Transfer from digits 0--4 to different target classes 5--9.
    source_train=ty<5;source_val=vy<5;torch.manual_seed(125);source=TinyCNN(5)
    train(source,tx[source_train],ty[source_train],vx[source_val],vy[source_val],epochs=40)
    rng=np.random.default_rng(126);few=np.concatenate([rng.choice(np.flatnonzero(ty.numpy()==k),20,replace=False) for k in range(5,10)])
    target_val=vy>=5;target_test=ey>=5;transfer={}
    for setting in ['scratch','frozen','finetune']:
        torch.manual_seed(127);target=TinyCNN(5)
        if setting!='scratch':
            target.conv1.load_state_dict(source.conv1.state_dict());target.conv2.load_state_dict(source.conv2.state_dict())
        if setting=='frozen':
            for p in list(target.conv1.parameters())+list(target.conv2.parameters()):p.requires_grad=False
        h,best=train(target,tx[few],ty[few]-5,vx[target_val],vy[target_val]-5,epochs=60,lr=.005)
        score,_=evaluate(target,ex[target_test],ey[target_test]-5)
        transfer[setting]={'test_accuracy':score,'best_epoch':best,'trainable_parameters':sum(p.numel() for p in target.parameters() if p.requires_grad)}
        torch.save(target.state_dict(),output/f'transfer-{setting}.pt')
    fig,ax=plt.subplots(figsize=(8,4.6),layout='constrained');labels=tr(['从头训练','冻结卷积特征','全部微调'],['From scratch','Frozen features','Fine-tuned features'])
    scores=[v['test_accuracy'] for v in transfer.values()];ax.bar(range(3),scores,color=['#89939b','#0072B2','#D58500'],width=.6)
    for j,score in enumerate(scores):ax.text(j,score+.015,f'{score:.1%}',ha='center')
    ax.set(xticks=range(3),xticklabels=labels,ylim=(0,1.12),ylabel=tr('目标类别5–9测试准确率','Target-class 5–9 test accuracy'))
    fig.savefig(output/f'transfer-{language}.svg');plt.close(fig)
    # Exact checks: cross-correlation window and zero-residual identity on nonnegative data.
    edge=torch.tensor([[-1.,0,1],[-1,0,1],[-1,0,1]]).view(1,1,3,3)
    image=torch.zeros(1,1,7,7);image[:,:,:,3:]=1;edge_result=nn.functional.conv2d(image,edge)
    assert float(edge_result[0,0,2,1])==3
    residual=nn.Conv2d(8,8,3,padding=1);nn.init.zeros_(residual.weight);nn.init.zeros_(residual.bias)
    positive=torch.rand(2,8,4,4);identity_error=float((torch.relu(positive+residual(positive))-positive).abs().max().detach());assert identity_error==0
    summary={'dataset':'sklearn bundled UCI optical digits','total':len(y),'splits':{'train':len(tx),'validation':len(vx),'test':len(ex)},'models':metrics,'parameter_count':sum(p.numel() for p in model.parameters()),'test_error_count':len(errors),'feature_sample_dataset_index':int(test_ids[ix]),'transfer_source_train_n':int(source_train.sum()),'transfer_target_train_n':len(few),'transfer_target_test_n':int(target_test.sum()),'transfer':transfer,'edge_manual_value':float(edge_result[0,0,2,1]),'zero_residual_identity_error':identity_error,'torch_version':torch.__version__,'sklearn_version':sklearn.__version__}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    np.savez(output/'experiment.npz',train_ids=train_ids,validation_ids=val_ids,test_ids=test_ids,predictions=pred,confusion=cm,kernels=kernels,maps=maps,gallery_ids=test_ids[gallery],few_shot_train_ids=train_ids[few],**{f'history_{k}':v for k,v in histories.items()})
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();run(a.output,a.language)
