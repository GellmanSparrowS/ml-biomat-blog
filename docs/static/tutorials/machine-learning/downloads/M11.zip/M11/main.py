"""Representation, label budgets, and forgetting: an entirely local CPU experiment.

Data: sklearn digits (E. Alpaydin / C. Kaynak, UCI, CC BY 4.0).
Run: python main.py --output results --language en
"""
from pathlib import Path
import argparse, copy, json, platform
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
import sklearn
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

torch.set_num_threads(2)
torch.use_deterministic_algorithms(True)
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,default=Path('results'))
parser.add_argument('--language',choices=['zh','en'],default='en')
args=parser.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True)
zh=args.language=='zh'
def tr(a,b): return a if zh else b
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],
 'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5',
 'axes.facecolor':'#faf9f5','svg.fonttype':'none','axes.titleweight':'bold'})
def save(fig,name):
 fig.savefig(out/f'{name}-{args.language}.svg',bbox_inches='tight');plt.close(fig)

data=load_digits();X=(data.data/16).astype('float32');y=data.target
train,other=train_test_split(np.arange(len(y)),test_size=720,stratify=y,random_state=110)
val,test=train_test_split(other,test_size=360,stratify=y[other],random_state=111)
xt=torch.tensor(X[train]);yt=torch.tensor(y[train]);xte=torch.tensor(X[test]);yte=y[test]
class Encoder(nn.Module):
 def __init__(self):
  super().__init__();self.net=nn.Sequential(nn.Linear(64,64),nn.ReLU(),nn.Linear(64,32))
 def forward(self,x): return self.net(x)
class Contrastive(nn.Module):
 def __init__(self):
  super().__init__();self.encoder=Encoder();self.projector=nn.Sequential(nn.Linear(32,32),nn.ReLU(),nn.Linear(32,16))
 def forward(self,x): return F.normalize(self.projector(self.encoder(x)),dim=1)
def augment(x,g):
 noise=.08*torch.randn(x.shape,generator=g)
 visible=torch.rand(x.shape,generator=g)>.15
 return (x+noise).clamp(0,1)*visible
def ntxent(a,b,tau=.2):
 z=torch.cat([a,b]);n=len(a);scores=z@z.T/tau
 scores=scores.masked_fill(torch.eye(2*n,dtype=torch.bool),-1e9)
 target=(torch.arange(2*n)+n)%(2*n)
 return F.cross_entropy(scores,target)
torch.manual_seed(112);model=Contrastive();untrained=copy.deepcopy(model.encoder)
optimizer=torch.optim.Adam(model.parameters(),lr=.001)
g=torch.Generator().manual_seed(113);losses=[]
for epoch in range(80):
 total=0.;order=torch.randperm(len(xt),generator=g)
 for ids in order.split(128):
  a,b=augment(xt[ids],g),augment(xt[ids],g)
  loss=ntxent(model(a),model(b));optimizer.zero_grad();loss.backward();optimizer.step()
  total+=loss.item()*len(ids)
 losses.append(total/len(xt))
model.eval()
with torch.no_grad():
 feat=F.normalize(model.encoder(xt),dim=1).numpy()
 testfeat=F.normalize(model.encoder(xte),dim=1).numpy()
 rawfeat=F.normalize(untrained(xt),dim=1).numpy()
 rawtestfeat=F.normalize(untrained(xte),dim=1).numpy()
rng=np.random.default_rng(114)
initial=np.concatenate([rng.choice(np.where(y[train]==k)[0],5,replace=False) for k in range(10)])
def probe(features,testing,ids):
 clf=LogisticRegression(C=10,max_iter=1500).fit(features[ids],y[train][ids])
 return clf,float(clf.score(testing,yte))
cl,accuracy=probe(feat,testfeat,initial)
_,random_accuracy=probe(rawfeat,rawtestfeat,initial)
_,pixel_accuracy=probe(X[train],X[test],initial)
prototypes=np.stack([feat[initial[y[train][initial]==k]].mean(0) for k in range(10)])
prototype_pred=((testfeat[:,None]-prototypes[None])**2).sum(2).argmin(1)
prototype_accuracy=float((prototype_pred==yte).mean())
pool=np.setdiff1d(np.arange(len(train)),initial)
confidence=cl.predict_proba(feat[pool]);accepted=confidence.max(1)>=.8
pseudo=dict(threshold=.8,count=int(accepted.sum()),correct_fraction=float((cl.predict(feat[pool][accepted])==y[train][pool][accepted]).mean()) if accepted.any() else None)
active={};acquired={}
for policy in ['entropy','random']:
 ids=initial.copy();curve=[];round_ids=[];rg=np.random.default_rng(115)
 for round_index in range(6):
  classifier,score=probe(feat,testfeat,ids);curve.append([len(ids),score])
  if round_index==5:break
  remaining=np.setdiff1d(np.arange(len(train)),ids)
  probabilities=classifier.predict_proba(feat[remaining])
  entropy=-(probabilities*np.log(np.maximum(probabilities,1e-15))).sum(1)
  selected=remaining[np.argsort(-entropy,kind='stable')[:20]] if policy=='entropy' else rg.choice(remaining,20,replace=False)
  round_ids.append(selected);ids=np.r_[ids,selected]
 active[policy]=curve;acquired[policy]=np.array(round_ids)

# Exact differentiable inner update: three tasks y = a*x, each with one support point.
w=torch.tensor(0.,requires_grad=True);outer=[]
for slope in [-1.,1.,3.]:
 support_loss=.5*(w-slope)**2
 inner_grad=torch.autograd.grad(support_loss,w,create_graph=True)[0]
 adapted=w-.5*inner_grad
 outer.append(.5*(2*adapted-2*slope)**2)
meta_loss=torch.stack(outer).mean();meta_gradient=torch.autograd.grad(meta_loss,w)[0].item()

# Class-incremental labels: the encoder has seen every training image without labels.
class Classifier(nn.Module):
 def __init__(self,encoder):
  super().__init__();self.encoder=copy.deepcopy(encoder);self.head=nn.Linear(32,10)
 def forward(self,x): return self.head(self.encoder(x))
torch.manual_seed(116);stage_a=Classifier(model.encoder)
old=np.where(y[train]<5)[0];new=np.where(y[train]>=5)[0]
def fit_steps(net,primary,replay=None,seed=117):
 opt=torch.optim.Adam(net.parameters(),lr=.003);gen=np.random.default_rng(seed)
 net.train()
 for step in range(200):
  ids=gen.choice(primary,64 if replay is None else 32)
  if replay is not None:ids=np.r_[ids,gen.choice(replay,32)]
  loss=F.cross_entropy(net(xt[ids]),yt[ids]);opt.zero_grad();loss.backward();opt.step()
 net.eval()
def task_scores(net):
 with torch.no_grad(): pred=net(xte).argmax(1).numpy()
 return [float((pred[yte<5]==yte[yte<5]).mean()),float((pred[yte>=5]==yte[yte>=5]).mean())]
fit_steps(stage_a,old);continual={'after_A':task_scores(stage_a)}
replay_rng=np.random.default_rng(118)
buffer=np.concatenate([replay_rng.choice(np.where(y[train]==k)[0],16,replace=False) for k in range(5)])
for name,replay in [('new_only',None),('replay',buffer)]:
 net=copy.deepcopy(stage_a);fit_steps(net,new,replay,119);continual[name]=task_scores(net)
 torch.save(net.state_dict(),out/f'continual-{name}.pt')
torch.save(model.state_dict(),out/'contrastive.pt')

gv=torch.Generator().manual_seed(120)
chosen=np.array([np.flatnonzero(y[train]==k)[0] for k in range(10)])
images=xt[chosen];view1=augment(images,gv);view2=augment(images,gv)
fig,axs=plt.subplots(3,10,figsize=(13,4.8),gridspec_kw={'wspace':.03,'hspace':.15})
for row,items in enumerate([images,view1,view2]):
 for col,img in enumerate(items):
  axs[row,col].imshow(img.reshape(8,8),cmap='gray_r',vmin=0,vmax=1);axs[row,col].set_xticks([]);axs[row,col].set_yticks([])
  if row==0:axs[row,col].set_title(str(col))
 axs[row,0].set_ylabel(tr(['原图','视图 A','视图 B'][row],['Original','View A','View B'][row]))
fig.suptitle(tr('同一张图，两次独立变化：噪声 σ=0.08，遮挡概率 0.15','One image, two independent views: noise σ=0.08; masking probability 0.15'))
save(fig,'views')
with torch.no_grad():
 za,zb=model(view1),model(view2);similarity=(za@zb.T).numpy()
pca=PCA(n_components=2).fit(feat);coords=pca.transform(testfeat)
fig=plt.figure(figsize=(13,7.8));grid=fig.add_gridspec(2,2,width_ratios=[1,1.3],hspace=.4,wspace=.32)
ax=fig.add_subplot(grid[0,0]);ax.plot(np.arange(1,81),losses,color='#125f82',lw=2)
ax.set(xlabel=tr('训练轮数','Epoch'),ylabel=tr('平均 NT-Xent / nats','Mean NT-Xent / nats'),title=tr('A  标签未进入表示训练','A  Representation training sees no labels'))
ax=fig.add_subplot(grid[1,0]);im=ax.imshow(similarity,cmap='viridis',vmin=-1,vmax=1);ax.set(xlabel=tr('视图 B：样本编号','View B: sample index'),ylabel=tr('视图 A：样本编号','View A: sample index'),title=tr('B  对角线是同一原图的配对','B  Diagonal entries are positive pairs'))
fig.colorbar(im,ax=ax,fraction=.045,label=tr('余弦相似度','Cosine similarity'))
ax=fig.add_subplot(grid[:,1]);sc=ax.scatter(coords[:,0],coords[:,1],c=yte,cmap='tab10',s=23,alpha=.8,edgecolors='none')
ax.set(xlabel=tr('主成分 1','Principal component 1'),ylabel=tr('主成分 2','Principal component 2'),title=tr('C  测试表示的二维投影；颜色只用于读图','C  Test representations; labels color the plot only'))
fig.colorbar(sc,ax=ax,ticks=range(10),fraction=.045,label=tr('真实数字','True digit'));save(fig,'representation')
fig,(ax,bar)=plt.subplots(1,2,figsize=(12,4.6),gridspec_kw={'width_ratios':[1.5,1]},layout='constrained')
for policy,color,label in [('entropy','#b85d30',tr('熵选样','Entropy queries')),('random','#125f82',tr('随机选样','Random queries'))]:
 c=np.array(active[policy]);ax.plot(c[:,0],c[:,1],'-o',color=color,lw=2,label=label)
ax.set(xlabel=tr('累计人工标签数','Cumulative human labels'),ylabel=tr('测试准确率','Test accuracy'),ylim=(.5,1),title=tr('A  每轮新增 20 个标签','A  Twenty additional labels per round'));ax.legend()
names=[tr('像素 + 线性','Pixels + linear'),tr('随机表示 + 线性','Random + linear'),tr('对比表示 + 线性','Contrastive + linear'),tr('对比表示 + 原型','Contrastive + prototypes')]
vals=[pixel_accuracy,random_accuracy,accuracy,prototype_accuracy]
bar.barh(names,vals,color=['#a9b2b8','#a9b2b8','#125f82','#b85d30']);bar.set(xlim=(0,1.05),title=tr('B  相同的 50 个标签','B  The same 50 labels'),xlabel=tr('测试准确率','Test accuracy'))
for i,v in enumerate(vals):bar.text(v+.01,i,f'{v:.1%}',va='center',fontsize=10)
save(fig,'labels')
fig,(ax,table)=plt.subplots(1,2,figsize=(12,4.8),gridspec_kw={'width_ratios':[1.4,1]},layout='constrained')
names=['after_A','new_only','replay'];xx=np.arange(3)
ax.bar(xx-.18,[continual[n][0] for n in names],.36,label=tr('旧类 0–4','Old classes 0–4'),color='#125f82')
ax.bar(xx+.18,[continual[n][1] for n in names],.36,label=tr('新类 5–9','New classes 5–9'),color='#b85d30')
ax.set_xticks(xx,[tr('学完 A','After A'),tr('B：仅新样本','B: new only'),tr('B：加入回放','B: with replay')]);ax.set(ylim=(0,1.12),ylabel=tr('测试准确率','Test accuracy'),title=tr('A  学到新类后，旧知识还在吗？','A  Learning new classes: what survives?'));ax.legend(loc='upper left',fontsize=9)
matrix=np.array([continual[n] for n in names]);im=table.imshow(matrix,vmin=0,vmax=1,cmap='Blues',aspect='auto')
table.set_xticks([0,1],[tr('旧类','Old'),tr('新类','New')]);table.set_yticks(xx,[tr('A 后','After A'),tr('新样本','New only'),tr('80 张回放','80 replay images')]);table.set_title(tr('B  每种方式的实际结果','B  Measured task accuracies'))
for i in range(3):
 for j in range(2):table.text(j,i,f'{matrix[i,j]:.1%}',ha='center',va='center',color='white' if matrix[i,j]>.6 else '#152d3a',fontsize=14)
save(fig,'forgetting')
summary=dict(versions=dict(python=platform.python_version(),torch=torch.__version__,numpy=np.__version__,sklearn=sklearn.__version__),
 splits=dict(train=len(train),validation=len(val),test=len(test)),seed=110,
 contrastive=dict(epochs=80,temperature=.2,batch_size=128,final_loss=losses[-1],encoder_parameters=sum(p.numel() for p in model.encoder.parameters()),projector_parameters=sum(p.numel() for p in model.projector.parameters())),
 probes=dict(contrastive=accuracy,random=random_accuracy,pixels=pixel_accuracy,prototype=prototype_accuracy),
 active=active,pseudo=pseudo,continual=continual,replay_count=len(buffer),
 meta=dict(gradient=meta_gradient,initial=0,inner_rate=.5,outer_rate=.1,updated=-.1*meta_gradient),
 hand=dict(cosine=float(np.dot([.6,.8],[0.,1.])),uniform_three_candidate_loss=float(np.log(3)),masked_mse=float(np.mean((np.array([.3,.6])-np.array([.2,.8]))**2)),prototype=np.mean([[0.,1.],[2.,1.]],axis=0).tolist()))
(out/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
np.savez_compressed(out/'experiment.npz',train_indices=train,val_indices=val,test_indices=test,initial_labels=initial,
 features=feat,test_features=testfeat,pca_coordinates=coords,loss=losses,similarity=similarity,view1=view1.numpy(),view2=view2.numpy(),
 entropy_queries=acquired['entropy'],random_queries=acquired['random'],replay_indices=buffer)
print(json.dumps(summary,ensure_ascii=False,indent=2))
