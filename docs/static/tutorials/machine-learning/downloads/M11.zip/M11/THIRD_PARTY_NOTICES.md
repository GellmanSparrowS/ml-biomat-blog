# Public sources and third-party materials

- SimCLR: https://arxiv.org/abs/2002.05709
  Primary paper; figures not copied
- UvA Tutorial 17: SimCLR: https://uvadlc-notebooks.readthedocs.io/en/latest/tutorial_notebooks/tutorial17/SimCLR.html
  MIT; copyright 2020 Phillip Lippe; original tutorial output figure only
- Bootstrap Your Own Latent: https://arxiv.org/abs/2006.07733
  Primary paper; figures not copied
- Masked Autoencoders Are Scalable Vision Learners: https://arxiv.org/abs/2111.06377
  Primary paper; figures not copied
- FixMatch: https://arxiv.org/abs/2001.07685
  Primary paper; figures not copied
- Snorkel: Rapid Training Data Creation with Weak Supervision: https://arxiv.org/abs/1711.10160
  Primary paper; figures not copied
- Prototypical Networks for Few-shot Learning: https://arxiv.org/abs/1703.05175
  Primary paper; figures not copied
- Model-Agnostic Meta-Learning: https://arxiv.org/abs/1703.03400
  Primary paper; figures not copied
- Domain-Adversarial Training of Neural Networks: https://arxiv.org/abs/1505.07818
  Primary paper; figures not copied
- Experience Replay for Continual Learning: https://arxiv.org/abs/1811.11682
  Primary paper; our digit experiment is independently designed
- UCI Optical Recognition of Handwritten Digits: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits
  CC BY 4.0; E. Alpaydin and C. Kaynak
