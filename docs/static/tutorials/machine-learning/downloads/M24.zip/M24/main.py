"""Tabular reinforcement learning: bandits and the cliff-walking task.

Run: python main.py --output results --language en
Requires NumPy and Matplotlib. All data are synthetic and generated here.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

BLUE, RED, GOLD = '#176b91', '#b04743', '#c18a28'
START, GOAL, ROWS, COLS = 36, 47, 4, 12
MOVES = [(-1, 0), (0, 1), (1, 0), (0, -1)]


def transition(state, action):
    row, col = divmod(int(state), COLS)
    dr, dc = MOVES[int(action)]
    row, col = np.clip(row + dr, 0, ROWS-1), np.clip(col + dc, 0, COLS-1)
    next_state = int(row * COLS + col)
    if row == 3 and 0 < col < 11:
        return START, -100., False
    return next_state, -1., next_state == GOAL


def choose(q, rng, epsilon):
    if rng.random() < epsilon:
        return int(rng.integers(len(q)))
    ties = np.flatnonzero(np.isclose(q, q.max(), rtol=0, atol=1e-12))
    return int(rng.choice(ties))


def learn(method, seed, episodes=500, epsilon=.1, alpha=.5, gamma=1.):
    rng = np.random.default_rng(seed)
    q = np.zeros((ROWS * COLS, 4))
    returns, falls, lengths = [], [], []
    for _ in range(episodes):
        state = START
        action = choose(q[state], rng, epsilon)
        total, dropped = 0., 0
        for step in range(600):
            nxt, reward, done = transition(state, action)
            next_action = choose(q[nxt], rng, epsilon)
            future = q[nxt].max() if method == 'Q-learning' else q[nxt, next_action]
            target = reward if done else reward + gamma * future
            q[state, action] += alpha * (target - q[state, action])
            total += reward
            dropped += int(reward == -100)
            state, action = nxt, next_action
            if done:
                break
        returns.append(total); falls.append(dropped); lengths.append(step + 1)
    return q, np.array(returns), np.array(falls), np.array(lengths)


def greedy_route(q):
    state, path, total = START, [START], 0.
    for _ in range(100):
        state, reward, done = transition(state, int(q[state].argmax()))
        path.append(state); total += reward
        if done:
            return path, total, True
    return path, total, False


def bandit(method, seed, steps=400):
    means = np.array([.2, .5, .8, 1.])
    rng = np.random.default_rng(seed)
    q, counts = np.zeros(4), np.zeros(4, dtype=int)
    gaps = []
    for t in range(steps):
        if method == 'UCB':
            action = t if t < 4 else int(np.argmax(q + np.sqrt(2*np.log(t+1)/counts)))
        else:
            action = choose(q, rng, .1 if method == 'epsilon' else 0.)
        reward = means[action] + rng.normal(0, 1)
        counts[action] += 1
        q[action] += (reward - q[action]) / counts[action]
        gaps.append(means.max()-means[action])
    return np.cumsum(gaps), counts


def configure(language):
    plt.rcParams.update({'font.family':'sans-serif', 'font.sans-serif':['Microsoft YaHei','Arial'],
                         'font.size':11, 'axes.spines.top':False, 'axes.spines.right':False,
                         'svg.fonttype':'none', 'pdf.fonttype':42, 'axes.unicode_minus':False,
                         'figure.facecolor':'white', 'axes.facecolor':'white'})


def loop_figure(out, zh):
    fig, ax = plt.subplots(figsize=(11, 4.5)); ax.set(xlim=(0,11), ylim=(0,4.5)); ax.axis('off')
    boxes=[(1,2.0,3,1.2,'学习者：选择动作\n策略与价值估计' if zh else 'Agent: choose action\nPolicy and value estimates',BLUE),
           (7,2.0,3,1.2,'环境：回应动作\n位置变化与奖励' if zh else 'Environment: respond\nNew position and reward',RED)]
    for x,y,w,h,label,color in boxes:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.12',facecolor=color,edgecolor='none'))
        ax.text(x+w/2,y+h/2,label,color='white',ha='center',va='center',fontsize=13,linespacing=1.6)
    ax.add_patch(FancyArrowPatch((4.2,2.9),(6.8,2.9),arrowstyle='-|>',mutation_scale=18,color=BLUE,lw=2))
    ax.add_patch(FancyArrowPatch((6.8,2.25),(4.2,2.25),arrowstyle='-|>',mutation_scale=18,color=RED,lw=2))
    ax.text(5.5,3.18,'动作 a(t)' if zh else 'Action a(t)',ha='center')
    ax.text(5.5,1.8,'奖励 r(t+1)，状态 s(t+1)' if zh else 'Reward r(t+1), state s(t+1)',ha='center')
    for x,year,text in [(1.1,'规划 / Planning','已知转移，计算价值' if zh else 'Known transitions → values'),(4.3,'1988 · TD','由下一次预测更新' if zh else 'Learn from the next prediction'),(7.5,'1992 · Q-learning','由经验改进动作价值' if zh else 'Improve action values from experience')]:
        ax.text(x,.9,year,color=BLUE,fontweight='bold');ax.text(x,.42,text,fontsize=10)
    fig.tight_layout();fig.savefig(out/f'loop-{lang(zh)}.svg');fig.savefig(out/f'loop-{lang(zh)}.png',dpi=150);plt.close(fig)


def lang(zh):
    return 'zh' if zh else 'en'


def make_figures(out, zh, runs, routes, bandits):
    fig, axes = plt.subplots(1,2,figsize=(11,4.4),gridspec_kw={'width_ratios':[1.45,1]})
    for method,color,label in [('greedy',GOLD,'贪心' if zh else 'Greedy'),('epsilon',RED,'ε=0.1'),('UCB',BLUE,'UCB')]:
        regrets=np.stack([x[0] for x in bandits[method]])
        axes[0].plot(np.arange(1,401),regrets.mean(0),color=color,label=label,lw=2)
        lo,hi=np.quantile(regrets,[.25,.75],axis=0);axes[0].fill_between(np.arange(1,401),lo,hi,color=color,alpha=.12)
        x={'greedy':0,'epsilon':1,'UCB':2}[method]
        axes[1].scatter(np.full(len(regrets),x)+np.linspace(-.12,.12,len(regrets)),regrets[:,-1],c=color,alpha=.65,s=24)
    axes[0].set(xlabel='选择次数' if zh else 'Number of choices',ylabel='累计伪遗憾（奖励单位）' if zh else 'Cumulative pseudo-regret (reward units)');axes[0].legend(frameon=False)
    axes[1].set(xticks=[0,1,2],xticklabels=['贪心' if zh else 'Greedy','ε=0.1','UCB'],ylabel='第400步的累计伪遗憾' if zh else 'Pseudo-regret after 400 choices')
    fig.tight_layout();fig.savefig(out/f'bandits-{lang(zh)}.svg');fig.savefig(out/f'bandits-{lang(zh)}.png',dpi=150);plt.close(fig)
    fig=plt.figure(figsize=(12,7.4));gs=fig.add_gridspec(2,2,height_ratios=[1,1.4],hspace=.5,wspace=.3)
    for j,(method,color) in enumerate([('Q-learning',BLUE),('SARSA',RED)]):
        ax=fig.add_subplot(gs[0,j]);ax.set(xlim=(-.5,11.5),ylim=(3.5,-.5),aspect='equal',xticks=range(12),yticks=range(4))
        for row in range(4):
            for col in range(12):
                face='#efc9c7' if row==3 and 0<col<11 else '#f1f4f5'
                ax.add_patch(Rectangle((col-.48,row-.48),.96,.96,facecolor=face,edgecolor='white'))
        path=routes[method][0];pos=np.array([divmod(s,12) for s in path]);ax.plot(pos[:,1],pos[:,0],color=color,lw=2.3,marker='o',ms=3)
        ax.text(0,3,'S',ha='center',va='center',fontweight='bold');ax.text(11,3,'G',ha='center',va='center',fontweight='bold')
        ax.set_title(method+' · '+('种子0的贪心路径' if zh else 'greedy route, seed 0'));ax.set_xlabel('列' if zh else 'Column');ax.set_ylabel('行' if zh else 'Row')
    ax=fig.add_subplot(gs[1,0]);bx=fig.add_subplot(gs[1,1])
    for j,(method,color) in enumerate([('Q-learning',BLUE),('SARSA',RED)]):
        returns=np.stack([x[1] for x in runs[method]])
        blocks=returns.reshape(len(returns),25,20).mean(2)
        lo,hi=np.quantile(blocks,[.25,.75],axis=0)
        ax.plot(np.arange(20,501,20),blocks.mean(0),color=color,lw=2,label=method)
        ax.fill_between(np.arange(20,501,20),lo,hi,color=color,alpha=.15)
        scores=returns[:,-100:].mean(1);bx.scatter(j+np.linspace(-.12,.12,len(scores)),scores,c=color,s=35)
        bx.plot([j-.2,j+.2],[scores.mean()]*2,color=color,lw=2)
    ax.set(xlabel='训练回合（20回合分组）' if zh else 'Training episode (20-episode blocks)',ylabel='平均未折扣回报' if zh else 'Mean undiscounted return');ax.legend(frameon=False)
    bx.set(xticks=[0,1],xticklabels=['Q-learning','SARSA'],ylabel='末100回合平均回报' if zh else 'Mean return, last 100 episodes')
    fig.savefig(out/f'cliff-{lang(zh)}.svg',bbox_inches='tight');fig.savefig(out/f'cliff-{lang(zh)}.png',dpi=150,bbox_inches='tight');plt.close(fig)


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True);zh=args.language=='zh';configure(args.language)
    assert transition(START,1)==(START,-100.,False)
    assert transition(35,2)==(GOAL,-1.,True)
    assert abs(2+.2*(1+.9*4-2)-2.52)<1e-12
    runs={m:[learn(m,s) for s in range(8)] for m in ['Q-learning','SARSA']}
    routes={m:greedy_route(runs[m][0][0]) for m in runs}
    bandits={m:[bandit(m,s) for s in range(32)] for m in ['greedy','epsilon','UCB']}
    summary={'seeds':list(range(8)),'episodes':500,'epsilon':.1,'alpha':.5,'gamma':1.,'max_steps':600,'hand_update':2.52,'algorithms':{}}
    for m,results in runs.items():
        summary['algorithms'][m]={'last100_mean_return':float(np.mean([r[1][-100:].mean() for r in results])),
          'last100_falls_per_episode':float(np.mean([r[2][-100:].mean() for r in results])),
          'greedy_seed0_return':routes[m][1],'greedy_seed0_reached_goal':routes[m][2],'greedy_seed0_steps':len(routes[m][0])-1,
          'capped_episodes':int(sum((r[3]==600).sum() for r in results))}
        np.savez(args.output/f'{m.replace("-","")}-data.npz',returns=np.stack([r[1] for r in results]),q=np.stack([r[0] for r in results]),falls=np.stack([r[2] for r in results]))
    summary['bandit_final_pseudoregret']={m:float(np.mean([r[0][-1] for r in xs])) for m,xs in bandits.items()}
    loop_figure(args.output,zh);make_figures(args.output,zh,runs,routes,bandits)
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
