# Public sources and third-party materials

- Dive into Deep Learning — Q-Learning: https://d2l.ai/chapter_reinforcement-learning/qlearning.html
  CC BY-SA 4.0 (book text and original figures)
- Gymnasium — Cliff Walking: https://gymnasium.farama.org/environments/toy_text/cliff_walking/
  Technical reference
- Sutton (1988), Learning to predict by the methods of temporal differences: https://link.springer.com/article/10.1007/BF00115009
  Original paper reference
- Watkins and Dayan (1992), Q-learning: https://link.springer.com/article/10.1007/BF00992698
  Original paper reference
