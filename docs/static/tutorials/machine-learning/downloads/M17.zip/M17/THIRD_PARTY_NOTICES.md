# Public sources and third-party materials

- Haystack — First RAG Pipeline: https://haystack.deepset.ai/tutorials/27_first_rag_pipeline
  Technical reference; original teaching code, corpus and figures. External AgentCycle.gif is linked, not copied.
- Hugging Face Agents Course — Agent Cycle: https://huggingface.co/learn/agents-course/en/unit1/agent-steps-and-structure
  Technical reference; original teaching code, corpus and figures. External AgentCycle.gif is linked, not copied.
- Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks: https://arxiv.org/abs/2005.11401
  Technical reference; original teaching code, corpus and figures. External AgentCycle.gif is linked, not copied.
- ReAct: https://arxiv.org/abs/2210.03629
  Technical reference; original teaching code, corpus and figures. External AgentCycle.gif is linked, not copied.
- Apache Lucene — BM25Similarity: https://raw.githubusercontent.com/apache/lucene/main/lucene/core/src/java/org/apache/lucene/search/similarities/BM25Similarity.java
  Technical reference; original teaching code, corpus and figures. External AgentCycle.gif is linked, not copied.
- Elasticsearch — Reciprocal Rank Fusion: https://www.elastic.co/docs/reference/elasticsearch/rest-apis/reciprocal-rank-fusion
  Technical reference; original teaching code, corpus and figures. External AgentCycle.gif is linked, not copied.
- Sentence Transformers — Retrieve and Rerank: https://sbert.net/examples/sentence_transformer/applications/retrieve_rerank/README.html
  Technical reference; original teaching code, corpus and figures. External AgentCycle.gif is linked, not copied.
- JSON Schema — Objects: https://json-schema.org/understanding-json-schema/reference/object
  Technical reference; original teaching code, corpus and figures. External AgentCycle.gif is linked, not copied.
- Indirect Prompt Injection: https://arxiv.org/abs/2302.12173
  Technical reference; original teaching code, corpus and figures. External AgentCycle.gif is linked, not copied.
- Haystack — DocumentCleaner: https://docs.haystack.deepset.ai/docs/documentcleaner
  Technical reference; original teaching code, corpus and figures. External AgentCycle.gif is linked, not copied.
