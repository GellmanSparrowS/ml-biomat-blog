# Public sources and third-party materials

- scikit-learn — Linear Models: https://scikit-learn.org/stable/modules/linear_model.html
  BSD-3-Clause
- scikit-learn — Nearest Neighbors: https://scikit-learn.org/stable/modules/neighbors.html
  BSD-3-Clause
- scikit-learn — Naive Bayes: https://scikit-learn.org/stable/modules/naive_bayes.html
  BSD-3-Clause
- Tibshirani (1996), Regression Shrinkage and Selection via the Lasso: https://www2.stat.duke.edu/courses/Spring06/sta395/tibshirani.pdf
  Reference
- Kaplan & Meier (1958), Nonparametric Estimation from Incomplete Observations: https://web.stanford.edu/~lutian/coursepdf/KMpaper.pdf
  Reference
