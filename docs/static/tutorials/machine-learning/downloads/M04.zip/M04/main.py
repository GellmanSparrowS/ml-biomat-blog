"""Interpretable baseline models and explicit censoring on seeded teaching data."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split,GridSearchCV,KFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler,PolynomialFeatures
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression,Ridge,Lasso,LogisticRegression,PoissonRegressor
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import mean_squared_error,accuracy_score,log_loss

def kaplan_meier(duration,event):
 times=np.unique(duration[event]);survival=1.;ys=[];risk=[];deaths=[]
 for tm in times:
  n=int(np.sum(duration>=tm));d=int(np.sum((duration==tm)&event));survival*=1-d/n;ys.append(survival);risk.append(n);deaths.append(d)
 return np.r_[0,times],np.r_[1,ys],risk,deaths

def main(output,language):
 out=Path(output);out.mkdir(parents=True,exist_ok=True);rng=np.random.default_rng(44);zh=language=='zh'
 plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
 def t(z,e):return z if zh else e
 def save(f,n):f.savefig(out/f'{n}-{language}.svg',bbox_inches='tight');plt.close(f)
 # Regression: a known mean relation with correlated measurements and missing values.
 X=rng.normal(size=(300,10));X[:,1]=X[:,0]+rng.normal(0,.08,300);truth=np.array([2.,0.,-1.5,1.,0.,0.,0.,0.,0.,0.]);y=20+X@truth+rng.normal(0,1.4,300)
 missing=rng.random(X.shape)<.06;Xm=X.copy();Xm[missing]=np.nan;tr,te=train_test_split(np.arange(300),test_size=.3,random_state=44)
 cv=KFold(5,shuffle=True,random_state=44);results={};fits={}
 for name,est,grid in [('OLS',LinearRegression(),None),('Ridge',Ridge(),{'ridge__alpha':[.01,.1,1,10,100]}),('Lasso',Lasso(max_iter=10000),{'lasso__alpha':[.001,.01,.05,.1,.3]})]:
  pipe=make_pipeline(SimpleImputer(strategy='median',add_indicator=True),StandardScaler(),est)
  fitted=GridSearchCV(pipe,grid,cv=cv,scoring='neg_mean_squared_error') if grid else pipe;fitted.fit(Xm[tr],y[tr]);pred=fitted.predict(Xm[te]);best=fitted.best_estimator_ if grid else fitted
  results[name]={'test_rmse':float(np.sqrt(mean_squared_error(y[te],pred))),'selected':fitted.best_params_ if grid else {},'coefficients':best[-1].coef_.tolist(),'nonzero_coefficients':int(np.sum(np.abs(best[-1].coef_)>1e-9))};fits[name]=(best,pred)
 fig,axs=plt.subplots(1,3,figsize=(12,3.7),layout='constrained')
 for ax,(name,(m,pred)) in zip(axs,fits.items()):
  ax.scatter(pred,y[te]-pred,c=X[te,0],cmap='viridis',s=19,alpha=.8);ax.axhline(0,color='#d48745');ax.set(title=f'{name}: RMSE={results[name]["test_rmse"]:.3f}',xlabel=t('预测响应','Predicted response'),ylabel=t('观测−预测','Observed minus predicted'));ax.set_ylim(-5.5,5.5)
 fig.colorbar(axs[0].collections[0],ax=axs,shrink=.8,label=t('特征x₀（无量纲）','Feature x₀ (dimensionless)'));save(fig,'residuals')
 clean=StandardScaler().fit_transform(X[tr]);alphas=np.logspace(-3,2,60);paths={};fig,axs=plt.subplots(1,2,figsize=(11,4),layout='constrained')
 for ax,(name,cls) in zip(axs,[('Ridge',Ridge),('Lasso',Lasso)]):
  coefs=np.array([cls(alpha=a,max_iter=10000).fit(clean,y[tr]).coef_ for a in alphas]);paths[name]=coefs
  for j in range(10):ax.semilogx(alphas,coefs[:,j],label=f'x{j}',lw=2 if j<4 else .8,alpha=1 if j<4 else .5)
  ax.set(title=name,xlabel=t('惩罚参数 alpha（各模型约定不同）','Penalty alpha (model conventions differ)'),ylabel=t('标准化特征的系数','Coefficient of standardized feature'));ax.axhline(0,color='#b0c2cb',lw=.7)
 axs[1].legend(ncol=2,fontsize=9);save(fig,'regularization')
 # Identical held-out moon observations for three basic classifiers.
 Xc,yc=make_moons(n_samples=600,noise=.25,random_state=44);ct,ce=train_test_split(np.arange(600),test_size=.3,stratify=yc,random_state=44)
 gx,gy=np.meshgrid(np.linspace(-1.8,2.8,230),np.linspace(-1.3,1.9,160));grid=np.c_[gx.ravel(),gy.ravel()];class_results={};fig,axs=plt.subplots(1,3,figsize=(12,3.7),layout='constrained')
 for ax,(name,clf) in zip(axs,[('Logistic',LogisticRegression()),('kNN k=15',KNeighborsClassifier(n_neighbors=15)),('Gaussian NB',GaussianNB())]):
  pipe=make_pipeline(StandardScaler(),clf);pipe.fit(Xc[ct],yc[ct]);prob=pipe.predict_proba(Xc[ce])[:,1];field=pipe.predict_proba(grid)[:,1].reshape(gx.shape);ax.contourf(gx,gy,field,levels=np.linspace(0,1,11),cmap='RdBu_r',alpha=.6);ax.contour(gx,gy,field,levels=[.5],colors='#243b49',linewidths=1.2);ax.scatter(*Xc[ce].T,c=yc[ce],cmap='RdBu_r',edgecolor='white',linewidths=.4,s=17);ax.set(title=name,xlabel='x₀',ylabel='x₁');class_results[name]={'accuracy':float(accuracy_score(yc[ce],prob>=.5)),'log_loss':float(log_loss(yc[ce],np.c_[1-prob,prob]))}
 fig.colorbar(axs[0].collections[0],ax=axs,shrink=.8,label=t('正类预测概率','Predicted positive probability'));save(fig,'classification')
 # Poisson response: expected count exp(0.5+0.8*x), one equal exposure unit each.
 xp=rng.uniform(-2,2,400);mu=np.exp(.5+.8*xp);yp=rng.poisson(mu);pr,pe=train_test_split(np.arange(400),test_size=.25,random_state=44)
 pm=PoissonRegressor(alpha=0,max_iter=1000).fit(xp[pr,None],yp[pr]);lm=LinearRegression().fit(xp[pr,None],yp[pr]);xx=np.linspace(-2,2,250)
 fig,ax=plt.subplots(figsize=(8,4),layout='constrained');ax.scatter(xp[pe],yp[pe],alpha=.5,s=20,color='#536e80',label=t('测试计数','Test counts'));ax.plot(xx,np.exp(.5+.8*xx),'--',color='#111827',label=t('生成均值','Generating mean'));ax.plot(xx,pm.predict(xx[:,None]),color='#167d87',lw=2,label='Poisson GLM');ax.plot(xx,lm.predict(xx[:,None]),color='#d48745',label='OLS');ax.set(xlabel=t('无量纲输入','Dimensionless input'),ylabel=t('每个等长观察窗的计数','Count per equal observation window'));ax.legend();save(fig,'poisson')
 # Independent right censoring of exponential lifetimes, time unit: hours.
 lifetime=rng.exponential(10,80);censor=rng.uniform(2,18,80);duration=np.minimum(lifetime,censor);event=lifetime<=censor;tm,surv,risk,deaths=kaplan_meier(duration,event);truegrid=np.linspace(0,20,200)
 fig=plt.figure(figsize=(11,4.5),layout='constrained');gs=fig.add_gridspec(1,2,width_ratios=[1,1.25]);ax=fig.add_subplot(gs[0,0]);
 for i in range(12):ax.plot([0,duration[i]],[i,i],color='#96aeb8');ax.scatter(duration[i],i,marker='o' if event[i] else '|',s=60,color='#d48745' if event[i] else '#167d87')
 ax.set(xlabel=t('观察时间（小时）','Observed time (hours)'),ylabel=t('前12个部件','First 12 components'),title=t('圆点：事件；竖线：删失','Circle: event; tick: censoring'));ax=fig.add_subplot(gs[0,1]);ax.step(np.r_[tm,duration.max()],np.r_[surv,surv[-1]],where='post',color='#167d87',lw=2,label='Kaplan–Meier');ax.plot(truegrid,np.exp(-truegrid/10),'--',color='#34495e',label=t('生成生存函数','Generating survival'))
 censor_surv=np.array([surv[np.searchsorted(tm,d,side='right')-1] for d in duration[~event]]);ax.scatter(duration[~event],censor_surv,marker='|',color='#167d87',label=t('删失','Censored'));ax.set(xlabel=t('时间（小时）','Time (hours)'),ylabel=t('生存概率 S(t)','Survival probability S(t)'),ylim=(0,1.03));ax.legend();save(fig,'survival')
 hand_t=np.array([2.,3.,4.,5.]);hand_e=np.array([1,0,1,1],dtype=bool);ht,hs,_,_=kaplan_meier(hand_t,hand_e)
 summary={'regression_train':len(tr),'regression_test':len(te),'regression':results,'missing_cells':int(missing.sum()),'classification_train':len(ct),'classification_test':len(ce),'classification':class_results,'poisson_intercept':float(pm.intercept_),'poisson_slope':float(pm.coef_[0]),'survival_n':len(duration),'events':int(event.sum()),'censored':int((~event).sum()),'km_hand_times':ht.tolist(),'km_hand_survival':hs.tolist()}
 (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');np.savez(out/'experiment_data.npz',X=X,X_missing=Xm,y=y,train=tr,test=te,X_class=Xc,y_class=yc,class_train=ct,class_test=ce,lifetime=lifetime,censor=censor,duration=duration,event=event,poisson_x=xp,poisson_y=yp)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--language',choices=['zh','en'],default='en');a=ap.parse_args();main(a.output,a.language)
