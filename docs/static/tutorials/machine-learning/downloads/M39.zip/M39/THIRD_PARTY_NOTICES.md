# Public sources and third-party materials

- Guo et al. (2017), On Calibration of Modern Neural Networks: https://proceedings.mlr.press/v70/guo17a.html
  Primary technical reference; linked, not reproduced
- Angelopoulos & Bates, A Gentle Introduction to Conformal Prediction: https://arxiv.org/abs/2107.07511
  Primary technical reference; linked, not reproduced
- Kendall & Gal (2017), What Uncertainties Do We Need in Bayesian Deep Learning?: https://arxiv.org/abs/1703.04977
  Primary technical reference; linked, not reproduced
- Goodfellow et al., Explaining and Harnessing Adversarial Examples: https://arxiv.org/abs/1412.6572
  Primary technical reference; linked, not reproduced
- Fairlearn: common fairness metrics: https://fairlearn.org/main/user_guide/assessment/common_fairness_metrics.html
  Primary technical reference; linked, not reproduced
- Dwork & Roth (2014), The Algorithmic Foundations of Differential Privacy: https://www.cis.upenn.edu/~aaroth/Papers/privacybook.pdf
  Primary technical reference; linked, not reproduced
- Opacus FAQ: https://opacus.ai/docs/faq
  Primary technical reference; linked, not reproduced
- McMahan et al. (2017), Communication-Efficient Learning of Deep Networks from Decentralized Data: https://proceedings.mlr.press/v54/mcmahan17a.html
  Primary technical reference; linked, not reproduced
- scikit-learn: Probability calibration curves: https://scikit-learn.org/stable/auto_examples/calibration/plot_calibration_curve.html
  BSD-3-Clause; original figure reused
- UCI Optical Recognition of Handwritten Digits: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits
  CC BY 4.0; digit data
