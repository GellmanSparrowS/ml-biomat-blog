"""Reliability experiments with separate fit, temperature, conformal and test sets."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.ndimage import rotate
from scipy.special import softmax
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss,roc_auc_score
import torch
from torch import nn
from torch.nn import functional as F
from threadpoolctl import threadpool_limits
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
def bins(prob,y):
 conf=prob.max(1);correct=prob.argmax(1)==y;edges=np.linspace(0,1,11);rows=[]
 for lo,hi in zip(edges[:-1],edges[1:]):
  mask=(conf>=lo)&(conf<(hi if hi<1 else hi+1e-9));n=int(mask.sum())
  if n:rows.append({'n':n,'confidence':float(conf[mask].mean()),'accuracy':float(correct[mask].mean())})
 return rows,float(sum(r['n']*abs(r['confidence']-r['accuracy']) for r in rows)/len(y))
class Classifier(nn.Module):
 def __init__(self):super().__init__();self.net=nn.Sequential(nn.Linear(64,48),nn.ReLU(),nn.Linear(48,10))
 def forward(self,x):return self.net(x)
def fgsm(model,x,y,epsilon):
 xx=x.clone().detach().requires_grad_(True);loss=F.cross_entropy(model(xx),y);g=torch.autograd.grad(loss,xx)[0];return (xx+epsilon*g.sign()).clamp(0,1).detach()
def train_classifier(x,y,adversarial=False):
 torch.manual_seed(39);m=Classifier();opt=torch.optim.Adam(m.parameters(),lr=.005)
 for epoch in range(30):
  order=torch.randperm(len(x))
  for ids in order.split(128):
   xx=x[ids];yy=y[ids];loss=F.cross_entropy(m(xx),yy)
   if adversarial:adv=fgsm(m,xx,yy,.1);loss=.5*(loss+F.cross_entropy(m(adv),yy))
   opt.zero_grad();loss.backward();opt.step()
 m.eval();return m
def main(output,language):
 out=Path(output);out.mkdir(parents=True,exist_ok=True);z=language=='zh';L=lambda a,b:a if z else b;rng=np.random.default_rng(39);torch.set_num_threads(1)
 plt.rcParams.update({'font.family':'Microsoft YaHei' if z else 'DejaVu Sans','font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
 def save(fig,name):fig.savefig(out/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
 # Five independently initialized/bootstrap heteroscedastic Gaussian regressors.
 rx=rng.uniform(-3,3,100);true_sd=.1+.12*abs(rx);ry=np.sin(1.5*rx)+rng.normal(size=100)*true_sd;grid=np.linspace(-5,5,240);means=[];vars=[]
 for seed in range(5):
  torch.manual_seed(390+seed);model=nn.Sequential(nn.Linear(1,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,2));opt=torch.optim.Adam(model.parameters(),lr=.01);ii=np.random.default_rng(seed).choice(100,100,replace=True);xx=torch.tensor(rx[ii,None],dtype=torch.float32);yy=torch.tensor(ry[ii],dtype=torch.float32)
  for _ in range(350):mu,lv=model(xx).unbind(1);lv=lv.clamp(-6,2);loss=.5*((yy-mu).square()*torch.exp(-lv)+lv).mean();opt.zero_grad();loss.backward();opt.step()
  with torch.no_grad():a=model(torch.tensor(grid[:,None],dtype=torch.float32));means.append(a[:,0].numpy());vars.append(torch.exp(a[:,1].clamp(-6,2)).numpy())
  torch.save(model.state_dict(),out/f'uncertainty-model-{seed}.pt')
 means=np.array(means);vars=np.array(vars);mean=means.mean(0);alea=vars.mean(0);epis=means.var(0);total=alea+epis
 fig,axs=plt.subplots(1,2,figsize=(12,4.8),layout='constrained');axs[0].fill_between(grid,mean-1.96*np.sqrt(total),mean+1.96*np.sqrt(total),color='#d2e6ec',label=L('均值±1.96总标准差','Mean ±1.96 total SD'));axs[0].plot(grid,mean,color='#247b94',label=L('集成均值','Ensemble mean'));axs[0].plot(grid,np.sin(1.5*grid),'--',color='#d97b36',label=L('生成均值','Generating mean'));axs[0].scatter(rx,ry,s=14,color='#293f4c',alpha=.6);axs[0].set(xlabel='x',ylabel='y',title=L('100训练点；训练范围[-3,3]','100 training points; training range[-3,3]'));axs[0].legend(fontsize=8)
 axs[1].plot(grid,alea,label=L('平均预测噪声方差','Mean predicted noise variance'));axs[1].plot(grid,epis,label=L('模型均值方差','Variance of model means'));axs[1].plot(grid,(.1+.12*abs(grid))**2,':',label=L('已知生成噪声方差','Known generating noise variance'));axs[1].set(xlabel='x',ylabel=L('y单位平方','Squared y units'));axs[1].legend(fontsize=8)
 for ax in axs:
  for edge in [-3,3]:ax.axvline(edge,color='#8399a5',ls=':')
 save(fig,'uncertainty')
 data=load_digits();X=data.data/16;y=data.target;ids=np.arange(len(y));train,rest=train_test_split(ids,train_size=900,random_state=39);cal,test=train_test_split(rest,train_size=300,random_state=39);tune,conf=train_test_split(cal,train_size=150,random_state=39);tx=torch.tensor(X[train],dtype=torch.float32);ty=torch.tensor(y[train]);testx=torch.tensor(X[test],dtype=torch.float32);testy=torch.tensor(y[test]);model=train_classifier(tx,ty)
 # Explicitly sharpen by2.5 to create a controlled overconfidence example.
 all_logits=model(torch.tensor(X,dtype=torch.float32)).detach()*2.5;logT=torch.tensor(0.,requires_grad=True);opt=torch.optim.LBFGS([logT],lr=.2,max_iter=80,line_search_fn='strong_wolfe');tune_y=torch.tensor(y[tune])
 def closure():opt.zero_grad();loss=F.cross_entropy(all_logits[tune]/logT.exp(),tune_y);loss.backward();return loss
 opt.step(closure);temperature=float(logT.exp().detach());raw=softmax(all_logits[test].numpy(),axis=1);prob=softmax(all_logits[test].numpy()/temperature,axis=1);cp=softmax(all_logits[conf].numpy()/temperature,axis=1);alpha=.1;k=int(np.ceil((len(conf)+1)*(1-alpha)));scores=1-cp[np.arange(len(conf)),y[conf]];q=float(np.sort(scores)[k-1]);sets=prob>=1-q;coverage=float(sets[np.arange(len(test)),y[test]].mean());setsize=float(sets.sum(1).mean());rawbins,rawece=bins(raw,y[test]);calbins,calece=bins(prob,y[test]);selection=[]
 for threshold in [.5,.7,.9,.95,.99]:
  accept=prob.max(1)>=threshold;selection.append({'threshold':threshold,'retained':int(accept.sum()),'fraction':float(accept.mean()),'error':float(np.mean(prob[accept].argmax(1)!=y[test][accept])) if accept.any() else None})
 fig,axs=plt.subplots(1,3,figsize=(15,4.7),layout='constrained');axs[0].plot([0,1],[0,1],':',color='#8d9da6')
 for name,rows,c in [(L('原始分数×2.5','Raw logits×2.5'),rawbins,'#d97b36'),(L('温度校准','Temperature'),calbins,'#247b94')]:axs[0].plot([r['confidence'] for r in rows],[r['accuracy'] for r in rows],'o-',label=name,color=c)
 axs[0].set(xlabel=L('分箱平均最大概率','Mean maximum probability in bin'),ylabel=L('该箱分类正确率','Classification accuracy in bin'),title=L('10个等宽置信箱','10 equal-width confidence bins'));axs[0].legend(fontsize=8);axs[1].hist(raw.max(1),bins=np.linspace(0,1,11),alpha=.5,color='#d97b36',label=L('原始分数×2.5','Raw logits×2.5'));axs[1].hist(prob.max(1),bins=np.linspace(0,1,11),alpha=.5,color='#247b94',label=L('温度校准','Temperature'));axs[1].set(xlabel=L('最大预测概率','Maximum predicted probability'),ylabel=L('测试对象数','Test records'));axs[1].legend(fontsize=8);axs[2].plot([a['fraction'] for a in selection],[a['error'] for a in selection],'o-',color='#247b94')
 for a in selection:axs[2].annotate(str(a['threshold']),(a['fraction'],a['error']),xytext=(3,3),textcoords='offset points')
 axs[2].set(xlabel=L('保留预测比例','Fraction retained'),ylabel=L('保留对象中的错误率','Error among retained records'),title=L('阈值改变工作量与错误','Threshold changes workload and errors'));save(fig,'calibration')
 shifted=np.array([rotate(im,30,reshape=False,order=1,mode='constant',cval=0) for im in data.images[test]/16]);shiftx=torch.tensor(shifted.reshape(-1,64),dtype=torch.float32);sp=softmax(model(shiftx).detach().numpy()*2.5/temperature,axis=1);ssets=sp>=1-q;shiftcover=float(ssets[np.arange(len(test)),y[test]].mean());shiftacc=float(np.mean(sp.argmax(1)==y[test]));oodauc=float(roc_auc_score(np.r_[np.zeros(len(test)),np.ones(len(test))],np.r_[1-prob.max(1),1-sp.max(1)]));groups={};ink_cut=float(np.median(X[train].mean(1)))
 for g,mask in [('Lower ink',X[test].mean(1)<ink_cut),('Higher ink',X[test].mean(1)>=ink_cut)]:groups[g]={'n':int(mask.sum()),'accuracy':float(np.mean(prob[mask].argmax(1)==y[test][mask])),'coverage':float(sets[mask][np.arange(mask.sum()),y[test][mask]].mean()),'mean_set_size':float(sets[mask].sum(1).mean())}
 fig,axs=plt.subplots(1,3,figsize=(15,4.8),layout='constrained');axs[0].bar([L('原图','Original'),L('旋转30°','Rotated30°')],[coverage,shiftcover],color=['#247b94','#d97b36']);axs[0].axhline(.9,ls='--',color='#263c49');axs[0].set(ylim=(0,1),ylabel=L('真实标签落入集合的比例','Fraction of true labels in prediction set'),title=L('同一共形阈值','Same conformal threshold'));axs[1].hist(sets.sum(1),bins=np.arange(-.5,2.5),alpha=.6,color='#247b94',label=L('原图','Original'));axs[1].hist(ssets.sum(1),bins=np.arange(-.5,2.5),alpha=.6,color='#d97b36',label=L('旋转30°','Rotated30°'));axs[1].set(xlabel=L('集合类别数','Prediction-set size'),ylabel=L('测试对象数','Test records'),xticks=[0,1],xlim=(-.5,1.5));axs[1].legend(fontsize=8);ix=np.arange(2);axs[2].bar(ix-.16,[g['accuracy'] for g in groups.values()],width=.3,label=L('准确率','Accuracy'));axs[2].bar(ix+.16,[g['coverage'] for g in groups.values()],width=.3,label=L('覆盖率','Coverage'));axs[2].set(xticks=ix,xticklabels=[f'{L("较少墨迹" if k=="Lower ink" else "较多墨迹",k)}\nn={v["n"]}' for k,v in groups.items()],ylim=(0,1),title=L('按训练亮度阈值分组','Groups from a training-set ink threshold'));axs[2].legend(fontsize=8);save(fig,'coverage_shift')
 # Separate trained models and fresh white-box attacks for each defense.
 robust=train_classifier(tx,ty,adversarial=True);poison_labels=ty.clone();pi=rng.choice(900,90,replace=False);poison_labels[pi]=(poison_labels[pi]+1)%10;poison=train_classifier(tx,poison_labels);attacks={};adversarial_examples={}
 for name,net in [('Standard',model),('Adversarial training',robust)]:
  vals=[]
  for eps in [0,.05,.1,.2]:
   adv=fgsm(net,testx,testy,eps);vals.append(float((net(adv).argmax(1)==testy).float().mean()));
   if eps==.1:adversarial_examples[name]=adv
  attacks[name]=vals
 changed=np.flatnonzero((model(testx).argmax(1)==testy).detach().numpy()&(model(adversarial_examples['Standard']).argmax(1)!=testy).detach().numpy());pick=int(changed[0]);original=testx[pick].reshape(8,8).numpy();adv=adversarial_examples['Standard'][pick].reshape(8,8).numpy();fig=plt.figure(figsize=(13,5),layout='constrained');gs=fig.add_gridspec(2,4,width_ratios=[1,1,1,2]);axs=[fig.add_subplot(gs[:,i]) for i in range(4)];titles=[L(f'原图：真实{int(testy[pick])}，预测{int(model(testx[pick:pick+1]).argmax(1)[0])}',f'Original: true {int(testy[pick])}, predicted {int(model(testx[pick:pick+1]).argmax(1)[0])}'),L(f'FGSM ε=0.1：预测{int(model(adversarial_examples["Standard"][pick:pick+1]).argmax(1)[0])}',f'FGSM ε=0.1: predicted {int(model(adversarial_examples["Standard"][pick:pick+1]).argmax(1)[0])}'),L('像素变化（真实尺度）','Pixel change (actual scale)')]
 for ax,arr,title,cmap in zip(axs[:3],[original,adv,adv-original],titles,['gray','gray','coolwarm']):im=ax.imshow(arr,cmap=cmap,vmin=-.1 if cmap=='coolwarm' else 0,vmax=.1 if cmap=='coolwarm' else 1);ax.set_title(title,fontsize=10);ax.set_xticks([]);ax.set_yticks([]);fig.colorbar(im,ax=ax,shrink=.55)
 for name,vals in attacks.items():axs[3].plot([0,.05,.1,.2],vals,'o-',label=L('标准训练' if name=='Standard' else '对抗训练',name))
 axs[3].set(xlabel=L('L∞扰动上限','L∞ perturbation budget'),ylabel=L('相应模型的FGSM准确率','FGSM accuracy for the attacked model'),ylim=(0,1));axs[3].legend(fontsize=8);save(fig,'robustness')
 # Public synthetic-data simulation of Laplace accuracy; fixed seed is for the teaching plot.
 bounded=rng.uniform(0,1,100);sensitivity=.01;epsilons=np.array([.1,.2,.5,1.]);dp=[];noises=[]
 for eps in epsilons:
  noise=rng.laplace(0,sensitivity/eps,10000);noises.append(noise);dp.append({'epsilon':float(eps),'scale':float(sensitivity/eps),'theoretical_rmse':float(np.sqrt(2)*sensitivity/eps),'empirical_rmse':float(np.sqrt(np.mean(noise**2)))})
 # Federated full-batch linear regression, two equally sized heterogeneous clients.
 clients=[]
 for center,offset in [(-2.,-1.),(2.,1.)]:
  cx=rng.normal(center,.8,100);cy=2*cx+offset+rng.normal(0,.2,100);clients.append((np.c_[cx,np.ones(100)],cy))
 FX=np.vstack([a for a,b in clients]);FY=np.concatenate([b for a,b in clients]);optimal=np.linalg.lstsq(FX,FY,rcond=None)[0];fed={};fweights={};lr=.03
 for steps in [1,5,20]:
  w=np.zeros(2);trace=[]
  for _ in range(40):
   local=[]
   for cx,cy in clients:
    v=w.copy()
    for _ in range(steps):v-=lr*2*cx.T@(cx@v-cy)/len(cy)
    local.append(v)
   w=np.mean(local,axis=0);trace.append(float(np.mean((FX@w-FY)**2)))
  fed[str(steps)]=trace;fweights[str(steps)]=w.tolist()
 central=np.zeros(2)
 for _ in range(40):central-=lr*2*FX.T@(FX@central-FY)/len(FY)
 fig,axs=plt.subplots(1,3,figsize=(15,4.6),layout='constrained');axs[0].hist(noises[0],bins=70,density=True,alpha=.5,label='ε=0.1');axs[0].hist(noises[2],bins=70,density=True,alpha=.6,label='ε=0.5');axs[0].set(xlabel=L('发布均值减去原均值','Released mean minus original mean'),ylabel=L('密度','Density'),title=L('公开模拟；每条件10000次噪声','Public simulation;10,000 noise draws each'));axs[0].legend();axs[1].plot(epsilons,[d['theoretical_rmse'] for d in dp],'o-',label=L('理论RMSE','Theoretical RMSE'));axs[1].plot(epsilons,[d['empirical_rmse'] for d in dp],'x',label=L('模拟RMSE','Simulated RMSE'));axs[1].set(xlabel='ε',ylabel=L('均值单位的RMSE','RMSE in mean units'));axs[1].legend(fontsize=8)
 for steps,trace in fed.items():axs[2].plot(range(1,41),trace,label=f'{L("本地步数","Local steps")}={steps}')
 axs[2].axhline(np.mean((FX@optimal-FY)**2),color='#8299a5',ls=':',label=L('合并数据最小二乘','Pooled least-squares optimum'));axs[2].set(xlabel=L('通信轮数','Communication round'),ylabel=L('全体数据MSE','Pooled-data MSE'),yscale='log');axs[2].legend(fontsize=7);save(fig,'privacy_federation')
 acc=float(np.mean(prob.argmax(1)==y[test]));summary={'n_total':len(y),'n_train':len(train),'n_temperature':len(tune),'n_conformal':len(conf),'n_test':len(test),'split_intersection':sum(len(set(a)&set(b)) for i,a in enumerate([train,tune,conf,test]) for b in [train,tune,conf,test][i+1:]),'temperature':temperature,'sharpening_factor':2.5,'accuracy':acc,'raw_nll':float(log_loss(y[test],raw)),'temperature_nll':float(log_loss(y[test],prob)),'raw_ece':rawece,'temperature_ece':calece,'argmax_change_count':int(np.sum(raw.argmax(1)!=prob.argmax(1))),'conformal_rank':k,'conformal_threshold':q,'coverage':coverage,'mean_set_size':setsize,'empty_set_count':int(np.sum(sets.sum(1)==0)),'shift_accuracy':shiftacc,'shift_coverage':shiftcover,'shift_mean_set_size':float(ssets.sum(1).mean()),'ood_uncertainty_auroc':oodauc,'groups':groups,'selection':selection,'attacks':attacks,'poison_count':len(pi),'poison_clean_accuracy':float((poison(testx).argmax(1)==testy).float().mean()),'attack_max_linf':float(torch.max(abs(adversarial_examples['Standard']-testx))),'laplace_sensitivity':sensitivity,'privacy_accuracy':dp,'basic_two_release_epsilon':1.,'basic_two_release_delta':0.,'fedavg_E1_centralized_max_error':float(np.max(abs(np.array(fweights['1'])-central))),'fed_weights':fweights,'pooled_optimal_weights':optimal.tolist(),'pooled_optimal_mse':float(np.mean((FX@optimal-FY)**2)),'fed_final_mse':{k:v[-1] for k,v in fed.items()},'uncertainty_at_zero':{'aleatoric':float(alea[np.argmin(abs(grid))]),'epistemic':float(epis[np.argmin(abs(grid))])},'uncertainty_at_four':{'aleatoric':float(alea[np.argmin(abs(grid-4))]),'epistemic':float(epis[np.argmin(abs(grid-4))])}}
 for name,net in [('standard',model),('adversarial',robust),('poisoned',poison)]:torch.save(net.state_dict(),out/f'{name}-classifier.pt')
 np.savez_compressed(out/'experiment_data.npz',train_indices=train,temperature_indices=tune,conformal_indices=conf,test_indices=test,raw_probabilities=raw,calibrated_probabilities=prob,conformal_scores=scores,prediction_sets=sets,shifted_images=shifted,shifted_probabilities=sp,test_labels=y[test],regression_x=rx,regression_y=ry,regression_grid=grid,ensemble_means=means,ensemble_variances=vars,adversarial_example=adv,original_example=original,poison_indices=pi,client_X=FX,client_y=FY);(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args()
 with threadpool_limits(limits=1):main(a.output,a.language)
