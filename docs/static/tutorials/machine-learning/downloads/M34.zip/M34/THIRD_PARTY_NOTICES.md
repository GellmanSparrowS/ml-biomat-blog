# Public sources and third-party materials

- Deep Unsupervised Learning using Nonequilibrium Thermodynamics: https://arxiv.org/abs/1503.03585
  Primary paper; no copied figures
- Denoising Diffusion Probabilistic Models: https://arxiv.org/html/2006.11239v2
  Primary paper; independent experiment
- Denoising Diffusion Implicit Models: https://arxiv.org/html/2010.02502v4
  Primary paper; independent experiment
- Generative Modeling by Estimating Gradients of the Data Distribution: https://arxiv.org/abs/1907.05600
  Primary paper; own analytic mixture figure
- Score-Based Generative Modeling through Stochastic Differential Equations: https://arxiv.org/html/2011.13456v2
  Primary paper; no copied figures
- Classifier-Free Diffusion Guidance: https://arxiv.org/abs/2207.12598
  Primary paper; independent experiment
- High-Resolution Image Synthesis with Latent Diffusion Models: https://arxiv.org/abs/2112.10752
  Primary paper; no copied figures
- Diffusion Explainer: https://poloclub.github.io/diffusion-explainer/
  MIT, Copyright 2022 Polo Club of Data Science; adapted diagram; license retained
