"""A complete local model release: training, compression, ONNX, HTTP and monitoring.
Run: python main.py --output results --language en
Serve a previously generated bundle: python main.py --serve results --port 8765
"""
from pathlib import Path
import argparse, copy, hashlib, importlib.metadata, json, platform, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen, build_opener, ProxyHandler
from urllib.error import HTTPError
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
import onnx
from onnx import helper, numpy_helper, TensorProto
import onnxruntime as ort
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


class Network(nn.Module):
    def __init__(self, width):
        super().__init__()
        self.fc1 = nn.Linear(64, width)
        self.fc2 = nn.Linear(width, 10)

    def forward(self, x):
        return self.fc2(torch.relu(self.fc1(x)))


def fit(width, x, y, xv, yv, teacher=None):
    torch.manual_seed(270 + width)
    model = Network(width)
    optimizer = torch.optim.Adam(model.parameters(), lr=.01)
    history, best, chosen = [], float('inf'), 0
    teacher_logits = None if teacher is None else teacher(x).detach()
    for epoch in range(300):
        logits = model(x)
        loss = F.cross_entropy(logits, y)
        if teacher is not None:
            temperature = 3.
            soft = F.kl_div(F.log_softmax(logits / temperature, dim=1),
                            F.softmax(teacher_logits / temperature, dim=1), reduction='batchmean')
            loss = .4 * loss + .6 * temperature ** 2 * soft
        optimizer.zero_grad(); loss.backward(); optimizer.step()
        with torch.no_grad():
            validation = F.cross_entropy(model(xv), yv).item()
        history.append([float(loss.detach()), validation])
        if validation < best:
            best, chosen, state = validation, epoch + 1, copy.deepcopy(model.state_dict())
    model.load_state_dict(state); model.eval()
    return model, np.array(history), chosen


def export_graph(model, path):
    # The raw-pixel /16 transform travels inside the inference graph.
    arrays = {'scale': np.array(16, dtype=np.float32),
              'w1': model.fc1.weight.detach().numpy().T.copy(),
              'b1': model.fc1.bias.detach().numpy(),
              'w2': model.fc2.weight.detach().numpy().T.copy(),
              'b2': model.fc2.bias.detach().numpy()}
    nodes = [helper.make_node('Div', ['pixels', 'scale'], ['scaled']),
             helper.make_node('MatMul', ['scaled', 'w1'], ['m1']),
             helper.make_node('Add', ['m1', 'b1'], ['a1']),
             helper.make_node('Relu', ['a1'], ['hidden']),
             helper.make_node('MatMul', ['hidden', 'w2'], ['m2']),
             helper.make_node('Add', ['m2', 'b2'], ['logits'])]
    graph = helper.make_graph(nodes, 'digits-release',
        [helper.make_tensor_value_info('pixels', TensorProto.FLOAT, ['batch', 64])],
        [helper.make_tensor_value_info('logits', TensorProto.FLOAT, ['batch', 10])],
        [numpy_helper.from_array(v, name=k) for k, v in arrays.items()])
    model_proto = helper.make_model(graph, opset_imports=[helper.make_opsetid('', 18)])
    model_proto.ir_version = 10
    onnx.checker.check_model(model_proto)
    onnx.save(model_proto, path)


def session(path):
    settings = ort.SessionOptions()
    settings.intra_op_num_threads = 1; settings.inter_op_num_threads = 1
    return ort.InferenceSession(str(path), settings, providers=['CPUExecutionProvider'])


def quantize_weights(source, destination):
    """Store signed8-bit weights per output channel, with explicit dequantization.

    Activations remain float32; this graph demonstrates W8A32 storage.
    Execution providers may fold constant dequantization back into float matrices.
    """
    graph_model = onnx.load(source)
    additions, replacements = [], []
    for tensor in list(graph_model.graph.initializer):
        if tensor.name not in ['w1', 'w2']:
            continue
        weight = numpy_helper.to_array(tensor)
        scale = np.maximum(np.abs(weight).max(axis=0) / 127, 1e-12).astype(np.float32)
        quantized = np.clip(np.rint(weight / scale), -127, 127).astype(np.int8)
        name = tensor.name
        replacements.extend([numpy_helper.from_array(quantized, name + '_q'),
                             numpy_helper.from_array(scale, name + '_scale'),
                             numpy_helper.from_array(np.zeros(scale.shape, np.int8), name + '_zero')])
        additions.append(helper.make_node('DequantizeLinear',
                         [name + '_q', name + '_scale', name + '_zero'], [name], axis=1))
        graph_model.graph.initializer.remove(tensor)
    graph_model.graph.initializer.extend(replacements)
    original_nodes = list(graph_model.graph.node)
    del graph_model.graph.node[:]
    graph_model.graph.node.extend(additions + original_nodes)
    onnx.checker.check_model(graph_model)
    onnx.save(graph_model, destination)


def predict(sess, payload):
    if not isinstance(payload, dict) or set(payload) != {'pixels'}:
        raise ValueError('Expected one field: pixels')
    raw = np.asarray(payload['pixels'])
    if raw.ndim != 2 or raw.shape[1] != 64 or not 1 <= raw.shape[0] <= 256:
        raise ValueError('pixels must have shape [1..256,64]')
    if raw.dtype.kind not in 'fiu' or not np.isfinite(raw).all():
        raise ValueError('pixels must contain finite numbers')
    if raw.min() < 0 or raw.max() > 16:
        raise ValueError('Raw pixel range is 0..16')
    logits = sess.run(None, {'pixels': raw.astype(np.float32)})[0]
    return {'version': 'digits-v1', 'classes': logits.argmax(1).tolist(),
            'logits': logits.tolist()}


def handler(sess):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # No request features are written to a log.

        def do_POST(self):
            try:
                if self.path != '/predict':
                    self.send_error(404); return
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= 1000000:
                    raise ValueError('Invalid request size')
                result = predict(sess, json.loads(self.rfile.read(length)))
                code = 200
            except (ValueError, TypeError, OverflowError):
                result, code = {'error': 'Request does not match the pixel contract'}, 400
            data = json.dumps(result, allow_nan=False).encode()
            self.send_response(code); self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)
    return Handler


def http_checks(sess, sample):
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler(sess))
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    client = build_opener(ProxyHandler({})); records = []
    payloads = [{'pixels': sample.tolist()}, {'pixels': [[0] * 63]},
                {'pixels': [[17] * 64]}, {'pixels': [['zero'] * 64]},
                {'pixels': [[float('nan')] * 64]}, {'pixels': []}, {'image': sample.tolist()}]
    try:
        for payload in payloads:
            request = Request(f'http://127.0.0.1:{server.server_port}/predict',
                              json.dumps(payload).encode(), {'Content-Type': 'application/json'})
            try:
                with client.open(request, timeout=10) as response:
                    code, body = response.status, json.loads(response.read())
            except HTTPError as error:
                code, body = error.code, json.loads(error.read())
            records.append({'status': code, 'body': body})
    finally:
        server.shutdown(); server.server_close(); thread.join()
    assert [r['status'] for r in records] == [200, 400, 400, 400, 400, 400, 400]
    assert records[0]['body']['classes'] == predict(sess, payloads[0])['classes']
    return records


def psi(reference, current, edges):
    p = np.histogram(reference, edges)[0].astype(float) + .5
    q = np.histogram(current, edges)[0].astype(float) + .5
    p /= p.sum(); q /= q.sum()
    return float(np.sum((q - p) * np.log(q / p)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='results')
    parser.add_argument('--language', choices=['zh', 'en'], default='en')
    parser.add_argument('--serve', type=Path); parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    if args.serve:
        server = ThreadingHTTPServer(('127.0.0.1', args.port), handler(session(args.serve / 'student.onnx')))
        print(f'Local prediction endpoint: http://127.0.0.1:{args.port}/predict', flush=True)
        try: server.serve_forever()
        except KeyboardInterrupt: pass
        finally: server.server_close()
        return
    out = Path(args.output); out.mkdir(parents=True, exist_ok=True)
    zh = args.language == 'zh'; tr = lambda z, e: z if zh else e
    torch.set_num_threads(1); torch.manual_seed(271); np.random.seed(271)
    data = load_digits(); pixels = data.data.astype(np.float32); labels = data.target
    development, test = train_test_split(np.arange(len(labels)), test_size=450, stratify=labels, random_state=271)
    train, validation = train_test_split(development, test_size=270, stratify=labels[development], random_state=272)
    tensor = lambda ids: torch.from_numpy(pixels[ids] / 16)
    target = lambda ids: torch.from_numpy(labels[ids])
    teacher, ht, et = fit(64, tensor(train), target(train), tensor(validation), target(validation))
    hard, hh, eh = fit(16, tensor(train), target(train), tensor(validation), target(validation))
    student, hs, es = fit(16, tensor(train), target(train), tensor(validation), target(validation), teacher)
    pruned = copy.deepcopy(student)
    weights = torch.cat([pruned.fc1.weight.flatten(), pruned.fc2.weight.flatten()])
    threshold = torch.quantile(weights.abs(), .5)
    with torch.no_grad():
        for layer in [pruned.fc1, pruned.fc2]: layer.weight.mul_(layer.weight.abs() > threshold)
    models = {'teacher': teacher, 'hard': hard, 'student': student, 'pruned': pruned}
    for name, model in models.items():
        export_graph(model, out / f'{name}.onnx')
        torch.save(model.state_dict(), out / f'{name}.pt')
    quantize_weights(out / 'student.onnx', out / 'int8.onnx')
    sessions = {name: session(out / f'{name}.onnx') for name in [*models, 'int8']}
    raw = pixels[test]; truth = labels[test]
    logits = {name: sess.run(None, {'pixels': raw})[0] for name, sess in sessions.items()}
    with torch.no_grad():
        export_error = float(np.abs(logits['student'] - student(tensor(test)).numpy()).max())
        logits['wrong_scale'] = student(torch.from_numpy(raw)).numpy()
    logits['double_scale'] = sessions['student'].run(None, {'pixels': raw / 16})[0]
    predictions = {name: value.argmax(1) for name, value in logits.items()}
    accuracy = {name: float((prediction == truth).mean()) for name, prediction in predictions.items()}
    timings = {}
    for name, sess in sessions.items():
        timings[name] = {}
        for batch in [1, 32, 128]:
            feed = {'pixels': raw[:batch]}
            for _ in range(20): sess.run(None, feed)
            elapsed = []
            for _ in range(120):
                start = time.perf_counter_ns(); sess.run(None, feed)
                elapsed.append((time.perf_counter_ns() - start) / 1e6)
            timings[name][str(batch)] = elapsed
    contracts = http_checks(sessions['student'], raw[:2])
    # Rotation preserves each image's mean brightness exactly but changes its geometry.
    streams = {'clean': raw, 'dimmed': raw * .5,
               'rotated': np.rot90(raw.reshape(-1, 8, 8), k=1, axes=(1, 2)).reshape(-1, 64).copy()}
    edges = np.linspace(0, 16, 17); baseline = pixels[train].mean(1)
    drift = {}
    for name, value in streams.items():
        pred = sessions['student'].run(None, {'pixels': value})[0].argmax(1)
        drift[name] = {'psi_mean_brightness': psi(baseline, value.mean(1), edges),
                       'accuracy': float((pred == truth).mean())}
    model_files = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.onnx')}
    manifest = {'version': 'digits-v1', 'data_sha256': hashlib.sha256(pixels.tobytes() + labels.tobytes()).hexdigest(),
                'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'split': {'train': train.tolist(), 'validation': validation.tolist(), 'test': test.tolist()},
                'schema': {'field': 'pixels', 'shape': ['batch<=256', 64], 'range': [0, 16],
                           'order': '8x8 row-major', 'transform': 'divide by16 inside ONNX'},
                'versions': {n: importlib.metadata.version(n) for n in ['numpy', 'torch', 'onnx', 'onnxruntime', 'scikit-learn']},
                'python': platform.python_version(), 'models': model_files, 'evaluation': accuracy}
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf8')
    # Reload from the written file and verify both identity and prediction parity.
    restored = json.loads((out / 'manifest.json').read_text(encoding='utf8'))
    for name, expected in restored['models'].items():
        assert hashlib.sha256((out / name).read_bytes()).hexdigest() == expected
    replay = session(out / 'student.onnx').run(None, {'pixels': raw})[0]
    reload_error = float(np.abs(replay - logits['student']).max())
    summary = {'samples': len(labels), 'train': len(train), 'validation': len(validation), 'test': len(test),
        'selected_epochs': {'teacher': et, 'hard': eh, 'student': es}, 'accuracy': accuracy,
        'onnx_max_logit_error': export_error, 'reload_error': reload_error,
        'int8_max_logit_error': float(np.abs(logits['int8'] - logits['student']).max()),
        'wrong_scale_max_logit_error': float(np.abs(logits['wrong_scale'] - logits['student']).max()),
        'int8_changed_predictions': int(np.count_nonzero(predictions['int8'] != predictions['student'])),
        'parameters': {name: sum(p.numel() for p in model.parameters()) for name, model in models.items()},
        'pruned_weight_zeros': sum(int((layer.weight == 0).sum()) for layer in [pruned.fc1, pruned.fc2]),
        'total_weights': len(weights), 'onnx_bytes': {name: (out / f'{name}.onnx').stat().st_size for name in sessions},
        'contract_statuses': [r['status'] for r in contracts], 'monitoring': drift,
        'timing_ms': {name: {batch: {'median': float(np.median(t)), 'p95': float(np.quantile(t, .95)),
                       'throughput': int(batch) * 1000 / float(np.median(t))} for batch, t in values.items()} for name, values in timings.items()}}
    np.savez_compressed(out / 'experiment.npz', train=train, validation=validation, test=test, labels=truth,
                        pixels=raw, teacher_history=ht, hard_history=hh, student_history=hs,
                        **{'logits_' + k: v for k, v in logits.items()},
                        **{'timing_' + k + '_' + b: np.array(t) for k, a in timings.items() for b, t in a.items()})
    (out / 'replay.json').write_text(json.dumps({'labels': truth.tolist(), 'predictions': {k: v.tolist() for k, v in predictions.items()}}), encoding='utf8')
    (out / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf8')
    for language in ['zh', 'en']:
        zh = language == 'zh'
        plt.rcParams.update({'font.family': ['Microsoft YaHei', 'DejaVu Sans'], 'font.size': 11,
                             'svg.fonttype': 'none', 'axes.spines.top': False, 'axes.spines.right': False,
                             'figure.facecolor': '#faf8f3', 'axes.facecolor': '#faf8f3'})
        colors = ['#1b4660', '#897d68', '#1c8282', '#bd7049', '#77649b']
        def save(fig, name):
            fig.savefig(out / f'{name}-{language}.svg', bbox_inches='tight')
            fig.savefig(out / f'{name}-{language}.png', dpi=150, bbox_inches='tight'); plt.close(fig)
        fig, axes = plt.subplots(1, 3, figsize=(13, 4.3), layout='constrained')
        for h, name, color in zip([ht, hh, hs], ['teacher', 'hard', 'student'], colors):
            axes[0].plot(np.arange(1, 301), h[:, 1], label=name, color=color)
        axes[0].set(xlabel=tr('训练轮数', 'Training epoch'), ylabel=tr('验证交叉熵 / nats', 'Validation cross entropy / nats')); axes[0].legend(frameon=False)
        for i, name in enumerate(sessions):
            axes[1].scatter(summary['onnx_bytes'][name] / 1024, accuracy[name], s=70, color=colors[i])
            if name != 'student':
                offsets = {'teacher': (-35, 14), 'hard': (-35, 22), 'pruned': (-20, -24), 'int8': (0, 14)}
                axes[1].annotate('hard / student' if name == 'hard' else name, (summary['onnx_bytes'][name] / 1024, accuracy[name]), xytext=offsets[name], textcoords='offset points', arrowprops={'arrowstyle': '-', 'color': '#7c898e'})
        axes[1].set(xscale='log', xlabel=tr('ONNX文件 / KiB', 'ONNX file / KiB'), ylabel=tr('450张测试准确率', 'Accuracy on 450 test images'), ylim=(.93, 1.005))
        original = student.fc1.weight.detach().numpy(); sparse = pruned.fc1.weight.detach().numpy()
        im = axes[2].imshow(np.concatenate([original, sparse], axis=0), cmap='RdBu_r', vmin=-abs(original).max(), vmax=abs(original).max(), aspect='auto')
        fig.colorbar(im, ax=axes[2], label=tr('权重 / 无量纲', 'Weight / dimensionless'))
        axes[2].axhline(15.5, color='#253d4a'); axes[2].set(xlabel=tr('输入像素编号', 'Input pixel index'), yticks=[7.5, 23.5], yticklabels=['student', '50% zeros'], title=tr('同一矩阵：上原始、下剪枝', 'Same matrix: original / pruned'))
        save(fig, 'compression')
        fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.5), layout='constrained')
        for i, name in enumerate(sessions):
            t = np.sort(timings[name]['1']); axes[0].plot(t, np.arange(1, 121) / 120, label=name, color=colors[i])
            medians = [np.median(timings[name][str(b)]) for b in [1, 32, 128]]
            axes[1].plot([1, 32, 128], np.array([1, 32, 128]) * 1000 / medians, 'o-', label=name, color=colors[i])
        axes[0].set(xlabel=tr('单次推理 / ms', 'Inference call / ms'), ylabel=tr('实测累计比例', 'Empirical cumulative fraction'), xscale='log'); axes[0].legend(frameon=False)
        axes[1].set(xlabel=tr('批量大小', 'Batch size'), ylabel=tr('吞吐 / 图像每秒', 'Throughput / images per second'), xscale='log', yscale='log'); axes[1].legend(frameon=False)
        save(fig, 'latency')
        fig = plt.figure(figsize=(12, 6.5), layout='constrained'); gs = fig.add_gridspec(2, 3, height_ratios=[1, 1.6])
        for i, (name, value) in enumerate(streams.items()):
            ax = fig.add_subplot(gs[0, i]); ax.imshow(value[0].reshape(8, 8), cmap='gray_r', vmin=0, vmax=16); ax.set_title(name); ax.axis('off')
        ax = fig.add_subplot(gs[1, :2])
        for i, (name, value) in enumerate(streams.items()): ax.hist(value.mean(1), bins=edges, histtype='step', linewidth=4 if name == 'clean' else 2, linestyle='--' if name == 'rotated' else '-', label=name, color=colors[i])
        ax.set(xlabel=tr('每张图片的平均灰度', 'Mean intensity per image'), ylabel=tr('样本数', 'Image count')); ax.legend(frameon=False)
        ax = fig.add_subplot(gs[1, 2]); names = list(streams)
        ax.bar(names, [drift[n]['accuracy'] for n in names], color=colors[:3]); ax.set(ylim=(0, 1.08), ylabel=tr('标签到达后：准确率', 'After labels arrive: accuracy'))
        for i, n in enumerate(names): ax.text(i, drift[n]['accuracy'] + .025, f"{drift[n]['accuracy']:.3f}", ha='center')
        save(fig, 'monitoring')
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
