# Public sources and third-party materials

- Sculley et al. (2015), Hidden Technical Debt in Machine Learning Systems: https://research.google/pubs/hidden-technical-debt-in-machine-learning-systems/
  Primary paper reference; no reproduced figure.
- Breck et al. (2017), The ML Test Score: https://research.google/pubs/the-ml-test-score-a-rubric-for-ml-production-readiness-and-technical-debt-reduction/
  Primary paper reference; original teaching diagram.
- Hinton, Vinyals & Dean (2015), Distilling the Knowledge in a Neural Network: https://arxiv.org/abs/1503.02531
  Paper referenced; all experiments newly computed.
- ONNX — Python introduction: https://onnx.ai/onnx/intro/python.html
  Apache-2.0 project; conceptual reference.
- ONNX — DequantizeLinear: https://onnx.ai/onnx/operators/onnx__DequantizeLinear.html
  Apache-2.0 project; original implementation.
- ONNX Runtime — Quantization: https://onnxruntime.ai/docs/performance/model-optimizations/quantization.html
  MIT project; technical reference.
- PyTorch — Pruning tutorial: https://docs.pytorch.org/tutorials/intermediate/pruning_tutorial.html
  BSD-3-Clause documentation/code; no figure copied.
- MLflow — Model Registry: https://mlflow.org/docs/latest/registry/
  Apache-2.0 project; no MLflow server needed for the example.
- TensorFlow Data Validation: https://www.tensorflow.org/tfx/guide/tfdv
  CC BY4.0 documentation; original figures.
- scikit-learn — load_digits: https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html
  UCI Optical Recognition of Handwritten Digits; see dataset terms.
