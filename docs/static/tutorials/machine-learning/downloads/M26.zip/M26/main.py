"""Measure and verify CPU training: accumulation, real DDP, precision and recovery."""
import argparse
import copy
import json
import platform
import time
import uuid
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.checkpoint import checkpoint
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

torch.set_num_threads(2)


class Net(nn.Module):
    def __init__(self, dropout=0.):
        super().__init__()
        self.features=nn.Sequential(nn.Linear(32,128),nn.ReLU(),nn.Dropout(dropout),
            nn.Linear(128,128),nn.ReLU(),nn.Dropout(dropout),
            nn.Linear(128,128),nn.ReLU(),nn.Dropout(dropout),
            nn.Linear(128,128),nn.ReLU())
        self.head=nn.Linear(128,3)

    def forward(self,x,recompute=False):
        hidden=checkpoint(self.features,x,use_reentrant=False) if recompute else self.features(x)
        return self.head(hidden)


def make_data():
    generator=torch.Generator().manual_seed(26)
    x=torch.randn(768,32,generator=generator)
    teacher=torch.randn(32,3,generator=generator)
    y=(x@teacher+.25*torch.randn(768,3,generator=generator)).argmax(1)
    return x,y


def new_model(dropout=0.):
    torch.manual_seed(260)
    return Net(dropout)


def flatten(model,grad=False):
    return torch.cat([(p.grad if grad else p).detach().flatten()for p in model.parameters()])


def max_error(a,b):return float((a-b).abs().max())


def gradient_experiments(x,y):
    full=new_model();F.cross_entropy(full(x[:96]),y[:96]).backward();reference=flatten(full,True)
    accumulated=new_model();wrong=new_model();offset=0
    for size in [17,31,48]:
        xb,yb=x[offset:offset+size],y[offset:offset+size]
        (F.cross_entropy(accumulated(xb),yb,reduction='sum')/96).backward()
        (F.cross_entropy(wrong(xb),yb)/3).backward();offset+=size
    bf=new_model()
    with torch.autocast('cpu',dtype=torch.bfloat16):loss=F.cross_entropy(bf(x[:96]),y[:96])
    loss.backward()
    result={'accumulation_gradient_error':max_error(reference,flatten(accumulated,True)),
        'unweighted_microbatch_error':max_error(reference,flatten(wrong,True)),
        'bf16_gradient_error':max_error(reference,flatten(bf,True))}
    opt=torch.optim.SGD(full.parameters(),lr=.05);opt.step()
    return result,flatten(full),reference


def ddp_worker(rank,init_method,output):
    torch.set_num_threads(2)
    dist.init_process_group('gloo',rank=rank,world_size=2,init_method=init_method)
    try:
        x,y=make_data();model=DistributedDataParallel(new_model())
        optimizer=torch.optim.SGD(model.parameters(),lr=.05)
        sl=slice(rank*48,(rank+1)*48)
        optimizer.zero_grad();F.cross_entropy(model(x[sl]),y[sl]).backward();optimizer.step()
        total=torch.tensor([rank+1.,2.*rank+1.]);dist.all_reduce(total)
        torch.save({'parameters':flatten(model.module),'reduction':total},Path(output)/f'ddp-rank{rank}.pt')
    finally:dist.destroy_process_group()


def retained_storage(x,y,recompute):
    model=new_model();saved={};parameter_pointers={p.untyped_storage().data_ptr()for p in model.parameters()}
    def pack(tensor):
        storage=tensor.untyped_storage();ptr=storage.data_ptr()
        if ptr not in parameter_pointers:saved[ptr]=storage.nbytes()
        return tensor
    with torch.autograd.graph.saved_tensors_hooks(pack,lambda t:t):
        loss=F.cross_entropy(model(x[:96],recompute=recompute),y[:96])
    retained=sum(saved.values());loss.backward()
    return retained,flatten(model,True)


def train_steps(model,optimizer,x,y,start,end):
    losses=[]
    for _ in range(start,end):
        index=torch.randperm(576)[:96]
        optimizer.zero_grad();loss=F.cross_entropy(model(x[index]),y[index]);loss.backward();optimizer.step();losses.append(float(loss.detach()))
    return losses


def recovery(x,y,out):
    model=new_model(.2);optimizer=torch.optim.Adam(model.parameters(),lr=.003)
    torch.manual_seed(2026)
    first=train_steps(model,optimizer,x,y,0,6)
    checkpoint_data={'model':copy.deepcopy(model.state_dict()),'optimizer':copy.deepcopy(optimizer.state_dict()),
        'rng_state':torch.get_rng_state(),'completed_updates':6,'architecture':{'inputs':32,'hidden':128,'hidden_layers':4,'outputs':3,'dropout':.2},'learning_rate':.003}
    torch.save(checkpoint_data,out/'training-checkpoint.pt')
    later=train_steps(model,optimizer,x,y,6,12);reference=flatten(model)
    saved=torch.load(out/'training-checkpoint.pt',weights_only=True)
    restored=Net(.2);restored.load_state_dict(saved['model']);restored_opt=torch.optim.Adam(restored.parameters(),lr=.003);restored_opt.load_state_dict(saved['optimizer'])
    torch.set_rng_state(saved['rng_state']);restored_loss=train_steps(restored,restored_opt,x,y,6,12)
    weights_only=Net(.2);weights_only.load_state_dict(saved['model']);fresh_opt=torch.optim.Adam(weights_only.parameters(),lr=.003)
    torch.set_rng_state(saved['rng_state']);weights_loss=train_steps(weights_only,fresh_opt,x,y,6,12)
    model.eval()
    with torch.no_grad():test_accuracy=float((model(x[576:]).argmax(1)==y[576:]).float().mean())
    torch.save(model.state_dict(),out/'trained-model.pt')
    return {'resume_parameter_error':max_error(reference,flatten(restored)),'weights_only_parameter_error':max_error(reference,flatten(weights_only)),
        'resume_loss_error':float(np.max(abs(np.array(later)-restored_loss))),'test_accuracy':test_accuracy},np.array(first+later),np.array(first+restored_loss),np.array(first+weights_loss)


def measure(function,repeats=12,inner=5):
    for _ in range(3):function()
    values=[]
    for _ in range(repeats):
        start=time.perf_counter()
        for _ in range(inner):function()
        values.append((time.perf_counter()-start)*1000/inner)
    return np.array(values)


def timings(x,y,out):
    np.savetxt(out/'features.csv',x.numpy(),delimiter=',',fmt='%.9g');np.save(out/'features.npy',x.numpy())
    paths={'Parse CSV':lambda:np.loadtxt(out/'features.csv',delimiter=',',dtype=np.float32),
           'Read NPY':lambda:np.load(out/'features.npy'),
           'Cached rows':lambda:x[:96].clone()}
    data={k:measure(fn,inner=3)for k,fn in paths.items()}
    steps={}
    for name,amp,recompute in [('FP32',False,False),('CPU BF16',True,False),('Recompute',False,True)]:
        model=new_model();optimizer=torch.optim.SGD(model.parameters(),lr=.05)
        def step():
            optimizer.zero_grad()
            with torch.autocast('cpu',dtype=torch.bfloat16,enabled=amp):loss=F.cross_entropy(model(x[:96],recompute=recompute),y[:96])
            loss.backward();optimizer.step()
        steps[name]=measure(step)
    return data,steps


def profile(x,y,out):
    model=new_model();opt=torch.optim.Adam(model.parameters(),lr=.003)
    for _ in range(3):
        opt.zero_grad();F.cross_entropy(model(x[:96]),y[:96]).backward();opt.step()
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU],record_shapes=True) as prof:
        for _ in range(3):
            opt.zero_grad()
            with torch.profiler.record_function('forward'):prediction=model(x[:96])
            with torch.profiler.record_function('loss'):loss=F.cross_entropy(prediction,y[:96])
            with torch.profiler.record_function('backward'):loss.backward()
            with torch.profiler.record_function('optimizer'):opt.step()
    events=[{'name':e.name,'start_us':e.time_range.start,'duration_us':e.time_range.end-e.time_range.start}for e in prof.events()if e.name in ['forward','loss','backward','optimizer']]
    start=events[0]['start_us']
    for e in events:e['start_us']-=start
    operators=sorted([{'name':e.key,'self_cpu_us':e.self_cpu_time_total,'calls':e.count}for e in prof.key_averages()if e.key.startswith('aten::')],key=lambda e:e['self_cpu_us'],reverse=True)
    (out/'profile.json').write_text(json.dumps({'events':events,'operators':operators},indent=2),encoding='utf-8')
    trace=[{'name':e['name'],'cat':'training','ph':'X','ts':e['start_us'],'dur':e['duration_us'],'pid':0,'tid':0}for e in events]
    (out/'trace.json').write_text(json.dumps({'traceEvents':trace}),encoding='utf-8')
    return events,operators


def draw(out,lang,summary,data_timing,step_timing,events,operators,curves):
    zh=lang=='zh';plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
    colors=['#266d86','#dd8b38','#8a63a2','#4c9276']
    def save(fig,name):
        fig.savefig(out/f'{name}-{lang}.svg',bbox_inches='tight',facecolor='white');fig.savefig(out/f'{name}-{lang}.png',dpi=155,bbox_inches='tight',facecolor='white');plt.close(fig)
    fig=plt.figure(figsize=(12.7,8.1),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[.85,1])
    ax=fig.add_subplot(gs[0,:]);stages=['forward','loss','backward','optimizer'];names=['前向','损失','反向','参数更新']if zh else['Forward','Loss','Backward','Optimizer']
    for j,e in enumerate(events):
        i=stages.index(e['name']);ax.broken_barh([(e['start_us']/1000,e['duration_us']/1000)],(j//4-.28,.56),facecolors=colors[i])
    for i,n in enumerate(names):ax.plot([],[],lw=7,color=colors[i],label=n)
    ax.set_yticks([0,1,2],['1','2','3']);ax.invert_yaxis();ax.set_ylabel('训练步'if zh else'Training step');ax.set_xlabel('从首个前向开始 / ms'if zh else'Time from first forward / ms');ax.legend(ncols=4,frameon=False,loc='upper center',bbox_to_anchor=(.5,1.26));ax.set_title('CPU 实际分析器范围（包含测量开销）'if zh else'Actual CPU profiler ranges (including measurement overhead)',pad=42)
    ax=fig.add_subplot(gs[1,0]);top=operators[:7];ax.barh(range(len(top)),[o['self_cpu_us']/1000 for o in top],color=colors[0]);ax.set_yticks(range(len(top)),[o['name'] for o in top]);ax.invert_yaxis();ax.set_xlabel('三步累计自身 CPU 时间 / ms'if zh else'Self CPU time across three steps / ms')
    ax=fig.add_subplot(gs[1,1]);labels=['FP32','CPU BF16','重计算'if zh else'Recompute']
    for i,(name,v)in enumerate(step_timing.items()):ax.scatter(np.full(len(v),i)+np.linspace(-.08,.08,len(v)),v,color=colors[i],s=18,alpha=.7);ax.plot([i-.2,i+.2],[np.median(v)]*2,color='#243749',lw=2)
    ax.set_xticks(range(3),labels);ax.set_ylabel('每次更新 / ms'if zh else'Milliseconds per update');ax.set_title('12组计时，每组5次更新'if zh else'12 timing groups, five updates each')
    save(fig,'profile')
    fig=plt.figure(figsize=(12.4,6.6),layout='constrained');gs=fig.add_gridspec(2,2,width_ratios=[1,1.35]);ax=fig.add_subplot(gs[:,0])
    bars=[summary['saved_storage_plain_bytes']/1024,summary['saved_storage_checkpoint_bytes']/1024]
    ax.bar([0,1],bars,color=colors[:2],width=.6);ax.set_xticks([0,1],['普通前向','激活重计算']if zh else['Normal forward','Checkpointed']);ax.set_ylabel('保留的非参数张量存储 / KiB'if zh else'Retained non-parameter storage / KiB');ax.set_title('同一96样本前向，按存储地址去重'if zh else'Same 96 examples; unique storage addresses')
    for i,v in enumerate(bars):ax.text(i,v+4,f'{v:.1f}',ha='center')
    ax.set_ylim(0,max(bars)*1.18)
    ax=fig.add_subplot(gs[0,1]);gradkeys=['accumulation_gradient_error','unweighted_microbatch_error','bf16_gradient_error','checkpoint_gradient_error','ddp_update_error'];labels=['加权累积','等权平均小批','BF16','重计算','两进程 DDP']if zh else['Weighted accumulation','Unweighted microbatches','BF16','Recompute','Two-process DDP']
    vals=[summary[k]for k in gradkeys];ax.barh(range(5),np.maximum(vals,1e-10),color=[colors[0],colors[1],colors[2],colors[0],colors[0]]);ax.set_xscale('log');ax.set_yticks(range(5),labels);ax.invert_yaxis();ax.set_xlabel('最大绝对差（0显示在1e-10）'if zh else'Max absolute difference (zero drawn at 1e-10)')
    for i,v in enumerate(vals):ax.text(max(v,1e-10)*1.25,i,f'{v:.2g}',va='center',fontsize=9)
    ax.set_xlim(7e-11,max(vals)*20)
    ax=fig.add_subplot(gs[1,1]);v=np.array([1e-8,1e-5,.1,1.001,1000.1],dtype=np.float32);bf=torch.tensor(v).bfloat16().float().numpy();fp=torch.tensor(v).half().float().numpy();table=[[f'{n:g}',f'{p:.7g}',f'{b:.7g}']for n,p,b in zip(v,fp,bf)];ax.axis('off');t=ax.table(cellText=table,colLabels=['FP32','FP16','BF16'],loc='center',cellLoc='center');t.auto_set_font_size(False);t.set_fontsize(11);t.scale(1,1.7);ax.set_title('真实类型转换：范围与精度是两件事'if zh else'Actual conversions: range and precision differ')
    save(fig,'memory')
    fig,axes=plt.subplots(1,2,figsize=(12.4,5),layout='constrained')
    names=['不中断','完整恢复','只恢复权重']if zh else['Uninterrupted','Full recovery','Weights only']
    for i,c in enumerate(curves):axes[0].plot(np.arange(1,13),c,label=names[i],color=colors[i],lw=2,ls=['-','--',':'][i],marker='o',ms=3)
    axes[0].axvline(6.5,color='gray',ls=':');axes[0].set_xlabel('参数更新次数'if zh else'Optimizer updates');axes[0].set_ylabel('抽样批次交叉熵'if zh else'Sampled-batch cross-entropy');axes[0].legend(frameon=False);axes[0].set_xticks([1,3,6,9,12])
    for i,(name,v)in enumerate(data_timing.items()):axes[1].scatter(np.full(len(v),i)+np.linspace(-.08,.08,len(v)),v,color=colors[i],s=18,alpha=.7);axes[1].plot([i-.2,i+.2],[np.median(v)]*2,color='#243749',lw=2)
    axes[1].set_yscale('log');axes[1].set_xticks([0,1,2],['CSV全量解析','NPY全量读取','缓存96行复制']if zh else['Parse all CSV','Read all NPY','Copy 96 cached rows']);axes[1].tick_params(axis='x',labelsize=9);axes[1].set_ylabel('每次操作 / ms（对数轴）'if zh else'Milliseconds per operation (log scale)');axes[1].set_title('预热后的读取与解析成本'if zh else'Warm-cache reading and parsing costs')
    save(fig,'recovery')
    fig,axes=plt.subplots(1,2,figsize=(12.4,5.4),layout='constrained')
    n=1e8;devices=4;memory=np.array([[2,2,12],[2,2,12/devices],[2,2/devices,12/devices],[2/devices,2/devices,12/devices]])*n/1e9
    base=np.zeros(4)
    for j,label in enumerate(['参数','梯度','主权重 + Adam 状态']if zh else['Parameters','Gradients','Master weights + Adam state']):axes[0].bar(range(4),memory[:,j],bottom=base,color=colors[j],label=label);base+=memory[:,j]
    axes[0].set_xticks(range(4),['DDP','ZeRO-1','ZeRO-2','ZeRO-3']);axes[0].set_ylabel('每设备持久状态 / GB'if zh else'Persistent state per device / GB');axes[0].legend(frameon=False,fontsize=9);axes[0].set_title('解析预算：1亿参数、4设备、混合精度'if zh else'Analytical budget: 100M parameters, four devices')
    stages,micro=3,4
    for stage in range(stages):
        for mb in range(micro):
            axes[1].broken_barh([(stage+mb,1)],(stage-.32,.64),facecolors=colors[mb]);axes[1].text(stage+mb+.5,stage,str(mb+1),ha='center',va='center',color='white')
    axes[1].set_yticks(range(stages),['阶段1','阶段2','阶段3']if zh else['Stage 1','Stage 2','Stage 3']);axes[1].invert_yaxis();axes[1].set_xticks(range(7));axes[1].set_xlim(0,6);axes[1].set_xlabel('理想化前向时间槽（等时阶段）'if zh else'Idealized forward slots (equal stage times)');axes[1].set_title('4个微批，3阶段：利用率4/6'if zh else'Four microbatches, three stages: utilization 4/6')
    save(fig,'parallel')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--language',choices=['zh','en'],default='en');parser.add_argument('--render-only',action='store_true',help='Render another language from already measured outputs');args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    if args.render_only:
        summary=json.loads((out/'summary.json').read_text());stored=np.load(out/'data.npz');pr=json.loads((out/'profile.json').read_text())
        data_timing={k:stored['data_'+k.replace(' ','_')]for k in ['Parse CSV','Read NPY','Cached rows']};step_timing={k:stored['step_'+k.replace(' ','_')]for k in ['FP32','CPU BF16','Recompute']}
        curves=[stored[k]for k in ['loss_full','loss_restored','loss_weights_only']]
        draw(out,args.language,summary,data_timing,step_timing,pr['events'],pr['operators'],curves);return
    x,y=make_data();summary,reference_update,reference_gradient=gradient_experiments(x,y)
    rendezvous=out/('rendezvous-'+uuid.uuid4().hex)
    mp.spawn(ddp_worker,args=(rendezvous.as_uri(),str(out)),nprocs=2,join=True)
    ranks=[torch.load(out/f'ddp-rank{k}.pt',weights_only=True)for k in range(2)]
    summary.update({'ddp_update_error':max_error(reference_update,ranks[0]['parameters']),'ddp_replica_error':max_error(ranks[0]['parameters'],ranks[1]['parameters']),'all_reduce_hand':ranks[0]['reduction'].tolist()})
    if rendezvous.exists():rendezvous.unlink()
    plain,plain_gradient=retained_storage(x,y,False);saved,checkpoint_gradient=retained_storage(x,y,True)
    summary.update({'saved_storage_plain_bytes':plain,'saved_storage_checkpoint_bytes':saved,'checkpoint_gradient_error':max_error(plain_gradient,checkpoint_gradient)})
    recovery_summary,*curves=recovery(x,y,out);summary.update(recovery_summary)
    data_timing,step_timing=timings(x,y,out);events,operators=profile(x,y,out)
    summary.update({'parameter_count':sum(p.numel()for p in new_model().parameters()),'timing_median_ms':{k:float(np.median(v))for k,v in step_timing.items()},'data_median_ms':{k:float(np.median(v))for k,v in data_timing.items()},'fp16_tiny':float(torch.tensor(1e-8).half()),'scaled_fp16_recovered':float((torch.tensor(1e-8)*65536).half().float()/65536),'bf16_tiny':float(torch.tensor(1e-8).bfloat16()),'memory_budget_gb':[1.6,.7,.55,.4],'pipeline_forward_utilization':4/6,'effective_batch_hand':4*8*3,
        'environment':{'device':'CPU','threads_per_process':2,'ddp_processes':2,'backend':'gloo','torch':str(torch.__version__),'numpy':np.__version__,'python':platform.python_version(),'os':platform.system()}})
    np.savez(out/'data.npz',features=x.numpy(),labels=y.numpy(),loss_full=curves[0],loss_restored=curves[1],loss_weights_only=curves[2],**{'step_'+k.replace(' ','_'):v for k,v in step_timing.items()},**{'data_'+k.replace(' ','_'):v for k,v in data_timing.items()})
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    draw(out,args.language,summary,data_timing,step_timing,events,operators,curves)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
