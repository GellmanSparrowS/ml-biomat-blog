# Public sources and third-party materials

- Dive into Deep Learning: Training on Multiple GPUs: https://d2l.ai/chapter_computational-performance/multiple-gpus.html
  D2L original figure CC BY-SA4.0; full notice included.
- PyTorch Distributed design note: https://docs.pytorch.org/docs/2.15/notes/ddp.html
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- PyTorch Distributed: Experiences on Accelerating Data Parallel Training: https://arxiv.org/abs/2006.15704
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- PyTorch Automatic Mixed Precision: https://docs.pytorch.org/docs/2.15/amp.html
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- PyTorch activation checkpointing: https://docs.pytorch.org/docs/2.15/checkpoint.html
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- PyTorch data loading: https://docs.pytorch.org/docs/2.15/data.html
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- Getting Started with FSDP2: https://docs.pytorch.org/tutorials/intermediate/FSDP_tutorial.html
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- ZeRO: Memory Optimizations Toward Training Trillion Parameter Models: https://arxiv.org/abs/1910.02054
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- PyTorch Tensor Parallel tutorial: https://docs.pytorch.org/tutorials/intermediate/TP_tutorial.html
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- PyTorch Pipeline Parallel tutorial: https://docs.pytorch.org/tutorials/intermediate/pipelining_tutorial.html
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- Switch Transformers: https://arxiv.org/abs/2101.03961
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- JAX: grad and vmap: https://docs.jax.dev/en/latest/101/transformations.html
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- JAX: Distributed arrays and automatic parallelization: https://docs.jax.dev/en/latest/201/sharding.html
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- Keras: Customizing fit with TensorFlow: https://keras.io/guides/custom_train_step_in_tensorflow/
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- TensorFlow: Distributed training: https://www.tensorflow.org/guide/distributed_training
  Technical reference; original experiment code and diagrams, no external figure reproduced.
- D2L full figure license: https://github.com/d2l-ai/d2l-en/blob/master/LICENSE
  CC BY-SA4.0
