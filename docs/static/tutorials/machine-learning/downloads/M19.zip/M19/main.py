"""Small paired image-text experiment with explicit candidate sets and ablations."""
import argparse,copy,json
from pathlib import Path
import numpy as np
import torch
from torch import nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as PolygonPath
from sklearn.decomposition import PCA

torch.set_num_threads(2)
COLORS=np.array([[.85,.2,.18],[.18,.65,.3],[.15,.35,.85]])
CAPTIONS=['red circle','red square','red triangle','green circle','green square','green triangle','blue circle','blue square','blue triangle']
TOKENS=torch.tensor([[c,s+3]for c in range(3)for s in range(3)])

def dataset(perclass,seed):
    rng=np.random.default_rng(seed);images=[];labels=[];yy,xx=np.mgrid[:28,:28]
    for c in range(9):
        color,shape=divmod(c,3)
        for _ in range(perclass):
            cx,cy=rng.uniform(12,16,2);rad=rng.uniform(6,9)
            if shape==0:mask=(xx-cx)**2+(yy-cy)**2<=rad**2
            elif shape==1:mask=(abs(xx-cx)<=rad)&(abs(yy-cy)<=rad)
            else:mask=PolygonPath([[cx,cy-rad],[cx-rad,cy+rad],[cx+rad,cy+rad]]).contains_points(np.c_[xx.ravel(),yy.ravel()]).reshape(28,28)
            im=np.ones((28,28,3))*rng.uniform(.03,.15);im[mask]=COLORS[color]*rng.uniform(.8,1.1);im=np.clip(im+rng.normal(0,.025,im.shape),0,1)
            images.append(im.transpose(2,0,1));labels.append(c)
    return torch.tensor(np.array(images),dtype=torch.float32),np.array(labels)

class PairModel(nn.Module):
    def __init__(self):
        super().__init__();self.image=nn.Sequential(nn.Conv2d(3,12,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),nn.Conv2d(12,24,3,padding=1),nn.ReLU(),nn.AdaptiveAvgPool2d((4,4)),nn.Flatten(),nn.Linear(384,24))
        self.words=nn.Embedding(6,24);self.text=nn.Linear(24,24,bias=False)
    def encode_image(self,x):return nn.functional.normalize(self.image(x),dim=1)
    def encode_text(self,t):return nn.functional.normalize(self.text(self.words(t).mean(1)),dim=1)
    def forward(self,x,t):return self.encode_image(x)@self.encode_text(t).T/.12

def recall_at(similarity,querylabels,candidatelabels,k):
    top=np.argsort(-similarity,axis=1)[:,:k]
    return float(np.mean(np.any(candidatelabels[top]==querylabels[:,None],axis=1)))

def run(out,language):
    out.mkdir(parents=True,exist_ok=True);zh=language=='zh';text=lambda z,e:z if zh else e
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','axes.unicode_minus':False})
    save=lambda fig,name:(fig.savefig(out/f'{name}-{language}.svg',bbox_inches='tight'),fig.savefig(out/f'{name}-{language}.png',dpi=140,bbox_inches='tight'),plt.close(fig))
    torch.manual_seed(19);train,ytrain=dataset(32,19);valid,yvalid=dataset(8,119);test,ytest=dataset(12,219)
    model=PairModel();optimizer=torch.optim.Adam(model.parameters(),lr=.002);trace=[];best=float('inf');selected=0
    for step in range(1,301):
        model.train();idx=torch.arange(9)*32+torch.randint(32,(9,));optimizer.zero_grad();logits=model(train[idx],TOKENS);target=torch.arange(9)
        loss=(nn.functional.cross_entropy(logits,target)+nn.functional.cross_entropy(logits.T,target))/2;loss.backward();optimizer.step()
        if step%5==0:
            model.eval()
            with torch.no_grad():vl=nn.functional.cross_entropy(model(valid,TOKENS),torch.tensor(yvalid)).item()
            trace.append([step,loss.item(),vl])
            if vl<best:best=vl;weights=copy.deepcopy(model.state_dict());selected=step
    model.load_state_dict(weights);model.eval()
    torch.save(model.state_dict(),out/'paired-model.pt')
    (out/'model.json').write_text(json.dumps({'class':'PairModel','image_shape':[3,28,28],'embedding_dimensions':24,'vocabulary':['red','green','blue','circle','square','triangle'],'tokens':TOKENS.tolist(),'captions':CAPTIONS,'temperature':.12,'selected_step':selected},indent=2),encoding='utf-8')
    reloaded=PairModel();reloaded.load_state_dict(torch.load(out/'paired-model.pt',weights_only=True));reloaded.eval()
    with torch.no_grad():reload_error=float((model(test,TOKENS)-reloaded(test,TOKENS)).abs().max())
    with torch.no_grad():
        iz=model.encode_image(test).numpy();tz=model.encode_text(TOKENS).numpy();sim=iz@tz.T
        gray=test.mean(1,keepdim=True).repeat(1,3,1,1);gray_sim=(model.encode_image(gray)@model.encode_text(TOKENS).T).numpy()
        missing_sim=(model.encode_image(torch.zeros_like(test))@model.encode_text(TOKENS).T).numpy()
        shapeonly=model.encode_text(TOKENS[:3,1:]).numpy();shape_sim=(iz@shapeonly.T)[:,np.arange(9)%3]
    pred=sim.argmax(1);i2t=recall_at(sim,ytest,np.arange(9),1);t2i=recall_at(sim.T,np.arange(9),ytest,1)
    gray_pred=gray_sim.argmax(1);shape_pred=shape_sim.argmax(1)
    mean_sim=np.array([sim[ytest==k].mean(0)for k in range(9)])
    image_means=np.array([iz[ytest==k].mean(0)for k in range(9)]);pca=PCA(2);project=pca.fit_transform(np.r_[image_means,tz]);scores=(sim/.12);probs=np.exp(scores-scores.max(1,keepdims=True));probs/=probs.sum(1,keepdims=True)
    # Removing a candidate changes normalized scores but not remaining cosine similarities.
    hand=np.array([1,0,-1]);soft=np.exp(hand);soft/=soft.sum();soft_subset=np.exp(hand[:2]);soft_subset/=soft_subset.sum()
    summary={'train_images':len(train),'validation_images':len(valid),'test_images':len(test),'candidate_captions':9,'selected_step':selected,'i2t_recall1':i2t,'t2i_recall1':t2i,'i2t_recall3':recall_at(sim,ytest,np.arange(9),3),'gray_exact_accuracy':float(np.mean(gray_pred==ytest)),'gray_shape_accuracy':float(np.mean(gray_pred%3==ytest%3)),'missing_image_accuracy':float(np.mean(missing_sim.argmax(1)==ytest)),'shape_only_exact_accuracy':float(np.mean(shape_pred==ytest)),'shape_only_shape_accuracy':float(np.mean(shape_pred%3==ytest%3)),'image_norm_error':float(abs(np.linalg.norm(iz,axis=1)-1).max()),'text_norm_error':float(abs(np.linalg.norm(tz,axis=1)-1).max()),'paired_mean_cosine':float(np.mean(sim[np.arange(len(test)),ytest])),'pca_explained_variance_ratio':pca.explained_variance_ratio_.tolist(),'hand_probabilities':soft.tolist(),'hand_subset_probabilities':soft_subset.tolist(),'semantic_positives_per_text_query':12,'embedding_dimensions':24}
    summary['contradictory_color_mean_cosine']=float(np.mean(sim[np.arange(len(test)),(ytest+3)%9]))
    summary['reload_logits_error']=reload_error
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');np.savez_compressed(out/'data.npz',test_images=test.numpy(),test_labels=ytest,image_embeddings=iz,text_embeddings=tz,similarity=sim,gray_similarity=gray_sim,shape_only_similarity=shape_sim,zero_image_similarity=missing_sim,trace=trace,pca=project)
    assert summary['image_norm_error']<1e-6;assert summary['text_norm_error']<1e-6
    labels=[z for z in CAPTIONS];zhlabels=[c+s for c in ['红色','绿色','蓝色']for s in ['圆形','方形','三角形']];names=zhlabels if zh else labels
    fig,axs=plt.subplots(3,3,figsize=(8,8),layout='constrained')
    for k,ax in enumerate(axs.flat):ax.imshow(test[k*12].permute(1,2,0));ax.set_title(names[k]);ax.set(xticks=[],yticks=[])
    save(fig,'pairs')
    fig,axs=plt.subplots(1,2,figsize=(12,4.8),gridspec_kw={'width_ratios':[1.4,1]},layout='constrained')
    im=axs[0].imshow(mean_sim,cmap='RdBu_r',vmin=-1,vmax=1);axs[0].set(xticks=range(9),yticks=range(9),xticklabels=names,yticklabels=names,xlabel=text('文字候选','Text candidate'),ylabel=text('真实图像类别','True image class'));axs[0].tick_params(axis='x',labelrotation=60);fig.colorbar(im,ax=axs[0],label=text('余弦相似度','Cosine similarity'))
    tr=np.array(trace);axs[1].plot(tr[:,0],tr[:,1],label=text('训练：双向','Train: symmetric'),color='#176b91');axs[1].plot(tr[:,0],tr[:,2],label=text('验证：图检索文','Validation: image to text'),color='#bd554c');axs[1].set(xlabel=text('优化步数','Optimization step'),ylabel=text('交叉熵','Cross entropy'));axs[1].legend();save(fig,'alignment')
    fig,axs=plt.subplots(1,2,figsize=(12,4.5),gridspec_kw={'width_ratios':[1,1.15]},layout='constrained');marks=['o','s','^']
    for k in range(9):
        color=COLORS[k//3];v,w=project[k],project[9+k];axs[0].plot([v[0],w[0]],[v[1],w[1]],color=color,alpha=.5);axs[0].scatter(*v,c=[color],marker=marks[k%3],s=70);axs[0].scatter(*w,facecolors='none',edgecolors=[color],marker=marks[k%3],s=110)
    axs[0].set(xlabel=text('主成分 1','Principal component 1'),ylabel=text('主成分 2','Principal component 2'),title=text('实心：图像均值；空心：文本','Filled: mean image; open: text'))
    lab=[text('完整图文','Full pair'),text('灰度图像','Grayscale'),text('仅形状文字','Shape-only text'),text('全零图像','Zero image')];exact=[i2t,summary['gray_exact_accuracy'],summary['shape_only_exact_accuracy'],summary['missing_image_accuracy']];shape=[float(np.mean(pred%3==ytest%3)),summary['gray_shape_accuracy'],summary['shape_only_shape_accuracy'],float(np.mean(missing_sim.argmax(1)%3==ytest%3))]
    yy=np.arange(4);axs[1].barh(yy-.17,exact,height=.3,color='#176b91',label=text('颜色+形状均正确','Color and shape correct'));axs[1].barh(yy+.17,shape,height=.3,color='#bc8440',label=text('形状正确','Shape correct'));axs[1].set(yticks=yy,yticklabels=lab,xlim=(0,1.05),xlabel=text('正确率','Accuracy'));axs[1].invert_yaxis();axs[1].legend(loc='lower right',fontsize=9);save(fig,'ablation')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('output'));p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();run(args.output,args.language)
