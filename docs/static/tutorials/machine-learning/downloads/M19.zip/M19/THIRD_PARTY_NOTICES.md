# Public sources and third-party materials

- CLIP official repository and original diagram: https://github.com/openai/CLIP
  MIT; Copyright (c) 2021 OpenAI; https://raw.githubusercontent.com/openai/CLIP/main/LICENSE
- Learning Transferable Visual Models From Natural Language Supervision: https://arxiv.org/abs/2103.00020
  Technical reference; no paper figures reproduced.
- BLIP-2: https://arxiv.org/abs/2301.12597
  Technical reference.
- Flamingo: https://arxiv.org/abs/2204.14198
  Technical reference.
