"""Five real boosting implementations; isolated worker resource measurements."""
from pathlib import Path
import argparse,json,sys,subprocess,time,os,ctypes
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import AdaBoostClassifier,GradientBoostingClassifier,GradientBoostingRegressor
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score,log_loss,ndcg_score
from xgboost import XGBClassifier,XGBRanker,DMatrix
from lightgbm import LGBMClassifier,early_stopping,log_evaluation
from catboost import CatBoostClassifier

def peak_rss_mb():
    if os.name=='nt':
        class Counters(ctypes.Structure):
            _fields_=[('cb',ctypes.c_ulong),('PageFaultCount',ctypes.c_ulong)]+[(n,ctypes.c_size_t) for n in ['PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage']]
        c=Counters();c.cb=ctypes.sizeof(c);handle=ctypes.windll.kernel32.GetCurrentProcess;handle.restype=ctypes.c_void_p
        fun=ctypes.windll.psapi.GetProcessMemoryInfo;fun.argtypes=[ctypes.c_void_p,ctypes.POINTER(Counters),ctypes.c_ulong];fun.restype=ctypes.c_int
        if not fun(handle(),ctypes.byref(c),c.cb):raise OSError('Process memory counter failed')
        return c.PeakWorkingSetSize/1024**2
    import resource
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024**2 if sys.platform=='darwin' else 1024)

def worker(name,datafile,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);a=np.load(datafile);X=a['X'];cat=a['category'];y=a['y'];tr=a['train'];va=a['validation'];te=a['test']
    enc=OneHotEncoder(handle_unknown='ignore',sparse_output=False).fit(cat[tr,None]);Z=np.c_[X,enc.transform(cat[:,None])]
    frame=pd.DataFrame(X,columns=[f'x{j}' for j in range(X.shape[1])]);frame['category']=cat
    lframe=frame.copy();dtype=pd.CategoricalDtype(categories=sorted(np.unique(cat[tr])));lframe['category']=lframe['category'].astype(dtype)
    curves={};start=time.perf_counter()
    if name=='AdaBoost':
        model=AdaBoostClassifier(estimator=DecisionTreeClassifier(max_depth=1),n_estimators=400,learning_rate=.1,random_state=31);model.fit(Z[tr],y[tr]);prob=model.predict_proba(Z[te]);rounds=len(model.estimators_)
        curves={'train':[log_loss(y[tr],p) for p in model.staged_predict_proba(Z[tr])],'validation':[log_loss(y[va],p) for p in model.staged_predict_proba(Z[va])]}
    elif name=='GBDT':
        model=GradientBoostingClassifier(n_estimators=400,learning_rate=.05,max_depth=3,random_state=31);model.fit(Z[tr],y[tr]);vcur=[log_loss(y[va],p) for p in model.staged_predict_proba(Z[va])];rounds=int(np.argmin(vcur))+1
        curves={'train':[log_loss(y[tr],p) for p in model.staged_predict_proba(Z[tr])],'validation':vcur};prob=next(p for i,p in enumerate(model.staged_predict_proba(Z[te]),1) if i==rounds)
    elif name=='XGBoost':
        model=XGBClassifier(n_estimators=400,max_depth=3,learning_rate=.05,subsample=.85,colsample_bytree=.85,tree_method='hist',n_jobs=2,random_state=31,eval_metric='logloss',early_stopping_rounds=25,reg_lambda=1.)
        model.fit(Z[tr],y[tr],eval_set=[(Z[tr],y[tr]),(Z[va],y[va])],verbose=False);prob=model.predict_proba(Z[te]);rounds=model.best_iteration+1;ev=model.evals_result();curves={'train':ev['validation_0']['logloss'],'validation':ev['validation_1']['logloss']}
    elif name=='LightGBM':
        model=LGBMClassifier(n_estimators=400,max_depth=3,num_leaves=8,learning_rate=.05,n_jobs=2,random_state=31,verbosity=-1)
        xt=lframe.iloc[tr];yt=y[tr];xv=lframe.iloc[va];yv=y[va]
        model.fit(xt,yt,eval_X=(xt,xv),eval_y=(yt,yv),eval_names=['train','validation'],eval_metric='binary_logloss',callbacks=[early_stopping(25,verbose=False),log_evaluation(0)]);prob=model.predict_proba(lframe.iloc[te]);rounds=model.best_iteration_;curves={'train':model.evals_result_['train']['binary_logloss'],'validation':model.evals_result_['validation']['binary_logloss']}
    else:
        model=CatBoostClassifier(iterations=400,depth=3,learning_rate=.05,loss_function='Logloss',random_seed=31,thread_count=2,verbose=False,allow_writing_files=False,boosting_type='Ordered',one_hot_max_size=2)
        model.fit(frame.iloc[tr],y[tr],cat_features=['category'],eval_set=(frame.iloc[va],y[va]),early_stopping_rounds=25,use_best_model=True);prob=model.predict_proba(frame.iloc[te]);rounds=model.tree_count_;ev=model.get_evals_result();curves={'train':ev['learn']['Logloss'],'validation':ev['validation']['Logloss']}
    elapsed=time.perf_counter()-start;peak=peak_rss_mb();result={'name':name,'test_accuracy':float(accuracy_score(y[te],prob.argmax(1))),'test_log_loss':float(log_loss(y[te],prob)),'selected_rounds':int(rounds),'fit_and_curve_seconds':elapsed,'worker_peak_rss_mb':peak,'curves':curves}
    if name=='XGBoost':
        booster=model.get_booster();dm=DMatrix(Z[te[:1]]);contrib=booster.predict(dm,pred_contribs=True,iteration_range=(0,rounds))[0];margin=float(booster.predict(dm,output_margin=True,iteration_range=(0,rounds))[0]);result['contribution_sum_error']=float(abs(contrib.sum()-margin));result['example_margin']=margin;result['example_probability']=float(prob[0,1]);result['contributions']=contrib.tolist();result['feature_names']=[f'x{j}' for j in range(X.shape[1])]+enc.get_feature_names_out(['category']).tolist()+['bias'];model.save_model(out/'model.ubj')
    (out/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf8');np.save(out/'test_probability.npy',prob)

def main(output,language):
    out=Path(output);out.mkdir(parents=True,exist_ok=True);zh=language=='zh';rng=np.random.default_rng(31)
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
    def t(z,e):return z if zh else e
    def save(f,n):f.savefig(out/f'{n}-{language}.svg',bbox_inches='tight');plt.close(f)
    X,y=make_classification(n_samples=1800,n_features=10,n_informative=5,n_redundant=2,class_sep=1.,flip_y=.03,random_state=31)
    category=np.array(['A','B','C','D'])[np.digitize(X[:,0],[-.7,0,.7])];idx=np.arange(1800);tr,tmp=train_test_split(idx,test_size=.4,stratify=y,random_state=31);va,te=train_test_split(tmp,test_size=.5,stratify=y[tmp],random_state=31)
    datafile=out/'classification_data.npz';np.savez(datafile,X=X,category=category,y=y,train=tr,validation=va,test=te)
    results={}
    for name in ['AdaBoost','GBDT','XGBoost','LightGBM','CatBoost']:
        dest=out/'workers'/name;run=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',name,'--data',str(datafile),'--output',str(dest)],capture_output=True,text=True)
        if run.returncode:raise RuntimeError(f'{name} failed:\n{run.stderr}')
        results[name]=json.loads((dest/'summary.json').read_text())
    # Gradient boosting for a known continuous relationship, exposing component trees.
    xr=np.sort(rng.uniform(-2,2,100));yr=np.sin(2*xr)+.25*xr+rng.normal(0,.18,100);reg=GradientBoostingRegressor(n_estimators=60,learning_rate=.15,max_depth=2,random_state=31).fit(xr[:,None],yr);grid=np.linspace(-2,2,300);staged=list(reg.staged_predict(grid[:,None]));initial=float(yr.mean());first=reg.estimators_[0,0].predict(grid[:,None]);residual=yr-initial
    fig=plt.figure(figsize=(12,6),layout='constrained');gs=fig.add_gridspec(2,3)
    ax=fig.add_subplot(gs[0,0]);ax.scatter(xr,yr,s=12,color='#167d87');ax.axhline(initial,color='#d48745');ax.set(title=t('初始常数预测','Initial constant prediction'),xlabel='x',ylabel='y')
    ax=fig.add_subplot(gs[0,1]);ax.scatter(xr,residual,s=12,color='#167d87');ax.plot(grid,first,color='#d48745');ax.axhline(0,color='#a3b7c1',lw=.7);ax.set(title=t('第一棵树拟合残差','First tree fits residuals'),xlabel='x',ylabel=t('残差','Residual'))
    ax=fig.add_subplot(gs[0,2]);ax.plot(grid,.15*first,color='#d48745');ax.set(title=t('加入15%的树贡献','Add 15% of the tree contribution'),xlabel='x',ylabel=t('新增预测','Added prediction'))
    for ax,n in zip([fig.add_subplot(gs[1,j]) for j in range(3)],[1,10,60]):ax.scatter(xr,yr,s=9,color='#9bb1bd');ax.plot(grid,np.sin(2*grid)+.25*grid,'--',color='#263d4b');ax.plot(grid,staged[n-1],color='#167d87');ax.set(title=f'{n} '+t('棵树','trees'),xlabel='x',ylabel='y')
    save(fig,'residual_steps')
    fig,axs=plt.subplots(1,2,figsize=(11,4.4),layout='constrained');colors=['#9b6b89','#b78a44','#167d87','#5275a3','#7648a0']
    for (name,r),color in zip(results.items(),colors):
        axs[0].plot(np.arange(1,len(r['curves']['validation'])+1),r['curves']['validation'],label=name,color=color);axs[1].plot(np.arange(1,len(r['curves']['train'])+1),r['curves']['train'],label=name,color=color)
    axs[0].set(title=t('验证集概率对数损失','Validation probability log loss'),xlabel=t('树数','Tree count'),ylabel=t('对数损失（nat）','Log loss (nats)'));axs[1].set(title=t('训练集概率对数损失','Training probability log loss'),xlabel=t('树数','Tree count'),ylabel=t('对数损失（nat）','Log loss (nats)'));axs[0].legend();save(fig,'curves')
    fig,axs=plt.subplots(2,2,figsize=(11,7),layout='constrained');names=list(results)
    for ax,key,label in zip(axs.ravel(),['test_accuracy','test_log_loss','fit_and_curve_seconds','worker_peak_rss_mb'],[t('测试准确率','Test accuracy'),t('测试对数损失（nat）','Test log loss (nats)'),t('拟合与曲线计算时间（秒）','Fit and curve-computation time (s)'),t('独立进程峰值RSS（MiB）','Isolated-process peak RSS (MiB)')]):
        values=[results[n][key] for n in names];ax.barh(names,values,color=colors);ax.set(xlabel=label);ax.invert_yaxis();ax.set_xlim(0,max(values)*1.18)
        for i,v in enumerate(values):ax.text(v,i,f' {v:.3f}' if key!='worker_peak_rss_mb' else f' {v:.1f}',va='center',fontsize=10)
    save(fig,'comparison')
    r=results['XGBoost'];con=np.array(r['contributions']);order=np.argsort(np.abs(con[:-1]))[::-1][:7];fig,ax=plt.subplots(figsize=(9,4.6),layout='constrained');ax.barh(np.arange(len(order)),con[order],color=np.where(con[order]>=0,'#d48745','#167d87'));ax.set_yticks(np.arange(len(order)),np.array(r['feature_names'])[order]);ax.axvline(0,color='#7d97a4');ax.set(xlabel=t('原始分数贡献（log-odds）','Raw-score contribution (log odds)'),title=t('同一个测试样本：贡献相加得到原始分数','One test observation: contributions add to the raw score'));ax.invert_yaxis();save(fig,'contributions')
    # Query-disjoint ranking: each query contains eight candidates, relevance0..3.
    qx=rng.normal(size=(80,8,4));utility=2*qx[:,:,0]-qx[:,:,1]+.4*rng.normal(size=(80,8));rel=np.empty((80,8),int)
    for q in range(80):rel[q,np.argsort(utility[q])]=np.repeat(np.arange(4),2)
    ranker=XGBRanker(n_estimators=60,max_depth=3,learning_rate=.1,objective='rank:ndcg',tree_method='hist',n_jobs=2,random_state=31)
    ranker.fit(qx[:60].reshape(-1,4),rel[:60].ravel(),qid=np.repeat(np.arange(60),8));rs=ranker.predict(qx[60:].reshape(-1,4)).reshape(20,8);ranking=float(ndcg_score(2**rel[60:]-1,rs,k=5))
    summary={'train_n':len(tr),'validation_n':len(va),'test_n':len(te),'numeric_features':10,'categories':4,'models':{n:{k:v for k,v in r.items() if k not in ['curves','contributions','feature_names']} for n,r in results.items()},'regression_initial_residual_sum':float(residual.sum()),'xgb_contribution_sum_error':results['XGBoost']['contribution_sum_error'],'ranking_train_queries':60,'ranking_test_queries':20,'ranking_candidates_per_query':8,'ranking_ndcg5':ranking}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');np.savez(out/'regression_ranking_data.npz',x=xr,y=yr,rank_X=qx,rank_relevance=rel,rank_prediction=rs)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--language',choices=['zh','en'],default='en');ap.add_argument('--worker');ap.add_argument('--data');a=ap.parse_args()
    if a.worker:worker(a.worker,a.data,a.output)
    else:main(a.output,a.language)
