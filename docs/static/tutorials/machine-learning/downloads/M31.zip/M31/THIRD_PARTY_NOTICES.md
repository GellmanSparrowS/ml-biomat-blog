# Public sources and third-party materials

- Freund & Schapire (1997), A Decision-Theoretic Generalization of On-Line Learning and an Application to Boosting: https://www.schapire.net/papers/FreundSc95.pdf
  Reference
- Friedman (2001), Greedy Function Approximation: A Gradient Boosting Machine: https://www.cmi.ac.in/~madhavan/courses/dmml2025/literature/Friedman-Gradient-Boosting-Machine-2001.pdf
  Reference
- XGBoost — Introduction to Boosted Trees: https://xgboost.readthedocs.io/en/stable/tutorials/model.html
  Apache-2.0 project; technical reference
- LightGBM — Features: https://lightgbm.readthedocs.io/en/stable/Features.html
  MIT; Microsoft and LightGBM developers
- LightGBM (2017): https://proceedings.neurips.cc/paper/2017/hash/6449f44a102fde848669bdd9eb6b76fa-Abstract.html
  Reference
- CatBoost — Transforming categorical features to numerical features: https://catboost.ai/docs/en/concepts/algorithm-main-stages_cat-to-numberic
  Technical reference
- CatBoost: unbiased boosting with categorical features: https://arxiv.org/abs/1706.09516
  Reference
- LightGBM license: https://github.com/microsoft/LightGBM/blob/master/LICENSE
  MIT
