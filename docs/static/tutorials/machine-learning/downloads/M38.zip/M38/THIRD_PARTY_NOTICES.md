# Public sources and third-party materials

- Conservative Q-Learning for Offline Reinforcement Learning: https://arxiv.org/abs/2006.04779
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- imitation: Behavioral Cloning and DAgger: https://imitation.readthedocs.io/en/latest/algorithms/dagger.html
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- Minari: Basic Usage: https://minari.farama.org/content/basic_usage/
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- Underactuated Robotics: LQR: https://underactuated.mit.edu/lqr.html
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- Underactuated Robotics: Trajectory Optimization: https://underactuated.mit.edu/trajopt.html
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- DreamerV3: Mastering Diverse Domains through World Models: https://arxiv.org/abs/2301.04104
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- Counterfactual Multi-Agent Policy Gradients: https://arxiv.org/html/1705.08926v3
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- Multi-Agent Actor-Critic for Mixed Cooperative-Competitive Environments: https://arxiv.org/abs/1706.02275
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- QMIX: Monotonic Value Function Factorisation: https://arxiv.org/abs/1803.11485
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- PettingZoo: AEC and Parallel API: https://pettingzoo.farama.org/api/parallel/
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- Domain Randomization for Transferring Deep Neural Networks from Simulation to the Real World: https://arxiv.org/abs/1703.06907
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
- Empirical Study of Off-Policy Policy Evaluation: https://arxiv.org/abs/1911.06854
  Technical reference; no external text or figure reproduced. Original course calculations and graphics.
