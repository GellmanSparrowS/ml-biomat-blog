"""Offline learning, receding-horizon control, and cooperative credit assignment.

All environments and datasets are generated here. No external weights or data.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.linalg import solve_discrete_are, block_diag
from scipy.optimize import lsq_linear

torch.set_num_threads(2)
COLORS = ['#256d85', '#e58f38', '#8a5a9e', '#4c9571']


def offline_fit(alpha, covered=False):
    # Repeated rows are repeated observations, not independent environments.
    s = torch.tensor([0, 1] * 100)
    a = torch.zeros(200, dtype=torch.long)
    reward = torch.tensor([0., 1.] * 100)
    nxt = torch.ones(200, dtype=torch.long)
    done = torch.tensor([0., 1.] * 100)
    if covered:
        s = torch.cat((s, torch.tensor([0, 1] * 5)))
        a = torch.cat((a, torch.ones(10, dtype=torch.long)))
        reward = torch.cat((reward, -2 * torch.ones(10)))
        nxt = torch.cat((nxt, torch.zeros(10, dtype=torch.long)))
        done = torch.cat((done, torch.ones(10)))
    q = torch.nn.Parameter(torch.tensor([[0., 3.], [0., 3.]]))
    target = q.detach().clone()
    optimizer = torch.optim.Adam([q], lr=.03)
    curve = []
    for step in range(1000):
        y = reward + .9 * (1-done) * target[nxt].max(dim=1).values
        error = .5 * (q[s, a]-y).square().mean()
        penalty = (torch.logsumexp(q[s], dim=1)-q[s, a]).mean()
        loss = error + alpha * penalty
        optimizer.zero_grad(); loss.backward(); optimizer.step()
        if (step+1) % 20 == 0:
            target = q.detach().clone()
            curve.append(q.detach().numpy().copy())
    logits = torch.nn.Parameter(torch.zeros(2, 2))
    opt_bc = torch.optim.Adam([logits], lr=.03)
    for _ in range(300):
        loss = torch.nn.functional.cross_entropy(logits[s], a)
        opt_bc.zero_grad(); loss.backward(); opt_bc.step()
    return q.detach().numpy(), np.array(curve), logits.detach().softmax(1).numpy()


def rollout_table(q, unobserved_reward):
    state, value = 0, 0.
    for t in range(2):
        action = int(np.argmax(q[state]))
        if action == 1:
            return value + .9**t * unobserved_reward
        if state == 1:
            return value + .9**t
        state = 1
    return value


def mpc_plan(A, B, Q, R, P, x, horizon=12, limit=1.):
    # Stack x_1,...,x_H = S x_0 + T [u_0,...,u_(H-1)].
    n = len(x)
    S = np.vstack([np.linalg.matrix_power(A, i+1) for i in range(horizon)])
    T = np.zeros((n*horizon, horizon))
    for i in range(horizon):
        for j in range(i+1):
            T[n*i:n*(i+1), j] = (np.linalg.matrix_power(A, i-j) @ B).ravel()
    weights = block_diag(*([Q]*(horizon-1)+[P]))
    L = np.linalg.cholesky(weights).T
    design = np.vstack((L @ T, np.sqrt(R[0, 0])*np.eye(horizon)))
    rhs = np.r_[-L @ S @ x, np.zeros(horizon)]
    result = lsq_linear(design, rhs, bounds=(-limit, limit), tol=1e-10)
    assert result.success
    return result.x


def control_experiment():
    rng = np.random.default_rng(38)
    dt = .2
    A = np.array([[1., dt], [0., 1.]])
    B = np.array([[.5*dt*dt], [dt]])
    features = rng.uniform([-2., -1., -1.], [2., 1., 1.], size=(200, 3))
    exact = features[:, :2] @ A.T + features[:, 2:] @ B.T
    measured = exact + rng.normal(0., .01, exact.shape)
    fit = np.linalg.lstsq(features[:150], measured[:150], rcond=None)[0].T
    Ah, Bh = fit[:, :2], fit[:, 2:]
    test_error = features[150:] @ fit.T - exact[150:]
    Q, R = np.diag([1., .1]), np.array([[.1]])
    P = solve_discrete_are(A, B, Q, R)
    Ph = solve_discrete_are(Ah, Bh, Q, R)
    K = np.linalg.solve(R+B.T@P@B, B.T@P@A)
    outputs = {}
    initial = np.array([1.5, 0.])
    initial_plan = mpc_plan(A, B, Q, R, P, initial, horizon=40)
    for name in ['Open loop', 'LQR clipped', 'Learned MPC']:
        x = initial.copy(); states = [x.copy()]; actions = []; cost = 0.
        for t in range(40):
            if name == 'Open loop':
                u = initial_plan[t]
            elif name == 'LQR clipped':
                u = float(np.clip((-K@x).item(), -1., 1.))
            else:
                u = mpc_plan(Ah, Bh, Q, R, Ph, x)[0]
            cost += float(x@Q@x + R[0, 0]*u*u)
            x = A@x + B[:, 0]*u
            if t == 14:
                x[1] += .7
            actions.append(u); states.append(x.copy())
        outputs[name] = {'states': np.array(states), 'actions': np.array(actions), 'cost': cost}
    return A, B, Ah, Bh, K, outputs, np.sqrt(np.mean(test_error**2, axis=0))


PAYOFF = np.array([[1., -1.], [-1., 3.]])


def credit_statistics(p=.5, q=.5):
    pa, pb = np.array([1-p, p]), np.array([1-q, q])
    probability = pa[:, None]*pb[None, :]
    baseline = pa @ PAYOFF
    score = np.array([-p, 1-p])[:, None]
    shared = score * PAYOFF
    counterfactual = score * (PAYOFF-baseline[None, :])
    result = []
    for gradient in [shared, counterfactual]:
        mean = float((probability*gradient).sum())
        variance = float((probability*(gradient-mean)**2).sum())
        result.append([mean, variance])
    return np.array(result)


def cooperative_train(seed, counterfactual):
    torch.manual_seed(seed)
    logits = torch.nn.Parameter(torch.zeros(2))
    optimizer = torch.optim.Adam([logits], lr=.04)
    payoff = torch.tensor(PAYOFF, dtype=torch.float32)
    curves = []
    for _ in range(180):
        probs = torch.sigmoid(logits)
        distribution = torch.distributions.Bernoulli(probs=probs)
        actions = distribution.sample((32,)).long()
        rewards = payoff[actions[:, 0], actions[:, 1]]
        advantages = rewards[:, None].expand(-1, 2).clone()
        if counterfactual:
            weights = torch.stack((1-probs, probs), dim=1).detach()
            b0 = (weights[0, :, None]*payoff[:, actions[:, 1]]).sum(0)
            b1 = (weights[1, None, :]*payoff[actions[:, 0], :]).sum(1)
            advantages -= torch.stack((b0, b1), dim=1)
        loss = -(distribution.log_prob(actions.float())*advantages.detach()).sum(1).mean()
        optimizer.zero_grad(); loss.backward(); optimizer.step()
        p, q = torch.sigmoid(logits).detach().numpy()
        expected = np.array([1-p, p]) @ PAYOFF @ np.array([1-q, q])
        curves.append([float(p), float(q), float(expected)])
    return np.array(curves)


def draw(out, language, q_values, control, curves, statistics, model):
    zh = language == 'zh'
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],
                         'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    def save(fig, name):
        fig.savefig(out/f'{name}-{language}.svg', bbox_inches='tight', facecolor='white')
        fig.savefig(out/f'{name}-{language}.png', dpi=155, bbox_inches='tight', facecolor='white')
        plt.close(fig)
    fig = plt.figure(figsize=(12.8, 6.7), layout='constrained')
    grid = fig.add_gridspec(2, 4, height_ratios=[1, .8])
    names = ['离线 Q','CQL α=1','补齐动作后的 Q'] if zh else ['Offline Q','CQL α=1','Q with action coverage']
    for i, (name, q) in enumerate(zip(names, q_values)):
        ax = fig.add_subplot(grid[0, i]); im = ax.imshow(q, vmin=-4, vmax=4, cmap='RdBu')
        for row in range(2):
            for col in range(2):
                ax.text(col, row, f'{q[row,col]:.2f}', ha='center', va='center', color='white' if abs(q[row,col])>2.5 else '#172838')
        ax.set_xticks([0,1],['a0','a1']); ax.set_yticks([0,1],['s0','s1']); ax.set_title(name)
    fig.colorbar(im, ax=fig.axes, shrink=.75, label='Q（折扣奖励）' if zh else 'Q (discounted reward)', ticks=[-4,0,4])
    ax = fig.add_subplot(grid[0, 3]); counts = np.array([[100,0],[100,0]])
    ax.imshow(counts, cmap='Blues',vmin=0,vmax=100)
    for i in range(2):
        for j in range(2): ax.text(j,i,str(counts[i,j]),ha='center',va='center',color='white' if j==0 else '#172838')
    ax.set_xticks([0,1],['a0','a1']);ax.set_yticks([0,1],['s0','s1']);ax.set_title('原始数据次数' if zh else 'Original transition counts')
    ax = fig.add_subplot(grid[1,:]); rows = ['未知动作奖励 −2','未知动作奖励 +2'] if zh else ['Unobserved action reward −2','Unobserved action reward +2']
    values = np.array([[rollout_table(q,-2),rollout_table(q,2)] for q in q_values[:2]]+[[.9,.9]])
    labels = names[:2]+(['行为克隆（贪心）'] if zh else ['Behavior cloning (greedy)'])
    for i in range(3):ax.bar(np.arange(2)+(i-1)*.2, values[i],width=.19,label=labels[i],color=COLORS[i])
    ax.axhline(0,color='#687b88',lw=.7);ax.set_xticks([0,1],rows);ax.set_ylabel('真实折扣回报' if zh else 'True discounted return');ax.legend(ncols=4,loc='lower center',bbox_to_anchor=(.5,1.04),frameon=False)
    save(fig,'offline')
    fig, axes = plt.subplots(3,1,figsize=(12,8.6),layout='constrained',height_ratios=[1.4,1,.8])
    names_zh={'Open loop':'初始计划持续执行','LQR clipped':'限幅 LQR 反馈','Learned MPC':'学习模型 + MPC'}
    for i,(name,result) in enumerate(control.items()):
        label=names_zh[name] if zh else name
        axes[0].plot(np.arange(41)*.2,result['states'][:,0],label=label,color=COLORS[i],lw=2.1)
        axes[1].step(np.arange(40)*.2,result['actions'],where='post',color=COLORS[i],lw=1.7)
    for ax in axes[:2]:ax.axvline(3,color='#c74f48',ls='--',lw=1.2);ax.grid(alpha=.14)
    axes[0].set_ylabel('位置 / m' if zh else 'Position / m');axes[0].legend(ncols=3,frameon=False);axes[0].set_title('3 s 时速度突然增加 0.7 m/s' if zh else 'Velocity impulse +0.7 m/s at t = 3 s')
    axes[1].set_ylabel('加速度 / (m/s²)' if zh else 'Acceleration / (m/s²)');axes[1].axhline(1,ls=':',color='gray');axes[1].axhline(-1,ls=':',color='gray');axes[1].set_xlabel('时间 / s' if zh else 'Time / s')
    names=list(control);costs=[control[n]['cost'] for n in names]
    axes[2].barh(range(3), costs,color=COLORS[:3]);axes[2].set_yticks(range(3),[names_zh[n] if zh else n for n in names]);axes[2].invert_yaxis();axes[2].set_xlabel('40 步累积代价（归一化）' if zh else '40-step accumulated cost (normalized)')
    for i,c in enumerate(costs):axes[2].text(c+.3,i,f'{c:.2f}',va='center')
    axes[2].set_xlim(0,max(costs)*1.15)
    save(fig,'control')
    fig=plt.figure(figsize=(12.4,7.4),layout='constrained');gs=fig.add_gridspec(2,3,height_ratios=[1,1.15])
    ax=fig.add_subplot(gs[0,0]);im=ax.imshow(PAYOFF,cmap='RdBu',vmin=-3,vmax=3)
    for i in range(2):
        for j in range(2):ax.text(j,i,str(int(PAYOFF[i,j])),ha='center',va='center',fontsize=23,color='white' if PAYOFF[i,j]==3 else '#172838')
    ax.set_xticks([0,1],['0','1']);ax.set_yticks([0,1],['0','1']);ax.set_xlabel('智能体 B 动作' if zh else 'Agent B action');ax.set_ylabel('智能体 A 动作' if zh else 'Agent A action');ax.set_title('共同奖励矩阵' if zh else 'Shared reward matrix');fig.colorbar(im,ax=ax,shrink=.8,ticks=[-3,0,3])
    ax=fig.add_subplot(gs[0,1:]);bar_names=['共同奖励','反事实基线'] if zh else ['Shared reward','Counterfactual baseline']
    for i in range(2):ax.bar(np.arange(2)+(i-.5)*.3,statistics[:,i],.28,color=COLORS[i],label=['梯度均值','梯度方差'][i] if zh else ['Gradient mean','Gradient variance'][i])
    ax.set_xticks([0,1],bar_names);ax.set_ylim(0,.9);ax.legend(frameon=False,ncols=2,loc='upper center');ax.set_title('两方均以 0.5 概率选择动作 1' if zh else 'Both agents choose action 1 with probability 0.5');ax.set_ylabel('精确枚举值' if zh else 'Exact enumeration')
    for i in range(2):
        for j in range(2):ax.text(j+(i-.5)*.3,statistics[j,i]+.015,f'{statistics[j,i]:.4f}',ha='center',fontsize=10)
    ax=fig.add_subplot(gs[1,:])
    for i,c in enumerate(curves):
        y=c[:,:,2];ax.plot(np.arange(1,181),y.mean(0),color=COLORS[i],label=bar_names[i]);ax.fill_between(np.arange(1,181),y.min(0),y.max(0),color=COLORS[i],alpha=.17)
    ax.axhline(3,color='gray',ls=':',label='最优共同奖励' if zh else 'Optimal shared reward');ax.set_xlabel('更新次数（每次 32 次同步决策）' if zh else 'Updates (32 simultaneous decisions each)');ax.set_ylabel('策略的精确期望奖励' if zh else 'Exact expected policy reward');ax.legend(ncols=3,frameon=False)
    save(fig,'cooperation')
    fig,axes=plt.subplots(1,2,figsize=(11.8,4.9),layout='constrained')
    A,B,Ah,Bh=model
    true=np.column_stack((A,B));estimated=np.column_stack((Ah,Bh))
    error=estimated-true;lim=np.max(abs(error))
    im=axes[0].imshow(error,cmap='RdBu',vmin=-lim,vmax=lim)
    for i in range(2):
        for j in range(3):axes[0].text(j,i,f'{error[i,j]:+.4f}',ha='center',va='center',color='white' if abs(error[i,j])>.65*lim else '#172838')
    axes[0].set_xticks(range(3),['p','v','u']);axes[0].set_yticks(range(2),['下一步 p','下一步 v'] if zh else ['p next','v next']);axes[0].set_title('归一化模型系数误差' if zh else 'Normalized model-coefficient error');fig.colorbar(im,ax=axes[0],shrink=.8,label='无量纲' if zh else 'Dimensionless')
    for i,(name,result) in enumerate(control.items()):axes[1].plot(result['states'][:,0],result['states'][:,1],color=COLORS[i],label=names_zh[name] if zh else name)
    axes[1].scatter([0],[0],s=70,marker='*',c='#172838');axes[1].set_xlabel('位置 / m' if zh else 'Position / m');axes[1].set_ylabel('速度 / (m/s)' if zh else 'Velocity / (m/s)');axes[1].legend(frameon=False,fontsize=9);axes[1].set_title('同一扰动下的状态轨迹' if zh else 'State trajectories under the same impulse')
    save(fig,'identification')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args()
    out=args.output;out.mkdir(parents=True,exist_ok=True)
    q0,c0,bc=offline_fit(0);qc,cc,_=offline_fit(1);qcov,ccov,_=offline_fit(0,True)
    A,B,Ah,Bh,K,control,error=control_experiment()
    curves=np.array([[cooperative_train(seed,mode)for seed in [38,138,238,338]]for mode in [False,True]])
    statistics=credit_statistics()
    summary={'offline_q':q0.tolist(),'cql_q':qc.tolist(),'covered_q':qcov.tolist(),'bc_probabilities':bc.tolist(),
             'bad_world_returns':[rollout_table(q,-2) for q in [q0,qc,qcov]],'good_world_returns_original_data':[rollout_table(q,2) for q in [q0,qc]],
             'A_true':A.tolist(),'B_true':B.tolist(),'A_fit':Ah.tolist(),'B_fit':Bh.tolist(),'lqr_gain':K.tolist(),'heldout_model_rmse':error.tolist(),
             'control_costs':{k:v['cost']for k,v in control.items()},'max_abs_action':max(float(abs(v['actions']).max())for v in control.values()),
             'credit_mean':statistics[:,0].tolist(),'credit_variance':statistics[:,1].tolist(),'cooperation_final_return':curves[:,:,-1,2].tolist(),
             'one_step_state':(A@np.array([1.,.5])+B[:,0]*-1).tolist(),'discounted_demonstration_return':.9,
             'importance_weight_hand':(.8/.5)*(.6/.3),'is_hand_return':((.8/.5)*(.6/.3)*2+.4*1)/2}
    np.savez(out/'data.npz',offline_q=q0,cql_q=qc,covered_q=qcov,bc=bc,q_curve=c0,cql_curve=cc,covered_curve=ccov,cooperation=curves,
             **{k.replace(' ','_')+'_'+vname:v for k,result in control.items()for vname,v in result.items()})
    np.savez(out/'models.npz',offline_q=q0,cql_q=qc,bc_probabilities=bc,A_fit=Ah,B_fit=Bh,lqr_gain=K)
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    draw(out,args.language,[q0,qc,qcov],control,curves,statistics,(A,B,Ah,Bh))
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
