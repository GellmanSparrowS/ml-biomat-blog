# Public sources and third-party materials

- Cortes & Vapnik (1995), Support-vector networks: https://homepages.math.uic.edu/~lreyzin/papers/cortes95.pdf
  Reference; original explanatory prose and figures in this chapter.
- scikit-learn — Support Vector Machines: https://scikit-learn.org/stable/modules/svm.html
  BSD-3-Clause documentation/code; dataset terms separate.
- scikit-learn — SVM Margins Example: https://scikit-learn.org/stable/auto_examples/svm/plot_svm_margin.html
  BSD-3-Clause
- scikit-learn — Kernel Approximation: https://scikit-learn.org/stable/modules/kernel_approximation.html
  BSD-3-Clause
- scikit-learn — load_digits: https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html
  Dataset from UCI Optical Recognition of Handwritten Digits; see linked dataset terms.
