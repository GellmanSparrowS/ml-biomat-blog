"""SVM margins, digit recognition, support-vector regression and novelty detection.
Run: python main.py --output results --language en
The digits data are bundled with scikit-learn (UCI optical handwritten digits).
"""
from pathlib import Path
import argparse,json,time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split,GridSearchCV,StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC,SVR,LinearSVC,OneClassSVM
from sklearn.kernel_approximation import Nystroem
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,confusion_matrix


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',default='results');p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args()
    out=Path(a.output);out.mkdir(parents=True,exist_ok=True);zh=a.language=='zh';rng=np.random.default_rng(17)
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
    def save(fig,name):fig.savefig(out/f'{name}-{a.language}.svg',bbox_inches='tight');plt.close(fig)
    X=np.array([[-2,-1],[-2,1],[-1,0],[1,0],[2,-1],[2,1],[-.8,.3]])
    y=np.array([-1,-1,-1,1,1,1,1])
    gx,gy=np.meshgrid(np.linspace(-3,3,180),np.linspace(-2,2,150));grid=np.c_[gx.ravel(),gy.ravel()]
    fig,axs=plt.subplots(1,2,figsize=(11.4,4.5),layout='constrained');margins=[]
    for ax,C in zip(axs,[.1,10.]):
        model=SVC(kernel='linear',C=C).fit(X,y);z=model.decision_function(grid).reshape(gx.shape)
        ax.contourf(gx,gy,z,levels=[-100,0,100],colors=['#d7e9ed','#f5e2cb'])
        ax.contour(gx,gy,z,levels=[-1,0,1],colors='#183845',linestyles=['--','-','--'])
        ax.scatter(X[:,0],X[:,1],c=np.where(y<0,'#167b82','#ca8446'),s=65,edgecolors='white')
        ax.scatter(model.support_vectors_[:,0],model.support_vectors_[:,1],s=165,facecolors='none',edgecolors='#183845',lw=1.4)
        norm=np.linalg.norm(model.coef_);margins.append({'C':C,'w':model.coef_[0].tolist(),'b':float(model.intercept_[0]),'width':float(2/norm),'support_indices':model.support_.tolist()})
        ax.set(title=f'C = {C:g}; '+('间隔宽度 ' if zh else 'margin width ')+f'{2/norm:.2f}',xlabel='x₁',ylabel='x₂',xlim=(-3,3),ylim=(-2,2),aspect='equal')
    save(fig,'margins')
    digits=load_digits();train_idx,test_idx=train_test_split(np.arange(len(digits.target)),test_size=.25,stratify=digits.target,random_state=17)
    Xt,Xs=digits.data[train_idx],digits.data[test_idx];yt,ys=digits.target[train_idx],digits.target[test_idx]
    grid_search=GridSearchCV(make_pipeline(StandardScaler(),SVC(kernel='rbf')),{'svc__C':[.1,1,10,100],'svc__gamma':[.001,.01,.1,1]},cv=StratifiedKFold(3,shuffle=True,random_state=17),n_jobs=1)
    grid_search.fit(Xt,yt)
    models={'Linear SVM':make_pipeline(StandardScaler(),SVC(kernel='linear',C=1)),
            'RBF SVM':grid_search.best_estimator_,
            'Logistic regression':make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=2000)),
            'Nystroem + LinearSVC':make_pipeline(StandardScaler(),Nystroem(gamma=.01,n_components=150,random_state=17),LinearSVC(C=1,dual=False,max_iter=5000))}
    scores={};predictions={}
    for name,model in models.items():
        start=time.perf_counter()
        if name!='RBF SVM':model.fit(Xt,yt)
        pred=model.predict(Xs);predictions[name]=pred
        scores[name]={'test_accuracy':float(accuracy_score(ys,pred)),'prediction_seconds':None,'support_vectors':int(model[-1].support_.size) if hasattr(model[-1],'support_') else None}
        t=time.perf_counter();model.predict(Xs);scores[name]['prediction_seconds']=time.perf_counter()-t
    cv=np.array(grid_search.cv_results_['mean_test_score']).reshape(4,4)
    fig,axs=plt.subplots(1,2,figsize=(11.5,4.8),gridspec_kw={'width_ratios':[1,1.2]},layout='constrained')
    im=axs[0].imshow(cv,vmin=.1,vmax=1,cmap='YlGnBu',aspect='auto');fig.colorbar(im,ax=axs[0],label='CV accuracy')
    axs[0].set(xticks=range(4),xticklabels=['.001','.01','.1','1'],yticks=range(4),yticklabels=['.1','1','10','100'],xlabel='γ',ylabel='C',title='训练集内3折验证' if zh else '3-fold validation inside training data')
    for i in range(4):
        for j in range(4):axs[0].text(j,i,f'{cv[i,j]:.3f}',ha='center',va='center',color='white' if cv[i,j]>.7 else '#183845',fontsize=10)
    cm=confusion_matrix(ys,predictions['RBF SVM']);im=axs[1].imshow(cm,cmap='Blues');fig.colorbar(im,ax=axs[1],label='样本数' if zh else 'Count')
    axs[1].set(xlabel='预测数字' if zh else 'Predicted digit',ylabel='真实数字' if zh else 'True digit',xticks=range(10),yticks=range(10),title='独立测试集：RBF SVM' if zh else 'Held-out test set: RBF SVM')
    save(fig,'validation')
    fig=plt.figure(figsize=(11.4,6.1),layout='constrained');gs=fig.add_gridspec(2,6,height_ratios=[1,1.5]);err=np.flatnonzero(ys!=predictions['RBF SVM']);show=np.r_[err[:6],np.flatnonzero(ys==predictions['RBF SVM'])[:6-len(err[:6])]]
    for j,idx in enumerate(show):
        ax=fig.add_subplot(gs[0,j]);ax.imshow(Xs[idx].reshape(8,8),cmap='gray_r',vmin=0,vmax=16);ax.set_title(f'{ys[idx]} → {predictions["RBF SVM"][idx]}',fontsize=11);ax.axis('off')
    ax=fig.add_subplot(gs[1,:]);names=list(scores);vals=[scores[n]['test_accuracy'] for n in names];ax.barh(names,vals,color=['#6f8191','#167b82','#ca8446','#8b7557']);ax.set(xlim=(0,1.08),xlabel='测试准确率' if zh else 'Test accuracy')
    for i,v in enumerate(vals):ax.text(v+.01,i,f'{v:.3f}',va='center')
    save(fig,'digits')
    x=np.sort(rng.uniform(0,6,80));target=np.sin(x)+rng.normal(0,.12,80);xx=np.linspace(0,6,300)
    fig,axs=plt.subplots(1,2,figsize=(11.5,4.4),layout='constrained');svr=[]
    for ax,eps in zip(axs,[.05,.25]):
        model=SVR(C=10,gamma=.5,epsilon=eps).fit(x[:,None],target);fit=model.predict(xx[:,None])
        ax.fill_between(xx,fit-eps,fit+eps,color='#cfe5e6',label='ε '+('容忍带' if zh else 'tube'));ax.plot(xx,fit,color='#167b82',lw=2);ax.plot(xx,np.sin(xx),'--',color='#6f8191',label='生成函数' if zh else 'Generating function');ax.scatter(x,target,s=20,color='#183845');ax.scatter(x[model.support_],target[model.support_],s=70,facecolors='none',edgecolors='#ca8446');ax.set(xlabel='x',ylabel='y',title=f'ε={eps}; '+('支持向量 ' if zh else 'support vectors ')+str(len(model.support_)));ax.legend(frameon=False,fontsize=9)
        svr.append({'epsilon':eps,'n_support':len(model.support_)})
    save(fig,'svr')
    normal=rng.normal(0,.6,(160,2));new=rng.normal(0,.6,(40,2));outliers=rng.uniform(-3,3,(40,2));novel=make_pipeline(StandardScaler(),OneClassSVM(nu=.1,gamma=.5)).fit(normal)
    xx2,yy2=np.meshgrid(np.linspace(-3,3,140),np.linspace(-3,3,140));zz=novel.decision_function(np.c_[xx2.ravel(),yy2.ravel()]).reshape(xx2.shape)
    fig,ax=plt.subplots(figsize=(7.6,5.8),layout='constrained');ax.contourf(xx2,yy2,zz,levels=[zz.min(),0,zz.max()],colors=['#f7e6d7','#d6e9eb']);ax.contour(xx2,yy2,zz,levels=[0],colors='#183845');ax.scatter(normal[:,0],normal[:,1],s=12,color='#167b82',alpha=.6,label='正常训练样本' if zh else 'Normal training samples');ax.scatter(new[:,0],new[:,1],s=38,facecolors='none',edgecolors='#183845',label='新正常样本' if zh else 'New normal samples');ax.scatter(outliers[:,0],outliers[:,1],s=30,marker='x',color='#b45d3b',label='广域测试样本' if zh else 'Broad-range test samples');ax.set(xlabel='x₁',ylabel='x₂',aspect='equal',title='One-Class SVM');ax.legend(frameon=False,fontsize=9)
    save(fig,'novelty')
    summary={'digits_samples':len(digits.target),'train_samples':len(yt),'test_samples':len(ys),'best_params':grid_search.best_params_,'best_cv_accuracy':float(grid_search.best_score_),'models':scores,'margin_models':margins,'svr':svr,'one_class_normal_acceptance':float((novel.predict(new)==1).mean()),'one_class_broad_rejection':float((novel.predict(outliers)==-1).mean())}
    np.savez_compressed(out/'experiment_data.npz',tiny_X=X,tiny_y=y,train_idx=train_idx,test_idx=test_idx,test_y=ys,rbf_prediction=predictions['RBF SVM'],cv_scores=cv,svr_x=x,svr_y=target)
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))


if __name__=='__main__':main()
