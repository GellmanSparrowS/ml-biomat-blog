"""Daily bicycle demand: an auditable data table and three forecasting baselines.

Run: python main.py --output results --language en
Data: H. Fanaee-T, Bike Sharing, UCI, doi:10.24432/C5W894, CC BY 4.0.
The bundled day.csv has 731 observations of daily rental counts, not fleet size.
"""
from pathlib import Path
import argparse
import json
import hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='results')
    parser.add_argument('--language', choices=['zh', 'en'], default='en')
    args = parser.parse_args()
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    zh = args.language == 'zh'
    plt.rcParams.update({'font.family': ['Microsoft YaHei', 'DejaVu Sans'],
                         'font.size': 11, 'axes.spines.top': False,
                         'axes.spines.right': False, 'svg.fonttype': 'none',
                         'figure.facecolor': 'white', 'axes.titlepad': 12})
    source = Path(__file__).resolve().parent / 'data' / 'day.csv'
    df = pd.read_csv(source, parse_dates=['dteday']).sort_values('dteday')
    assert len(df) == 731 and df['dteday'].is_unique
    assert (df['cnt'] == df['casual'] + df['registered']).all()
    assert not df.isna().any().any()
    # The first 548 days fit two fixed baselines. Every later day is a new forecast.
    cut = 548
    train, test = df.iloc[:cut].copy(), df.iloc[cut:].copy()
    global_mean = float(train['cnt'].mean())
    weekday_means = train.groupby('weekday')['cnt'].mean()
    predictions = pd.DataFrame({'date': test['dteday'], 'observed': test['cnt'],
                                'mean': global_mean,
                                'weekday': test['weekday'].map(weekday_means),
                                'last_week': df['cnt'].shift(7).iloc[cut:]})
    names = {'mean': '训练均值' if zh else 'Training mean',
             'weekday': '星期均值' if zh else 'Weekday mean',
             'last_week': '上周同日' if zh else 'Same day last week'}
    colors = {'mean': '#6f8191', 'weekday': '#ca8446', 'last_week': '#167b82'}
    mae = {k: float(np.mean(np.abs(predictions[k] - predictions.observed))) for k in names}
    medae = {k: float(np.median(np.abs(predictions[k] - predictions.observed))) for k in names}
    summary = {'n_days': len(df), 'train_days': len(train), 'test_days': len(test),
               'split_date': str(test['dteday'].iloc[0].date()), 'missing_cells': 0,
               'unique_dates': int(df.dteday.nunique()), 'identity_max_error': 0,
               'global_mean': global_mean, 'mae_rentals_per_day': mae,
               'median_absolute_error': medae,
               'data_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
    (out / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    predictions.to_csv(out / 'predictions.csv', index=False)
    df[['dteday', 'weekday', 'workingday', 'temp', 'casual', 'registered', 'cnt']].to_csv(out / 'observations.csv', index=False)

    # A linked overview: the same daily records in time and in feature space.
    fig = plt.figure(figsize=(11.5, 7.0), layout='constrained')
    gs = fig.add_gridspec(2, 2, height_ratios=[1.1, 1])
    ax = fig.add_subplot(gs[0, :])
    ax.plot(df.dteday, df.cnt, color='#183845', lw=1.05)
    ax.axvline(test.dteday.iloc[0], color='#a95238', ls='--', lw=1.5,
               label='预测起点' if zh else 'First forecast date')
    ax.set(ylabel='租借次数 / 日' if zh else 'Rentals / day',
           title='每个点都对应一整天的城市租借记录' if zh else 'Each observation represents one day of citywide rentals')
    ax.legend(frameon=False)
    ax = fig.add_subplot(gs[1, 0])
    for year, color in [(0, '#788b98'), (1, '#167b82')]:
        sub = df[df.yr == year]
        ax.scatter(sub.temp, sub.cnt, s=13, alpha=.6, color=color, label=str(2011 + year))
    ax.set(xlabel='归一化温度（无量纲）' if zh else 'Normalized temperature (unitless)',
           ylabel='租借次数 / 日' if zh else 'Rentals / day')
    ax.legend(frameon=False, ncols=2)
    ax = fig.add_subplot(gs[1, 1])
    for year, offset, color in [(0, -.18, '#788b98'), (1, .18, '#167b82')]:
        means = df[df.yr == year].groupby('weekday')['cnt'].mean()
        ax.bar(np.arange(7) + offset, means.reindex(range(7)), width=.34, color=color)
    ax.set(xticks=range(7), xlabel='星期编码（0=星期日）' if zh else 'Weekday code (0 = Sunday)',
           ylabel='平均租借次数 / 日' if zh else 'Mean rentals / day')
    fig.savefig(out / f'observations-{args.language}.svg')
    plt.close(fig)

    fig, axs = plt.subplots(2, 1, figsize=(11.5, 7.4), height_ratios=[1.8, 1], layout='constrained')
    ax = axs[0]
    ax.plot(test.dteday, test.cnt, lw=1.8, color='#183845', label='观测' if zh else 'Observed')
    for k in names:
        ax.plot(test.dteday, predictions[k], lw=1.1, alpha=.85, label=names[k], color=colors[k])
    ax.set(ylabel='租借次数 / 日' if zh else 'Rentals / day',
           title='固定训练窗口；随后183天逐日向前预测' if zh else 'Fixed training window; 183 subsequent one-day-ahead forecasts')
    ax.legend(frameon=False, ncols=2)
    ax = axs[1]
    for i, k in enumerate(names):
        ax.barh(i, mae[k], color=colors[k], height=.48)
        ax.text(mae[k] + 35, i, f'{mae[k]:.1f}', va='center')
    ax.set(yticks=range(3), yticklabels=list(names.values()),
           xlabel='平均绝对误差（租借次数 / 日）' if zh else 'Mean absolute error (rentals / day)',
           xlim=(0, max(mae.values()) * 1.2))
    fig.savefig(out / f'baselines-{args.language}.svg')
    plt.close(fig)

    # Availability is a causal ordering in the workflow, not a correlation score.
    labels = ['星期/节假日', '前7日次数', '全天实测天气', '当日注册租借', '当日临时租借', '当日总次数'] if zh else ['Weekday / holiday', 'Count seven days ago', 'Full-day observed weather', 'Today: registered rentals', 'Today: casual rentals', 'Today: total rentals']
    fig, ax = plt.subplots(figsize=(11.5, 4.5), layout='constrained')
    for i, (label, available) in enumerate(zip(labels, [True, True, False, False, False, False])):
        y = 5-i
        ax.text(-.08, y, label, ha='right', va='center', fontsize=11)
        ax.plot([0, 1], [y, y], color='#d4dfe3', lw=8, solid_capstyle='round')
        x = 0 if available else 1
        ax.scatter([x], [y], s=135, color='#167b82' if available else '#b65b44', zorder=3)
    ax.axvline(.12, color='#183845', lw=1, ls='--')
    ax.text(.12, 5.65, '作出预测' if zh else 'Forecast issued', ha='center', fontsize=11)
    ax.set(xticks=[0,1], xticklabels=['一天开始前','当天结束后'] if zh else ['Before the day starts','After the day ends'],
           xlim=(-.65,1.2), ylim=(-.7,6.0), yticks=[])
    for spine in ax.spines.values(): spine.set_visible(False)
    fig.savefig(out / f'availability-{args.language}.svg')
    plt.close(fig)
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
