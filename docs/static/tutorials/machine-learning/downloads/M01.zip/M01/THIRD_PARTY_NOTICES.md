# Public sources and third-party materials

- Bike Sharing — UCI Machine Learning Repository: https://archive.ics.uci.edu/dataset/275/bike+sharing+dataset
  Dataset: CC BY 4.0; DOI 10.24432/C5W894.
- INRIA: First look at our dataset: https://inria.github.io/scikit-learn-mooc/python_scripts/01_tabular_data_exploration.html
  CC BY 4.0
- Samuel (1959), Some Studies in Machine Learning Using the Game of Checkers: https://www.cs.virginia.edu/~evans/greatworks/samuel1959.pdf
  Reference
- Dive into Deep Learning: Introduction: https://d2l.ai/chapter_introduction/index.html
  CC BY-SA 4.0
