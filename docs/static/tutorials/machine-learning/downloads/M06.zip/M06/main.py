"""Unsupervised structure: actual compression, neighborhoods, density and novelty."""
from pathlib import Path
import argparse,json,os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from scipy.cluster.hierarchy import linkage,dendrogram
from sklearn.datasets import load_digits,make_moons
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans,DBSCAN
from sklearn.mixture import GaussianMixture
from sklearn.manifold import TSNE,trustworthiness
from sklearn.neighbors import NearestNeighbors,LocalOutlierFactor
from sklearn.ensemble import IsolationForest
from sklearn.metrics import adjusted_rand_score,confusion_matrix
from umap import UMAP

COL=['#237b94','#d87430','#609b6d','#a268a6','#c7a22b','#465db0','#b95159','#7f8e37','#6e8290','#d38aab']
def main(out,lang):
 out=Path(out);out.mkdir(parents=True,exist_ok=True);zh=lang=='zh';T=lambda z,e:z if zh else e
 plt.rcParams.update({'font.family':'Microsoft YaHei' if zh else 'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'white','axes.titleweight':'bold','axes.unicode_minus':False})
 rng=np.random.default_rng(6)
 def save(fig,name):fig.savefig(out/f'{name}-{lang}.svg',bbox_inches='tight');plt.close(fig)
 d=load_digits();X=d.data/16;y=d.target;it,ie=train_test_split(np.arange(len(X)),test_size=.25,stratify=y,random_state=6)
 ranks=[2,5,10,20,40,64];errors=[];ratios=[];recons={}
 for k in ranks:
  p=PCA(n_components=k,svd_solver='full').fit(X[it]);rec=p.inverse_transform(p.transform(X[ie]));errors.append(float(np.mean((rec-X[ie])**2)));ratios.append(float(p.explained_variance_ratio_.sum()));recons[k]=rec
 # Every image is reconstructed from a training-only basis; common grayscale limits.
 fig=plt.figure(figsize=(14.2,9.2),layout='constrained')
 outer=fig.add_gridspec(1,2,width_ratios=[1.85,1],wspace=.17)
 gs=outer[0].subgridspec(6,6,hspace=.08,wspace=.06)
 curves=outer[1].subgridspec(2,1,hspace=.20)
 for row,k in enumerate([None,2,5,10,20,40]):
  for c in range(6):
   ax=fig.add_subplot(gs[row,c]);ax.imshow(X[ie[c]].reshape(8,8) if k is None else recons[k][c].reshape(8,8),cmap='gray',vmin=0,vmax=1);ax.set_xticks([]);ax.set_yticks([])
   if c==0:ax.set_ylabel(T('原图','Original') if k is None else f'k={k}',rotation=0,labelpad=27,va='center')
   if row==0:ax.set_title(str(y[ie[c]]))
 ax=fig.add_subplot(curves[0]);ax.plot(ranks,errors,'o-',color=COL[0]);ax.set(xlabel=T('保留分量数','Retained components'),ylabel=T('测试像素均方误差','Test pixel MSE'),title=T('450幅留出图像','450 held-out images'));ax.grid(alpha=.18)
 ax=fig.add_subplot(curves[1]);ax.plot(ranks,ratios,'s-',color=COL[1]);ax.set(xlabel=T('保留分量数','Retained components'),ylabel=T('训练累计方差比例','Training cumulative variance'),ylim=(0,1.05));ax.grid(alpha=.18);save(fig,'compression')
 # Labels are used for display after the unsupervised embeddings are fitted.
 subset=it[:900];A=X[subset];p2=PCA(2,svd_solver='full').fit_transform(A)
 embeddings={'PCA':p2,'t-SNE p=10':TSNE(perplexity=10,random_state=6,max_iter=800,init='pca',learning_rate='auto').fit_transform(A),'t-SNE p=50':TSNE(perplexity=50,random_state=6,max_iter=800,init='pca',learning_rate='auto').fit_transform(A),'UMAP n=15':UMAP(n_neighbors=15,min_dist=.15,random_state=6,n_jobs=1,n_epochs=300).fit_transform(A)}
 def neighbors(data):
  raw=NearestNeighbors(n_neighbors=11).fit(data).kneighbors(data,return_distance=False)
  return np.array([row[row!=i][:10] for i,row in enumerate(raw)])
 nbr=neighbors(A);quality={}
 fig,axs=plt.subplots(2,2,figsize=(12,10),layout='constrained')
 for ax,(name,Z) in zip(axs.flat,embeddings.items()):
  en=neighbors(Z);overlap=float(np.mean([len(set(a)&set(b))/10 for a,b in zip(nbr,en)]));tr=float(trustworthiness(A,Z,n_neighbors=10));quality[name]={'trustworthiness10':tr,'neighbor_overlap10':overlap}
  sc=ax.scatter(Z[:,0],Z[:,1],c=y[subset],s=10,cmap=ListedColormap(COL),vmin=-.5,vmax=9.5,alpha=.8);ax.set(title=f'{name} | T={tr:.3f}, overlap={overlap:.3f}',xlabel=T('嵌入坐标1（任意单位）','Embedding coordinate 1 (arbitrary units)'),ylabel=T('嵌入坐标2','Embedding coordinate 2'));ax.set_xticks([]);ax.set_yticks([])
 cb=fig.colorbar(sc,ax=axs,ticks=range(10),shrink=.75);cb.set_label(T('真实数字标签（拟合未使用）','Digit label (unused during fitting)'));save(fig,'neighborhoods')
 moon,ym=make_moons(500,noise=.07,random_state=6)
 e0=rng.multivariate_normal([-2,0],[[1.2,.7],[.7,.6]],250);e1=rng.multivariate_normal([2,0],[[.6,-.45],[-.45,1.2]],250);ell=np.vstack([e0,e1]);ye=np.repeat([0,1],250);cluster_scores={};fig,axs=plt.subplots(2,3,figsize=(13,8),layout='constrained')
 for row,(name,D,Y) in enumerate([('moons',moon,ym),('ellipses',ell,ye)]):
  for col,(n,model) in enumerate([('k-means',KMeans(2,n_init=20,random_state=6)),('GMM',GaussianMixture(2,n_init=5,random_state=6)),('DBSCAN',DBSCAN(eps=.19 if row==0 else .4,min_samples=8))]):
   labels=model.fit_predict(D);ari=float(adjusted_rand_score(Y,labels));noise=int((labels==-1).sum());cluster_scores[f'{name}/{n}']={'ari':ari,'noise':noise,'clusters':len(set(labels)-{-1})};ax=axs[row,col];colors=[('#acb5bc' if a==-1 else COL[a%len(COL)]) for a in labels];ax.scatter(*D.T,c=colors,s=13,alpha=.8);ax.set(title=f'{n} | ARI={ari:.3f}, noise={noise}',xlabel=T('特征1','Feature 1'),ylabel=T('特征2','Feature 2'));ax.set_aspect('equal',adjustable='datalim')
 save(fig,'cluster_shapes')
 gt,ge=train_test_split(np.arange(500),test_size=.25,random_state=6);gm=GaussianMixture(2,n_init=10,random_state=6).fit(ell[gt]);xx,yy=np.meshgrid(np.linspace(-6,6,180),np.linspace(-4,4,150));grid=np.c_[xx.ravel(),yy.ravel()];density=np.exp(gm.score_samples(grid)).reshape(xx.shape);bics=[];ll=[]
 for k in range(1,6):
  q=GaussianMixture(k,n_init=10,random_state=6).fit(ell[gt]);bics.append(float(q.bic(ell[gt])));ll.append(float(q.score(ell[ge])))
 fig,axs=plt.subplots(1,3,figsize=(15,4.6),layout='constrained');im=axs[0].contourf(xx,yy,density,levels=12,cmap='Blues');axs[0].scatter(*ell[gt].T,s=4,color='#293d4b',alpha=.35);fig.colorbar(im,ax=axs[0],label=T('概率密度','Probability density'));axs[0].set(title=T('GMM：密度不等于组分概率','GMM: density versus membership'),xlabel=T('特征1','Feature 1'),ylabel=T('特征2','Feature 2'))
 axs[1].plot(range(1,6),bics,'o-',color=COL[0]);axs[1].set(xlabel=T('组分数','Components'),ylabel='BIC',title=T('训练拟合与复杂度','Training fit and complexity'));ax2=axs[1].twinx();ax2.plot(range(1,6),ll,'s--',color=COL[1]);ax2.set_ylabel(T('测试平均对数密度','Test mean log density'),color=COL[1]);axs[1].set_xticks(range(1,6))
 small=np.array([[0,0],[.2,.1],[.5,0],[2,0],[2.1,.2],[2.4,0]]);Z=linkage(small,method='complete');dendrogram(Z,labels=list('ABCDEF'),ax=axs[2],color_threshold=1);axs[2].set(ylabel=T('完全连接距离','Complete-link distance'),title=T('六点的逐步合并','Six observations merge'));save(fig,'density_hierarchy')
 # Training and threshold selection see only normal observations.
 train=rng.multivariate_normal([0,0],[[1,.6],[.6,1]],400);cal=rng.multivariate_normal([0,0],[[1,.6],[.6,1]],200);normal=rng.multivariate_normal([0,0],[[1,.6],[.6,1]],200)
 anomaly=rng.normal(loc=[3.3,-3.3],scale=.6,size=(40,2));test=np.vstack([normal,anomaly]);truth=np.r_[np.zeros(200,dtype=int),np.ones(40,dtype=int)];novel={};models=[('Isolation Forest',IsolationForest(n_estimators=150,random_state=6,n_jobs=1)),('LOF novelty',LocalOutlierFactor(n_neighbors=20,novelty=True))]
 fig,axs=plt.subplots(1,3,figsize=(15,4.7),layout='constrained')
 for ax,(name,model) in zip(axs[:2],models):
  model.fit(train);cs=-model.score_samples(cal);score=-model.score_samples(test);threshold=float(np.quantile(cs,.95));pred=(score>threshold).astype(int);tn,fp,fn,tp=confusion_matrix(truth,pred).ravel();novel[name]={'threshold':threshold,'tn':int(tn),'fp':int(fp),'fn':int(fn),'tp':int(tp),'cost_fp1_fn20':int(fp+20*fn)};field=-model.score_samples(grid).reshape(xx.shape);im=ax.contourf(xx,yy,field,levels=16,cmap='YlOrRd');ax.contour(xx,yy,field,levels=[threshold],colors=['#263744'],linewidths=1.5);ax.scatter(*normal.T,s=8,c=COL[0],alpha=.7);ax.scatter(*anomaly.T,s=15,c=COL[2],marker='x');fig.colorbar(im,ax=ax,label=T('异常分数（越大越异常）','Anomaly score (higher is more unusual)'));ax.set(title=f'{name} | FP={fp}, FN={fn}',xlabel=T('特征1','Feature 1'),ylabel=T('特征2','Feature 2'))
  fr=[];rec=[]
  for quantile in np.linspace(.8,.995,40):
   p=score>np.quantile(cs,quantile);fr.append(float(p[:200].mean()));rec.append(float(p[200:].mean()))
  axs[2].plot(fr,rec,'o-',ms=3,label=name)
 axs[2].set(xlabel=T('正常测试样本误报比例','False-positive fraction on normal test data'),ylabel=T('异常测试样本检出比例','Detected fraction of anomalous test data'),ylim=(0,1.05),title=T('阈值改变检查工作量','Thresholds alter review workload'));axs[2].legend(fontsize=9);axs[2].grid(alpha=.2);save(fig,'novelty')
 summary={'digits_n':len(X),'train_n':len(it),'test_n':len(ie),'pixel_features':64,'map_n':len(subset),'pca_ranks':ranks,'pca_test_mse':errors,'pca_train_variance_fraction':ratios,'neighborhoods':quality,'clusters':cluster_scores,'gmm_bic':bics,'gmm_test_mean_log_density':ll,'gmm_best_bic_components':int(np.argmin(bics)+1),'gmm_responsibility_sum_max_error':float(abs(gm.predict_proba(ell[ge]).sum(1)-1).max()),'novelty_train_normal':len(train),'novelty_calibration_normal':len(cal),'novelty_test_normal':len(normal),'novelty_test_anomaly':len(anomaly),'novelty':novel,'hierarchy_final_complete_distance':float(Z[-1,2])}
 np.savez_compressed(out/'experiment_data.npz',digits=X,labels=y,train_indices=it,test_indices=ie,map_indices=subset,moons=moon,moon_labels=ym,ellipses=ell,ellipse_labels=ye,novelty_train=train,novelty_calibration=cal,novelty_test=test,novelty_truth=truth,**{f'map_{j}':v for j,v in enumerate(embeddings.values())});(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();main(a.output,a.language)
