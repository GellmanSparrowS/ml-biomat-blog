# Public sources and third-party materials

- Pearson (1901), On Lines and Planes of Closest Fit: https://zenodo.org/records/1430636
  Reference
- UCI — Optical Recognition of Handwritten Digits: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits
  CC BY 4.0
- scikit-learn — Decomposing signals in components: https://scikit-learn.org/stable/modules/decomposition.html
  BSD-3-Clause
- scikit-learn — Comparing clustering algorithms: https://scikit-learn.org/stable/auto_examples/cluster/plot_cluster_comparison.html
  BSD-3-Clause
- scikit-learn — Gaussian mixture models: https://scikit-learn.org/stable/modules/mixture.html
  BSD-3-Clause
- van der Maaten & Hinton (2008), Visualizing Data using t-SNE: https://www.jmlr.org/papers/v9/vandermaaten08a.html
  Reference
- UMAP — How UMAP Works: https://umap-learn.readthedocs.io/en/latest/how_umap_works.html
  BSD-3-Clause project
- UMAP — Basic Parameters: https://umap-learn.readthedocs.io/en/latest/parameters.html
  BSD-3-Clause project
- scikit-learn — Novelty and Outlier Detection: https://scikit-learn.org/stable/modules/outlier_detection.html
  BSD-3-Clause
