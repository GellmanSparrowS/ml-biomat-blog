# Public sources and third-party materials

- scikit-learn — Cross-validation: https://scikit-learn.org/stable/modules/cross_validation.html
  BSD-3-Clause
- scikit-learn — Model evaluation: https://scikit-learn.org/stable/modules/model_evaluation.html
  BSD-3-Clause
- Cawley & Talbot (2010), Over-fitting in Model Selection: https://www.jmlr.org/papers/volume11/cawley10a/cawley10a.pdf
  Reference
- MIT — Learnability and VC Dimension: https://gradml.mit.edu/supervised/learnability_and_vc/
  Reference
- Columbia — Introduction to PAC Learning: https://www.cs.columbia.edu/~aho/cs3261/Lectures/L22-Introduction_to_PAC_Learning.html
  Reference
