"""Evaluation protocols, thresholds and repeated comparisons on known generators."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split,GroupShuffleSplit,StratifiedKFold,GridSearchCV,cross_val_score,learning_curve
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score,average_precision_score,roc_auc_score,precision_recall_curve,confusion_matrix
from scipy.stats import binomtest

def main(output,language):
 out=Path(output);out.mkdir(parents=True,exist_ok=True);zh=language=='zh';rng=np.random.default_rng(33)
 plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
 def t(z,e):return z if zh else e
 def save(fig,n):fig.savefig(out/f'{n}-{language}.svg',bbox_inches='tight');plt.close(fig)
 # Object identity has no relation to its assigned class, but repeated views reveal identity.
 identities=rng.normal(0,3,(120,8));labels=rng.integers(0,2,120);groups=np.repeat(np.arange(120),6)
 Xg=identities[groups]+rng.normal(0,.12,(720,8));yg=labels[groups];random_scores=[];group_scores=[];split_examples=[]
 for seed in range(20):
  tr,te=train_test_split(np.arange(720),test_size=.25,random_state=seed,stratify=yg)
  gt,ge=next(GroupShuffleSplit(n_splits=1,test_size=.25,random_state=seed).split(Xg,yg,groups))
  for dest,a,b in [(random_scores,tr,te),(group_scores,gt,ge)]:
   m=make_pipeline(StandardScaler(),KNeighborsClassifier(n_neighbors=1));m.fit(Xg[a],yg[a]);dest.append(accuracy_score(yg[b],m.predict(Xg[b])))
  if seed==0:split_examples=[te,ge]
 fig=plt.figure(figsize=(11,5),layout='constrained');gs=fig.add_gridspec(1,2,width_ratios=[1.3,1]);ax=fig.add_subplot(gs[0,0]);matrix=np.zeros((4,72));
 for k,idx in enumerate(split_examples):
  matrix[k*2]=np.isin(np.arange(72),idx);matrix[k*2+1]=np.isin(groups[:72],groups[idx])
 ax.imshow(matrix,aspect='auto',cmap='Blues',vmin=0,vmax=1);ax.set_yticks(range(4),[t('随机：测试行','Random: test rows'),t('随机：测试对象的全部行','Random: rows of test objects'),t('分组：测试行','Grouped: test rows'),t('分组：测试对象的全部行','Grouped: rows of test objects')]);ax.set(xlabel=t('前12个对象，每个6行','First 12 objects, six rows each'));ax.set_xticks(np.arange(2.5,72,6),np.arange(12));
 for x in np.arange(5.5,72,6):ax.axvline(x,color='white',lw=1)
 ax=fig.add_subplot(gs[0,1]);ax.boxplot([random_scores,group_scores],tick_labels=[t('随机行','Random rows'),t('新对象','New objects')],showmeans=True);ax.set(ylim=(0,1.05),ylabel=t('测试准确率','Test accuracy'));ax.grid(axis='y',alpha=.2);save(fig,'splits')
 # A distinct independent-row rare-event classification experiment.
 X,y=make_classification(n_samples=2400,n_features=12,n_informative=5,n_redundant=2,weights=[.94,.06],flip_y=.01,class_sep=1.,random_state=33)
 idx=np.arange(len(y));tr,tmp=train_test_split(idx,test_size=.4,stratify=y,random_state=33);va,te=train_test_split(tmp,test_size=.5,stratify=y[tmp],random_state=33)
 model=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=1000));model.fit(X[tr],y[tr]);pv=model.predict_proba(X[va])[:,1];pt=model.predict_proba(X[te])[:,1]
 thresholds=np.linspace(0,1,201);fn_cost=10
 def counts(a,b,q):tn,fp,fn,tp=confusion_matrix(a,b>=q,labels=[0,1]).ravel();return {'tn':int(tn),'fp':int(fp),'fn':int(fn),'tp':int(tp),'cost':int(fp+fn_cost*fn)}
 costs=[counts(y[va],pv,q)['cost'] for q in thresholds];qstar=float(thresholds[np.argmin(costs)]);test_default=counts(y[te],pt,.5);test_selected=counts(y[te],pt,qstar)
 precision,recall,_=precision_recall_curve(y[te],pt)
 fig,axs=plt.subplots(1,3,figsize=(12,3.8),layout='constrained');axs[0].hist([pt[y[te]==0],pt[y[te]==1]],bins=np.linspace(0,1,21),stacked=True,color=['#167d87','#d48745'],label=['0','1']);axs[0].axvline(qstar,color='#523e67',ls='--');axs[0].set(xlabel=t('测试预测概率','Test predicted probability'),ylabel=t('样本数','Observations'));axs[0].legend(title=t('真实类别','True class'))
 axs[1].plot(thresholds,costs,color='#167d87');axs[1].axvline(qstar,color='#d48745',ls='--');axs[1].set(xlabel=t('候选阈值','Candidate threshold'),ylabel=t('验证集成本：FP+10FN','Validation cost: FP+10FN'))
 axs[2].plot(recall,precision,color='#167d87');axs[2].axhline(y[te].mean(),ls='--',color='#9aabb4');axs[2].set(xlabel=t('召回率','Recall'),ylabel=t('精确率','Precision'),xlim=(0,1),ylim=(0,1.02));save(fig,'threshold')
 # Nested tuning estimates the entire selection procedure on training data only.
 inner=StratifiedKFold(3,shuffle=True,random_state=34);outer=StratifiedKFold(4,shuffle=True,random_state=35)
 search=GridSearchCV(make_pipeline(StandardScaler(),LogisticRegression(max_iter=1000)),{'logisticregression__C':[.01,.1,1,10]},cv=inner,scoring='average_precision',n_jobs=1)
 nested=cross_val_score(search,X[tr],y[tr],cv=outer,scoring='average_precision');search.fit(X[tr],y[tr])
 sizes=np.array([.15,.3,.5,.75,1]);curves={};fig,axs=plt.subplots(1,2,figsize=(11,4),layout='constrained')
 for ax,(name,est) in zip(axs,[('Logistic',make_pipeline(StandardScaler(),LogisticRegression(max_iter=1000))),('Tree',DecisionTreeClassifier(random_state=33))]):
  ns,train,valid=learning_curve(est,X[tr],y[tr],cv=inner,train_sizes=sizes,scoring='average_precision',shuffle=True,random_state=33,n_jobs=1)
  for vals,label,col in [(train,t('训练','Train'),'#d48745'),(valid,t('验证','Validation'),'#167d87')]:
   ax.plot(ns,vals.mean(1),'o-',label=label,color=col);ax.fill_between(ns,vals.mean(1)-vals.std(1),vals.mean(1)+vals.std(1),alpha=.15,color=col)
  ax.set(title=name,xlabel=t('每折训练样本数','Training observations per fold'),ylabel=t('平均精确率 AP','Average precision'),ylim=(0,1.02));ax.legend();curves[name]={'sizes':ns.tolist(),'train':train.tolist(),'validation':valid.tolist()}
 save(fig,'learning')
 # Paired test-object bootstrap, conditional on the fitted models.
 ablated=make_pipeline(StandardScaler(),LogisticRegression(C=1,max_iter=1000));ablated.fit(X[tr,:3],y[tr]);pa=ablated.predict_proba(X[te,:3])[:,1]
 full_loss=(pt-y[te])**2;abl_loss=(pa-y[te])**2;dif=abl_loss-full_loss;boot=[]
 for _ in range(2000):b=rng.integers(0,len(te),len(te));boot.append(dif[b].mean())
 ci=np.quantile(boot,[.025,.975]);b=int(np.sum((pt>=.5)==y[te]) - np.sum(((pt>=.5)==y[te])&((pa>=.5)==y[te])))
 c=int(np.sum((pa>=.5)==y[te]) - np.sum(((pt>=.5)==y[te])&((pa>=.5)==y[te])))
 pvalue=float(binomtest(b,b+c,.5).pvalue) if b+c else 1.
 rawp=np.array([.001,.018,.04,.3]);order=np.argsort(rawp);adj_sorted=np.maximum.accumulate(rawp[order]*(len(rawp)-np.arange(len(rawp))));holm=np.empty_like(rawp);holm[order]=np.minimum(adj_sorted,1)
 fig,axs=plt.subplots(1,2,figsize=(11,3.8),layout='constrained');axs[0].hist(boot,bins=35,color='#167d87',alpha=.85);axs[0].axvline(0,color='#6a7783',ls='--');axs[0].axvline(ci[0],color='#d48745');axs[0].axvline(ci[1],color='#d48745');axs[0].set(xlabel=t('删减模型−完整模型：Brier差','Reduced minus full model: Brier difference'),ylabel=t('重抽样次数','Bootstrap replicates'))
 axs[1].plot(np.arange(1,5),rawp,'o-',label=t('原始p值（教学示例）','Raw p-values (illustration)'),color='#167d87');axs[1].plot(np.arange(1,5),holm,'s-',label='Holm',color='#d48745');axs[1].axhline(.05,color='#6a7783',ls='--');axs[1].set(xlabel=t('检验编号','Test index'),ylabel='p',xticks=[1,2,3,4],ylim=(0,.35));axs[1].legend();save(fig,'uncertainty')
 summary={'group_random_accuracy_mean':float(np.mean(random_scores)),'group_heldout_accuracy_mean':float(np.mean(group_scores)),'train_n':len(tr),'validation_n':len(va),'test_n':len(te),'test_positive_n':int(y[te].sum()),'threshold':qstar,'default':test_default,'selected':test_selected,'always_negative_accuracy':float(1-y[te].mean()),'test_roc_auc':float(roc_auc_score(y[te],pt)),'test_average_precision':float(average_precision_score(y[te],pt)),'nested_average_precision':nested.tolist(),'best_inner_ap':float(search.best_score_),'brier_difference':float(dif.mean()),'brier_bootstrap95':ci.tolist(),'mcnemar_discordant':[b,c],'mcnemar_exact_p':pvalue,'holm_p':holm.tolist(),'learning_curves':curves}
 (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');np.savez(out/'experiment_data.npz',X=X,y=y,train=tr,validation=va,test=te,probability=pt,ablated_probability=pa,group_X=Xg,group_y=yg,groups=groups,bootstrap=np.array(boot))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--language',choices=['zh','en'],default='en');a=ap.parse_args();main(a.output,a.language)
