"""Actual AE, denoising AE, beta-VAE, and conditional VAE on bundled digits."""
from pathlib import Path
import argparse,copy,json,platform
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True)
zh=args.language=='zh'
def tr(z,e):return z if zh else e
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','svg.fonttype':'none','axes.titleweight':'bold'})
def save(fig,name):fig.savefig(out/f'{name}-{args.language}.svg',bbox_inches='tight');plt.close(fig)
d=load_digits();x=(d.data/16).astype('float32');y=d.target
train,other=train_test_split(np.arange(len(y)),test_size=720,random_state=330,stratify=y)
val,test=train_test_split(other,test_size=360,random_state=331,stratify=y[other])
xt,xv,xe=[torch.tensor(x[i]) for i in [train,val,test]];yt,yv,ye=[torch.tensor(y[i]) for i in [train,val,test]]
class AE(nn.Module):
 def __init__(self,latent):
  super().__init__();self.encoder=nn.Sequential(nn.Linear(64,64),nn.ReLU(),nn.Linear(64,latent));self.decoder=nn.Sequential(nn.Linear(latent,64),nn.ReLU(),nn.Linear(64,64),nn.Sigmoid())
 def forward(self,x):return self.decoder(self.encoder(x))
class VAE(nn.Module):
 def __init__(self,conditional=False):
  super().__init__();self.conditional=conditional;c=10 if conditional else 0
  self.encoder=nn.Sequential(nn.Linear(64+c,64),nn.ReLU());self.mu=nn.Linear(64,2);self.logvar=nn.Linear(64,2)
  self.decoder=nn.Sequential(nn.Linear(2+c,64),nn.ReLU(),nn.Linear(64,64),nn.Sigmoid())
 def condition(self,v,y):return torch.cat([v,F.one_hot(y,10).float()],1) if self.conditional else v
 def encode(self,x,y):
  h=self.encoder(self.condition(x,y));return self.mu(h),self.logvar(h)
 def decode(self,z,y):return self.decoder(self.condition(z,y))
 def forward(self,x,y,eps):
  mu,lv=self.encode(x,y);z=mu+torch.exp(.5*lv)*eps;return self.decode(z,y),mu,lv
def kl(mu,lv):return .5*(mu.square()+lv.exp()-1-lv).sum(1)
sigma=.25;models={};histories={};metrics={}
noisegen=torch.Generator().manual_seed(332)
noisy_test=(xe+.25*torch.randn(xe.shape,generator=noisegen)).clamp(0,1)
fixed_val_noise=(xv+.25*torch.randn(xv.shape,generator=noisegen)).clamp(0,1)
for name,latent,denoise in [('ae2',2,False),('ae8',8,False),('denoise8',8,True)]:
 torch.manual_seed(333);model=AE(latent);opt=torch.optim.Adam(model.parameters(),lr=.003);gen=torch.Generator().manual_seed(334);best=1e9;history=[]
 for epoch in range(100):
  model.train()
  for ids in torch.randperm(len(xt),generator=gen).split(64):
   inp=xt[ids]
   if denoise:inp=(inp+.25*torch.randn(inp.shape,generator=gen)).clamp(0,1)
   loss=F.mse_loss(model(inp),xt[ids]);opt.zero_grad();loss.backward();opt.step()
  model.eval()
  with torch.no_grad():vl=F.mse_loss(model(fixed_val_noise if denoise else xv),xv).item()
  history.append(vl)
  if vl<best:best=vl;beststate=copy.deepcopy(model.state_dict());bestepoch=epoch+1
 model.load_state_dict(beststate);models[name]=model;histories[name]=history
 with torch.no_grad():metrics[name]=dict(clean_mse=F.mse_loss(model(xe),xe).item(),noisy_mse=F.mse_loss(model(noisy_test),xe).item(),best_epoch=bestepoch,parameters=sum(p.numel() for p in model.parameters()))
for name,beta,condition in [('vae02',.2,False),('vae1',1.,False),('vae4',4.,False),('conditional',1.,True)]:
 torch.manual_seed(335);model=VAE(condition);opt=torch.optim.Adam(model.parameters(),lr=.003);gen=torch.Generator().manual_seed(336);history=[];best=1e9
 vg=torch.Generator().manual_seed(337);valeps=torch.randn((8,len(xv),2),generator=vg)
 for epoch in range(100):
  model.train()
  for ids in torch.randperm(len(xt),generator=gen).split(64):
   recon,mu,lv=model(xt[ids],yt[ids],torch.randn((len(ids),2),generator=gen))
   distortion=(recon-xt[ids]).square().sum(1)/(2*sigma*sigma)
   loss=(distortion+beta*kl(mu,lv)).mean();opt.zero_grad();loss.backward();opt.step()
  model.eval()
  with torch.no_grad():
   mu,lv=model.encode(xv,yv);pred=torch.stack([model.decode(mu+(.5*lv).exp()*eps,yv) for eps in valeps]);dist=(pred-xv).square().sum(2).mean(0)/(2*sigma*sigma);vl=(dist+beta*kl(mu,lv)).mean().item()
  history.append(vl)
  if vl<best:best=vl;beststate=copy.deepcopy(model.state_dict());bestepoch=epoch+1
 model.load_state_dict(beststate);models[name]=model;histories[name]=history
 with torch.no_grad():
  mu,lv=model.encode(xe,ye);meanrec=model.decode(mu,ye)
  eg=torch.Generator().manual_seed(338);eps=torch.randn((32,len(xe),2),generator=eg)
  pred=torch.stack([model.decode(mu+(.5*lv).exp()*e,ye) for e in eps]);expectedmse=(pred-xe).square().mean().item();k=kl(mu,lv).mean().item()
  constant=64*.5*np.log(2*np.pi*sigma*sigma)
  metrics[name]=dict(beta=beta,mean_reconstruction_mse=F.mse_loss(meanrec,xe).item(),sampled_reconstruction_mse=expectedmse,kl_nats=k,negative_elbo_nats=expectedmse*64/(2*sigma*sigma)+constant+k,mu_variance=mu.var(0,unbiased=False).tolist(),best_epoch=bestepoch,parameters=sum(p.numel() for p in model.parameters()))
for name,model in models.items():torch.save(model.state_dict(),out/f'{name}.pt')
chosen=np.array([np.flatnonzero(y[test]==k)[0] for k in range(10)])
with torch.no_grad():
 mu,lv=models['vae1'].encode(xe,ye);vae_rec=models['vae1'].decode(mu,ye)
 rows=[xe[chosen],models['ae2'](xe[chosen]),models['ae8'](xe[chosen]),vae_rec[chosen],noisy_test[chosen],models['denoise8'](noisy_test[chosen])]
fig,axs=plt.subplots(6,10,figsize=(13,8.6),gridspec_kw={'wspace':.04,'hspace':.2})
labels=tr(['原图','AE：2维','AE：8维','VAE：均值重建','含噪输入','去噪AE：8维'],['Original','AE: 2D','AE: 8D','VAE: mean code','Noisy input','Denoising AE: 8D'])
for r,row in enumerate(rows):
 for c,img in enumerate(row):
  axs[r,c].imshow(img.reshape(8,8),cmap='gray_r',vmin=0,vmax=1);axs[r,c].set_xticks([]);axs[r,c].set_yticks([])
  if r==0:axs[r,c].set_title(str(c))
 axs[r,0].set_ylabel(labels[r],fontsize=10)
fig.suptitle(tr('同一测试图：容量、随机潜变量与去噪目标','The same test images: capacity, stochastic codes, and denoising'),y=.97);save(fig,'reconstruction')
with torch.no_grad():
 az=models['ae2'].encoder(xe).numpy();vz=mu.numpy();vg=np.linspace(-2.5,2.5,11)
 grid=np.array([[a,b] for b in vg[::-1] for a in vg],dtype='float32');decoded=models['vae1'].decode(torch.tensor(grid),torch.zeros(len(grid),dtype=torch.long)).numpy()
mosaic=np.zeros((88,88))
for i,img in enumerate(decoded):mosaic[(i//11)*8:(i//11+1)*8,(i%11)*8:(i%11+1)*8]=img.reshape(8,8)
fig=plt.figure(figsize=(13,7));gs=fig.add_gridspec(2,2,width_ratios=[1,1.2],hspace=.5,wspace=.32)
for i,(arr,title) in enumerate([(az,tr('A  AE 的确定性坐标','A  Deterministic AE coordinates')),(vz,tr('B  VAE 的编码均值','B  VAE encoder means'))]):
 ax=fig.add_subplot(gs[i,0]);sc=ax.scatter(arr[:,0],arr[:,1],c=y[test],cmap='tab10',s=9,alpha=.7);ax.set(xlabel=r'$z_1$' if i==0 else r'$\mu_1$',ylabel=r'$z_2$' if i==0 else r'$\mu_2$',title=title)
 fig.colorbar(sc,ax=ax,ticks=range(10),fraction=.04,pad=.03,label=tr('数字','Digit'))
 if i==1:
  ax.set_aspect('equal',adjustable='box')
  for radius in [1,2]:ax.add_patch(plt.Circle((0,0),radius,fill=False,color='#6c767c',ls='--',lw=.8))
ax=fig.add_subplot(gs[:,1]);ax.imshow(mosaic,cmap='gray_r',vmin=0,vmax=1,extent=[-2.75,2.75,-2.75,2.75]);ax.set(xlabel=r'$z_1$',ylabel=r'$z_2$',title=tr('C  β=1：解码均值图册，网格间距 0.5','C  β=1 decoder-mean atlas; grid spacing 0.5'));save(fig,'latent')
fig,(ax,bar)=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
colors=['#125f82','#b85d30','#658248']
for name,color in zip(['vae02','vae1','vae4'],colors):
 m=metrics[name];ax.scatter(m['kl_nats'],m['sampled_reconstruction_mse'],s=110,color=color);ax.annotate('β='+str(m['beta']),(m['kl_nats'],m['sampled_reconstruction_mse']),xytext=(8,7),textcoords='offset points',fontsize=11)
ax.set(xlabel=tr('平均 KL / nats 每图','Mean KL / nats per image'),ylabel=tr('采样重建均方误差 / 像素','Sampled reconstruction MSE / pixel'),title=tr('A  信息约束与重建的实际取舍','A  Measured information–distortion tradeoff'));ax.margins(.25)
names=['ae8','denoise8'];xx=np.arange(2);bar.bar(xx-.17,[metrics[n]['clean_mse'] for n in names],.34,color='#125f82',label=tr('干净输入','Clean input'));bar.bar(xx+.17,[metrics[n]['noisy_mse'] for n in names],.34,color='#b85d30',label=tr('含噪输入','Noisy input'));bar.set_xticks(xx,[tr('普通 AE','Ordinary AE'),tr('去噪 AE','Denoising AE')]);bar.set(ylabel=tr('对干净图的均方误差 / 像素','MSE against clean images / pixel'),title=tr('B  相同8维瓶颈，不同训练目标','B  Same 8D bottleneck, different objectives'));bar.legend();save(fig,'tradeoff')
gen=torch.Generator().manual_seed(339);prior=torch.randn((60,2),generator=gen)
with torch.no_grad():
 samples=models['vae1'].decode(prior,torch.zeros(60,dtype=torch.long)).numpy()
 positions=torch.tensor([[-1.,0.],[0.,0.],[1.,0.]])
 cond=np.stack([models['conditional'].decode(positions,torch.full((3,),k)).numpy() for k in range(10)])
fig=plt.figure(figsize=(13,8));gs=fig.add_gridspec(2,1,height_ratios=[1,1.2],hspace=.32)
top=gs[0].subgridspec(3,10,wspace=.03,hspace=.06)
for k in range(10):
 for j in range(3):
  ax=fig.add_subplot(top[j,k]);ax.imshow(cond[k,j].reshape(8,8),cmap='gray_r',vmin=0,vmax=1);ax.set_xticks([]);ax.set_yticks([])
  if j==0:ax.set_title('c='+str(k))
  if k==0:ax.set_ylabel(f'z1={j-1}, z2=0',fontsize=9)
bottom=gs[1].subgridspec(5,12,wspace=.03,hspace=.06)
for i,img in enumerate(samples):
 ax=fig.add_subplot(bottom[i//12,i%12]);ax.imshow(img.reshape(8,8),cmap='gray_r',vmin=0,vmax=1);ax.set_xticks([]);ax.set_yticks([])
 if i==0:ax.set_title(tr('无条件先验抽样','Unconditional prior draws'),loc='left',fontsize=11)
fig.suptitle(tr('条件控制与随机变化：显示解码分布均值','Conditional control and random variation: decoder means'),y=.98);save(fig,'generation')
with torch.no_grad():
 means=models['vae1'].encode(xt,yt)[0].numpy()
 probes={str(pair):models['vae1'].decode(torch.tensor([pair],dtype=torch.float32),torch.tensor([0]))[0].tolist() for pair in [[0,0],[1,-1],[-2,2]]}
weights={k:v.detach().numpy().tolist() for k,v in models['vae1'].decoder.state_dict().items()}
(out/'decoder.json').write_text(json.dumps(dict(weights=weights,means=means[::7].tolist(),labels=y[train][::7].tolist(),probes=probes)),encoding='utf-8')
mu_hand=torch.tensor([.5],dtype=torch.float64,requires_grad=True);lv_hand=torch.tensor([np.log(.25)],dtype=torch.float64,requires_grad=True);eps_hand=torch.tensor([-.4],dtype=torch.float64);z_hand=mu_hand+(.5*lv_hand).exp()*eps_hand
grad_mu,grad_lv=torch.autograd.grad(z_hand.sum(),[mu_hand,lv_hand]);kl_hand=kl(mu_hand.reshape(1,1),lv_hand.reshape(1,1)).item()
summary=dict(versions=dict(python=platform.python_version(),torch=torch.__version__,numpy=np.__version__),splits=dict(train=len(train),validation=len(val),test=len(test)),seed=330,epochs=100,sigma=sigma,metrics=metrics,
 hand=dict(z=z_hand.item(),dz_dmu=grad_mu.item(),dz_dlogvar=grad_lv.item(),kl=kl_hand,normal_constant_per_image=float(64*.5*np.log(2*np.pi*sigma*sigma))),
 decoder_checks={str(k):dict(sum=float(np.sum(v)),pixel0=v[0]) for k,v in probes.items()})
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
np.savez_compressed(out/'experiment.npz',train_indices=train,val_indices=val,test_indices=test,chosen_test_indices=chosen,reconstruction=np.stack([r.numpy() for r in rows]),ae_latents=az,vae_means=vz,grid=grid,decoded=decoded,prior=prior.numpy(),samples=samples,conditional=cond,**{n+'_history':h for n,h in histories.items()})
print(json.dumps(summary,ensure_ascii=False,indent=2))
