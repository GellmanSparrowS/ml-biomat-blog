# Public sources and third-party materials

- Auto-Encoding Variational Bayes: https://arxiv.org/html/1312.6114v11
  Primary paper; no figure copied
- UvA Tutorial 9: Deep Autoencoders: https://uvadlc-notebooks.readthedocs.io/en/latest/tutorial_notebooks/tutorial9/AE_CIFAR10.html
  MIT; copyright 2020 Phillip Lippe; license included
- PyTorch examples: VAE: https://github.com/pytorch/examples/tree/main/vae
  BSD-3-Clause code; independent teaching implementation
- Understanding disentangling in beta-VAE: https://arxiv.org/abs/1804.03599
  Primary paper; no figure copied
- Learning Structured Output Representation using Deep Conditional Generative Models: https://proceedings.neurips.cc/paper/2015/hash/8d55a249e6baa5c06772297520da2051-Abstract.html
  Primary paper; no figure copied
- UCI Optical Recognition of Handwritten Digits: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits
  CC BY 4.0; E. Alpaydin and C. Kaynak
