"""9.8.2: conformations, correlated observations and grouped AI evaluation."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

output = Path("statistics_outputs")
output.mkdir(exist_ok=True)
rng = np.random.default_rng(20261023)

# 1. 独立生成2000条三维等长珠链：每条32段，每段1 nm。
# 正态向量归一化后，方向均匀分布在球面上。
directions = rng.normal(size=(2000, 32, 3))
directions /= np.linalg.norm(directions, axis=2, keepdims=True)
positions = np.concatenate([np.zeros((2000, 1, 3)),
                            np.cumsum(directions, axis=1)], axis=1)
end_vectors = positions[:, -1, :]
distances = np.linalg.norm(end_vectors, axis=1)
print("链的平均端到端距离 / nm:", round(distances.mean(), 4))
print("平均端到端向量 / nm:", end_vectors.mean(axis=0).round(4))

# 2. 用标量随机序列隔离相关性的影响。
# z代表一个观测量相对均值的偏离；phi决定前一帧的影响保留多少。
# 这是统计教学模型，步号没有映射为真实分子的物理时间。
mu, sigma, n, repetitions = 4.0, 0.7, 400, 2000
def correlated_series(phi, repeats, frames):
    z = np.empty((repeats, frames))
    z[:, 0] = rng.normal(0, sigma, repeats)
    scale = sigma*np.sqrt(1-phi**2)
    for t in range(1, frames):
        z[:, t] = phi*z[:, t-1] + rng.normal(0, scale, repeats)
    return mu+z

def exact_mean_se(phi, frames):
    lag = np.arange(1, frames)
    inflation = 1 + 2*np.sum((1-lag/frames)*phi**lag)
    return sigma*np.sqrt(inflation/frames)

independent = correlated_series(0.0, repetitions, n)
correlated = correlated_series(0.95, repetitions, n)
summary = {}
for label, values, phi in [("independent", independent, 0.0),
                            ("correlated", correlated, 0.95)]:
    mean_sd = values.mean(axis=1).std(ddof=1)
    naive_se = np.mean(values.std(axis=1, ddof=1)/np.sqrt(n))
    summary[label] = dict(mean_sd=float(mean_sd), naive_se=float(naive_se),
                          exact_se=float(exact_mean_se(phi, n)))
    print(label, "重复实验均值的标准差:", round(mean_sd, 4),
          "逐帧独立公式给出的SE:", round(naive_se, 4))

# 3. 给120个虚拟样品各保存12帧。样品指纹在帧间保留。
# A/B标签按样品随机分配，构造一个“新样品上无可学规律”的对照。
groups = np.repeat(np.arange(120), 12)
centers = rng.normal(size=(120, 8))
features = centers[groups] + rng.normal(0, .025, (len(groups), 8))
sample_labels = np.repeat([0, 1], 60)
rng.shuffle(sample_labels)
labels = sample_labels[groups]
row_test = np.zeros(len(groups), dtype=bool)
row_test[rng.permutation(len(groups))[:360]] = True
heldout = rng.permutation(120)[:30]
group_test = np.isin(groups, heldout)

def nearest_neighbor(test):
    train = ~test
    # 缩放参数只从训练记录估计；测试记录使用同一套参数。
    center = features[train].mean(axis=0)
    scale = features[train].std(axis=0)
    a = (features[test]-center)/scale
    b = (features[train]-center)/scale
    squared = (a*a).sum(axis=1)[:, None] + (b*b).sum(axis=1)[None, :] - 2*a@b.T
    prediction = labels[train][np.argmin(squared, axis=1)]
    return prediction, float(np.mean(prediction == labels[test]))

scores = {}
for name, test in [("row", row_test), ("group", group_test)]:
    prediction, accuracy = nearest_neighbor(test)
    train_groups, test_groups = set(groups[~test]), set(groups[test])
    scores[name] = dict(accuracy=accuracy,
                       overlapping_groups=len(train_groups & test_groups),
                       test_rows=int(test.sum()), test_groups=len(test_groups))
    print(name, "准确率:", round(accuracy, 4),
          "两侧共有样品数:", scores[name]["overlapping_groups"])
assert scores["group"]["overlapping_groups"] == 0

# 4. 所有图表由上面的同一批数据生成，保存为SVG与PNG。
available = {f.name for f in font_manager.fontManager.ttflist}
font = next((s for s in ["Microsoft YaHei", "Noto Sans CJK SC", "SimHei"]
             if s in available), "DejaVu Sans")
plt.rcParams.update({"font.family": font, "font.size": 13,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#82968e", "text.color": "#203b39",
    "axes.labelcolor": "#203b39", "axes.unicode_minus": False,
    "svg.fonttype": "path", "svg.hashsalt": "ai4s-statistics-20261023"})
green, orange, blue = "#00796f", "#b46b36", "#6170a4"
panels = ["conformations", "trajectory", "means", "precision", "split_row", "split_group"]
def draw(ax, name):
    ax.grid(color="#e4eae6", zorder=0, linewidth=.7)
    if name == "conformations":
        ax.hist(distances, bins=np.linspace(0, 15, 31), density=True,
                color=green, alpha=.75, edgecolor="white", zorder=2)
        ax.axvline(distances.mean(), color=orange, lw=2, label="平均距离")
        ax.set(xlabel="端到端距离 R / nm", ylabel="概率密度 / 每nm", xlim=(0, 15))
        ax.set_title("同一链模型的2000幅构象", loc="left", pad=13, fontsize=14)
        ax.legend(frameon=False, fontsize=11)
    elif name == "trajectory":
        ax.plot(independent[0], color=green, alpha=.6, lw=1, label="相邻帧独立")
        ax.plot(correlated[0], color=orange, lw=1.6, label="相关系数 φ = 0.95")
        ax.axhline(mu, color="#777777", ls="--", lw=1)
        ax.set(xlabel="记录步号", ylabel="示意观测量 X / nm", xlim=(0, n), ylim=(1.4, 6.6))
        ax.set_title("同样400帧，不同的信息重复程度", loc="left", pad=13, fontsize=14)
        ax.legend(frameon=False, fontsize=10, loc="upper right")
    elif name == "means":
        bins=np.linspace(3.2, 4.8, 45)
        ax.hist(correlated.mean(axis=1), bins=bins, density=True, color=orange, alpha=.6, label="相关序列")
        ax.hist(independent.mean(axis=1), bins=bins, density=True, color=green, alpha=.65, label="独立序列")
        ax.axvline(mu, color="#324e45", ls="--", lw=1.2)
        ax.set(xlabel="一次实验的平均值 / nm", ylabel="概率密度 / 每nm", xlim=(3.2, 4.8))
        ax.set_title("重复2000次，平均值会怎样波动", loc="left", pad=13, fontsize=14)
        ax.legend(frameon=False, fontsize=11)
    elif name == "precision":
        counts=np.unique(np.logspace(1.3, 3.6, 80).astype(int))
        for phi, color, label in [(0, green, "独立帧"), (.95, orange, "φ = 0.95")]:
            ax.loglog(counts, [exact_mean_se(phi, int(m)) for m in counts],
                      lw=2.4, color=color, label=label)
        for count in [100, 400]:
            value=exact_mean_se(0, count)
            ax.scatter(count,value,color=green,zorder=4)
            ax.annotate(f"{count}帧 / {value:.3f}", (count,value),
                        xytext=(6,7), textcoords="offset points",fontsize=10)
        ax.set(xlabel="记录帧数 n", ylabel="平均值的标准误差 / nm")
        ax.set_title("先考虑相关性，再计算精度", loc="left", pad=13, fontsize=14)
        ax.legend(frameon=False, fontsize=11)
    else:
        test=row_test if name=="split_row" else group_test
        for mask,color,label in [(~test,green,"训练记录"),(test,orange,"测试记录")]:
            ax.scatter(features[mask,0],features[mask,1],s=11,c=color,alpha=.65,label=label)
        key="row" if name=="split_row" else "group"
        title="逐帧随机划分" if key=="row" else "整份样品留出"
        ax.set_title(title+f"：准确率 {100*scores[key]['accuracy']:.1f}%",loc="left",pad=13,fontsize=14)
        ax.set(xlabel="指纹特征1（无量纲）",ylabel="指纹特征2（无量纲）",
               xlim=(-3.5,3.5),ylim=(-3.5,3.5))
        ax.legend(frameon=False,fontsize=10,loc="upper left")

for name in panels:
    fig,ax=plt.subplots(figsize=(5.2,4.5),layout="constrained")
    draw(ax,name)
    fig.savefig(output/f"{name}.svg",metadata={"Date":None})
    fig.savefig(output/f"{name}.png",dpi=180)
    plt.close(fig)
fig,axes=plt.subplots(2,3,figsize=(16.2,10),layout="constrained")
for ax,name in zip(axes.flat,panels):draw(ax,name)
fig.suptitle("从构象分布到可信的AI评价\n独立构象与相关序列为不同的教学模型",fontsize=20)
fig.savefig(output/"statistics_diagnostics.svg",metadata={"Date":None})
fig.savefig(output/"statistics_diagnostics.png",dpi=220)
plt.close(fig)

# 记录数值、模型条件及少量构象，供网页交互和复核使用。
payload={"seed":20261023,"n_chains":2000,"segments":32,"bond_nm":1,
    "mean_R":float(distances.mean()),"rms_R":float(np.sqrt(np.mean(distances**2))),
    "mean_vector":end_vectors.mean(axis=0).tolist(),"std_R":float(distances.std(ddof=1)),
    "photos":positions[:24].round(7).tolist(),"distances":distances.tolist(),
    "mean_model":{"mu":mu,"sigma":sigma,"n":n,"phi":.95,"repetitions":repetitions},
    "summary":summary,"scores":scores,
    "exact_neff":float(sigma**2/exact_mean_se(.95,n)**2)}
(output/"statistics_results.json").write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
print("图表与数值已保存至：",output.as_posix())
