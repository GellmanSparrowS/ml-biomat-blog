# AI4S in Hand · Science 补给 · 材料科学
import numpy as np

# 160 virtual material batches; three strips per batch.
# E: MPa = N/mm^2; h, width and free length: mm.
rng = np.random.default_rng(20261021)
batch = np.repeat(np.arange(160), 3)
E = np.repeat(np.exp(rng.uniform(np.log(100), np.log(1000), 160)), 3)
h = rng.uniform(0.2, 1.0, len(batch))
width, length = 5.0, 20.0

# Rectangular, uniform, linear-elastic cantilever; small deflection.
# Convert N/mm to mN/mm by multiplying by 1000.
k_exact = 1000 * E * width * h**3 / (4 * length**3)
noise = rng.normal(0, 0.04, len(batch))
k_observed = k_exact * np.exp(noise)

# Keep every strip from one batch in the same data subset.
order = rng.permutation(160)
test = np.isin(batch, order[:40])
train = ~test
assert set(batch[train]).isdisjoint(set(batch[test]))

# Logs use dimensionless ratios; k is divided by 1 mN/mm.
one = np.ones(len(batch))
x_E = np.log(E / 100)
x_h = np.log(h / 0.5)
y = np.log(k_observed / 1.0)
inputs = {
    "material": np.column_stack([one, x_E]),
    "thickness": np.column_stack([one, x_h]),
    "both": np.column_stack([one, x_E, x_h]),
}

results = {}
for name, X in inputs.items():
    weights = np.linalg.lstsq(X[train], y[train], rcond=None)[0]
    predicted = np.exp(X @ weights)  # mN/mm
    mae = np.mean(np.abs(predicted[test] - k_observed[test]))
    mape = 100 * np.mean(np.abs(predicted[test] / k_observed[test] - 1))
    results[name] = dict(weights=weights, predicted=predicted, mae=mae, mape=mape)
    print(name, "weights =", weights.round(4),
          "MAE =", round(mae, 4), "mN/mm; MAPE =", round(mape, 2), "%")

# 接在上方拟合代码之后运行：生成可复用的结果图与表格。
from pathlib import Path
import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import FuncFormatter

output = Path("strip_learning_outputs")
output.mkdir(exist_ok=True)
# 优先使用系统中已有的中文字体；跨平台时可安装 Noto Sans CJK SC。
available = {f.name for f in font_manager.fontManager.ttflist}
font = next((n for n in ["Microsoft YaHei", "Noto Sans CJK SC", "SimHei"]
             if n in available), "DejaVu Sans")
plt.rcParams.update({
    "font.family": font, "font.size": 13, "axes.labelsize": 13,
    "axes.titlesize": 14, "axes.titleweight": "bold",
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#80918d", "text.color": "#203b39",
    "axes.labelcolor": "#203b39", "xtick.color": "#53676e",
    "ytick.color": "#53676e", "axes.unicode_minus": False,
    "figure.facecolor": "white", "axes.facecolor": "white",
    "svg.fonttype": "path", "svg.hashsalt": "ai4s-strip-20261021",
})
colors = {"material": "#b46b36", "thickness": "#6170a4", "both": "#00796f"}
labels = {"material": "只看 E", "thickness": "只看 h", "both": "同时看 E 和 h"}
keys = list(results)
formatter = FuncFormatter(lambda value, _: f"{value:g}")

# 每次重新抽取的是40个测试批次，每个批次的3根条带一起进入。
# 这描述固定已训练模型在测试批次组成变化时的MAE波动。
test_batches = np.unique(batch[test])
bootstrap_rng = np.random.default_rng(20261022)
resamples = bootstrap_rng.integers(0, len(test_batches), (2000, len(test_batches)))
intervals = {}
for name in keys:
    error = np.abs(results[name]["predicted"] - k_observed)
    batch_mae = np.array([error[batch == g].mean() for g in test_batches])
    intervals[name] = np.quantile(batch_mae[resamples].mean(axis=1), [0.025, 0.975])

def draw_panel(ax, kind):
    ax.grid(color="#e6ece8", linewidth=0.7, zorder=0)
    if kind in keys:
        name = kind
        ax.loglog([.1, 200], [.1, 200], color="#82928e", ls="--", lw=1.2)
        ax.scatter(k_observed[test], results[name]["predicted"][test],
                   c=colors[name], s=23, alpha=.75, edgecolors="white", linewidths=.35)
        ax.set(xlim=(.1, 200), ylim=(.1, 200),
               xlabel="观测刚度 / (mN/mm)", ylabel="预测刚度 / (mN/mm)")
        ax.set_xticks([.1, 1, 10, 100]); ax.set_yticks([.1, 1, 10, 100])
        ax.xaxis.set_major_formatter(formatter); ax.yaxis.set_major_formatter(formatter)
        ax.minorticks_off()
        ax.set_title(labels[name], loc="left", color=colors[name], pad=13)
        ax.text(.04, .94, f"MAE  {results[name]['mae']:.3f}",
                transform=ax.transAxes, va="top", fontsize=12,
                bbox=dict(facecolor="white", alpha=.9, edgecolor="none", pad=3))
    elif kind == "residuals":
        for name in keys:
            residual = np.log10(results[name]["predicted"][test] / k_observed[test])
            ax.scatter(h[test], residual, s=16, alpha=.55, color=colors[name], label=labels[name])
        ax.axhline(0, color="#203b39", lw=1)
        ax.set(xlabel="厚度 h / mm", ylabel=r"$\log_{10}$(预测值 / 观测值)",
               xlim=(.18, 1.02), ylim=(-1.25, 1.6))
        ax.set_title("误差是否随厚度变化", loc="left", pad=13)
        ax.legend(frameon=False, fontsize=10, loc="upper right")
    elif kind == "response":
        thickness = np.linspace(.2, 1, 150)
        truth = 1000 * 500 * width * thickness**3 / (4 * length**3)
        ax.plot(thickness, truth, color="#203b39", lw=4, alpha=.3, label="物理公式")
        for name in keys:
            ones = np.ones(len(thickness))
            features = {"material": [ones, ones*np.log(500/100)],
                        "thickness": [ones, np.log(thickness/.5)],
                        "both": [ones, ones*np.log(500/100), np.log(thickness/.5)]}
            prediction = np.exp(np.column_stack(features[name]) @ results[name]["weights"])
            ax.plot(thickness, prediction, color=colors[name], lw=2,
                    ls="--" if name == "both" else "-", label=labels[name])
        ax.set(xlabel="厚度 h / mm", ylabel="初始刚度 / (mN/mm)",
               xlim=(.2, 1), ylim=(0, 85))
        ax.set_title("固定 E = 500 MPa，再改变厚度", loc="left", pad=13)
        ax.legend(frameon=False, fontsize=10, loc="upper left")
    elif kind == "uncertainty":
        for i, name in enumerate(keys):
            mid = results[name]["mae"]; low, high = intervals[name]
            ax.hlines(i, low, high, color=colors[name], lw=4)
            ax.scatter(mid, i, s=75, color=colors[name], zorder=3, edgecolors="white")
            ax.annotate(f"{mid:.3f}  [{low:.3f}, {high:.3f}]", (mid, i),
                        xytext=(0, 14), textcoords="offset points", ha="center", fontsize=10)
        ax.set_xscale("log"); ax.set_xlim(.35, 28); ax.set_ylim(-.6, 2.7)
        ax.set_yticks(range(3), [labels[k] for k in keys]); ax.tick_params(axis="y", labelsize=11)
        ax.set_xticks([.5, 1, 3, 10, 20]); ax.xaxis.set_major_formatter(formatter); ax.minorticks_off()
        ax.set_xlabel("测试 MAE / (mN/mm)，对数刻度")
        ax.set_title("按批次重抽样的95%区间", loc="left", pad=13)

panel_ids = keys + ["residuals", "response", "uncertainty"]
for panel_id in panel_ids:
    fig, ax = plt.subplots(figsize=(5.2, 4.5), layout="constrained")
    draw_panel(ax, panel_id)
    fig.savefig(output / f"{panel_id}.svg", metadata={"Date": None})
    fig.savefig(output / f"{panel_id}.png", dpi=180)
    plt.close(fig)

fig, axes = plt.subplots(2, 3, figsize=(16.2, 10.0), layout="constrained")
for ax, panel_id in zip(axes.flat, panel_ids):
    draw_panel(ax, panel_id)
fig.suptitle("输入表示如何改变学习结果\n120根测试条带 · 40个独立测试批次 · 合成数据", fontsize=20)
fig.savefig(output / "model_diagnostics.svg", metadata={"Date": None})
fig.savefig(output / "model_diagnostics.png", dpi=220)
plt.close(fig)
with (output / "model_summary.csv").open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.writer(f)
    writer.writerow(["model", "MAE_mN_per_mm", "MAPE_percent", "MAE_q025", "MAE_q975"])
    for name in keys:
        writer.writerow([name, results[name]["mae"], results[name]["mape"], *intervals[name]])
print("结果图与汇总表已保存至：", output.as_posix())
