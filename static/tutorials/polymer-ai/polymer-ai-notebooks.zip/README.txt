ML-Biomat 高分子与生物大分子教程 · 9.8 高分子与生物大分子的计算实践
20节配套计算

notebooks/L01到L20：已执行Notebook，含说明、完整代码和输出组图。
examples/L01_example.py到L20_example.py：与Notebook相同的完整代码。
各节独立运行，结果写入当前工作目录中对应的输出文件夹。

运行环境：Windows，Python 3.14.3，CPU；实际依赖版本见environment.json。
基础依赖：python -m pip install -r requirements-core.txt
AI依赖：python -m pip install -r requirements-ai.txt
Notebook界面：python -m pip install jupyterlab
打开界面：python -m jupyterlab
直接运行一个例子：python examples/L20_example.py

涉及公开数据和预训练模型的例子会在首次运行时下载固定来源，并检查版本或哈希；后续使用本地缓存。来源、标签和数据划分在相应正文与代码中说明。
HTML阅读版已经包含图像、公式和实际输出，可以离线阅读。
