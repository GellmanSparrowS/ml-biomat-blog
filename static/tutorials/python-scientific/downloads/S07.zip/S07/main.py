"""Extract, slice, measure, and render an analytical ellipsoid field with PyVista."""
from pathlib import Path
import argparse
import json
import math
import numpy as np
import pyvista as pv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
from matplotlib import font_manager
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

AXES = np.array([3., 2., 1.])  # mm: reference semiaxes at q = 1
RESOLUTIONS = [17, 33, 65]
LEVELS = [.5, 1., 1.5]
SLICE_Z = [0., .25, .5, .75, 1., 1.25]  # mm


def scalar_field(points):
    return np.sum((points / AXES)**2, axis=1)


def create_grid(n):
    spacing = 8. / (n - 1)
    grid = pv.ImageData(dimensions=(n, n, n), spacing=(spacing,)*3, origin=(-4.,)*3)
    grid.point_data['q'] = scalar_field(grid.points)
    return grid


def polygon_slice(surface, z):
    """Use VTK to cut the surface, then order this convex ellipse's boundary."""
    cut = surface.slice(normal=(0, 0, 1), origin=(0, 0, z))
    if cut.n_points < 3:
        return np.empty((0, 2)), 0.
    points = np.unique(cut.points[:, :2], axis=0).astype(float)
    center = points.mean(axis=0)
    order = np.argsort(np.arctan2(points[:, 1]-center[1], points[:, 0]-center[0]))
    points = points[order]
    area = abs(np.dot(points[:, 0], np.roll(points[:, 1], -1))
               - np.dot(points[:, 1], np.roll(points[:, 0], -1))) / 2
    return points, float(area)


def analytic_volume(level):
    return 4 * math.pi * np.prod(AXES) * level**1.5 / 3


def analytic_area(level, z):
    return math.pi * AXES[0] * AXES[1] * max(level-(z/AXES[2])**2, 0.)


def triangle_volume(surface):
    """Independent signed tetrahedron sum for a consistently oriented closed mesh."""
    faces = surface.faces.reshape(-1, 4)[:, 1:]
    a, b, c = (surface.points[faces[:, i]].astype(float) for i in range(3))
    return abs(float(np.sum(np.einsum('ij,ij->i', a, np.cross(b, c))) / 6))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--language', choices=['zh', 'en'], default='en')
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    tr = lambda z, e: z if args.language == 'zh' else e
    fonts = {f.name for f in font_manager.fontManager.ttflist}
    plt.rcParams.update({'font.family': [f for f in ['Noto Sans CJK SC','Noto Sans SC',
        'Microsoft YaHei','SimHei','DejaVu Sans'] if f in fonts], 'font.size': 12,
        'svg.fonttype':'none', 'axes.spines.top':False, 'axes.spines.right':False, 'grid.alpha':.16})
    def save(fig, name):
        fig.savefig(args.output / f'{name}-{args.language}.svg')
        fig.savefig(args.output / f'{name}-{args.language}.png', dpi=160)
        plt.close(fig)

    records, mesh_bank, surfaces = [], {}, {}
    for n in RESOLUTIONS:
        grid = create_grid(n)
        for level in LEVELS:
            # A one-item list requests this value; integer 1 would request one automatic contour.
            surface = grid.contour([level], scalars='q', method='marching_cubes').triangulate()
            assert surface.n_open_edges == 0
            assert surface.is_all_triangles
            volume = float(surface.volume)
            independent = triangle_volume(surface)
            assert math.isclose(volume, independent, rel_tol=2e-7, abs_tol=2e-7)
            slices = []
            for z in SLICE_Z:
                poly, area = polygon_slice(surface, z)
                slices.append({'z':z, 'points':poly.tolist(), 'area':area,
                               'exact_area':float(analytic_area(level, z))})
            mid = slices[2]
            key = f'{n}-{level:g}'
            mesh_bank[key] = {'n':n, 'level':level, 'spacing':8/(n-1),
                'points':surface.points.tolist(), 'faces':surface.faces.reshape(-1,4)[:,1:].tolist(),
                'volume':volume, 'exact_volume':float(analytic_volume(level)), 'slices':slices}
            surfaces[key] = surface
            records.append({'n':n,'level':level,'spacing_mm':8/(n-1),'points':surface.n_points,
                'triangles':surface.n_cells,'open_edges':surface.n_open_edges,'volume_mm3':volume,
                'independent_volume_mm3':independent,'exact_volume_mm3':float(analytic_volume(level)),
                'volume_error_percent':100*abs(volume/analytic_volume(level)-1),
                'slice_area_mm2':mid['area'],'exact_slice_area_mm2':mid['exact_area'],
                'slice_error_percent':100*abs(mid['area']/mid['exact_area']-1)})
    (args.output/'mesh-bank.json').write_text(json.dumps(mesh_bank,separators=(',',':')),encoding='utf-8')
    columns=list(records[0]);np.savetxt(args.output/'convergence.csv',
        [[row[k] for k in columns] for row in records],delimiter=',',header=','.join(columns),comments='')
    default=surfaces['33-1']; default_grid=create_grid(33)
    default.save(args.output/'ellipsoid.vtp');default_grid.save(args.output/'scalar-grid.vti')
    field_plane=default_grid.slice(normal='z',origin=(0,0,.5)).triangulate()
    field_plane.save(args.output/'field-slice.vtp')
    cut_points, cut_area=polygon_slice(default,.5)

    # Render the actual VTK geometry; physical coordinates are in millimeters.
    plotter=pv.Plotter(off_screen=True,window_size=(1100,850))
    plotter.set_background('white')
    plotter.add_mesh(default,color='#477f9b',opacity=.25,smooth_shading=False)
    loop=np.column_stack([cut_points,np.full(len(cut_points),.5)])
    disk=pv.PolyData(loop,np.r_[len(loop),np.arange(len(loop))]).triangulate()
    plotter.add_mesh(disk,color='#c8753c',opacity=.85)
    plotter.add_mesh(pv.lines_from_points(loop,close=True),color='#8f451d',line_width=4)
    # Coordinate rulers sit outside the object; each tick keeps its physical position.
    ruler_origin=np.array([-3.6,-2.6,-1.4])
    label_points=[];label_text=[]
    for axis,end,ticks in [(0,3.6,[-3,0,3]),(1,2.6,[-2,0,2]),(2,1.4,[-1,0,1])]:
        endpoint=ruler_origin.copy();endpoint[axis]=end
        plotter.add_mesh(pv.Line(ruler_origin,endpoint),color='#617780',line_width=1.4)
        for tick in ticks:
            location=ruler_origin.copy();location[axis]=tick
            label_points.append(location);label_text.append(str(tick))
        middle=ruler_origin.copy();middle[axis]=(ruler_origin[axis]+end)/2
        middle[(axis+1)%3]+= .35 if axis==2 else (-1.0 if axis==0 else -.55)
        label_points.append(middle);label_text.append(['x / mm','y / mm','z / mm'][axis])
    plotter.add_point_labels(np.array(label_points),label_text,font_size=23,text_color='#263b46',
        show_points=False,shape=None,always_visible=True)
    plotter.camera_position=[(7,-10,6),(0,0,0),(0,0,1)]
    plotter.enable_parallel_projection()
    plotter.camera.zoom(.85)
    plotter.show(screenshot=args.output/'native-surface.png')

    fig,axes=plt.subplots(1,2,figsize=(13,6.2),layout='constrained',gridspec_kw={'width_ratios':[1.05,1]})
    axes[0].imshow(plt.imread(args.output/'native-surface.png'));axes[0].axis('off')
    axes[0].set_title(tr('A  等值面与内部切片的位置','A  Surface and internal slice position'))
    xy=field_plane.points[:,:2];tri=field_plane.faces.reshape(-1,4)[:,1:]
    colored=axes[1].tripcolor(mtri.Triangulation(xy[:,0],xy[:,1],tri),field_plane['q'],
        shading='gouraud',cmap='cividis',vmin=0,vmax=7)
    close=np.vstack([cut_points,cut_points[0]])
    axes[1].plot(close[:,0],close[:,1],color='#e98a43',lw=2.4,label=tr('网格切片边界','Mesh intersection'))
    theta=np.linspace(0,2*np.pi,501);radius=np.sqrt(.75)
    axes[1].plot(3*radius*np.cos(theta),2*radius*np.sin(theta),'--',color='white',lw=1.6,label=tr('解析边界','Analytical boundary'))
    axes[1].set(xlim=(-4,4),ylim=(-4,4),aspect='equal',xlabel='x / mm',ylabel='y / mm',
        title=tr('B  在z = 0.5 mm处读内部数值','B  Read values at z = 0.5 mm'))
    axes[1].legend(loc='upper right',fontsize=10)
    fig.colorbar(colored,ax=axes[1],shrink=.8,label=tr('标量q / 无量纲','Scalar q / dimensionless'))
    fig.suptitle(tr('同一体数据：N = 33，等值面q = 1','One volume dataset: N = 33, isosurface q = 1'),fontsize=16)
    save(fig,'surface-and-slice')

    # A real marching-cubes cell, plus one edge where interpolation is hand-checkable.
    cell=pv.ImageData(dimensions=(2,2,2),spacing=(.5,.5,.5),origin=(1.5,1.,.5))
    cell['q']=scalar_field(cell.points)
    patch=cell.contour([1.],scalars='q',method='marching_cubes').triangulate()
    fig=plt.figure(figsize=(12.6,6.8),layout='constrained');gs=fig.add_gridspec(1,2,width_ratios=[1.1,1])
    ax=fig.add_subplot(gs[0],projection='3d')
    pts=cell.points
    for i in range(8):
        for j in range(i):
            if np.count_nonzero(np.abs(pts[i]-pts[j])>1e-10)==1:
                ax.plot(*np.array([pts[i],pts[j]]).T,color='#899ba6',lw=1.2)
    faces=patch.faces.reshape(-1,4)[:,1:]
    ax.add_collection3d(Poly3DCollection(patch.points[faces],facecolors='#72a7bc',edgecolors='#28658c',alpha=.65,lw=1.5))
    ax.scatter(*pts.T,c=np.where(cell['q']<1,'#28658c','#c26835'),s=48,depthshade=False)
    for point,q in zip(pts,cell['q']):ax.text(*(point+np.array([.015,.015,.025])),f'{q:.3f}',fontsize=10)
    ax.set(xlabel='x / mm',ylabel='y / mm',zlabel='z / mm',xticks=[1.5,2],yticks=[1,1.5],zticks=[.5,1],
        title=tr('A  八个采样值决定局部三角面','A  Eight samples define a local patch'))
    ax.set_box_aspect((1,1,1));ax.view_init(elev=23,azim=-63)
    ax=fig.add_subplot(gs[1]);zz=np.linspace(.5,1,200)
    ax.plot(zz,.5+zz**2,color='#28658c',lw=2.5,label=tr('解析场：q = 0.5 + (z/mm)²','Known field: q = 0.5 + (z/mm)²'))
    ax.plot([.5,1],[.75,1.5],'o--',color='#c26835',lw=2,label=tr('边上的线性插值','Linear interpolation on edge'))
    ax.axhline(1,color='#677b86',lw=1.2)
    ax.scatter([2/3,np.sqrt(.5)],[1,1],s=65,c=['#c26835','#28658c'],zorder=4)
    ax.annotate('0.6667 mm',(2/3,1),xytext=(.51,1.15),arrowprops={'arrowstyle':'->','color':'#c26835'},color='#a65329')
    ax.annotate('0.7071 mm',(np.sqrt(.5),1),xytext=(.74,.85),arrowprops={'arrowstyle':'->','color':'#28658c'},color='#28658c')
    ax.set(xlabel='z / mm',ylabel=tr('标量q / 无量纲','Scalar q / dimensionless'),
        title=tr('B  同一条边：交点怎样确定','B  One edge: locating the crossing'))
    ax.legend(loc='upper left',fontsize=10);ax.grid(True)
    fig.suptitle(tr('1987年Marching Cubes：从相邻采样值构造边界','Marching Cubes, 1987: constructing a boundary from neighboring samples'),fontsize=15)
    save(fig,'history-interpolation')

    fig=plt.figure(figsize=(12.8,8.5),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1.25,1])
    axs=[fig.add_subplot(gs[0,0]),fig.add_subplot(gs[0,1])]
    for level,color in zip(LEVELS,['#28658c','#2b8a74','#c26835']):
        group=[r for r in records if r['level']==level]
        for ax,key in zip(axs,['volume_error_percent','slice_error_percent']):
            ax.loglog([r['spacing_mm'] for r in group],[r[key] for r in group],'o-',color=color,lw=2,label=f'λ = {level:g}')
    for ax,title in zip(axs,[tr('A  封闭网格体积误差','A  Enclosed mesh volume error'),tr('B  z = 0.5 mm处的面积误差','B  Area error at z = 0.5 mm')]):
        ax.set(title=title,xlabel=tr('网格间距 / mm','Grid spacing / mm'),ylabel=tr('相对误差 / %','Relative error / %'))
        ax.set_xticks([.125,.25,.5],labels=['0.125','0.25','0.5']);ax.minorticks_off();ax.legend();ax.grid(True)
    ax=fig.add_subplot(gs[1,:]);ax.axis('off')
    labels=['N','h / mm','λ',tr('三角面数','Triangles'),'V / mm³',tr('体积误差 / %','Volume error / %')]
    rows=[[r['n'],f"{r['spacing_mm']:.3f}",f"{r['level']:g}",r['triangles'],f"{r['volume_mm3']:.5f}",f"{r['volume_error_percent']:.3f}"] for r in records]
    table=ax.table(cellText=rows,colLabels=labels,loc='center',cellLoc='center',bbox=[0,.0,1,.96])
    table.auto_set_font_size(False);table.set_fontsize(11)
    for (i,j),cell in table.get_celld().items():cell.set_facecolor('#eaf1f4' if i==0 else 'white');cell.set_edgecolor('#d2dfe5')
    fig.suptitle(tr('固定解析场，仅改变采样间距；参考答案由椭球公式给出',
        'One analytical field, different sample spacings; ellipsoid formulas provide the reference'),fontsize=15)
    save(fig,'convergence')

    baseline=next(row for row in records if row['n']==33 and row['level']==1)
    summary={'pyvista_version':pv.__version__,'vtk_version':pv.vtk_version_info._asdict(),
        'reference_semiaxes_mm':AXES.tolist(),'reference_volume_mm3':float(analytic_volume(1)),
        'reference_area_z05_mm2':float(analytic_area(1,.5)),'default':baseline,'records':records,
        'single_cell_triangles':patch.n_cells,'edge_linear_crossing_mm':2/3,
        'edge_exact_crossing_mm':float(np.sqrt(.5)),
        'field_slice_points':field_plane.n_points,'field_slice_triangles':field_plane.n_cells}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
