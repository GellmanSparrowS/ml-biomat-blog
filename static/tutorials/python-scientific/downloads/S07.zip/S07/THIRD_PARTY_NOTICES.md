# Public sources and third-party materials

- PyVista: Creating a Uniform Grid: https://docs.pyvista.org/examples/00-load/create_uniform_grid.html
  PyVista documentation and software: MIT; original example and figures here.
- PyVista: Contouring: https://docs.pyvista.org/examples/01-filter/contouring.html
  MIT
- PyVista: DataSetFilters.contour: https://docs.pyvista.org/api/core/_autosummary/pyvista.datasetfilters.contour
  MIT
- PyVista: Slicing: https://docs.pyvista.org/examples/01-filter/slice.html
  MIT
- PyVista: PolyData.volume: https://docs.pyvista.org/api/core/_autosummary/pyvista.polydata.volume
  MIT
- Lorensen & Cline (1987), Marching Cubes: A High Resolution 3D Surface Construction Algorithm: https://graphics.stanford.edu/courses/cs348a-20-winter/Papers/Marching_Cubes.pdf
  Original paper consulted for historical and technical facts; no paper figures reproduced.
- Sullivan & Kaszynski (2019), PyVista: 3D plotting and mesh analysis through a streamlined interface for the Visualization Toolkit (VTK): https://joss.theoj.org/papers/10.21105/joss.01450
  JOSS article CC BY 4.0; software MIT.
