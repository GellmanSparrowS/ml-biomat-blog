"""Align two irregular teaching time series and inspect aggregation and coverage."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import FuncFormatter

BLUE,RED,INK,GRAY='#28658c','#b64a35','#202e39','#71808b'
EPOCH=pd.Timestamp('2000-01-01T00:00:00Z')


def teaching_data():
    definitions={'A':([0,1,2.5,5,6,9,15,16,19],[22,26,35,47,51,58,67,69,71],'2000-01-01T09:00:00Z'),
                 'B':([0,2,3,5,8,9,15,17,19],[21,29,35,44,53,55,65,68,70],'2000-01-01T09:07:00Z')}
    frames=[]
    for batch,(elapsed,temperature,start) in definitions.items():
        stamp=pd.Timestamp(start)+pd.to_timedelta(elapsed,unit='min')
        frames.append(pd.DataFrame({'batch':batch,'timestamp':stamp.astype(str),'start':start,
                                    'temperature_C':temperature}))
    frame=pd.concat(frames,ignore_index=True)
    frame['timestamp']=pd.to_datetime(frame['timestamp'],utc=True)
    frame['start']=pd.to_datetime(frame['start'],utc=True)
    frame['elapsed_min']=(frame['timestamp']-frame['start']).dt.total_seconds()/60
    return frame.sort_values(['batch','timestamp']).reset_index(drop=True)


def aggregate(frame,width,offset=0):
    relative_index=EPOCH+pd.to_timedelta(frame['elapsed_min'],unit='min')
    signal=pd.Series(frame['temperature_C'].to_numpy(dtype=float),index=relative_index)
    grouped=signal.resample(f'{width}min',origin=EPOCH,offset=pd.Timedelta(minutes=offset),
                            closed='left',label='left').agg(['mean','count'])
    grouped['left_min']=(grouped.index-EPOCH).total_seconds()/60
    grouped['right_min']=grouped['left_min']+width
    return grouped.reset_index(drop=True)


def main(output,language):
    output.mkdir(parents=True,exist_ok=True)
    def tr(a,b):return a if language=='zh' else b
    plt.rcParams.update({'font.family':[name for name in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if name in {f.name for f in font_manager.fontManager.ttflist}],'font.size':11,
        'axes.labelsize':12,'axes.titlesize':13,'axes.titleweight':'bold','axes.spines.top':False,
        'axes.spines.right':False,'text.color':INK,'svg.fonttype':'none','svg.hashsalt':'P14'})
    data=teaching_data();data.to_csv(output/'thermal-records.csv',index=False)
    cases={}
    for batch,frame in data.groupby('batch',sort=True):
        for width,offset in [(5,0),(5,2),(10,0),(2,0)]:
            result=aggregate(frame,width,offset)
            result.to_csv(output/f'bins-{batch}-{width}-{offset}.csv',index=False)
            records=[{'left_min':float(r.left_min),'right_min':float(r.right_min),
                      'mean_C':None if pd.isna(r.mean) else float(r.mean),'count':int(r.count)}
                     for r in result.itertuples(index=False)]
            cases[f'{batch}-{width}-{offset}']={'bins':records,'empty_bins':sum(r['count']==0 for r in records),
                'total_observations':sum(r['count'] for r in records)}
    a=data.loc[data['batch'].eq('A')].copy()
    a['row_window_mean']=a['temperature_C'].rolling(3,min_periods=1).mean()
    time_signal=pd.Series(a['temperature_C'].to_numpy(dtype=float),index=pd.to_timedelta(a['elapsed_min'],unit='min'))
    a['time_window_mean']=time_signal.rolling('5min',min_periods=1,closed='right').mean().to_numpy()
    a.to_csv(output/'rolling-A.csv',index=False)
    at15=a.loc[a['elapsed_min'].eq(15)].iloc[0]
    assert abs(cases['A-5-0']['bins'][0]['mean_C']-83/3)<1e-12
    assert cases['A-5-0']['bins'][2]['count']==0
    assert cases['A-5-0']['bins'][2]['mean_C'] is None
    assert at15['row_window_mean']==(51+58+67)/3
    assert at15['time_window_mean']==67
    def save(fig,name):
        fig.savefig(output/f'{name}-{language}.svg',metadata={'Date':None})
        fig.savefig(output/f'{name}-{language}.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12.4,5.6),layout='constrained',sharey=True)
    origin=pd.Timestamp('2000-01-01T09:00:00Z')
    for batch,frame in data.groupby('batch'):
        color=BLUE if batch=='A' else RED
        clock=(frame['timestamp']-origin).dt.total_seconds()/60
        axes[0].plot(clock,frame['temperature_C'],'o-',color=color,ms=5,lw=1.3,label=tr('批次','Batch ')+batch)
        axes[1].plot(frame['elapsed_min'],frame['temperature_C'],'o-',color=color,ms=5,lw=1.3,label=tr('批次','Batch ')+batch)
    axes[0].xaxis.set_major_formatter(FuncFormatter(lambda v,p:f'09:{int(v):02}'))
    axes[0].set(xticks=np.arange(0,31,5),xlabel=tr('钟表时间 / UTC','Clock time / UTC'),
                title=tr('钟表时间保留启动先后','Clock time retains start order'))
    axes[1].set(xlabel=tr('从各自启动起经过的时间 / min','Elapsed time from each start / min'),
                title=tr('经过时间对齐过程阶段','Elapsed time aligns process stage'))
    axes[0].set_ylabel(tr('温度 / °C','Temperature / °C'))
    for ax in axes:ax.legend(frameon=False);ax.set_ylim(15,78)
    save(fig,'alignment')
    fig,axes=plt.subplots(2,2,figsize=(12.4,8),sharex='col',gridspec_kw={'height_ratios':[2,1]},layout='constrained')
    for j,width in enumerate([5,10]):
        binned=aggregate(a,width)
        centers=(binned['left_min']+binned['right_min'])/2
        axes[0,j].scatter(a['elapsed_min'],a['temperature_C'],s=35,color=GRAY,label=tr('原始记录','Original records'),clip_on=False)
        axes[0,j].plot(centers,binned['mean'],'o-',color=BLUE,lw=2,label=tr('箱内观测均值','Mean of observations in bin'))
        axes[0,j].set(ylim=(15,78),title=tr(f'{width}分钟分箱',f'{width}-minute bins'))
        axes[0,j].legend(frameon=False,fontsize=9)
        axes[1,j].bar(centers,binned['count'],width=width*.8,color=BLUE)
        axes[1,j].set(xlim=(0,20),ylim=(0,7),xticks=np.arange(0,21,5),xlabel=tr('经过时间 / min','Elapsed time / min'))
        for x,count in zip(centers,binned['count']):axes[1,j].text(x,count+.15,str(count),ha='center',color=RED if count==0 else INK)
        for ax in axes[:,j]:
            for edge in binned['left_min']:ax.axvline(edge,color='#dce3e8',lw=.7,zorder=0)
    axes[0,0].set_ylabel(tr('温度 / °C','Temperature / °C'));axes[1,0].set_ylabel(tr('记录数','Observation count'))
    save(fig,'coverage')
    fig,axes=plt.subplots(1,2,figsize=(12.4,5.7),gridspec_kw={'width_ratios':[1.35,1]},layout='constrained')
    axes[0].scatter(a['elapsed_min'],a['temperature_C'],s=30,color=INK,label=tr('原始记录','Original records'),zorder=4)
    axes[0].plot(a['elapsed_min'],a['row_window_mean'],'o-',color=RED,label=tr('最近3条记录','Last 3 records'))
    axes[0].plot(a['elapsed_min'],a['time_window_mean'],'s-',color=BLUE,label=tr('最近5分钟','Trailing 5 minutes'))
    axes[0].set(xlabel=tr('经过时间 / min','Elapsed time / min'),ylabel=tr('温度 / °C','Temperature / °C'),
                title=tr('窗口长度可以按行，也可以按时间','Window length can mean rows or elapsed time'))
    axes[0].legend(frameon=False,fontsize=10)
    axes[1].set_axis_off()
    axes[1].text(.03,.94,tr('在15分钟这一刻','At elapsed time 15 min'),fontsize=14,weight='bold')
    lines=[tr('最近3条记录：6、9、15 min','Last 3 records: 6, 9, 15 min'),
           tr('温度：51、58、67 °C','Temperatures: 51, 58, 67 °C'),
           tr('均值 = 58.67 °C','Mean = 58.67 °C'),'',
           tr('最近5分钟：(10, 15] min','Trailing 5 min: (10, 15] min'),
           tr('区间内有1条记录：67 °C','One observation in the interval: 67 °C'),
           tr('均值 = 67.00 °C','Mean = 67.00 °C')]
    for i,line in enumerate(lines):axes[1].text(.03,.79-i*.105,line,fontsize=11,color=RED if i<3 else BLUE)
    save(fig,'windows')
    summary={'data_kind':'explicit teaching timestamps and temperatures','n_records':len(data),
        'start_delay_B_min':7,'cases':cases,'at_15_min':{'row_window_mean_C':float(at15['row_window_mean']),
        'time_window_mean_C':float(at15['time_window_mean'])},'versions':{'pandas':pd.__version__,'numpy':np.__version__,'matplotlib':matplotlib.__version__}}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,default=Path('output'))
    parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args();main(args.output,args.language)
