# Public sources and third-party materials

- pandas: Time series / date functionality: https://pandas.pydata.org/docs/user_guide/timeseries.html
  pandas BSD-3 documentation; original case and figures
- pandas: Windowing operations: https://pandas.pydata.org/docs/user_guide/window.html
  pandas BSD-3 documentation
- McKinney (2010), Data Structures for Statistical Computing in Python: https://github.com/scipy-conference/scipy_proceedings_2010/blob/master/papers/mckinney/pandas_scipy.rst
  Historical facts and design ideas paraphrased; original diagrams, no source code or image reproduced
