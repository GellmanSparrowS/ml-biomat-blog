"""Build molecular identity tables and figures with RDKit.

Run: python main.py --output results --language en
All molecular inputs are defined below; no network service is required.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
from rdkit import Chem, RDLogger, rdBase
from rdkit.Chem import Descriptors, Lipinski, rdDepictor, rdMolDescriptors
from rdkit.Chem.Draw import rdMolDraw2D


BLUE, ORANGE, GREEN, INK = "#235b89", "#bf5635", "#177d72", "#192b3a"
PATTERNS = {
    "hydroxyl": "[OX2H]",
    "ether": "[OD2]([#6])[#6]",
    "carboxyl": "[CX3](=[OX1])[OX2H1,O-]",
    "aromatic": "a",
}



def available_plot_fonts():
    """Choose installed fonts; keep a Latin fallback on every platform."""
    choices = ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]



def inputs():
    rows = [{"id": f"EG{n}", "smiles": "O" + "CCO" * n, "n": n,
             "zh": f"乙二醇系列 n={n}", "en": f"Glycol series n={n}"}
            for n in range(1, 7)]
    rows.extend([
        {"id": "LA1", "smiles": "C[C@H](O)C(=O)O", "zh": "乳酸：指定构型 1", "en": "Lactic acid: stereo 1"},
        {"id": "LA2", "smiles": "C[C@@H](O)C(=O)O", "zh": "乳酸：指定构型 2", "en": "Lactic acid: stereo 2"},
        {"id": "LA?", "smiles": "CC(O)C(=O)O", "zh": "乳酸：构型未指定", "en": "Lactic acid: unspecified"},
        {"id": "LAC", "smiles": "CC(O)C(=O)[O-]", "zh": "乳酸根：构型未指定", "en": "Lactate: unspecified"},
        {"id": "BZ1", "smiles": "c1ccccc1", "zh": "苯：芳香写法", "en": "Benzene: aromatic input"},
        {"id": "BZ2", "smiles": "C1=CC=CC=C1", "zh": "苯：单双键写法", "en": "Benzene: Kekule input"},
        {"id": "BAD", "smiles": "C(C)(C)(C)(C)C", "zh": "五键中性碳测试", "en": "Neutral five-bond carbon test"},
    ])
    return rows


def depiction(mol, highlight=()):
    drawer = rdMolDraw2D.MolDraw2DSVG(640, 360)
    opt = drawer.drawOptions()
    opt.addAtomIndices = True
    opt.baseFontSize = 0.85
    opt.minFontSize = 20
    opt.maxFontSize = 28
    opt.padding = 0.13
    rdMolDraw2D.PrepareAndDrawMolecule(drawer, mol, highlightAtoms=list(highlight),
                                     highlightAtomColors={i: (0.99, 0.78, 0.36) for i in highlight})
    positions = [[drawer.GetDrawCoords(i).x, drawer.GetDrawCoords(i).y]
                 for i in range(mol.GetNumAtoms())]
    drawer.FinishDrawing()
    svg = drawer.GetDrawingText()
    svg = svg[svg.find("<svg"):]
    return svg, positions


def process(row):
    # Keep a rejected row visible in the output table instead of silently dropping it.
    with rdBase.BlockLogs():
        mol = Chem.MolFromSmiles(row["smiles"])
    if mol is None:
        return {**row, "valid": False, "reason": "invalid neutral carbon valence"}, None
    rdDepictor.Compute2DCoords(mol)
    Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
    atoms = [{"index": a.GetIdx(), "element": a.GetSymbol(),
              "hydrogens": a.GetTotalNumHs(), "charge": a.GetFormalCharge(),
              "aromatic": a.GetIsAromatic(),
              "neighbors": [x.GetIdx() for x in a.GetNeighbors()],
              "cip": a.GetProp("_CIPCode") if a.HasProp("_CIPCode") else None}
             for a in mol.GetAtoms()]
    hits = {name: [list(match) for match in mol.GetSubstructMatches(Chem.MolFromSmarts(pattern))]
            for name, pattern in PATTERNS.items()}
    drawings = {}
    for pattern in ["none", *PATTERNS]:
        indices = sorted({i for match in hits.get(pattern, []) for i in match})
        drawings[pattern], xy = depiction(mol, indices)
    canonical = Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True)
    plain = Chem.MolToSmiles(mol, canonical=True, isomericSmiles=False)
    restored = Chem.MolFromSmiles(canonical)
    assert restored is not None
    assert Chem.MolToSmiles(restored, isomericSmiles=True) == canonical
    result = {**row, "valid": True, "canonical": canonical, "without_stereo": plain,
              "formula": rdMolDescriptors.CalcMolFormula(mol),
              "mass_g_mol": Descriptors.MolWt(mol),
              "monoisotopic_mass_Da": Descriptors.ExactMolWt(mol),
              "heavy_atoms": mol.GetNumHeavyAtoms(),
              "total_atoms_with_H": Chem.AddHs(mol).GetNumAtoms(),
              "formal_charge": Chem.GetFormalCharge(mol),
              "hbd": Lipinski.NumHDonors(mol), "hba": Lipinski.NumHAcceptors(mol),
              "tpsa_A2": rdMolDescriptors.CalcTPSA(mol),
              "logP_model": Descriptors.MolLogP(mol),
              "atoms": atoms, "bonds": Chem.GetAdjacencyMatrix(mol).tolist(),
              "matches": hits, "drawings": drawings, "xy": xy}
    return result, mol


def molecule_image(ax, mol, highlighted=()):
    drawer = rdMolDraw2D.MolDraw2DCairo(800, 380)
    opt = drawer.drawOptions()
    opt.addAtomIndices = True
    opt.minFontSize = 20
    opt.maxFontSize = 29
    opt.padding = 0.12
    rdMolDraw2D.PrepareAndDrawMolecule(drawer, mol, highlightAtoms=list(highlighted),
                                     highlightAtomColors={i: (.99, .78, .36) for i in highlighted})
    drawer.FinishDrawing()
    ax.imshow(plt.imread(io.BytesIO(drawer.GetDrawingText()), format="png"))
    ax.axis("off")


def figures(records, mols, out, language):
    zh = language == "zh"
    tr = lambda cn, en: cn if zh else en
    plt.rcParams.update({"font.family": available_plot_fonts() if zh else ["DejaVu Sans"],
        "font.size": 13, "axes.titlesize": 15, "axes.labelsize": 14,
        "figure.facecolor": "#faf9f6", "axes.spines.top": False,
        "axes.spines.right": False, "svg.fonttype": "path"})
    byid = {r["id"]: r for r in records}
    def save(fig, name):
        for ext in ("svg", "png"):
            fig.savefig(out / f"{name}-{language}.{ext}", dpi=165, bbox_inches="tight")
        plt.close(fig)

    # F1: the same numbered molecular graph explains the branch tokens and atom table.
    fig = plt.figure(figsize=(13, 8.2), layout="constrained")
    gs = fig.add_gridspec(2, 2, height_ratios=[1.15, 1], width_ratios=[1.15, 1])
    ax = fig.add_subplot(gs[0, 0])
    molecule_image(ax, mols["LA?"], [2, 3, 4, 5])
    ax.set_title(tr("同一张图：6 个重原子，6 个隐含氢", "One graph: 6 heavy atoms and 6 implicit H"))
    ax = fig.add_subplot(gs[0, 1]); ax.axis("off")
    ax.text(0, .95, "CC(O)C(=O)O", fontsize=23, family="monospace", color=BLUE, va="top")
    lines = [tr("0–1–3–5：主路径", "0–1–3–5: main traversal"),
             tr("(O)：在原子 1 处分支到原子 2", "(O): branch from atom 1 to atom 2"),
             tr("(=O)：原子 3 与原子 4 形成双键", "(=O): double bond from atom 3 to atom 4"),
             tr("括号控制连接；不增加原子", "Parentheses control connectivity"),
             tr("H 由价态补足，保存在原子属性中", "Hydrogens follow the atom valences")]
    for k, line in enumerate(lines): ax.text(0, .70-k*.125, line, fontsize=14, color=INK)
    ax = fig.add_subplot(gs[1, 0]); ax.axis("off")
    r = byid["LA?"]
    table = ax.table(cellText=[[a["index"], a["element"], a["hydrogens"],
                               ", ".join(map(str, a["neighbors"]))] for a in r["atoms"]],
                     colLabels=[tr("索引", "Index"), tr("元素", "Element"), "H", tr("邻接原子", "Neighbors")],
                     loc="center", cellLoc="center", bbox=[0, .06, 1, .9])
    table.auto_set_font_size(False); table.set_fontsize(14)
    for (i, j), cell in table.get_celld().items():
        cell.set_edgecolor("#d6e1e5")
        if i == 0: cell.set_facecolor("#dce9ee")
    ax = fig.add_subplot(gs[1, 1]); ax.axis("off")
    ax.text(0, .92, tr("1988：SMILES 把分子图写进一行文字", "1988: SMILES encodes a graph in one line"),
            fontsize=15, weight="bold", va="top")
    ax.text(0, .72, "CC(O)C(=O)O\nOC(=O)C(O)C", family="monospace", fontsize=20, color=BLUE, linespacing=1.6, va="top")
    ax.annotate("", xy=(.45, .32), xytext=(.45, .43), arrowprops={"arrowstyle": "->", "color": INK})
    ax.text(0, .25, tr("RDKit 规范表示：CC(O)C(=O)O", "RDKit canonical form: CC(O)C(=O)O"), fontsize=14)
    ax.text(0, .10, tr("不同遍历顺序 → 相同连接关系", "Different traversals → the same connectivity"), fontsize=14)
    save(fig, "graph-and-string")

    # F2: values have separate axes and retain their scientific units.
    fig, axes = plt.subplots(2, 2, figsize=(13, 8), layout="constrained")
    series = [r for r in records if r.get("n")]
    n = np.array([r["n"] for r in series])
    mass = np.array([r["mass_g_mol"] for r in series])
    axes[0, 0].plot(n, mass, "o-", color=BLUE, lw=2.5)
    axes[0, 0].plot(n, 44.053*n+18.015, "+", color=ORANGE, ms=15, mew=2,
                    label=tr("按分子式加和", "Formula sum"))
    axes[0, 0].set_ylabel(tr("摩尔质量 / g mol⁻¹", "Molar mass / g mol⁻¹")); axes[0, 0].legend()
    for i in (0, 5): axes[0, 0].annotate(f"{mass[i]:.3f}", (n[i], mass[i]), xytext=(4, 8), textcoords="offset points")
    axes[0, 1].plot(n, [r["tpsa_A2"] for r in series], "o-", color=GREEN, lw=2.5)
    axes[0, 1].set_ylabel(tr("拓扑极性表面积 / Å²", "Topological polar surface area / Å²"))
    axes[1, 0].plot(n, [r["hba"] for r in series], "o-", lw=2.5, color=BLUE, label=tr("受体位点 HBA", "Acceptor sites HBA"))
    axes[1, 0].plot(n, [r["hbd"] for r in series], "s-", lw=2.5, color=ORANGE, label=tr("供体位点 HBD", "Donor sites HBD"))
    axes[1, 0].set_ylabel(tr("位点数", "Site count")); axes[1, 0].legend()
    axes[1, 1].plot(n, [r["logP_model"] for r in series], "o-", lw=2.5, color=ORANGE)
    axes[1, 1].set_ylabel(tr("片段模型 logP / 无量纲", "Fragment-model logP / dimensionless"))
    for ax in axes.flat:
        ax.set_xlabel(tr("链中乙二醇单元数 n", "Number of ethylene-glycol units n"))
        ax.set_xticks(n); ax.grid(alpha=.18)
    fig.suptitle(tr("明确端基的六个分子：HO–(CH₂CH₂O)ₙ–H", "Six molecules with defined end groups: HO–(CH₂CH₂O)ₙ–H"), fontsize=18)
    save(fig, "oligomer-descriptors")

    # F3: molecular identity depends on which structural attributes are retained.
    fig = plt.figure(figsize=(13, 8.2), layout="constrained")
    gs = fig.add_gridspec(3, 3, height_ratios=[1, 1, .65])
    ids = ["LA1", "LA2", "LA?", "LAC", "BZ1", "BZ2"]
    for k, ident in enumerate(ids):
        ax = fig.add_subplot(gs[k//3, k%3]); r = byid[ident]
        molecule_image(ax, mols[ident])
        stereo = ",".join(a["cip"] for a in r["atoms"] if a["cip"])
        ax.set_title(r[language]+(f" ({stereo})" if stereo else ""), fontsize=14)
        ax.text(.5, -.02, f"{r['formula']}  |  {r['mass_g_mol']:.3f} g mol⁻¹\n{r['canonical']}",
                transform=ax.transAxes, ha="center", va="top", fontsize=12.5)
    ax = fig.add_subplot(gs[2, :]); ax.axis("off")
    cols = [tr("去重时保留的属性", "Attributes retained in the key"), tr("三种乳酸记录", "Three lactic-acid records"), tr("两种苯写法", "Two benzene inputs")]
    cells = [[tr("连接关系、键型、形式电荷、指定构型", "Connectivity, bond type, charge, specified stereo"), "3", "1"],
             [tr("连接关系、键型、形式电荷", "Connectivity, bond type, charge"), "1", "1"]]
    tab = ax.table(cellText=cells, colLabels=cols, cellLoc="center", bbox=[0, .03, 1, .65], colWidths=[.55, .25, .20])
    tab.auto_set_font_size(False); tab.set_fontsize(13)
    for (i, j), cell in tab.get_celld().items():
        cell.set_edgecolor("#d6e1e5")
        if i == 0: cell.set_facecolor("#dce9ee")
    save(fig, "identity-and-stereo")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("results"))
    parser.add_argument("--language", choices=["zh", "en"], default="en")
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    records, molecules = [], {}
    for row in inputs():
        result, mol = process(row); records.append(result)
        if mol is not None: molecules[row["id"]] = mol
    valid = [r for r in records if r["valid"]]
    columns = ["id", "smiles", "valid", "canonical", "without_stereo", "formula", "mass_g_mol",
               "monoisotopic_mass_Da", "heavy_atoms", "total_atoms_with_H", "formal_charge",
               "hbd", "hba", "tpsa_A2", "logP_model", "reason"]
    with (args.output / "structures.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader(); writer.writerows(records)
    writer = Chem.SDWriter(str(args.output / "structures.sdf"))
    for r in valid:
        mol = molecules[r["id"]]; mol.SetProp("_Name", r["id"])
        mol.SetProp("input_smiles", r["smiles"]); writer.write(mol)
    writer.close()
    roundtrip = [m for m in Chem.SDMolSupplier(str(args.output / "structures.sdf")) if m is not None]
    assert len(roundtrip) == len(valid)
    assert [Chem.MolToSmiles(m, isomericSmiles=True) for m in roundtrip] == [r["canonical"] for r in valid]
    series = [r for r in valid if r.get("n")]
    mass_error = max(abs(r["mass_g_mol"]-(44.053*r["n"]+18.015)) for r in series)
    assert mass_error < 1e-10
    summary = {"rdkit_version": rdBase.rdkitVersion, "input_rows": len(records), "valid_rows": len(valid),
               "unique_isomeric": len({r["canonical"] for r in valid}),
               "unique_without_stereo": len({r["without_stereo"] for r in valid}),
               "formula_mass_max_error_g_mol": mass_error,
               "rows": [{k: v for k, v in r.items() if k not in ("drawings", "xy", "atoms", "bonds", "matches")} for r in records]}
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    (args.output / "lab-data.json").write_text(json.dumps({"records": records, "patterns": PATTERNS}, ensure_ascii=False), encoding="utf-8")
    figures(valid, molecules, args.output, args.language)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
