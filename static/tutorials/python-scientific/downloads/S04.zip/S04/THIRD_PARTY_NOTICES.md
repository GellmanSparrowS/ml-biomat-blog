# Public sources and third-party materials

- RDKit: Getting Started in Python: https://www.rdkit.org/docs/GettingStartedInPython.html
  Greg Landrum documentation: CC BY-SA 4.0; RDKit software: BSD 3-Clause.
- The RDKit Book: https://www.rdkit.org/docs/RDKit_Book.html
  RDKit documentation; consult the page license and project license for reuse.
- Weininger (1988), SMILES: methodology and encoding rules: https://doi.org/10.1021/ci00057a005
  American Chemical Society journal article.
