# Public sources and third-party materials

- NetworkX tutorial: https://networkx.org/documentation/stable/tutorial.html
  NetworkX BSD-3-Clause; original chapter text and implementation.
- NetworkX bridges: https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.bridges.bridges.html
  NetworkX BSD-3-Clause.
- NetworkX weighted shortest paths: https://networkx.org/documentation/stable/reference/algorithms/generated/networkx.algorithms.shortest_paths.weighted.dijkstra_path.html
  NetworkX BSD-3-Clause.
- Euler Archive E53: Solutio problematis ad geometriam situs pertinentis: https://scholarlycommons.pacific.edu/euler-works/53/
  Historical citation; newly drawn explanatory graph.
