"""Analyze a constructed material network using NetworkX and resistor balance."""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyArrowPatch

COORDINATES = {0:(0,0),1:(1,0),2:(2,0),3:(0,1.4),4:(1,1.4),5:(2,1.4),
               6:(3,0),7:(4,0),8:(5,0),9:(3,1.4),10:(4,1.4),11:(5,1.4),12:(2,2.7)}
BASE_EDGES = [(0,1),(1,2),(3,4),(4,5),(0,3),(1,4),(2,5),(1,5),
              (6,7),(7,8),(9,10),(10,11),(6,9),(7,10),(8,11),(6,10),
              (2,6),(5,12)]
BYPASS=(5,9)
SOURCE, SINK = 0,11



def available_plot_fonts():
    """Choose installed fonts; keep a Latin fallback on every platform."""
    choices = ["Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei", "DejaVu Sans"]
    installed = {font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]



def edge_id(u,v):
    return f'{min(u,v)}-{max(u,v)}'


def build_graph(bypass=False):
    graph=nx.Graph()
    for node,(x,y) in COORDINATES.items():
        graph.add_node(node,x_um=x,y_um=y)
    for u,v in BASE_EDGES+([BYPASS] if bypass else []):
        length=float(np.linalg.norm(np.array(COORDINATES[u])-COORDINATES[v]))
        graph.add_edge(u,v,length_um=length,conductance_uS=1/length,id=edge_id(u,v))
    return graph


def solve_potentials(graph):
    potentials={node:None for node in graph}
    for component in nx.connected_components(graph):
        boundary={node:value for node,value in [(SOURCE,1.0),(SINK,0.0)] if node in component}
        if not boundary:
            continue  # An isolated floating component has no prescribed absolute potential.
        if len(boundary)==1:
            potentials.update({node:next(iter(boundary.values())) for node in component})
            continue
        nodes=sorted(component);indices={node:i for i,node in enumerate(nodes)}
        matrix=nx.laplacian_matrix(graph.subgraph(component),nodelist=nodes,
                                   weight='conductance_uS').toarray()
        free=[indices[node] for node in nodes if node not in boundary]
        fixed=[indices[node] for node in boundary]
        values=np.array(list(boundary.values()))
        rhs=-matrix[np.ix_(free,fixed)]@values
        solution=np.linalg.solve(matrix[np.ix_(free,free)],rhs)
        potentials.update(boundary)
        potentials.update({nodes[index]:float(value) for index,value in zip(free,solution)})
    currents={};balance={node:0.0 for node in graph}
    for u,v,attr in graph.edges(data=True):
        current=0.0 if potentials[u] is None else attr['conductance_uS']*(potentials[u]-potentials[v])
        currents[edge_id(u,v)]=float(current if u<v else -current)
        balance[u]+=current;balance[v]-=current
    residual=max(abs(value) for node,value in balance.items() if node not in [SOURCE,SINK])
    return potentials,currents,float(balance[SOURCE]),float(balance[SINK]),float(residual)


def analyze(bypass,removed='none'):
    graph=build_graph(bypass)
    if removed!='none':
        u,v=map(int,removed.split('-'));graph.remove_edge(u,v)
    components=sorted([sorted(c) for c in nx.connected_components(graph)],key=lambda c:(-len(c),c))
    potential,current,source_current,sink_current,residual=solve_potentials(graph)
    connected=nx.has_path(graph,SOURCE,SINK)
    route=nx.shortest_path(graph,SOURCE,SINK,weight='length_um') if connected else []
    route_length=sum(graph.edges[u,v]['length_um'] for u,v in zip(route,route[1:])) if route else None
    degree=dict(graph.degree())
    assert sum(degree.values())==2*graph.number_of_edges()
    assert residual<1e-12 and abs(source_current+sink_current)<1e-12
    return {'bypass':bypass,'removed':removed,'nodes':graph.number_of_nodes(),'edges':graph.number_of_edges(),
            'components':components,'component_count':len(components),'largest_component':len(components[0]),
            'bridges':sorted(edge_id(u,v) for u,v in nx.bridges(graph)),
            'degree':degree,'route':route,'route_length_um':route_length,
            'potential_V':potential,'current_uA':current,'effective_conductance_uS':source_current,
            'sink_current_uA':sink_current,'max_internal_current_imbalance_uA':residual,
            'adjacency_uS':nx.to_numpy_array(graph,nodelist=sorted(graph),weight='conductance_uS').tolist()}


def draw_network(ax,state,language):
    graph=build_graph(state['bypass']);pos=COORDINATES
    if state['removed']!='none':
        u,v=map(int,state['removed'].split('-'))
        ax.plot([pos[u][0],pos[v][0]],[pos[u][1],pos[v][1]],color='#b64d34',ls='--',lw=2)
        graph.remove_edge(u,v)
    max_current=0.4  # microampere: shared line-width scale across every state
    for u,v in graph.edges:
        value=abs(state['current_uA'][edge_id(u,v)])
        ax.plot([pos[u][0],pos[v][0]],[pos[u][1],pos[v][1]],
                 color='#205b8c' if value>1e-12 else '#a9b4b9',lw=1+5*value/max_current,zorder=1)
    values=[state['potential_V'][n] if state['potential_V'][n] is not None else .5 for n in graph]
    scatter=ax.scatter([pos[n][0] for n in graph],[pos[n][1] for n in graph],c=values,cmap='viridis',
                        vmin=0,vmax=1,s=340,edgecolor='#172534',linewidth=1,zorder=3)
    floating=[n for n in graph if state['potential_V'][n] is None]
    if floating:
        ax.scatter([pos[n][0] for n in floating],[pos[n][1] for n in floating],
                    s=340,facecolor='#faf9f5',edgecolor='#82949e',linewidth=1.5,zorder=4)
    for n in graph:
        ax.text(pos[n][0],pos[n][1]+.20,str(n),ha='center',va='bottom',fontsize=13)
    ax.set(xlim=(-.45,5.45),ylim=(-.5,3.2),xlabel='x / μm',ylabel='y / μm')
    ax.set_aspect('equal');ax.grid(alpha=.15)
    return scatter


def figures(states,output,language):
    zh=language=='zh';tr=lambda a,b:a if zh else b
    plt.rcParams.update({'font.family':available_plot_fonts() if zh else ['DejaVu Sans'],'font.size':13,
                         'axes.spines.top':False,'axes.spines.right':False,
                         'axes.unicode_minus':False,'svg.fonttype':'none'})
    find=lambda bypass,removed:next(s for s in states if s['bypass']==bypass and s['removed']==removed)
    base=find(False,'none')
    def save(fig,name):
        for ext in ['svg','png']:fig.savefig(output/f'{name}-{language}.{ext}',dpi=160,bbox_inches='tight',facecolor='#faf9f5')
        plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(13,6),gridspec_kw={'width_ratios':[1.35,1]},layout='constrained')
    scatter=draw_network(axes[0],base,language)
    axes[0].set_title(tr('几何位置、节点电势与边电流','Geometry, node potential, and edge current'))
    fig.colorbar(scatter,ax=axes[0],label=tr('电势 / V','Potential / V'),shrink=.65)
    im=axes[1].imshow(base['adjacency_uS'],cmap='Blues',vmin=0,vmax=1)
    axes[1].set(xticks=range(13),yticks=range(13),xlabel=tr('节点编号','Node index'),ylabel=tr('节点编号','Node index'),title=tr('同一网络的加权邻接矩阵','Weighted adjacency of the same network'))
    axes[1].tick_params(labelsize=12.5);fig.colorbar(im,ax=axes[1],label=tr('边电导 / μS','Edge conductance / μS'),shrink=.65)
    save(fig,'network-and-matrix')
    scenarios=[find(False,'none'),find(False,'2-6'),find(False,'5-12'),find(True,'2-6')]
    titles=[tr('原网络','Original'),tr('移除2–6','Remove 2–6'),tr('移除5–12','Remove 5–12'),tr('增加5–9后移除2–6','Add 5–9, then remove 2–6')]
    fig=plt.figure(figsize=(13,10),layout='constrained');gs=fig.add_gridspec(3,2,height_ratios=[1.2,1.2,.85])
    for j,state in enumerate(scenarios):
        ax=fig.add_subplot(gs[j//2,j%2]);draw_network(ax,state,language)
        ax.set_title('ABCD'[j]+'  '+titles[j]+f"\nG = {state['effective_conductance_uS']:.4f} μS",fontsize=14)
    ax=fig.add_subplot(gs[2,0]);other=fig.add_subplot(gs[2,1])
    colors=['#205b8c','#b64d34','#82949e','#2b7c73']
    ax.bar(range(4),[s['effective_conductance_uS'] for s in scenarios],color=colors)
    other.bar(range(4),[s['largest_component'] for s in scenarios],color=colors)
    for axis in [ax,other]:axis.set_xticks(range(4),['A','B','C','D'])
    ax.set_ylabel(tr('端到端电导 / μS','End-to-end conductance / μS'));other.set(ylabel=tr('最大连通分量节点数','Nodes in largest component'),ylim=(0,14))
    for j,state in enumerate(scenarios):
        ax.text(j,state['effective_conductance_uS']+.008,f"{state['effective_conductance_uS']:.3f}",ha='center',fontsize=12)
        other.text(j,state['largest_component']+.3,str(state['largest_component']),ha='center',fontsize=12)
    save(fig,'removal-and-redundancy')
    fig=plt.figure(figsize=(13,7.5),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1.7,1])
    ax=fig.add_subplot(gs[:,0]);degree_ax=fig.add_subplot(gs[0,1]);text_ax=fig.add_subplot(gs[1,1]);text_ax.axis('off')
    positions={'A':(0,0),'B':(-1.7,1.6),'C':(-1.7,-1.6),'D':(1.8,0)}
    edges=[('A','B',.18),('A','B',-.18),('A','C',.18),('A','C',-.18),('A','D',0),('B','D',-.18),('C','D',.18)]
    historic=nx.MultiGraph();historic.add_edges_from((u,v) for u,v,_ in edges)
    for j,(u,v,rad) in enumerate(edges):
        ax.add_patch(FancyArrowPatch(positions[u],positions[v],connectionstyle=f'arc3,rad={rad}',arrowstyle='-',
                     color='#b64d34' if j==6 else '#205b8c',linewidth=3,linestyle='--' if j==6 else '-',shrinkA=25,shrinkB=25))
    for node,(x,y) in positions.items():
        ax.scatter(x,y,s=1500,color='#e3ebee',edgecolor='#172534',zorder=3)
        ax.text(x,y,node,ha='center',va='center',fontsize=19)
        ax.text(x,y-.40,tr('度数 ','degree ')+str(historic.degree[node]),ha='center',fontsize=13,
                bbox=dict(facecolor='#faf9f5',edgecolor='none',pad=1.5),zorder=5)
    ax.set(xlim=(-2.5,2.6),ylim=(-2.4,2.5));ax.set_aspect('equal');ax.axis('off')
    ax.set_title(tr('Euler七桥问题：保留四块陆地与七条连接','Euler’s seven bridges: four regions, seven links'),fontsize=14)
    degree_ax.barh(list(historic),[historic.degree[n] for n in historic],color='#205b8c');degree_ax.set(xlabel=tr('关联桥的条数','Number of incident bridges'),xticks=range(6),title=tr('四个节点的度数都为奇数','All four vertices have odd degree'))
    text_ax.text(0,.95,'Euler · E53 · 1741',fontsize=20,weight='bold',transform=text_ax.transAxes)
    text_ax.text(0,.64,'A → B → A → C → A → D → B',fontsize=15,color='#205b8c',transform=text_ax.transAxes)
    text_ax.text(0,.34,tr('已走六座桥；停在B，余下C–D\n经过中间节点，进入与离开必须成对。','Six bridges used; at B, C–D remains.\nAt an intermediate vertex, arrivals pair with departures.'),fontsize=14,linespacing=1.8,transform=text_ax.transAxes)
    save(fig,'euler-bridge-parity')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,default=Path('results'))
    parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    states=[]
    for bypass in [False,True]:
        graph=build_graph(bypass)
        for removed in ['none']+sorted(edge_id(u,v) for u,v in graph.edges):states.append(analyze(bypass,removed))
    base=states[0];bridge=next(s for s in states if not s['bypass'] and s['removed']=='2-6');leaf=next(s for s in states if not s['bypass'] and s['removed']=='5-12')
    assert base['nodes']==13 and base['edges']==18 and base['bridges']==['2-6','5-12']
    assert bridge['largest_component']==7 and bridge['component_count']==2 and abs(bridge['effective_conductance_uS'])<1e-12
    assert leaf['largest_component']==12 and abs(leaf['effective_conductance_uS']-base['effective_conductance_uS'])<1e-12
    assert abs(base['current_uA']['5-12'])<1e-12
    graph=build_graph(True)
    nodes=[{'id':n,**graph.nodes[n]} for n in graph]
    edges=[{'u':u,'v':v,**attr,'bypass':edge_id(u,v)==edge_id(*BYPASS)} for u,v,attr in graph.edges(data=True)]
    pd.DataFrame(nodes).to_csv(args.output/'nodes.csv',index=False);pd.DataFrame(edges).to_csv(args.output/'edges.csv',index=False)
    pd.DataFrame([{k:s[k] for k in ['bypass','removed','edges','component_count','largest_component','route_length_um','effective_conductance_uS']} for s in states]).to_csv(args.output/'removal-comparison.csv',index=False)
    (args.output/'lab-data.json').write_text(json.dumps({'nodes':nodes,'edges':edges,'states':states}),encoding='utf8')
    summary={'data_identity':'constructed 13-node resistor-network teaching model','states':len(states),'baseline':base,'bridge_removed':bridge,'leaf_removed':leaf}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    figures(states,args.output,args.language)
    print(json.dumps({'nodes':base['nodes'],'edges':base['edges'],'states':len(states),'conductance_uS':base['effective_conductance_uS'],'route':base['route'],'route_length_um':base['route_length_um'],'bridges':base['bridges'],'imbalance_uA':base['max_internal_current_imbalance_uA']}))


if __name__=='__main__':main()
