# Public sources and third-party materials

- Python Tutorial — Virtual Environments and Packages: https://docs.python.org/3.14/tutorial/venv.html
  PSF License
- Python Packaging User Guide — Installing packages using pip and virtual environments: https://packaging.python.org/en/latest/guides/installing-using-pip-and-virtual-environments/
  CC BY-SA 3.0 documentation; no adapted prose reproduced
- Python Tutorial — Modules: https://docs.python.org/3.14/tutorial/modules.html
  PSF License
- Software Carpentry — Errors and Exceptions: https://swcarpentry.github.io/python-novice-inflammation/09-errors.html
  CC BY 4.0 lessons; MIT code
- PEP 405 — Python Virtual Environments: https://peps.python.org/pep-0405/
  Public domain
- Python — Downloads and platform installation: https://www.python.org/downloads/
  Python Software Foundation website; factual installation reference.
