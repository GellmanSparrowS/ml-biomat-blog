"""Mass density of a rectangular specimen with explicit length units."""
import math


def density(mass_g, length, width, thickness, length_unit='mm'):
    """Return density in g/cm^3 and volume in cm^3.

    All three lengths share length_unit, either mm or cm.
    Mass and lengths must be finite and strictly positive.
    """
    factors_to_cm={'mm':0.1,'cm':1.0}
    if length_unit not in factors_to_cm:
        raise ValueError('length_unit must be mm or cm')
    for name,value in [('mass_g',mass_g),('length',length),('width',width),('thickness',thickness)]:
        if not math.isfinite(value) or value<=0:
            raise ValueError(f'{name} must be finite and positive')
    factor=factors_to_cm[length_unit]
    volume_cm3=(length*factor)*(width*factor)*(thickness*factor)
    return {'density_g_per_cm3':mass_g/volume_cm3,'volume_cm3':volume_cm3}
