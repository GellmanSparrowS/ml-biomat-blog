"""Run a local module, inspect its runtime, and diagnose a specimen calculation."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import math
import platform
import sys
import traceback
import textwrap
from calibration import density
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, FancyArrowPatch, Polygon


def analyze_specimen(thickness):
    return density(mass_g=.2,length=10,width=8,thickness=thickness,length_unit='mm')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('output'));parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    baseline=analyze_specimen(2)
    converted=density(.2,1,.8,.2,length_unit='cm')
    assert math.isclose(baseline['density_g_per_cm3'],1.25)
    assert math.isclose(baseline['volume_cm3'],.16)
    assert math.isclose(converted['density_g_per_cm3'],baseline['density_g_per_cm3'])
    assert math.isclose(density(.4,10,8,2)['density_g_per_cm3'],2.5)
    try:
        analyze_specimen(0)
    except ValueError as error:
        failure={'type':type(error).__name__,'message':str(error),'frames':[{'file':Path(frame.filename).name,'function':frame.name,'line':frame.lineno,'statement':frame.line} for frame in traceback.extract_tb(error.__traceback__)]}
    else:
        raise AssertionError('Zero thickness should trigger its input check')
    runtime={'python':platform.python_version(),'implementation':platform.python_implementation(),'executable_name':Path(sys.executable).name,'virtual_environment':sys.prefix!=sys.base_prefix,'matplotlib':importlib.metadata.version('matplotlib')}
    thicknesses=[.5+i*.025 for i in range(141)]
    densities=[analyze_specimen(h)['density_g_per_cm3'] for h in thicknesses]
    unchecked_density=.2/(10*8*2)
    zh=args.language=='zh'
    def tr(z,e):return z if zh else e
    fonts={f.name for f in font_manager.fontManager.ttflist};family=next((f for f in ['Microsoft YaHei','Noto Sans CJK SC','DejaVu Sans'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[family,'DejaVu Sans'] if zh else ['DejaVu Sans','Arial'],'font.size':12,'axes.titlesize':15,'axes.titleweight':'bold','svg.fonttype':'none','figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','text.color':'#172b36','axes.labelcolor':'#172b36','axes.spines.top':False,'axes.spines.right':False})
    blue,red,green,ink='#28648a','#b85336','#467a62','#172b36'
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg',bbox_inches='tight');fig.savefig(args.output/f'{name}-{args.language}.png',dpi=180,bbox_inches='tight');plt.close(fig)

    fig=plt.figure(figsize=(12,7.8),layout='constrained');ax=fig.add_subplot();ax.axis('off');ax.set_xlim(0,12);ax.set_ylim(0,8)
    ax.text(.2,7.55,tr('PEP 405：把项目依赖分开，同时复用基础Python','PEP 405: separate project packages, reuse a base Python'),fontsize=18,weight='bold')
    ax.text(.2,6.95,tr('2011年提出；随Python 3.3加入标准库。下图表示结构，不指定示意项目的实际版本。','Proposed in 2011; included with Python 3.3. Diagram shows structure, not measured project versions.'),fontsize=12)
    for i,label in enumerate([tr('项目 A','Project A'),tr('项目 B','Project B')]):
        x=.3+i*6;ax.add_patch(Rectangle((x,2.9),5.1,3.3,facecolor=blue if i==0 else green,alpha=.08));ax.text(x+.2,5.72,label,fontsize=19,weight='bold')
        ax.text(x+.2,5.03,tr('环境自己的解释器入口','Environment interpreter entry'),fontsize=14)
        ax.text(x+.2,4.3,'python -m pip',fontsize=17,color=blue if i==0 else green)
        ax.text(x+.2,3.6,tr('本环境的 site-packages','This environment’s site-packages'),fontsize=14)
        ax.add_patch(FancyArrowPatch((x+2.55,2.85),(6,1.75),arrowstyle='->',mutation_scale=20,lw=2,color=blue if i==0 else green))
    ax.add_patch(Rectangle((2.5,.65),7,1.1,facecolor='#d9dfd9'));ax.text(6,1.15,tr('基础Python与共享的标准库','Base Python and shared standard library'),ha='center',fontsize=17)
    ax.text(.3,.1,tr('环境改变导入位置；数据文件、分析脚本和科学单位仍需明确。','An environment changes import locations; data, scripts, and scientific units remain explicit.'),fontsize=12)
    save(fig,'environment-history')

    fig=plt.figure(figsize=(12,7.3),layout='constrained');gs=fig.add_gridspec(1,2,width_ratios=[1,1.25])
    ax=fig.add_subplot(gs[0]);ax.set_aspect('equal');ax.set_xlim(-1,12);ax.set_ylim(-2,12)
    ax.add_patch(Rectangle((0,3),10,8,facecolor=blue,alpha=.16,edgecolor=blue,lw=2));ax.add_patch(Rectangle((0,0),10,2,facecolor=green,alpha=.18,edgecolor=green,lw=2))
    ax.text(5,7,tr('上视图：10 × 8 mm','Top view: 10 × 8 mm'),ha='center',fontsize=14);ax.text(5,1,tr('侧视图：厚度2 mm','Side view: thickness 2 mm'),ha='center',va='center',fontsize=13)
    ax.set(xlabel=tr('长度坐标 / mm','Length coordinate / mm'),ylabel=tr('示意平面坐标 / mm','Diagram coordinate / mm'),title=tr('a  定义体积所需的三种长度','a  Three lengths define the volume'));ax.grid(alpha=.12)
    ax=fig.add_subplot(gs[1]);ax.plot(thicknesses,densities,color=blue,lw=2.5)
    for h in [1,2,4]:
        value=analyze_specimen(h)['density_g_per_cm3'];ax.scatter(h,value,color=red,s=65);ax.annotate(f'{h:g} mm → {value:g} g/cm³',(h,value),xytext=(h-.25 if h<4 else 2.9,value+.35),fontsize=12,bbox={'facecolor':'#fbfaf6','edgecolor':'none','alpha':.9,'pad':2})
    ax.set(xlabel=tr('厚度 / mm','Thickness / mm'),ylabel=tr('质量密度 / g·cm⁻³','Mass density / g·cm⁻³'),title=tr('b  同一质量下，厚度决定体积','b  Thickness changes volume at fixed mass'),ylim=(0,5.5),xlim=(.4,4.7));ax.grid(alpha=.15)
    ax.text(1.3,4.5,tr('质量0.20 g；长10 mm；宽8 mm','Mass 0.20 g; length 10 mm; width 8 mm'),fontsize=11)
    save(fig,'density-sensitivity')

    fig=plt.figure(figsize=(12,9),layout='constrained');gs=fig.add_gridspec(2,1,height_ratios=[1.65,1]);ax=fig.add_subplot(gs[0]);ax.axis('off');ax.set_xlim(0,12);ax.set_ylim(0,5.5)
    ax.text(.1,5.2,tr('a  实际捕获的调用路径：厚度0 mm','a  Captured call path: thickness 0 mm'),fontsize=17,weight='bold')
    for i,frame in enumerate(failure['frames']):
        y=4.55-i*1.25;ax.text(.2,y,f"{frame['file']}:{frame['line']}  |  {frame['function']}",fontsize=13,color=blue);ax.text(.45,y-.35,textwrap.fill(frame['statement'],width=88),fontsize=10.5,va='top')
    ax.text(.2,.35,f"{failure['type']}: {failure['message']}",fontsize=16,color=red)
    ax=fig.add_subplot(gs[1]);labels=[tr('统一成cm后计算','Convert to cm before calculating'),tr('mm³数值误标成cm³','Mislabel numerical mm³ as cm³')];values=[baseline['density_g_per_cm3'],unchecked_density]
    ax.scatter(values,[1,0],s=100,color=[blue,red]);ax.plot(values,[1,0],color='#aab5b2',ls='--');ax.set_xscale('log');ax.set(yticks=[1,0],yticklabels=labels,xlabel=tr('被报告的密度数值 / g·cm⁻³','Reported density value / g·cm⁻³'),xlim=(.0005,5),ylim=(-.5,1.5),title=tr('b  没有异常的计算，也要核对单位','b  Check units even when arithmetic completes'));ax.grid(axis='x',alpha=.15)
    for value,y in zip(values,[1,0]):ax.annotate(f'{value:g}',(value,y),xytext=(8,12),textcoords='offset points',fontsize=14)
    ax.text(.015,.5,tr('相差1000倍','A factor of 1000'),fontsize=15,color=red)
    save(fig,'diagnostic-evidence')
    summary={'dataset':'Constructed rectangular specimen','inputs':{'mass_g':.2,'length_mm':10,'width_mm':8,'thickness_mm':2},'baseline':baseline,'same_specimen_in_cm':converted,'incorrect_density_if_mm3_labeled_cm3':unchecked_density,'unit_error_factor':baseline['density_g_per_cm3']/unchecked_density,'runtime':runtime,'captured_failure':failure,'source_sha256':{n:hashlib.sha256((Path(__file__).parent/n).read_bytes()).hexdigest() for n in ['main.py','calibration.py']}}
    (args.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
    (args.output/'runtime.json').write_text(json.dumps(runtime,indent=2),encoding='utf8')
    print(json.dumps({'baseline':baseline,'runtime':runtime,'failure_type':failure['type'],'unit_error_factor':summary['unit_error_factor']},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
