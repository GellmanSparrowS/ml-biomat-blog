PDB 1BRS, deposited barnase–barstar crystal structure

File: 1BRS.cif
Download: https://files.rcsb.org/download/1BRS.cif
Entry: https://www.rcsb.org/structure/1BRS
PDB DOI: https://doi.org/10.2210/pdb1BRS/pdb
SHA-256: 1c98dcc3eac7ccb88657e3ab0f745121d7ddbd2fe11357c65dbaffdd5704f153

Primary structural reference: Buckle AM, Schreiber G, Fersht AR (1994).
Protein-protein recognition: crystal structural analysis of a barnase-barstar
complex at 2.0-A resolution. Biochemistry 33, 8878–8889.
https://doi.org/10.1021/bi00196a004

PDB archive data: CC0 1.0 Universal Public Domain Dedication.
Policy: https://www.rcsb.org/pages/policies
The original structural record is included unchanged. Figures and derived
residue tables are generated from these coordinates and deposited sequences.
