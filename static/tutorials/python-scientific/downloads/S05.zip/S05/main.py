"""Connect deposited protein sequences to observed alpha-carbon coordinates.

Public input: PDB 1BRS (CC0), Buckle, Schreiber and Fersht (1994),
doi:10.1021/bi00196a004. Run: python main.py --output results --language en
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import ListedColormap
import numpy as np
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.SeqUtils import seq1
from Bio.PDB import MMCIFParser, Superimposer
from Bio.PDB.MMCIF2Dict import MMCIF2Dict

BLUE,ORANGE,GREEN,INK='#235b89','#bf5635','#177d72','#192b3a'
INPUT=Path(__file__).resolve().parent/'data'/'1BRS.cif'


def available_plot_fonts():
    choices=['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans']
    installed={font.name for font in font_manager.fontManager.ttflist}
    return [name for name in choices if name in installed]


def read_chains(path):
    data=MMCIF2Dict(str(path))
    sequence={entity:''.join(text.split()) for entity,text in zip(
        data['_entity_poly.entity_id'],data['_entity_poly.pdbx_seq_one_letter_code_can'])}
    chains={chain:{'id':chain,'entity':entity,'sequence':sequence[entity],
        'protein':'barnase' if entity=='1' else 'barstar', 'residues':[]}
        for chain,entity in zip(data['_struct_asym.id'],data['_struct_asym.entity_id']) if entity in sequence}
    parser=MMCIFParser(QUIET=True,auth_chains=False,auth_residues=False)
    structure=parser.get_structure('1BRS',str(path))
    selected={}
    count=len(data['_atom_site.id'])
    for row in range(count):
        get=lambda name:data['_atom_site.'+name][row]
        if get('pdbx_PDB_model_num')!='1' or get('label_atom_id')!='CA': continue
        chain,position=get('label_asym_id'),get('label_seq_id')
        if chain not in chains or position in ('.','?'): continue
        position=int(position)
        candidate={'position':position,'resname':get('label_comp_id'),
            'letter':seq1(get('label_comp_id')),'author_chain':get('auth_asym_id'),
            'author_number':get('auth_seq_id'),'insertion_code':get('pdbx_PDB_ins_code'),
            'altloc':get('label_alt_id'),'occupancy':float(get('occupancy')),
            'xyz_A':[float(get('Cartn_'+axis)) for axis in 'xyz'],
            'bfactor_A2':float(get('B_iso_or_equiv'))}
        key=(chain,position)
        if key not in selected or candidate['occupancy']>selected[key]['occupancy']:
            selected[key]=candidate
    maximum_error=0.
    for chain,record in chains.items():
        for position,letter in enumerate(record['sequence'],1):
            observed=selected.get((chain,position))
            if observed:
                assert observed['letter']==letter
                atom=structure[0][chain][position]['CA']
                maximum_error=max(maximum_error,float(np.max(np.abs(atom.coord-np.array(observed['xyz_A'])))))
            record['residues'].append(observed or {'position':position,'letter':letter,'xyz_A':None,'bfactor_A2':None})
        record['observed_count']=sum(r['xyz_A'] is not None for r in record['residues'])
        record['missing']=[r['position'] for r in record['residues'] if r['xyz_A'] is None]
        xyz=np.array([r['xyz_A'] if r['xyz_A'] is not None else [np.nan]*3 for r in record['residues']])
        record['xyz']=xyz
        record['distances']=np.linalg.norm(xyz[:,None,:]-xyz[None,:,:],axis=-1)
    assert maximum_error<1e-5  # Parser coordinates are float32; mmCIF decimals are read as float64.
    return chains,structure,maximum_error


def contacts(record,cutoff=8.,separation=4):
    n=len(record['sequence']);positions=np.arange(1,n+1)
    mask=(record['distances']<=cutoff)&(np.abs(positions[:,None]-positions[None,:])>=separation)
    return np.argwhere(np.triu(mask,1))


def projection(xyz):
    # One fixed orthographic view, shared by each pair of overlaid structures.
    a,b=np.deg2rad([35.,25.])
    rz=np.array([[np.cos(a),-np.sin(a),0],[np.sin(a),np.cos(a),0],[0,0,1]])
    rx=np.array([[1,0,0],[0,np.cos(b),-np.sin(b)],[0,np.sin(b),np.cos(b)]])
    return xyz@rz.T@rx.T


def draw_trace(ax,xyz,color=BLUE,lw=1.8):
    p=projection(xyz)
    # NaN positions break the drawn trace at a missing coordinate.
    ax.plot(p[:,0],p[:,1],color=color,lw=lw)
    ax.set_aspect('equal');ax.set_xlabel('u / Å');ax.set_ylabel('v / Å')


def compare_copies(chains,structure):
    common=[i for i in range(1,90) if i not in chains['D']['missing']]
    fixed=[structure[0]['D'][i]['CA'] for i in common]
    moving=[structure[0]['F'][i]['CA'] for i in common]
    fit=Superimposer();fit.set_atoms(fixed,moving)
    rot,tran=fit.rotran
    transformed=chains['F']['xyz']@rot+tran
    delta=np.linalg.norm(chains['D']['xyz']-transformed,axis=1)
    rms=float(np.sqrt(np.nanmean(delta**2)))
    assert abs(rms-fit.rms)<1e-5
    return {'common_positions':common,'rotation':rot.tolist(),'translation_A':tran.tolist(),
            'rmsd_A':rms,'F_aligned_xyz_A':transformed.tolist(),
            'residue_deviation_A':[None if np.isnan(x) else float(x) for x in delta]}


def make_figures(chains,comparison,out,language):
    zh=language=='zh';tr=lambda cn,en:cn if zh else en
    plt.rcParams.update({'font.family':available_plot_fonts() if zh else ['DejaVu Sans'],
        'font.size':13,'axes.titlesize':15,'axes.labelsize':14,'svg.fonttype':'path',
        'figure.facecolor':'#faf9f6','axes.spines.top':False,'axes.spines.right':False})
    def save(fig,name):
        for ext in ('svg','png'):fig.savefig(out/f'{name}-{language}.{ext}',dpi=165,bbox_inches='tight')
        plt.close(fig)
    fig=plt.figure(figsize=(13,7.5),layout='constrained')
    gs=fig.add_gridspec(2,1,height_ratios=[1,.85])
    ax=fig.add_subplot(gs[0]);arr=np.full((6,110),np.nan)
    for row,record in enumerate(chains.values()):
        arr[row,:len(record['sequence'])]=1
        arr[row,np.array(record['missing'],dtype=int)-1]=0
    cm=ListedColormap([ORANGE,BLUE]);cm.set_bad('#e7e9e9')
    ax.imshow(arr,aspect='auto',interpolation='nearest',cmap=cm,vmin=0,vmax=1,extent=[.5,110.5,5.5,-.5])
    ax.set_yticks(range(6),[f"{r['id']} · {r['protein']}  {r['observed_count']}/{len(r['sequence'])}" for r in chains.values()])
    ax.set_xlabel(tr('沉积序列位置 label_seq_id','Deposited sequence position label_seq_id'))
    ax.set_title(tr('蓝：有 Cα 坐标；橙：缺少坐标；灰：超出该链序列','Blue: Cα present; orange: absent; gray: beyond this chain'))
    ax=fig.add_subplot(gs[1]);ax.set_xlim(59.5,70.5);ax.set_ylim(-.7,2.6)
    for row,chain in enumerate(['D','E','F']):
        r=chains[chain]
        for pos in range(60,71):
            missing=pos in r['missing']
            ax.add_patch(plt.Rectangle((pos-.46,row-.32),.92,.64,facecolor=ORANGE if missing else BLUE))
            ax.text(pos,row,r['sequence'][pos-1],color='white',ha='center',va='center',fontsize=16,weight='bold')
    ax.set_yticks(range(3),['D','E','F']);ax.set_xticks(range(60,71));ax.set_xlabel(tr('序列位置；字母仍保留在缺坐标的位置','Sequence position; letters remain at positions without coordinates'))
    ax.set_title(tr('放大内部缺口：64 E 与 65 N','Internal-gap detail: 64 E and 65 N'))
    save(fig,'sequence-coverage')

    r=chains['D'];fig=plt.figure(figsize=(13,9),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1.25,.65])
    ax=fig.add_subplot(gs[0,0]);draw_trace(ax,r['xyz']);p=projection(r['xyz'])
    values=np.array([x['bfactor_A2'] for x in r['residues']],dtype=float)
    dots=ax.scatter(p[:,0],p[:,1],c=values,cmap='viridis',vmin=0,vmax=70,s=25,zorder=3)
    for pos in (63,66):ax.scatter(*p[pos-1,:2],s=80,facecolor=ORANGE,edgecolor='white',zorder=5);ax.annotate(str(pos),p[pos-1,:2],xytext=(6,6),textcoords='offset points')
    ax.set_title(tr('D 链：Cα 轨迹与晶体模型 B 因子','Chain D: Cα trace and crystallographic B factor'))
    fig.colorbar(dots,ax=ax,shrink=.65,label='B / Å²')
    ax=fig.add_subplot(gs[0,1]);distance=np.ma.masked_invalid(r['distances']);cmap=plt.get_cmap('magma_r').copy();cmap.set_bad('#cbd3d8')
    im=ax.imshow(distance,origin='lower',extent=[.5,89.5,.5,89.5],cmap=cmap,vmin=0,vmax=45,interpolation='nearest')
    ax.set_xlabel(tr('序列位置 j','Sequence position j'));ax.set_ylabel(tr('序列位置 i','Sequence position i'))
    ax.set_title(tr('两点的真实三维距离','Actual three-dimensional point distance'))
    fig.colorbar(im,ax=ax,shrink=.65,label='d / Å')
    ax=fig.add_subplot(gs[1,:]);positions=np.arange(1,90)
    for chain,color in [('D',BLUE),('E',ORANGE),('F',GREEN)]:
        ax.plot(positions,[x['bfactor_A2'] for x in chains[chain]['residues']],color=color,lw=1.8,label=chain)
    ax.axvspan(63.5,65.5,color='#dbe1e5',alpha=.7);ax.set_xlabel(tr('barstar 序列位置','Barstar sequence position'));ax.set_ylabel('Cα B / Å²');ax.legend(ncol=3);ax.grid(alpha=.16)
    save(fig,'structure-and-distance')

    fig=plt.figure(figsize=(13,8),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[.62,1])
    ax=fig.add_subplot(gs[0,:]);ax.axis('off')
    columns=['label_seq_id',tr('序列字母','Sequence letter'),tr('D 链有 Cα？','Cα in D?'),tr('坐标列表行号（从 1 开始）','Coordinate-list row (one-based)')]
    cell=[]
    observed=[x['position'] for x in r['residues'] if x['xyz_A'] is not None]
    for pos in range(62,68):cell.append([pos,r['sequence'][pos-1],tr('有','Yes') if pos in observed else tr('缺少','Absent'),observed.index(pos)+1 if pos in observed else '—'])
    table=ax.table(cellText=cell,colLabels=columns,cellLoc='center',bbox=[0,.03,1,.94],colWidths=[.19,.18,.18,.45]);table.auto_set_font_size(False);table.set_fontsize(13)
    for (i,j),c in table.get_celld().items():
        c.set_edgecolor('#d4dde2')
        if i==0:c.set_facecolor('#dce9ee')
        elif i in (3,4):c.set_facecolor('#f5dfd7')
    ax=fig.add_subplot(gs[1,0]);fxyz=np.array(comparison['F_aligned_xyz_A']);draw_trace(ax,r['xyz'],BLUE);draw_trace(ax,fxyz,GREEN,lw=1.3)
    p=projection(fxyz)
    for pos in (64,65):ax.scatter(*p[pos-1,:2],color=ORANGE,s=90,zorder=8);ax.annotate(f'F:{pos}',p[pos-1,:2],xytext=(7,7 if pos==64 else -17),textcoords='offset points',color=ORANGE)
    ax.set_title(tr('D（蓝）与对齐后的 F（绿）','D (blue) and aligned F (green)'))
    ax=fig.add_subplot(gs[1,1]);ax.axis('off')
    lines=[(tr('序列位置 ↔ 空间坐标','Sequence positions ↔ coordinates'),15),
           (tr('1958 · Sanger：胰岛素序列','1958 · Sanger: insulin sequence'),14),
           (tr('1960 · Kendrew 等：肌红蛋白结构','1960 · Kendrew: myoglobin structure'),14),
           (tr('1971 · PDB：初始收录 7 个结构','1971 · PDB: seven initial structures'),14),
           (tr('1BRS D/F：沉积序列相同','1BRS D/F: same deposited sequence'),14),
           (tr(f'D/F：87 个共同 Cα；RMSD {comparison["rmsd_A"]:.3f} Å',f'D/F: 87 common Cα; RMSD {comparison["rmsd_A"]:.3f} Å'),14),
           (tr('橙色 64/65：F 链有坐标，D 链空缺','F:64/65 have coordinates; D:64/65 absent'),14)]
    for k,(text,size) in enumerate(lines):ax.text(0,.97-k*.135,text,fontsize=size,va='top',color=INK,weight='bold' if k==0 else 'normal')
    save(fig,'mapping-and-history')


def clean(value):
    if isinstance(value,np.ndarray):return clean(value.tolist())
    if isinstance(value,dict):return {k:clean(v) for k,v in value.items()}
    if isinstance(value,list):return [clean(v) for v in value]
    if isinstance(value,float) and not np.isfinite(value):return None
    return value


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('results'));parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    chains,structure,coordinate_error=read_chains(INPUT)
    records=[SeqRecord(Seq(r['sequence']),id='1BRS_'+r['id'],description=r['protein']+' deposited polymer sequence') for r in chains.values()]
    fasta=args.output/'deposited-sequences.fasta';SeqIO.write(records,fasta,'fasta')
    reread=SeqIO.to_dict(SeqIO.parse(fasta,'fasta'));assert all(str(reread[r.id].seq)==str(r.seq) for r in records)
    fields=['chain','position','letter','observed_CA','author_chain','author_number','insertion_code','bfactor_A2','x_A','y_A','z_A']
    with (args.output/'residue-map.csv').open('w',encoding='utf8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader()
        for chain,record in chains.items():
            for r in record['residues']:
                row={k:r.get(k) for k in fields};row.update(chain=chain,observed_CA=r['xyz_A'] is not None)
                for axis,v in zip('xyz',r['xyz_A'] or [None]*3):row[axis+'_A']=v
                writer.writerow(row)
    comparison=compare_copies(chains,structure)
    summary={'pdb_id':'1BRS','source_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),
        'parser_coordinate_max_difference_A':coordinate_error,
        'chains':{key:{'length':len(r['sequence']),'observed_CA':r['observed_count'],'missing':r['missing'],
                  'coverage':r['observed_count']/len(r['sequence']),'contacts_8A_sep4':len(contacts(r))} for key,r in chains.items()},
        'D_62_63_distance_A':float(chains['D']['distances'][61,62]),
        'D_63_66_distance_A':float(chains['D']['distances'][62,65]),'DF_common_CA':87,'DF_rmsd_A':comparison['rmsd_A']}
    (args.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    payload={'chains':chains,'comparison':comparison,'bfactor_colors':(plt.get_cmap('viridis')(np.linspace(0,1,256))[:,:3]*255).round().astype(int).tolist()}
    (args.output/'lab-data.json').write_text(json.dumps(clean(payload),ensure_ascii=False),encoding='utf8')
    make_figures(chains,comparison,args.output,args.language)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
