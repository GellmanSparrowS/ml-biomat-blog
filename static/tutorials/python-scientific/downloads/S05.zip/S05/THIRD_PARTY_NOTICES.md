# Public sources and third-party materials

- Biopython Tutorial: Going 3D: https://biopython.org/docs/latest/Tutorial/chapter_pdb.html
  Biopython License Agreement covers software and documentation; some files offer BSD 3-Clause as an alternative.
- Biopython Tutorial: Sequence Input/Output: https://biopython.org/docs/latest/Tutorial/chapter_seqio.html
  Biopython License Agreement.
- PDB 1BRS: barnase–barstar complex: https://www.rcsb.org/structure/1BRS
  PDB archive data: CC0 1.0.
- Buckle, Schreiber and Fersht (1994): https://doi.org/10.1021/bi00196a004
  American Chemical Society journal article.
- wwPDB: label_seq_id and author numbering: https://mmcif.wwpdb.org/dictionaries/mmcif_pdbx_v50.dic/Items/_atom_site.auth_seq_id.html
  wwPDB dictionary reference.
- Sanger (1958): The Chemistry of Insulin: https://www.nobelprize.org/prizes/chemistry/1958/sanger/lecture/
  Nobel lecture; historical reference.
- Kendrew et al. (1960): Structure of Myoglobin: https://doi.org/10.1038/185422a0
  Nature journal article.
- RCSB PDB History: https://www.rcsb.org/pages/about-us/history
  RCSB website content: CC BY 4.0.
