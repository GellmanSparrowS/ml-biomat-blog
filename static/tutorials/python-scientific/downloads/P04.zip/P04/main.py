"""Trace reusable calculations over a small set of teaching specimens."""
from pathlib import Path
import argparse
import json
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, FancyArrowPatch


def uptake(dry_g, wet_g):
    """Return retained-liquid mass per dry mass, or None if wet mass is absent.

    Masses are net specimen masses in grams. This example assumes no loss
    of dry material. Invalid mass accounting raises ValueError.
    """
    if not math.isfinite(dry_g) or dry_g <= 0:
        raise ValueError("dry_g must be finite and positive")
    if wet_g is None:
        return None
    if not math.isfinite(wet_g) or wet_g < dry_g:
        raise ValueError("wet_g must be finite and at least dry_g")
    return (wet_g - dry_g) / dry_g


def summarize(values):
    """Return the count and equally weighted mean of available values."""
    valid = [value for value in values if value is not None]
    return {"valid_count": len(valid),
            "mean": math.fsum(valid) / len(valid) if valid else None}


def analyze(records):
    """Return new result records and an execution trace, preserving inputs."""
    results, trace, available = [], [], []
    for step, record in enumerate(records, start=1):
        item = record.copy()
        try:
            value = uptake(record["dry_g"], record["wet_g"])
            status = "missing" if value is None else "valid"
            reason = "wet mass absent" if value is None else "calculated"
        except ValueError as error:
            value, status, reason = None, "invalid", str(error)
        item.update(uptake_g_per_g=value, status=status, reason=reason)
        results.append(item)
        if value is not None:
            available.append(value)
        trace.append({"step": step, "id": record["id"], "status": status,
                      "returned": value, "valid_count": len(available),
                      "sum": math.fsum(available),
                      "mean": summarize(available)["mean"]})
    return results, trace


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("output"))
    parser.add_argument("--language", choices=["zh", "en"], default="en")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    zh = args.language == "zh"
    def tr(a, b): return a if zh else b
    records = [
        {"id":"A01", "dry_g":1.2, "wet_g":4.8},
        {"id":"A02", "dry_g":1.0, "wet_g":3.4},
        {"id":"A03", "dry_g":0.8, "wet_g":2.8},
        {"id":"B01", "dry_g":1.2, "wet_g":3.6},
        {"id":"B02", "dry_g":1.0, "wet_g":None},
        {"id":"B03", "dry_g":0.8, "wet_g":2.32},
    ]
    results, trace = analyze(records)
    assert math.isclose(uptake(1.2, 4.8), 3.0)
    assert math.isclose(uptake(2.4, 9.6), uptake(1.2, 4.8))
    assert uptake(1.0, 1.0) == 0.0
    assert uptake(1.0, None) is None
    assert summarize([]) == {"valid_count": 0, "mean": None}
    invalid_examples = []
    for dry, wet in [(0.0, 1.0), (1.0, 0.5), (float("nan"), 2.0)]:
        try:
            uptake(dry, wet)
        except ValueError as error:
            invalid_examples.append({"reason": str(error)})
        else:
            raise AssertionError("An invalid input was accepted")
    assert "status" not in records[0]
    fonts = {f.name for f in font_manager.fontManager.ttflist}
    family = next((f for f in ["Noto Sans CJK SC", "Microsoft YaHei", "DejaVu Sans"] if f in fonts), "DejaVu Sans")
    plt.rcParams.update({"font.family":[family,"DejaVu Sans"] if zh else ["DejaVu Sans","Arial"],"font.size":12,"axes.titlesize":15,"axes.titleweight":"bold","svg.fonttype":"none","figure.facecolor":"#fbfaf6","axes.facecolor":"#fbfaf6","text.color":"#172b36","axes.labelcolor":"#172b36","axes.spines.top":False,"axes.spines.right":False})
    ink, blue, red, green = "#172b36", "#28648a", "#b85336", "#467a62"
    def save(fig, name):
        fig.savefig(args.output/f"{name}-{args.language}.svg", bbox_inches="tight")
        fig.savefig(args.output/f"{name}-{args.language}.png", dpi=180, bbox_inches="tight")
        plt.close(fig)

    fig = plt.figure(figsize=(12,8), layout="constrained")
    gs = fig.add_gridspec(2,1,height_ratios=[1.4,1])
    ax = fig.add_subplot(gs[0]);ax.axis("off");ax.set_xlim(0,12);ax.set_ylim(0,7)
    ax.text(.15,6.6,tr("a  每次循环保留输入、分支与返回值","a  Each iteration retains inputs, branch, and return"),fontsize=17,weight="bold")
    headers=[tr("步骤","Step"),"ID",tr("干 / 湿质量 (g)","Dry / wet mass (g)"),tr("分支","Branch"),tr("返回 (g/g)","Return (g/g)"),tr("有效计数","Valid count")]
    xs=[.2,1.2,2.5,6.2,8.4,10.5]
    for x,h in zip(xs,headers):ax.text(x,5.8,h,fontsize=12,weight="bold")
    for i,(r,t) in enumerate(zip(records,trace)):
        y=5.1-i*.75;color=red if t["status"]=="missing" else blue
        ax.add_patch(Rectangle((.1,y-.2),11.7,.65,color=color,alpha=.065))
        wet="None" if r['wet_g'] is None else f"{r['wet_g']:.2f}"
        vals=[str(i+1),r['id'],f"{r['dry_g']:.2f} / {wet}",tr("缺失","Missing") if t['status']=='missing' else tr("计算","Calculate"),'None' if t['returned'] is None else f"{t['returned']:.2f}",str(t['valid_count'])]
        for x,v in zip(xs,vals):ax.text(x,y,v,color=color,fontsize=13)
    ax = fig.add_subplot(gs[1]);steps=[t['step'] for t in trace]
    ax.plot(steps,[t['mean'] for t in trace],color=blue,marker='o',lw=2,label=tr('累计样品均值','Running specimen mean'))
    ax.axvspan(4.7,5.3,color=red,alpha=.1)
    ax.annotate(tr('第5条缺失：计数与均值保持','Record 5 missing: count and mean unchanged'),(5,trace[4]['mean']),xytext=(3.0,3.15),arrowprops={'arrowstyle':'->','color':red},fontsize=12,color=red)
    ax.set(xticks=steps,xlabel=tr('已处理记录数','Records processed'),ylabel=tr('累计均值 / g·g⁻¹','Running mean / g·g⁻¹'),ylim=(2.2,3.35),title=tr('b  跟踪计算顺序；不是随时间的吸液曲线','b  A computational trace, not an uptake time curve'));ax.grid(alpha=.15)
    save(fig,'execution-trace')

    fig=plt.figure(figsize=(12,6.7),layout='constrained');gs=fig.add_gridspec(1,2,width_ratios=[1.2,1])
    ax=fig.add_subplot(gs[0]);dry_values=[.5+i*.025 for i in range(61)];wet_values=[.5+i*.05 for i in range(111)]
    field=[[uptake(d,w) if w>=d else math.nan for d in dry_values] for w in wet_values]
    mesh=ax.pcolormesh(dry_values,wet_values,field,shading='auto',cmap='cividis',vmin=0,vmax=11)
    contours=ax.contour(dry_values,wet_values,field,levels=[0.5,1,2,3,5,8],colors='white',linewidths=.8)
    ax.clabel(contours,fmt='%g',fontsize=11);ax.plot([.5,2],[.5,2],color=red,lw=2)
    ax.text(1.1,.75,tr('检查质量账本','Check mass accounting'),color=red,fontsize=11,rotation=25)
    ax.scatter([1.2, .8],[4.8,3.2],s=80,facecolors='none',edgecolors='white',linewidths=2)
    ax.set(xlabel=tr('干质量 / g','Dry mass / g'),ylabel=tr('湿质量 / g','Wet mass / g'),title=tr('a  函数的输入平面与输出','a  An input plane and its output'))
    fig.colorbar(mesh,ax=ax,label=tr('吸液量 / g·g⁻¹','Uptake / g·g⁻¹'),shrink=.8)
    ax=fig.add_subplot(gs[1]);scales=[.5+i*.05 for i in range(31)]
    ax.plot(scales,[uptake(1.2*k,4.8*k) for k in scales],color=blue,lw=2)
    ax.scatter([.5,1,2],[3,3,3],s=65,color=blue)
    ax.set(xlabel=tr('同时缩放两种质量的倍数','Factor applied to both masses'),ylabel=tr('吸液量 / g·g⁻¹','Uptake / g·g⁻¹'),ylim=(0,4),title=tr('b  比一个答案更强的关系检查','b  Check a relationship, not one answer'))
    ax.text(.55,.65,tr('干、湿质量同时加倍\n相减结果与分母都加倍\n比值保持 3 g/g','Double both masses:\nthe difference and denominator\nboth double; the ratio stays 3 g/g'),fontsize=13)
    ax.grid(alpha=.15);save(fig,'function-domain')

    fig=plt.figure(figsize=(12,7),layout='constrained');ax=fig.add_subplot();ax.axis('off');ax.set_xlim(0,12);ax.set_ylim(0,7)
    ax.text(.2,6.65,tr('复用的关键：带着输入进入，带着结果返回','Reuse: enter with inputs, return with a result'),fontsize=19,weight='bold')
    ax.text(.2,6.05,tr('EDSAC：1948–49年的子程序研究 → 今天的函数调用示意','EDSAC subroutine work, 1948–49 → a modern function-call illustration'),fontsize=13)
    for i,(label,inputs,result) in enumerate([('A01','1.20 g, 4.80 g','3.00 g/g'),('A02','1.00 g, 3.40 g','2.40 g/g')]):
        y=4.9-i*2.5
        ax.add_patch(Rectangle((.3,y-.6),3.1,1.2,facecolor=blue,alpha=.1));ax.text(.5,y+.15,f'{label} → uptake(...)',fontsize=16);ax.text(.5,y-.3,inputs,fontsize=14)
        ax.add_patch(FancyArrowPatch((3.6,y+.25),(7.2,3.55),arrowstyle='->',connectionstyle=f'arc3,rad={-.2 if i==0 else .2}',mutation_scale=18,color=blue,lw=2))
        ax.add_patch(FancyArrowPatch((7.2,3.15),(3.6,y-.25),arrowstyle='->',connectionstyle=f'arc3,rad={.25 if i==0 else -.25}',mutation_scale=18,color=red,lw=2))
        ax.text(4.0,y+.3,tr('传入参数','Pass arguments'),fontsize=12,color=blue,bbox={'facecolor':'#fbfaf6','edgecolor':'none','pad':1.5})
        ax.text(4.0,y-.5,tr('返回','Return')+' '+result,fontsize=13,color=red,bbox={'facecolor':'#fbfaf6','edgecolor':'none','pad':1.5})
    ax.add_patch(Rectangle((7.4,2.35),4.2,2.3,facecolor=green,alpha=.1,edgecolor=green))
    ax.text(7.7,4.18,'def uptake(dry_g, wet_g):',fontsize=14,weight='bold')
    ax.text(7.7,3.6,tr('检查输入与缺失','Check inputs and missing data'),fontsize=14)
    ax.text(7.7,3.05,'return (wet_g - dry_g) / dry_g',fontsize=13)
    ax.text(.3,.45,tr('同一份定义；两次调用具有各自的局部参数。图为原理示意，并非EDSAC指令。','One definition; two calls with separate local parameters. Conceptual diagram, not EDSAC instructions.'),fontsize=12)
    save(fig,'subroutine-history')
    summary={'dataset':'Constructed six-specimen uptake records','record_count':len(records),**summarize([r['uptake_g_per_g'] for r in results]),'sum':math.fsum(r['uptake_g_per_g'] for r in results if r['uptake_g_per_g'] is not None),'missing_ids':[r['id'] for r in results if r['status']=='missing'],'invalid_examples':invalid_examples,'empty_summary':summarize([]),'scaling_check':uptake(2.4,9.6),'trace':trace}
    for name,data in [('summary',summary),('results',results),('records',records)]:
        (args.output/f'{name}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
    print(json.dumps({k:summary[k] for k in ['record_count','valid_count','sum','mean','missing_ids']},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
