# Public sources and third-party materials

- Software Carpentry — Writing Functions: https://swcarpentry.github.io/python-novice-gapminder/16-writing-functions.html
  CC BY 4.0, https://creativecommons.org/licenses/by/4.0/; original case, prose, code and figures.
- Python 3.14 — More Control Flow Tools: https://docs.python.org/3.14/tutorial/controlflow.html
  PSF documentation license; https://docs.python.org/3.14/license.html
- Python 3.14 — Errors and Exceptions: https://docs.python.org/3.14/tutorial/errors.html
  PSF documentation license
- University of Cambridge — A Brief Informal History of the Computer Laboratory: https://www.cl.cam.ac.uk/events/EDSAC99/history.html
  Historical factual reference; copyright University of Cambridge. Original diagram; no reproduced source illustration.
