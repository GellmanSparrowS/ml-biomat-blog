"""Select, calibrate, and normalize a constructed specimen-by-time array."""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, FancyArrowPatch

TIME=np.array([0,10,20,40,60],dtype=float)
H=np.array([[1,1.08,1.14,1.18,1.2],[1.02,1.09,1.16,1.21,1.24],[.98,1.05,1.11,1.15,1.18]],dtype=np.float64)
DRIFT=np.array([0,.01,.02,.03,.04])
NAMES=['A','B','C'];COLORS=['#28648a','#b85336','#467a62']

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('output'));parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    baseline=H[:,0:1]
    strain=H/baseline-1
    corrected=H-DRIFT[None,:]
    corrected_strain=corrected/corrected[:,0:1]-1
    selected=(TIME>=10)&(TIME<=40)
    selected_values=H[:,selected]
    qualifying=strain[:,-1]>=.21
    square=H[:,:3];wrong_square=square/H[:,0]-1;correct_square=square/baseline-1
    shared=H.copy();view=shared[:,1:4];isolated=shared[:,1:4].copy();advanced=shared[:,[1,2,3]]
    view[0,0]=9.0
    assert shared[0,1]==9 and isolated[0,0]==1.08 and advanced[0,0]==1.08
    independent=np.array([[float(H[i,j])/float(H[i,0])-1 for j in range(5)] for i in range(3)])
    assert np.allclose(strain,independent)
    assert np.allclose(corrected,[[float(H[i,j])-float(DRIFT[j]) for j in range(5)] for i in range(3)])
    assert qualifying.tolist()==[False,True,False]
    assert np.shares_memory(view,shared) and not np.shares_memory(isolated,shared) and not np.shares_memory(advanced,shared)
    try:H/H[:,0]
    except ValueError as error:incompatible=str(error)
    else:raise AssertionError('Shapes (3,5) and (3,) should be incompatible')
    zh=args.language=='zh';tr=lambda z,e:z if zh else e
    available={x.name for x in font_manager.fontManager.ttflist};family=next((x for x in ['Microsoft YaHei','Noto Sans CJK SC','DejaVu Sans'] if x in available),'DejaVu Sans')
    plt.rcParams.update({'font.family':[family,'DejaVu Sans'] if zh else ['DejaVu Sans','Arial'],'font.size':12,'axes.titlesize':14,'axes.titleweight':'bold','axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','text.color':'#172b36'})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg',bbox_inches='tight');fig.savefig(args.output/f'{name}-{args.language}.png',dpi=170,bbox_inches='tight');plt.close(fig)
    def grid(ax,data,title,cols,unit):
        im=ax.imshow(data,cmap='cividis',vmin=H.min(),vmax=H.max(),aspect='auto')
        for i in range(data.shape[0]):
            for j in range(data.shape[1]):ax.text(j,i,f'{data[i,j]:.2f}',ha='center',va='center',fontsize=15,color='white' if data[i,j]<1.1 else '#172b36')
        ax.set(xticks=range(data.shape[1]),xticklabels=cols,yticks=range(3),yticklabels=NAMES,xlabel=unit,title=title)
        return im
    fig=plt.figure(figsize=(12.5,7.7),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1,.9],width_ratios=[1.5,1]);ax=fig.add_subplot(gs[0,0]);im=grid(ax,H,tr('a  原数组 h：(3,5)','a  Original h: (3,5)'),TIME.astype(int),tr('时间 / min','Time / min'))
    ax.add_patch(Rectangle((.5,-.5),3,3,fill=False,edgecolor='#c6623b',lw=3));fig.colorbar(im,ax=ax,pad=.02).set_label(tr('厚度 / mm','Thickness / mm'))
    ax=fig.add_subplot(gs[0,1]);grid(ax,baseline,tr('b  每个样品的基准：(3,1)','b  Baseline per specimen: (3,1)'),[0],tr('时间 / min','Time / min'))
    ax=fig.add_subplot(gs[1,0]);grid(ax,selected_values,tr('c  h[:, 1:4] 对应10、20、40 min','c  h[:, 1:4] selects 10, 20, 40 min'),TIME[selected].astype(int),tr('时间 / min','Time / min'))
    ax=fig.add_subplot(gs[1,1]);ax.axis('off');ax.text(0,.9,'(3, 5) / (3, 1) → (3, 5)',fontsize=19,weight='bold');ax.text(0,.65,tr('末轴：5 与 1，可广播','Last axis: 5 and 1 are compatible'),fontsize=14);ax.text(0,.43,tr('前轴：3 与 3，一一配对','First axis: 3 and 3 match'),fontsize=14);ax.text(0,.15,tr('B，20 min：1.16 / 1.02 − 1 = 0.137255','B, 20 min: 1.16 / 1.02 − 1 = 0.137255'),fontsize=13)
    save(fig,'selection-broadcast')

    fig=plt.figure(figsize=(12.5,8.1),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1.4,1]);ax=fig.add_subplot(gs[0,:])
    for i,c in enumerate(COLORS):
        ax.plot(TIME,strain[i]*100,'o-',color=c,lw=2,label=f'{NAMES[i]} '+tr('原始','raw'))
        ax.plot(TIME,corrected_strain[i]*100,'s--',color=c,lw=1.8,ms=5,label=f'{NAMES[i]} '+tr('校正后','corrected'))
    ax.set(xlabel=tr('时间 / min','Time / min'),ylabel=tr('相对厚度变化 / %','Relative thickness change / %'),title=tr('a  各样品用自己的初始厚度归一化','a  Normalize each specimen by its own initial thickness'));ax.legend(ncol=3,fontsize=11);ax.grid(alpha=.15)
    for k,(data,title) in enumerate([(correct_square,tr('b  (3,3) / (3,1)：按样品','b  (3,3) / (3,1): by specimen')),(wrong_square,tr('c  (3,3) / (3,)：误按时间列','c  (3,3) / (3,): wrong time columns'))]):
        ax=fig.add_subplot(gs[1,k]);im=ax.imshow(data*100,cmap='RdBu_r',vmin=-3,vmax=18,aspect='auto')
        for i in range(3):
            for j in range(3):ax.text(j,i,f'{100*data[i,j]:.2f}%',ha='center',va='center',fontsize=14,color='white' if data[i,j]>.13 else '#172b36')
        ax.set(xticks=range(3),xticklabels=[0,10,20],yticks=range(3),yticklabels=NAMES,xlabel=tr('时间 / min','Time / min'),title=title)
    fig.colorbar(im,ax=fig.axes[1:3],shrink=.8,pad=.02).set_label(tr('相对变化 / %','Relative change / %'));save(fig,'normalized-response')

    fig=plt.figure(figsize=(12.5,8.3),layout='constrained');gs=fig.add_gridspec(3,1,height_ratios=[.3,.8,1.3]);ax=fig.add_subplot(gs[0]);ax.axis('off');ax.text(0,.7,tr('数组思想：一个数值缓冲区，多种访问方式','Array programming: one numerical buffer, multiple access patterns'),fontsize=18,weight='bold');ax.text(0,.05,tr('NumPy作者2020年回顾的核心结构：数值数据与形状、类型、步长分开组织。','Core structure in the authors’ 2020 retrospective: values plus shape, dtype, and strides.'),fontsize=12)
    ax=fig.add_subplot(gs[1]);ax.axis('off');ax.set_xlim(-.7,15.3);ax.set_ylim(-.4,2.8)
    for k,v in enumerate(H.ravel()):
        selected_cell=k%5 in [1,2,3];ax.add_patch(Rectangle((k,1),.94,.9,facecolor=COLORS[k//5],alpha=.25 if selected_cell else .08,edgecolor=COLORS[k//5]));ax.text(k+.47,1.45,f'{v:.2f}',ha='center',va='center',fontsize=11);ax.text(k+.47,.5,str(k*8),ha='center',fontsize=10)
    ax.text(0,2.35,tr('写入前的连续float64缓冲区：3 × 5 × 8 = 120字节','Before editing — contiguous float64 buffer: 3 × 5 × 8 = 120 bytes'),fontsize=14);ax.text(0,-.1,tr('数字下方：相对起点的字节偏移；每个数占8字节','Below: byte offsets from the buffer start; each value uses 8 bytes'),fontsize=12)
    ax=fig.add_subplot(gs[2]);ax.axis('off');ax.set_xlim(0,12);ax.set_ylim(0,5.5)
    for x,title,data,stride,c in [(0,tr('视图写入9.0：原表同格一起改变','Write 9.0 through view: source changes'),view,40,COLORS[0]),(6.2,tr('提前复制的数据：仍然保留1.08','Earlier copy: still retains 1.08'),isolated,24,COLORS[2])]:
        ax.text(x+.05,5.05,title,fontsize=14,weight='bold');ax.text(x+.05,4.45,f'shape = (3,3); strides = ({stride},8) bytes',fontsize=12)
        for i in range(3):
            for j in range(3):
                px=x+.2+j*1.7;py=3.1-i*.85;changed=x==0 and i==0 and j==0;ax.add_patch(Rectangle((px,py),1.55,.7,facecolor=COLORS[1] if changed else c,alpha=.22 if changed else .08));ax.text(px+.775,py+.35,f'{data[i,j]:.2f}',ha='center',va='center',fontsize=15,color=COLORS[1] if changed else '#172b36')
        ax.text(x+.05,.35,tr('共享存储；从原缓冲区偏移8字节','Shared storage; start offset 8 bytes') if x==0 else tr('独立存储：3 × 3 × 8 = 72字节','Independent storage: 3 × 3 × 8 = 72 bytes'),fontsize=12)
    save(fig,'memory-history')
    summary={'dataset':'Constructed specimen thickness table','shape':list(H.shape),'selected_times_min':TIME[selected].tolist(),'selected_values_mm':selected_values.tolist(),'baseline_shape':list(baseline.shape),'strain':strain.tolist(),'corrected_strain':corrected_strain.tolist(),'qualifying_at_21_percent':[NAMES[i] for i in np.flatnonzero(qualifying)],'wrong_square_strain':wrong_square.tolist(),'correct_square_strain':correct_square.tolist(),'incompatible_shape_error':incompatible,'view_copy':{'view_shares_memory':bool(np.shares_memory(view,shared)),'copy_shares_memory':bool(np.shares_memory(isolated,shared)),'advanced_shares_memory':bool(np.shares_memory(advanced,shared)),'edited_original_value':float(shared[0,1]),'isolated_value':float(isolated[0,0]),'original_strides_bytes':list(H.strides),'view_strides_bytes':list(view.strides),'copy_strides_bytes':list(isolated.strides)}}
    (args.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({'selected_times_min':summary['selected_times_min'],'last_raw_percent':(strain[:,-1]*100).tolist(),'last_corrected_percent':(corrected_strain[:,-1]*100).tolist(),'view_copy':summary['view_copy']},indent=2))

if __name__=='__main__':main()
