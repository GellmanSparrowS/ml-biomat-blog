# Public sources and third-party materials

- NumPy — Indexing on ndarrays: https://numpy.org/doc/2.4/user/basics.indexing.html
  BSD-3-Clause
- NumPy — Broadcasting: https://numpy.org/doc/2.4/user/basics.broadcasting.html
  BSD-3-Clause
- NumPy — Copies and views: https://numpy.org/doc/2.4/user/basics.copies.html
  BSD-3-Clause
- Harris et al. — Array Programming with NumPy (2020): https://arxiv.org/html/2006.10256v1
  CC BY 4.0 article; no original artwork reproduced
