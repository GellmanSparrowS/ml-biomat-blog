"""Units, floating-point representation and thickness sensitivity."""
from pathlib import Path
import argparse
import json
import math
from decimal import Decimal, localcontext
from fractions import Fraction
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, FancyArrowPatch


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,default=Path("output"))
    parser.add_argument("--language",choices=["zh","en"],default="en")
    args=parser.parse_args(); args.output.mkdir(parents=True,exist_ok=True)
    zh=args.language=="zh"
    def tr(a,b): return a if zh else b

    # Defined teaching model; width and thickness are initial dimensions.
    force_N=5.0; width_mm=2.0; thickness_mm=0.1
    width_m=width_mm*1e-3; thickness_m=thickness_mm*1e-3
    area_mm2=width_mm*thickness_mm
    area_m2=width_m*thickness_m
    stress_Pa=force_N/area_m2
    stress_MPa=stress_Pa/1e6
    stress_from_mm=force_N/area_mm2
    assert math.isclose(stress_MPa,stress_from_mm,rel_tol=1e-12)

    decimal_sum=Decimal("0.1")+Decimal("0.2")
    rational_sum=Fraction(1,10)+Fraction(2,10)
    float_sum=0.1+0.2
    cancellation=(1e16+1.0)-1e16
    stable_sum=math.fsum([1e16,1.0,-1e16])
    with localcontext() as ctx:
        ctx.prec=12
        decimal_third=str(Decimal(1)/Decimal(3))
    print(f"Area: {area_mm2:.3f} mm^2 = {area_m2:.3e} m^2")
    print(f"Nominal stress: {stress_MPa:.3f} MPa")
    print("Float addition:",repr(float_sum),"Decimal:",decimal_sum,"Fraction:",rational_sum)
    print("Cancellation:",cancellation,"math.fsum:",stable_sum)
    print("Near zero, relative-only:",math.isclose(0,1e-9,rel_tol=1e-6))
    print("Near zero, absolute tolerance:",math.isclose(0,1e-9,abs_tol=2e-9))

    fonts={f.name for f in font_manager.fontManager.ttflist}
    family=next((f for f in ["Noto Sans CJK SC","Microsoft YaHei","DejaVu Sans"] if f in fonts),"DejaVu Sans")
    plt.rcParams.update({"font.family":[family,"DejaVu Sans"] if zh else ["DejaVu Sans"],"font.size":12,"axes.titlesize":15,"axes.titleweight":"bold","svg.fonttype":"none","figure.facecolor":"#fbfaf6","axes.facecolor":"#fbfaf6","text.color":"#172b36","axes.labelcolor":"#172b36","axes.spines.top":False,"axes.spines.right":False})
    blue,red,ink,green="#28648a","#b85336","#172b36","#467a62"
    def save(fig,name):
        fig.savefig(args.output/f"{name}-{args.language}.svg",bbox_inches="tight")
        fig.savefig(args.output/f"{name}-{args.language}.png",dpi=180,bbox_inches="tight")
        plt.close(fig)

    fig=plt.figure(figsize=(12,7),layout="constrained")
    gs=fig.add_gridspec(2,2,height_ratios=[.9,1.3])
    ax=fig.add_subplot(gs[0,:]);ax.axis("off")
    ax.text(.01,.87,tr("a  同一截面，两套一致的单位", "a  One cross-section, two consistent unit choices"),fontsize=16,weight="bold",transform=ax.transAxes)
    ax.text(.03,.55,"2.00 mm × 0.10 mm = 0.20 mm²",fontsize=19,color=red,transform=ax.transAxes)
    ax.text(.03,.18,"0.002 m × 0.0001 m = 0.0000002 m²",fontsize=19,color=blue,transform=ax.transAxes)
    ax.text(.64,.55,"5 N / 0.20 mm² = 25 MPa",fontsize=17,color=red,transform=ax.transAxes)
    ax.text(.64,.18,"5 N / (2 × 10⁻⁷ m²) = 25 × 10⁶ Pa",fontsize=15,color=blue,transform=ax.transAxes)
    ts=[.04+i*.001 for i in range(201)]
    ax=fig.add_subplot(gs[1,0]);ax.plot(ts,[force_N/(width_mm*t) for t in ts],lw=2.8,color=blue)
    for t in [.08,.1,.12]:
        y=force_N/(width_mm*t);ax.scatter([t],[y],s=55,color=red);ax.annotate(f"{t:.2f} mm → {y:.2f} MPa",(t,y),xytext=(.13,y+5) if t!=.12 else (.145,6),fontsize=11,arrowprops={"arrowstyle":"-","color":ink})
    ax.set(xlabel=tr("初始厚度 / mm","Initial thickness / mm"),ylabel=tr("名义应力 / MPa","Nominal stress / MPa"),title=tr("b  分母越薄，应力越大","b  A thinner denominator gives higher stress"),xlim=(.04,.24),ylim=(0,66));ax.grid(alpha=.15)
    ax=fig.add_subplot(gs[1,1]);errors=[-.4+i*.004 for i in range(201)]
    ax.plot([100*e for e in errors],[100*(1/(1+e)-1) for e in errors],color=red,lw=2.8)
    ax.axhline(0,color=ink,lw=.8);ax.axvline(0,color=ink,lw=.8)
    ax.scatter([-20,20],[25,-100/6],s=60,color=ink)
    ax.set(xlabel=tr("厚度输入相对偏差 / %","Relative thickness-input shift / %"),ylabel=tr("应力结果相对变化 / %","Relative stress change / %"),title=tr("c  相同正负偏差，影响并不对称","c  Equal signed shifts have unequal effects"));ax.grid(alpha=.15)
    save(fig,"units-sensitivity")

    fig=plt.figure(figsize=(12,7),layout="constrained")
    gs=fig.add_gridspec(2,2,height_ratios=[1.2,1])
    ax=fig.add_subplot(gs[0,:]);ax.set_xlim(-.025,.38);ax.set_ylim(-.35,1.7);ax.axis("off")
    ax.set_title(tr("a  玩具数轴：固定小数位，展示有限刻度", "a  A toy fixed-fraction grid makes finite spacing visible"),loc="left")
    for row,bits in enumerate([3,5,8]):
        y=1.3-row*.55;step=2**(-bits);ax.hlines(y,0,.35,color="#bcc7c7",lw=1)
        for k in range(int(.35/step)+1):ax.vlines(k*step,y-.05,y+.05,color=blue,lw=1)
        rounded=round(.1/step)*step;ax.scatter([rounded],[y],s=65,color=red,zorder=3)
        ax.annotate(f"{bits} bits: {rounded:.7f}",(rounded,y),xytext=(.19,y+.07),fontsize=12,arrowprops={"arrowstyle":"-","color":red})
    ax.axvline(.1,ymin=.13,ymax=.9,color=ink,ls="--",lw=1.4);ax.text(.1,-.2,"0.1",ha="center",fontsize=14)
    ax.text(.005,1.57,tr("红点：离0.1最近的格点；这不是实际float格式。","Red: nearest grid point to 0.1; this is not the actual float format."),fontsize=12)
    ax=fig.add_subplot(gs[1,0]); ax.axis("off")
    ax.set_title(tr("b  实际Python浮点加法", "b  Actual Python floating-point addition"),loc="left")
    ax.text(.02,.75,"0.1 + 0.2",fontsize=21,transform=ax.transAxes)
    ax.text(.02,.48,repr(float_sum),fontsize=21,color=blue,transform=ax.transAxes)
    ax.text(.02,.18,tr("显示位数改变文字，不改变已存储的值。","Formatting changes the text, not the stored value."),fontsize=12,transform=ax.transAxes)
    ax=fig.add_subplot(gs[1,1]);ax.axis("off")
    ax.set_title(tr("c  精确记录小数或有理数", "c  Exact decimal input or a rational value"),loc="left")
    ax.text(.02,.76,'Decimal("0.1") + Decimal("0.2")',fontsize=14,transform=ax.transAxes)
    ax.text(.02,.56,str(decimal_sum),fontsize=23,color=red,transform=ax.transAxes)
    ax.text(.02,.30,'Fraction(1, 10) + Fraction(2, 10)',fontsize=14,transform=ax.transAxes)
    ax.text(.02,.10,str(rational_sum),fontsize=23,color=green,transform=ax.transAxes)
    save(fig,"finite-number-lines")

    fig=plt.figure(figsize=(12,6.3),layout="constrained");ax=fig.add_subplot();ax.axis("off");ax.set_xlim(0,12);ax.set_ylim(0,6.3)
    ax.text(.1,5.9,tr("长度标准怎样变得可以重现？", "How can a length standard become reproducible?"),fontsize=19,weight="bold")
    ax.text(.1,5.35,tr("原创方法示意：原器比较 → 光学计数 → 由光速与时间定义", "Original method schematic: artifact comparison → optical counting → light and time"),fontsize=12)
    ax.add_patch(Rectangle((.3,3.6),3.1,.35,facecolor="#bfc6c5",edgecolor=ink))
    for x in [.55,3.15]:ax.plot([x,x],[3.5,4.08],color=ink,lw=2)
    ax.annotate('',(.55,4.35),(3.15,4.35),arrowprops={"arrowstyle":"<->","color":ink})
    ax.text(1.85,4.55,tr("刻线间的距离","Distance between marks"),ha="center",fontsize=13)
    ax.text(.3,2.9,tr("铂铱原器（1889）", "Platinum–iridium (1889)"),fontsize=13,weight="bold")
    ax.text(.3,2.35,tr("与共同保存的实物比较", "Compare against a\nshared physical reference"),fontsize=13)
    xs=[4.4+i*.006 for i in range(451)];ys=[3.8+.27*math.sin((x-4.4)*2*math.pi/.45) for x in xs]
    ax.plot(xs,ys,color=blue,lw=2);ax.hlines(3.8,4.4,7.1,color="#bac4c6",lw=.7)
    ax.annotate('',(4.4,4.4),(4.85,4.4),arrowprops={"arrowstyle":"<->","color":ink});ax.text(4.625,4.58,tr("波长","Wavelength"),ha="center",fontsize=12)
    ax.text(4.4,2.9,tr("氪86辐射（1960）", "Krypton-86 radiation (1960)"),fontsize=13,weight="bold")
    ax.text(4.4,2.35,tr("通过光学干涉连接长度与波长", "Relate length to wavelength\nusing optical interference"),fontsize=12)
    ax.add_patch(FancyArrowPatch((8.4,3.8),(11.5,3.8),arrowstyle='->',mutation_scale=22,color=red,lw=2))
    ax.plot([8.5,8.5],[3.4,4.2],color=ink);ax.plot([11.35,11.35],[3.4,4.2],color=ink)
    ax.text(9.9,4.4,"c × Δt",ha="center",fontsize=21,color=red)
    ax.text(8.4,2.9,tr("真空中的光与时间（1983）", "Light in vacuum and time (1983)"),fontsize=12,weight="bold")
    ax.text(8.4,2.35,tr("固定光速，使用秒定义长度", "Fix light speed; use the\nsecond to define length"),fontsize=13)
    ax.text(.3,1.25,tr("今天的米：光在真空中经过1/299792458秒所走的距离。", "Today’s metre: the distance light travels in vacuum in 1/299792458 second."),fontsize=14)
    ax.text(.3,.55,tr("共同单位定义与实际测量精度，是两个相连但不同的问题。", "A shared unit definition and practical measurement precision are distinct, connected questions."),fontsize=13)
    save(fig,"length-history")
    summary={"model":"Nominal stress from initial rectangular section; defined teaching inputs","force_N":force_N,"width_mm":width_mm,"thickness_mm":thickness_mm,"area_mm2":area_mm2,"area_m2":area_m2,"stress_MPa":stress_MPa,"float_sum_repr":repr(float_sum),"decimal_sum":str(decimal_sum),"rational_sum":str(rational_sum),"decimal_third_12_digits":decimal_third,"direct_cancellation":cancellation,"fsum_result":stable_sum,"float_spacing_at_one":math.ulp(1.0),"near_zero_relative_only":math.isclose(0,1e-9,rel_tol=1e-6),"near_zero_absolute":math.isclose(0,1e-9,abs_tol=2e-9),"stress_at_thickness_mm":{str(t):force_N/(width_mm*t) for t in [.08,.1,.12]}}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')


if __name__=="__main__": main()
