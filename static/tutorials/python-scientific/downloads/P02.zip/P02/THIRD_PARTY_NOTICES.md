# Public sources and third-party materials

- Python — Floating-point arithmetic: https://docs.python.org/3.14/tutorial/floatingpoint.html
  PSF documentation license
- Python — Decimal: https://docs.python.org/3.14/library/decimal.html
  PSF documentation license
- Python — Fractions: https://docs.python.org/3.14/library/fractions.html
  PSF documentation license
- Python — math: https://docs.python.org/3.14/library/math.html
  PSF documentation license
- PEP 485 — Approximate equality: https://peps.python.org/pep-0485/
  Public-domain dedication in PEP
- BIPM — History of the metre: https://www.bipm.org/en/history-si/metre
  Technical factual reference; no reproduced image or prose
- BIPM — SI unit metre: https://www.bipm.org/en/si-base-units/metre
  Technical factual reference; original explanatory figure
