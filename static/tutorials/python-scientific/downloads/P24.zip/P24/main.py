"""Derive a spring model symbolically, then evaluate it with NumPy."""
from pathlib import Path
import argparse
import json
import numpy as np
import sympy as sp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager


def expression_tree(ax, expression):
    """Draw the actual func/args structure; each leaf receives one position."""
    nodes, edges = [], []
    next_leaf = [0]

    def visit(expr, depth=0):
        index = len(nodes)
        nodes.append(None)
        children = [visit(child, depth + 1) for child in expr.args]
        if children:
            horizontal = np.mean([nodes[child][0] for child in children])
        else:
            horizontal = next_leaf[0]
            next_leaf[0] += 1
        label = expr.func.__name__ if children else str(expr)
        nodes[index] = (horizontal, -depth, label, bool(children))
        edges.extend((index, child) for child in children)
        return index

    visit(expression)
    for parent, child in edges:
        a, b = nodes[parent], nodes[child]
        ax.plot([a[0], b[0]], [a[1], b[1]], color='#b7c6cd', lw=1.7, zorder=0)
    for x, y, label, branch in nodes:
        ax.text(x, y, label, ha='center', va='center', fontsize=14,
                bbox=dict(boxstyle='round,pad=.48', facecolor='#eaf2f5' if branch else '#fbf1e9',
                          edgecolor='#28658c' if branch else '#b36837', lw=1.3))
    ax.set(xlim=(-.65, next_leaf[0] - .35), ylim=(-3.65, .65))
    ax.axis('off')
    return len(nodes)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--language', choices=['zh', 'en'], default='en')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    tr = lambda zh, en: zh if args.language == 'zh' else en
    available = {f.name for f in font_manager.fontManager.ttflist}
    plt.rcParams.update({'font.family': [f for f in ['Noto Sans CJK SC', 'Noto Sans SC',
        'Microsoft YaHei', 'SimHei', 'DejaVu Sans'] if f in available],
        'font.size': 12, 'svg.fonttype': 'none', 'axes.spines.top': False,
        'axes.spines.right': False, 'grid.alpha': .16})

    def save(fig, name):
        fig.savefig(args.output / f'{name}-{args.language}.svg')
        fig.savefig(args.output / f'{name}-{args.language}.png', dpi=160)
        plt.close(fig)

    # Numerical values use mm, N, and N*mm (= mJ) consistently.
    x = sp.Symbol('x', real=True)
    k = sp.Symbol('k', positive=True)
    alpha = sp.Symbol('alpha', nonnegative=True)
    h = sp.Symbol('h', positive=True)
    U = sp.Rational(1, 2) * k * x**2 + sp.Rational(1, 4) * alpha * x**4
    F = sp.diff(U, x)
    K = sp.diff(F, x)
    reconstructed = sp.integrate(F, x)
    assert sp.simplify(reconstructed - U) == 0
    centered = (U.subs(x, x + h) - U.subs(x, x - h)) / (2 * h)
    truncation = sp.expand(centered - F)
    assert sp.simplify(truncation - alpha * x * h**2) == 0
    values = {k: sp.Integer(2), alpha: sp.Rational(1, 2)}
    exact_one = [expr.subs(values).subs(x, 1) for expr in (U, F, K)]
    work = sp.integrate(F.subs(values), (x, 0, 2))
    equilibrium = sp.nsolve(F.subs(values) - 3, x, 1, prec=40)
    equilibrium_residual = abs((F.subs(values) - 3).subs(x, equilibrium))
    u_num = sp.lambdify((x, k, alpha), U, modules='numpy')
    f_num = sp.lambdify((x, k, alpha), F, modules='numpy')
    stiffness_num = sp.lambdify((x, k, alpha), K, modules='numpy')
    grid = np.linspace(0, 2, 401)
    energy = u_num(grid, 2., .5)
    force = f_num(grid, 2., .5)
    stiffness = stiffness_num(grid, 2., .5)
    np.savetxt(args.output / 'model.csv', np.column_stack([grid, energy, force, stiffness]),
               delimiter=',', header='displacement_mm,energy_mJ,force_N,stiffness_N_per_mm', comments='')

    fig, axes = plt.subplots(1, 3, figsize=(13.4, 5.2), layout='constrained')
    for a, color in zip([0., .5, 2.], ['#82939b', '#28658c', '#c26835']):
        for ax, fn in zip(axes, [u_num, f_num, stiffness_num]):
            output = np.broadcast_to(fn(grid, 2., a), grid.shape)
            ax.plot(grid, output, color=color, lw=2.3, label=f'α = {a:g} N/mm³')
    for ax, value, title, ylabel in zip(axes, [1.125, 2.5, 3.5],
        [tr('A  储存了多少能量', 'A  Stored energy'), tr('B  维持位移的外力', 'B  Holding force'),
         tr('C  当前有多难再拉长', 'C  Tangent stiffness')],
        [tr('储能 U / mJ', 'Energy U / mJ'), tr('外力 F / N', 'Applied force F / N'),
         tr('切线刚度 K / (N/mm)', 'Tangent stiffness K / (N/mm)')]):
        ax.scatter([1], [value], s=58, color='#28658c', edgecolor='white', zorder=5)
        ax.annotate(f'{value:g}', (1, value), xytext=(6, 10), textcoords='offset points', color='#28658c',
                    bbox=dict(facecolor='white', edgecolor='none', alpha=.85, pad=.5))
        ax.set(title=title, xlabel=tr('位移 x / mm', 'Displacement x / mm'), ylabel=ylabel, xlim=(0, 2))
        ax.set_xticks([0, .5, 1, 1.5, 2]); ax.grid(True)
    axes[0].legend(loc='upper left', fontsize=11)
    fig.suptitle(tr('同一个储能函数的三个读法；k = 2 N/mm',
                       'Three readings of one energy function; k = 2 N/mm'), fontsize=16)
    save(fig, 'mechanics')

    fig = plt.figure(figsize=(12, 6.8), layout='constrained')
    gs = fig.add_gridspec(2, 1, height_ratios=[4, 1])
    ax = fig.add_subplot(gs[0]); node_count = expression_tree(ax, U)
    ax.set_title(tr('SymPy的2017年论文：表达式树架构',
                       'Expression-tree architecture in the 2017 SymPy paper'), fontsize=16, pad=14)
    ax = fig.add_subplot(gs[1]); ax.axis('off')
    ax.text(.02, .73, '$U=' + sp.latex(U) + '$', fontsize=19, transform=ax.transAxes)
    ax.text(.55, .73, '$F=' + sp.latex(F) + '$', fontsize=19, transform=ax.transAxes)
    ax.text(.02, .05, tr('Add：相加     Mul：相乘     Pow：乘方；叶子保留符号和精确分数。',
        'Add: sum     Mul: product     Pow: power; leaves retain symbols and exact fractions.'),
        fontsize=12, transform=ax.transAxes)
    save(fig, 'history')

    steps = np.logspace(-14, -1, 170)
    differences = (u_num(1 + steps, 2., .5) - u_num(1 - steps, 2., .5)) / (2 * steps)
    errors = abs(differences - 2.5)
    exact_error = .5 * steps**2
    np.savetxt(args.output / 'difference-error.csv', np.column_stack([steps, differences, errors, exact_error]),
        delimiter=',', header='step_mm,centered_force_N,absolute_error_N,exact_arithmetic_error_N', comments='')
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 6), layout='constrained', gridspec_kw={'width_ratios': [1, 1.22]})
    local = np.linspace(.65, 1.35, 200); hh = .2
    secant = float((u_num(1 + hh, 2., .5) - u_num(1 - hh, 2., .5)) / (2 * hh))
    intercept = float((u_num(1 + hh, 2., .5) + u_num(1 - hh, 2., .5)) / 2)
    axes[0].plot(local, u_num(local, 2., .5), color='#28658c', lw=2.5, label=tr('能量曲线', 'Energy'))
    axes[0].plot(local, 1.125 + 2.5 * (local - 1), color='#2b8a74', ls='--', label=tr('中心切线', 'Center tangent'))
    axes[0].plot(local, intercept + secant * (local - 1), color='#c26835', ls=':', lw=2.4, label=tr('两点割线', 'Two-point secant'))
    axes[0].scatter([.8, 1.2], u_num(np.array([.8, 1.2]), 2., .5), color='#c26835', zorder=5)
    axes[0].set(title=tr('A  先看斜率的几何意义', 'A  Read slope geometrically'),
        xlabel=tr('位移 / mm', 'Displacement / mm'), ylabel=tr('储能 / mJ', 'Stored energy / mJ'))
    axes[0].legend(loc='upper left', fontsize=11); axes[0].grid(True)
    positive = errors > 0
    axes[1].loglog(steps[positive], errors[positive], color='#28658c', lw=1.2, marker='.', ms=3,
                  label=tr('NumPy浮点计算', 'NumPy floating-point calculation'))
    axes[1].loglog(steps, exact_error, color='#c26835', lw=2.2, ls='--',
                  label=tr('精确算术：αxh²', 'Exact arithmetic: αxh²'))
    axes[1].set(title=tr('B  步长与力的绝对误差', 'B  Step size and absolute force error'),
        xlabel=tr('半间距 h / mm', 'Half-spacing h / mm'), ylabel=tr('绝对误差 / N', 'Absolute error / N'),
        ylim=(1e-17, .1))
    axes[1].legend(loc='upper center', fontsize=11); axes[1].grid(True, which='major')
    fig.suptitle(tr('x = 1 mm，k = 2 N/mm，α = 0.5 N/mm³；左图 h = 0.2 mm',
                       'x = 1 mm, k = 2 N/mm, α = 0.5 N/mm³; left panel h = 0.2 mm'), fontsize=14)
    save(fig, 'difference')
    summary = {'sympy_version': sp.__version__, 'energy_expression': str(U), 'force_expression': str(F),
        'stiffness_expression': str(K), 'truncation_expression': str(truncation),
        'energy_at_1_mJ': float(exact_one[0]), 'force_at_1_N': float(exact_one[1]),
        'stiffness_at_1_N_per_mm': float(exact_one[2]), 'work_0_to_2_mJ': float(work),
        'equilibrium_3N_mm': float(equilibrium), 'equilibrium_residual_N': float(equilibrium_residual),
        'centered_h01_N': float(centered.subs(values).subs({x: 1, h: sp.Rational(1, 10)})),
        'exact_h01_error_N': .005, 'expression_tree_nodes': node_count,
        'sqrt_real_x_squared': str(sp.sqrt(x**2)), 'zero_float_errors': int((errors == 0).sum()),
        'minimum_positive_float_error_N': float(errors[positive].min()),
        'maximum_float_error_N': float(errors.max())}
    (args.output / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
