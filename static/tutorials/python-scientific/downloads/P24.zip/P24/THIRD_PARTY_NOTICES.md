# Public sources and third-party materials

- SymPy: Basic Operations: https://docs.sympy.org/latest/tutorials/intro-tutorial/basic_operations.html
  BSD-3-Clause; technical reference
- SymPy: Calculus: https://docs.sympy.org/latest/tutorials/intro-tutorial/calculus.html
  BSD-3-Clause; technical reference
- SymPy: Lambdify: https://docs.sympy.org/latest/modules/utilities/lambdify.html
  BSD-3-Clause; technical reference
- SymPy: Gotchas and assumptions: https://docs.sympy.org/latest/tutorials/intro-tutorial/gotchas.html
  BSD-3-Clause; technical reference
- SymPy: Assumptions: https://docs.sympy.org/latest/guides/assumptions.html
  BSD-3-Clause; technical reference
- SymPy: Expression Manipulation: https://docs.sympy.org/latest/tutorials/intro-tutorial/manipulation.html
  BSD-3-Clause; technical reference
- SymPy: Numerical solving: https://docs.sympy.org/latest/guides/solving/solve-numerically.html
  BSD-3-Clause; technical reference
- Meurer et al. (2017): SymPy, symbolic computing in Python: https://github.com/sympy/sympy-paper
  Published article CC-BY-4.0; historical reference; figures here original
