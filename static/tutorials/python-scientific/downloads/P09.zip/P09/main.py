"""Simulate repeated thickness readings and distinguish noise, bias, and shared offsets."""
from pathlib import Path
import argparse
import json
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

MU=1.2
SIGMA=.04
TRIALS=4000
MAX_READINGS=64

def draws(seed):
    rng=np.random.default_rng(seed)
    individual=rng.normal(0,1,size=(TRIALS,MAX_READINGS))
    common=rng.normal(0,1,size=(TRIALS,1))
    return individual,common,type(rng.bit_generator).__name__

def scalar_sd(values):
    average=math.fsum(float(v) for v in values)/len(values)
    return math.sqrt(math.fsum((float(v)-average)**2 for v in values)/(len(values)-1))

def density(x,center,sd):
    return np.exp(-.5*((x-center)/sd)**2)/(sd*np.sqrt(2*np.pi))

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('output'));p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    z,c,bitgen=draws(2026);readings=MU+SIGMA*z
    sizes=[1,4,16,64];means={n:readings[:,:n].mean(axis=1) for n in sizes}
    empirical={n:float(means[n].std(ddof=1)) for n in sizes};theory={n:SIGMA/math.sqrt(n) for n in sizes}
    shared_means=(MU+SIGMA*z[:,:16]+.03*c).mean(axis=1)
    biased_means=means[16]+.03
    assert np.allclose(means[16],[math.fsum(float(x) for x in row)/16 for row in readings[:,:16]])
    for n in sizes:assert math.isclose(empirical[n],scalar_sd(means[n]),rel_tol=1e-12)
    assert math.isclose(float(biased_means.std(ddof=1)),empirical[16],rel_tol=1e-12)
    assert math.isclose(float(biased_means.mean()-means[16].mean()),.03,abs_tol=1e-12)
    zh=args.language=='zh';tr=lambda a,b:a if zh else b;colors=['#28648a','#467a62','#b85336','#7b5c90']
    fonts={f.name for f in font_manager.fontManager.ttflist};family=next((f for f in ['Microsoft YaHei','Noto Sans CJK SC','DejaVu Sans'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[family,'DejaVu Sans'] if zh else ['DejaVu Sans','Arial'],'font.size':12,'axes.titlesize':14,'axes.titleweight':'bold','axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','text.color':'#172b36'})
    def save(fig,n):
        fig.savefig(args.output/f'{n}-{args.language}.svg',bbox_inches='tight');fig.savefig(args.output/f'{n}-{args.language}.png',dpi=170,bbox_inches='tight');plt.close(fig)

    fig=plt.figure(figsize=(12.5,7.8),layout='constrained');gs=fig.add_gridspec(2,2,width_ratios=[3,1],height_ratios=[1,.85]);ax=fig.add_subplot(gs[0,0]);dev=1000*(readings[:8,:16]-MU);im=ax.imshow(dev,cmap='RdBu_r',vmin=-100,vmax=100,aspect='auto');ax.set(xticks=np.arange(0,16,3),xticklabels=np.arange(1,17,3),yticks=range(8),yticklabels=np.arange(1,9),xlabel=tr('同一次实验里的读数编号','Reading number within an experiment'),ylabel=tr('重新开展的实验编号','Repeated experiment'),title=tr('a  蒙特卡洛：按同一规则生成许多完整实验','a  Monte Carlo: generate complete repeated experiments'));fig.colorbar(im,ax=ax,pad=.02).set_label(tr('读数减去真值 / μm','Reading minus truth / μm'))
    im.set_clim(-20*math.ceil(float(np.abs(dev).max())/20),20*math.ceil(float(np.abs(dev).max())/20))
    ax=fig.add_subplot(gs[0,1]);ax.barh(np.arange(8),1000*(means[16][:8]-MU),color=colors[0]);ax.set_ylim(7.5,-.5);ax.axvline(0,color='#607078',lw=1);ax.set(yticks=np.arange(8),yticklabels=np.arange(1,9),xlabel=tr('均值偏离 / μm','Mean offset / μm'),title=tr('b  每行得到一个均值','b  One mean per row'))
    ax=fig.add_subplot(gs[1,:]);ax.hist(means[16],bins=np.arange(1.15,1.251,.004),density=True,color=colors[0],alpha=.4,edgecolor='#fbfaf6');xx=np.linspace(1.15,1.25,500);ax.plot(xx,density(xx,MU,.01),color=colors[0],lw=2.2,label=tr('模型：均值标准差0.01 mm','Model: mean SD 0.01 mm'));ax.axvline(MU,color='#172b36',ls='--',label=tr('设定真值1.20 mm','Specified truth 1.20 mm'));ax.set(xlabel=tr('每次16个读数的平均厚度 / mm','Mean thickness of 16 readings / mm'),ylabel=tr('概率密度 / mm⁻¹','Probability density / mm⁻¹'),title=tr('c  4000个模拟均值形成分布；上图只展示前8次','c  Distribution of 4000 simulated means; above shows the first 8'));ax.legend(fontsize=11);ax.grid(alpha=.1)
    save(fig,'monte-carlo-history')

    fig=plt.figure(figsize=(12.5,6.7),layout='constrained');gs=fig.add_gridspec(1,2,width_ratios=[1.4,1]);ax=fig.add_subplot(gs[0]);bins=np.arange(.99,1.411,.005);xx=np.linspace(1,1.4,700)
    for n,col in zip(sizes,colors):ax.hist(means[n],bins=bins,density=True,histtype='step',lw=1.5,color=col,alpha=.6);ax.plot(xx,density(xx,MU,theory[n]),color=col,lw=2,label=f'n = {n}')
    ax.set(xlabel=tr('一次实验的平均厚度 / mm','Mean thickness in one experiment / mm'),ylabel=tr('概率密度 / mm⁻¹','Probability density / mm⁻¹'),xlim=(1.04,1.36),title=tr('a  读数越多，均值分布越窄','a  More readings narrow the mean distribution'));ax.legend();ax.grid(alpha=.12)
    ax=fig.add_subplot(gs[1]);nn=np.arange(1,65);ax.plot(nn,SIGMA/np.sqrt(nn),color=colors[0],lw=2,label=tr('解析关系 σ/√n','Analytical σ/√n'));ax.scatter(sizes,[empirical[n] for n in sizes],s=65,color=colors[2],zorder=3,label=tr('4000次模拟的标准差','SD across 4000 simulations'));ax.set_xscale('log',base=2);ax.set_yscale('log',base=2);ax.set_xticks([1,4,16,64],[1,4,16,64]);ax.set_yticks([.005,.01,.02,.04],['0.005','0.010','0.020','0.040']);ax.set(xlabel=tr('每次实验的读数数目 n','Readings per experiment n'),ylabel=tr('均值标准差 / mm','Standard deviation of the mean / mm'),title=tr('b  四倍读数，使标准差减半','b  Four times as many halves the SD'));ax.legend(loc='lower left',fontsize=10);ax.grid(alpha=.15)
    save(fig,'averaging-distributions')

    fig=plt.figure(figsize=(12.5,7),layout='constrained');gs=fig.add_gridspec(1,2,width_ratios=[1.35,1]);ax=fig.add_subplot(gs[0]);xx=np.linspace(1.05,1.4,600)
    scenarios=[(means[16],MU,.01,colors[0],tr('独立噪声','Independent noise')),(biased_means,MU+.03,.01,colors[2],tr('再加固定偏差0.03 mm','Add fixed bias 0.03 mm')),(shared_means,MU,math.sqrt(.001),colors[1],tr('会话偏移标准差0.03 mm','Session offset SD 0.03 mm'))]
    for values,center,sd,col,label in scenarios:ax.hist(values,bins=np.arange(1.04,1.411,.005),density=True,histtype='step',color=col,alpha=.5);ax.plot(xx,density(xx,center,sd),color=col,lw=2,label=label)
    ax.axvline(MU,color='#172b36',ls='--',lw=1.5);ax.set(xlabel=tr('16个读数的平均厚度 / mm','Mean thickness of 16 readings / mm'),ylabel=tr('概率密度 / mm⁻¹','Probability density / mm⁻¹'),xlim=(1.08,1.35),title=tr('a  分布变窄，与中心正确是两件事','a  A narrow distribution can have a shifted center'));ax.legend(fontsize=10);ax.grid(alpha=.12)
    ax=fig.add_subplot(gs[1]);nn=np.arange(1,257);ax.plot(nn,SIGMA/np.sqrt(nn),color=colors[0],lw=2,label=tr('只有独立噪声','Independent noise only'));ax.plot(nn,np.sqrt(SIGMA**2/nn+.03**2),color=colors[1],lw=2,label=tr('加会话共有偏移','With shared session offset'));ax.axhline(.03,color=colors[1],ls=':',label=tr('共有部分：0.03 mm','Shared component: 0.03 mm'));ax.set_xscale('log',base=2);ax.set_xticks([1,4,16,64,256],[1,4,16,64,256]);ax.set(xlabel=tr('同一会话的读数数目 n','Readings within one session n'),ylabel=tr('均值标准差 / mm','Standard deviation of the mean / mm'),ylim=(0,.055),title=tr('b  重复读数无法消除共有偏移','b  Repeated readings retain a shared offset'));ax.legend(fontsize=10);ax.grid(alpha=.12);save(fig,'bias-and-shared-offset')
    lab={}
    for seed in [2026,2027]:
        zi,ci,_=draws(seed);lab[str(seed)]={'individual':zi[:200].tolist(),'common':ci[:200,0].tolist()}
    (args.output/'lab-draws.json').write_text(json.dumps(lab,separators=(',',':')),encoding='utf8')
    np.savez_compressed(args.output/'simulation.npz',individual_standard=z,session_standard=c,readings_mm=readings)
    summary={'model':{'true_thickness_mm':MU,'individual_sd_mm':SIGMA,'trials':TRIALS,'maximum_readings':MAX_READINGS,'seed':2026,'bit_generator':bitgen,'numpy_version':np.__version__},'mean_sd':{str(n):{'empirical_mm':empirical[n],'analytic_mm':theory[n],'mean_mm':float(means[n].mean())} for n in sizes},'n16_scenarios':{'unbiased':{'mean_mm':float(means[16].mean()),'sd_mm':empirical[16]},'fixed_bias':{'mean_mm':float(biased_means.mean()),'sd_mm':float(biased_means.std(ddof=1))},'shared_offset':{'mean_mm':float(shared_means.mean()),'sd_mm':float(shared_means.std(ddof=1)),'analytic_sd_mm':math.sqrt(.001)}},'first_trial_n16_mean_mm':float(means[16][0]),'first_trial_readings_mm':readings[0,:16].tolist()}
    (args.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary['mean_sd'],indent=2));print(json.dumps(summary['n16_scenarios'],indent=2))

if __name__=='__main__':main()
