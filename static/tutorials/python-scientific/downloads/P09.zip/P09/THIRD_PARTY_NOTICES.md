# Public sources and third-party materials

- NumPy — Random Generator: https://numpy.org/doc/2.4/reference/random/generator.html
  BSD-3-Clause
- NumPy — Generator.normal: https://numpy.org/doc/2.4/reference/random/generated/numpy.random.Generator.normal.html
  BSD-3-Clause
- NumPy — Random compatibility policy: https://numpy.org/doc/2.4/reference/random/compatibility.html
  BSD-3-Clause
- NIST/SEMATECH — Normal Distribution: https://www.itl.nist.gov/div898/handbook/eda/section3/eda3661.htm
  US government handbook; factual reference
- N. Metropolis — The Beginning of the Monte Carlo Method (1987): https://mcnp-green.lanl.gov/pdf_files/Article_1987_LAS_Metropolis_125--130.pdf
  Public LANL archival article; factual paraphrase and original figures
