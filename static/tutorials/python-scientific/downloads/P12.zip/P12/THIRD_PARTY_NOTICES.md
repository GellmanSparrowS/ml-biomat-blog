# Public sources and third-party materials

- pandas: Group by — split-apply-combine: https://pandas.pydata.org/docs/user_guide/groupby.html
  pandas BSD 3-Clause; API reference, original lesson prose/code/data.
- pandas: Summary statistics: https://pandas.pydata.org/docs/getting_started/intro_tutorials/06_calculate_statistics.html
  pandas BSD 3-Clause; API reference, original lesson prose/code/data.
- pandas: GroupBy.aggregate: https://pandas.pydata.org/docs/reference/api/pandas.api.typing.DataFrameGroupBy.aggregate.html
  pandas BSD 3-Clause; API reference, original lesson prose/code/data.
- pandas: GroupBy.transform: https://pandas.pydata.org/docs/reference/api/pandas.api.typing.DataFrameGroupBy.transform.html
  pandas BSD 3-Clause; API reference, original lesson prose/code/data.
- pandas: DataFrame.pivot: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.pivot.html
  pandas BSD 3-Clause; API reference, original lesson prose/code/data.
- Wickham (2011): The Split-Apply-Combine Strategy for Data Analysis: https://www.jstatsoft.org/article/view/v040i01
  JSS original article; historical reference, no reproduced figure or text.
