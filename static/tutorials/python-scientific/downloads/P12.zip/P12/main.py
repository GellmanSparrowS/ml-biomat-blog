"""Follow technical readings through specimen and formulation summaries.

The values are constructed teaching data. Copying A01 readings below is a
weighting experiment; the copies are not additional physical measurements.
Run: python main.py --output results --language en
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

READINGS = {'A01': [2.0, 2.2], 'A02': [2.8], 'A03': [3.0, 3.2, 3.4],
            'B01': [2.0, 2.2], 'B02': [2.5, 2.7], 'B03': [2.9]}
BLUE, ORANGE, INK = '#235f83', '#bd5838', '#1e303c'


def make_table(copies=1, missing=False):
    records = []
    for specimen, values in READINGS.items():
        for copy in range(copies if specimen == 'A01' else 1):
            for reading, value in enumerate(values, 1):
                records.append({'formulation': specimen[0], 'specimen': specimen,
                                'reading': reading, 'copy': copy + 1,
                                'q': np.nan if missing and specimen == 'A02' else value})
    return pd.DataFrame(records)


def summarize(table):
    specimens = (table.groupby(['formulation', 'specimen'], as_index=False, dropna=False)
                 .agg(q_mean=('q', 'mean'), rows=('q', 'size'), valid=('q', 'count')))
    formulations = (specimens.groupby('formulation', as_index=False, dropna=False)
                    .agg(q_equal=('q_mean', 'mean'), specimens=('specimen', 'size'),
                         valid_specimens=('q_mean', 'count'), sd_specimens=('q_mean', 'std')))
    row_means = table.groupby('formulation', dropna=False)['q'].mean()
    # Map by category label. Position alone is not a group identifier.
    formulations['q_rows'] = formulations['formulation'].map(row_means)
    traced = table.copy()
    traced['specimen_mean'] = traced.groupby('specimen')['q'].transform('mean')
    traced['within_specimen'] = traced['q'] - traced['specimen_mean']
    return specimens, formulations, traced


def plot_all(table, specimens, groups, output, language):
    zh = language == 'zh'
    tr = lambda z, e: z if zh else e
    available = {f.name for f in font_manager.fontManager.ttflist}
    fonts = [f for f in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','DejaVu Sans'] if f in available]
    plt.rcParams.update({'font.family': fonts if zh else ['DejaVu Sans'], 'font.size': 12,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'svg.fonttype': 'none', 'axes.unicode_minus': False})
    def save(fig, name):
        for ext in ['svg', 'png']:
            fig.savefig(output / f'{name}-{language}.{ext}', dpi=165, bbox_inches='tight')
        plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(13.8, 5.3), gridspec_kw={'width_ratios':[1.2, .9, 1]}, layout='constrained')
    for i, row in specimens.iterrows():
        values = table.loc[table.specimen == row.specimen, 'q'].to_numpy()
        offsets = np.linspace(-.14,.14,len(values)) if len(values)>1 else [0]
        axes[0].scatter(values, i+np.array(offsets), color=BLUE if row.formulation=='A' else ORANGE, s=45)
        axes[0].plot([row.q_mean-.03, row.q_mean+.03], [i,i], color=INK, lw=3)
    axes[0].set(yticks=range(6), yticklabels=specimens.specimen, xlabel='q / g g⁻¹',
                title=tr('a  11条读数，6个独立试样','a  11 readings, 6 independent specimens'))
    axes[0].invert_yaxis();axes[0].grid(axis='x',alpha=.15)
    axes[1].barh(np.arange(6)-.15, specimens.valid/np.repeat([6,5],3), height=.28,color=BLUE,label=tr('逐读数权重','Reading weights'))
    axes[1].barh(np.arange(6)+.15, np.ones(6)/3, height=.28,color=ORANGE,label=tr('试样等权','Equal specimens'))
    axes[1].set(yticks=range(6),yticklabels=specimens.specimen,xlim=(0,.62),xlabel=tr('配方内权重，无量纲','Weight within formulation'),title=tr('b  谁在平均值中占得更多','b  Who receives more weight'))
    axes[1].invert_yaxis();axes[1].legend(loc='lower right',fontsize=9)
    for i,row in groups.iterrows():
        axes[2].plot([i-.13,i+.13],[row.q_rows,row.q_equal],color='#9aa6ad',lw=1.5)
        axes[2].scatter(i-.13,row.q_rows,color=BLUE,s=65,label=tr('逐读数','Readings') if i==0 else None)
        axes[2].scatter(i+.13,row.q_equal,color=ORANGE,s=65,label=tr('试样等权','Equal specimens') if i==0 else None)
        axes[2].annotate(f'{row.q_rows:.4f}',(i-.13,row.q_rows),xytext=(-2,12),textcoords='offset points',ha='right',fontsize=10)
        axes[2].annotate(f'{row.q_equal:.4f}',(i+.13,row.q_equal),xytext=(2,-20),textcoords='offset points',ha='left',fontsize=10)
    axes[2].set(xticks=[0,1],xticklabels=['A','B'],xlim=(-.6,1.6),ylim=(2.25,2.95),ylabel='q / g g⁻¹',xlabel=tr('配方','Formulation'),title=tr('c  两个明确的平均问题','c  Two explicit averaging questions'))
    axes[2].legend(loc='upper right',fontsize=9);axes[2].grid(axis='y',alpha=.15)
    save(fig,'units-and-weights')

    fig,ax=plt.subplots(figsize=(13.5,6.4));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    ax.text(.02,.94,tr('2011：把分组计算组织成可复用的步骤','2011: organize grouped computation into reusable steps'),fontsize=19,weight='bold')
    ax.text(.02,.86,tr('Wickham的 split–apply–combine 思路；下方用本节构造读数演示。','Wickham’s split–apply–combine strategy, illustrated with this chapter’s constructed readings.'),fontsize=12)
    boxes=[(.02,.08,.25,.66),(.36,.08,.27,.66),(.73,.08,.25,.66)]
    for x,y,w,h in boxes:ax.add_patch(plt.Rectangle((x,y),w,h,facecolor='#edf3f4',edgecolor='#c5d2d9'))
    for x1,x2 in [(.28,.35),(.64,.72)]:ax.annotate('',xy=(x2,.43),xytext=(x1,.43),arrowprops={'arrowstyle':'->','lw':2,'color':INK})
    ax.text(.04,.68,tr('分开：按试样身份','Split: by specimen'),fontsize=14,weight='bold')
    ax.text(.04,.56,'A01   2.0, 2.2\nA02   2.8\nA03   3.0, 3.2, 3.4',fontsize=15,linespacing=2,va='top')
    ax.text(.04,.15,tr('6条A配方读数','6 readings for A'),fontsize=13)
    ax.text(.38,.68,tr('计算：每个试样一个均值','Apply: specimen mean'),fontsize=13,weight='bold')
    ax.text(.38,.56,'A01   (2.0+2.2)/2 = 2.1\nA02   2.8/1 = 2.8\nA03   (3.0+3.2+3.4)/3 = 3.2',fontsize=12.5,linespacing=2.3,va='top')
    ax.text(.38,.18,tr('保留编号\n与有效读数数','Retain identifiers\nand valid reading counts'),fontsize=12,va='top')
    ax.text(.75,.68,tr('合并：试样汇总表','Combine: summaries'),fontsize=13,weight='bold')
    ax.text(.75,.56,'A01   2.1\nA02   2.8\nA03   3.2',fontsize=14,linespacing=1.6,va='top')
    ax.plot([.75,.96],[.30,.30],color='#9baeb7',lw=1)
    ax.text(.75,.25,tr('下一轮：按配方再分组','Next grouping: formulation'),fontsize=12)
    ax.text(.75,.16,'A: (2.1+2.8+3.2)/3 = 2.7',fontsize=12)
    save(fig,'split-apply-combine')

    fig,axes=plt.subplots(1,2,figsize=(12.5,5.5),layout='constrained')
    copies=range(1,7);curve=[]
    for k in copies:
        _,g,_=summarize(make_table(k));curve.append(g.loc[g.formulation=='A','q_rows'].iloc[0])
    axes[0].plot(list(copies),curve,'o-',lw=2.5,color=BLUE,label=tr('逐读数平均','Mean over rows'))
    axes[0].axhline(2.7,color=ORANGE,lw=2.2,label=tr('3个试样等权','3 equally weighted specimens'))
    axes[0].set(xticks=list(copies),xlabel=tr('A01两条记录的保留份数 k','Copies k of the two A01 records'),ylabel='A: q / g g⁻¹',ylim=(2.1,2.9),title=tr('a  复制记录改变权重','a  Copied records change weights'))
    axes[0].legend(frameon=False);axes[0].grid(alpha=.15)
    absent=make_table(missing=True);s,g,t=summarize(absent)
    counts=pd.DataFrame({'rows':s.rows.to_numpy(),'valid':s.valid.to_numpy()},index=s.specimen)
    im=axes[1].imshow(counts,cmap='Blues',vmin=0,vmax=3,aspect='auto')
    axes[1].set(xticks=[0,1],xticklabels=[tr('行数 size','Rows: size'),tr('有效数 count','Valid: count')],yticks=range(6),yticklabels=counts.index,title=tr('b  A02缺失时，行仍然存在','b  An A02 row remains when q is missing'))
    for i in range(6):
        for j in range(2):axes[1].text(j,i,int(counts.iloc[i,j]),ha='center',va='center',fontsize=19,color='white' if counts.iloc[i,j]>=2 else INK)
    cb=fig.colorbar(im,ax=axes[1],ticks=[0,1,2,3],shrink=.75);cb.set_label(tr('条数','Count'))
    save(fig,'copies-and-missing')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('results'));parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    table=make_table();specimens,groups,traced=summarize(table)
    # A pivot rearranges unique cells. It does not select or average duplicates.
    wide=table.pivot(index='specimen',columns='reading',values='q')
    assert abs(groups.loc[0,'q_rows']-83/30)<1e-12
    assert abs(groups.loc[0,'q_equal']-27/10)<1e-12
    assert abs(groups.loc[1,'q_rows']-123/50)<1e-12
    assert abs(groups.loc[1,'q_equal']-38/15)<1e-12
    assert np.allclose(traced.groupby('specimen').within_specimen.sum(),0)
    _,missing_groups,_=summarize(make_table(missing=True))
    _,copied_groups,_=summarize(make_table(copies=6))
    for name,data in [('readings',table),('specimens',specimens),('formulations',groups),('trace',traced)]:data.to_csv(args.output/f'{name}.csv',index=False)
    wide.to_csv(args.output/'wide.csv')
    summary={'versions':{'pandas':pd.__version__,'numpy':np.__version__},'rows':len(table),'specimens':len(specimens),'A_row_mean':float(groups.q_rows.iloc[0]),'A_equal_mean':float(groups.q_equal.iloc[0]),'B_row_mean':float(groups.q_rows.iloc[1]),'B_equal_mean':float(groups.q_equal.iloc[1]),'A_missing_equal':float(missing_groups.q_equal.iloc[0]),'A_missing_valid_specimens':int(missing_groups.valid_specimens.iloc[0]),'A_six_copies_row_mean':float(copied_groups.q_rows.iloc[0]),'A_six_copies_equal_mean':float(copied_groups.q_equal.iloc[0]),'A_specimen_sd':float(groups.sd_specimens.iloc[0])}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    plot_all(table,specimens,groups,args.output,args.language)
    print(json.dumps(summary))


if __name__=='__main__':main()
