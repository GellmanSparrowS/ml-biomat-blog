"""Mass accounting for a gel: a complete, deterministic teaching example."""
from pathlib import Path
import argparse
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, FancyArrowPatch


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("output"))
    parser.add_argument("--language", choices=["zh", "en"], default="en")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    zh = args.language == "zh"
    def tr(cn, en):
        return cn if zh else en

    # Readings are constructed teaching data, all in grams.
    tare_g = 0.4
    dry_total_g = 1.6
    wet_total_g = 5.2
    dry_g = dry_total_g - tare_g
    wet_g = wet_total_g - tare_g
    water_g = wet_g - dry_g
    uptake_g_per_g = water_g / dry_g
    water_fraction = water_g / wet_g
    print(f"Dry material: {dry_g:.3f} g")
    print(f"Retained water: {water_g:.3f} g")
    print(f"Water per dry material: {uptake_g_per_g:.3f} g/g")
    print(f"Water fraction of wet specimen: {water_fraction:.1%}")

    available = {f.name for f in font_manager.fontManager.ttflist}
    family = next((f for f in ["Noto Sans CJK SC", "Microsoft YaHei", "DejaVu Sans"] if f in available), "DejaVu Sans")
    plt.rcParams.update({"font.family": family, "font.size": 12, "axes.titlesize": 15,
                         "axes.titleweight": "bold", "svg.fonttype": "none",
                         "figure.facecolor": "#fbfaf6", "axes.facecolor": "#fbfaf6",
                         "text.color": "#172b36", "axes.labelcolor": "#172b36",
                         "axes.spines.top": False, "axes.spines.right": False})
    ink, dry_color, water_color, tare_color = "#172b36", "#b85336", "#28648a", "#bfc6c5"
    def save(fig, name):
        fig.savefig(args.output / f"{name}-{args.language}.svg", bbox_inches="tight")
        fig.savefig(args.output / f"{name}-{args.language}.png", dpi=180, bbox_inches="tight")
        plt.close(fig)

    fig = plt.figure(figsize=(12, 6.5), layout="constrained")
    grids = fig.add_gridspec(1, 2, width_ratios=[1.3, 1])
    ax = fig.add_subplot(grids[0])
    labels = [tr("空容器", "Container"), tr("干样 + 容器", "Dry + container"), tr("湿样 + 容器", "Wet + container")]
    ax.barh(labels, [tare_g]*3, color=tare_color, label=tr("容器", "Container"), height=.52)
    ax.barh(labels, [0,dry_g,dry_g], left=[tare_g]*3, color=dry_color, label=tr("干材料", "Dry material"), height=.52)
    ax.barh(labels, [0,0,water_g], left=[tare_g,tare_g,dry_total_g], color=water_color, label=tr("留存水", "Retained water"), height=.52)
    for i, value in enumerate([tare_g,dry_total_g,wet_total_g]):
        ax.text(value+.07, i, f"{value:.2f} g", va="center")
    ax.set(xlim=(0,6.3), xlabel=tr("天平总读数 / g", "Total balance reading / g"), title=tr("a  把每次称量拆开", "a  Account for each weighing"))
    ax.invert_yaxis(); ax.legend(loc="upper right", frameon=False)
    ax.grid(axis="x", alpha=.16); ax.set_axisbelow(True)
    ax = fig.add_subplot(grids[1]); ax.axis("off")
    ax.set_title(tr("b  同一份湿样中的质量", "b  Mass inside the wet specimen"), loc="left")
    ax.add_patch(Rectangle((.08,.28),.84,.42,facecolor=water_color,transform=ax.transAxes))
    ax.add_patch(Rectangle((.08,.28),.84*(1-water_fraction),.42,facecolor=dry_color,transform=ax.transAxes))
    ax.text(.08+.42*(1-water_fraction),.49,f"{dry_g:.2f} g",color="white",ha="center",va="center",transform=ax.transAxes,fontsize=15)
    ax.text(.08+.84*(1-water_fraction)+.42*water_fraction,.49,f"{water_g:.2f} g",color="white",ha="center",va="center",transform=ax.transAxes,fontsize=18)
    ax.text(.08,.80,tr(f"总湿质量 {wet_g:.2f} g，不含容器", f"Wet mass {wet_g:.2f} g, container removed"),transform=ax.transAxes)
    ax.text(.08,.15,tr(f"干材料 {1-water_fraction:.0%}  |  水 {water_fraction:.0%}", f"Dry material {1-water_fraction:.0%}  |  water {water_fraction:.0%}"),transform=ax.transAxes,fontsize=14)
    fig.suptitle(tr("构造称量数据：相减保留了什么？", "Constructed weighings: what remains after subtraction?"),fontsize=17)
    save(fig,"mass-accounting")

    fig, axes = plt.subplots(1,2,figsize=(12,5),layout="constrained")
    water_values = [i*.03 for i in range(201)]
    axes[0].plot(water_values,[v/dry_g for v in water_values],color=dry_color,lw=2.8)
    axes[0].scatter([water_g],[uptake_g_per_g],s=85,color=ink,zorder=3)
    axes[0].annotate(f"{water_g:.2f} / {dry_g:.2f} = {uptake_g_per_g:.2f}",(water_g,uptake_g_per_g),xytext=(1,4),arrowprops={"arrowstyle":"-","color":ink})
    axes[0].set(ylabel=tr("水 / 干材料（g/g）", "Water / dry material (g/g)"),title=tr("a  干质量作分母：直线", "a  Dry mass denominator: a line"))
    axes[1].plot(water_values,[100*v/(dry_g+v) for v in water_values],color=water_color,lw=2.8)
    axes[1].scatter([water_g],[100*water_fraction],s=85,color=ink,zorder=3)
    axes[1].axhline(100,color="#899496",ls="--",lw=1)
    axes[1].annotate(f"{water_g:.2f} / {wet_g:.2f} = {water_fraction:.0%}",(water_g,100*water_fraction),xytext=(1,30),arrowprops={"arrowstyle":"-","color":ink})
    axes[1].set(ylabel=tr("水 / 湿样（%）", "Water / wet specimen (%)"),ylim=(0,108),title=tr("b  湿质量作分母：逐渐接近100%", "b  Wet mass denominator: approaches 100%"))
    for ax in axes:
        ax.set(xlabel=tr("留存水质量 / g", "Retained water mass / g"),xlim=(0,6)); ax.grid(alpha=.16)
    fig.suptitle(tr(f"固定干质量 {dry_g:.2f} g：两种比例回答两个问题", f"Dry mass fixed at {dry_g:.2f} g: two ratios answer two questions"),fontsize=16)
    save(fig,"denominators")

    fig = plt.figure(figsize=(12,7),layout="constrained")
    ax = fig.add_subplot(); ax.axis("off"); ax.set_xlim(0,12); ax.set_ylim(0,7)
    ax.text(0,6.65,tr("a  一段表达式如何连接测量与报告", "a  Expressions connect measurements to reports"),fontsize=17,weight="bold")
    boxes=[(.1,4.3,3.2,1.35,f"dry_total_g = {dry_total_g}\ntare_g = {tare_g}",tare_color),
           (4.2,4.3,3.2,1.35,"dry_g = (\n dry_total_g - tare_g\n)",dry_color),
           (8.3,4.3,3.4,1.35,f"print(dry_g)\n{dry_g!r}",water_color)]
    for x,y,w,h,label,color in boxes:
        ax.add_patch(Rectangle((x,y),w,h,facecolor=color,alpha=.13,edgecolor=color,lw=1.2))
        ax.text(x+.15,y+h/2,label,va="center",fontsize=13)
    for x in [3.35,7.45]: ax.add_patch(FancyArrowPatch((x,4.98),(x+.75,4.98),arrowstyle="->",mutation_scale=17,color=ink))
    ax.text(.1,3.72,tr("每次赋值读取当时的数值；修改输入后，需要重新执行后续计算。", "Each assignment reads current values. Changed inputs require recalculating dependent values."),fontsize=12)
    ax.text(0,2.95,tr("b  Python的起点：可读的语言，能连接已有工具", "b  Python's origins: readable language, access to existing tools"),fontsize=17,weight="bold")
    ax.text(.1,2.15,"ABC",fontsize=21,color=dry_color,weight="bold")
    ax.text(.1,1.55,tr("表达与组织容易阅读", "Readable expressions\nand program structure"),fontsize=13)
    ax.text(4.6,2.15,"Python",fontsize=25,color=ink,weight="bold")
    ax.text(4.6,1.55,tr("1989年开始开发\n1991年公开发布", "Development began in 1989\nPublic release in 1991"),fontsize=13)
    ax.text(8.5,2.15,"Amoeba",fontsize=21,color=water_color,weight="bold")
    ax.text(8.5,1.55,tr("访问操作系统的实际需求", "Practical access to\noperating-system services"),fontsize=13)
    ax.add_patch(FancyArrowPatch((2.6,2.2),(4.3,2.2),arrowstyle="->",mutation_scale=17,color=dry_color))
    ax.add_patch(FancyArrowPatch((8.2,2.2),(6.9,2.2),arrowstyle="->",mutation_scale=17,color=water_color))
    ax.text(.1,.45,tr("今天：少量清楚的Python语句，连接数据文件、数值库与绘图工具。", "Today: a few readable Python statements connect files, numerical libraries and plotting tools."),fontsize=13)
    save(fig,"program-history")
    summary={"dataset":"Constructed mass measurements in grams", "tare_g":tare_g,"dry_total_g":dry_total_g,"wet_total_g":wet_total_g,
             "dry_g":dry_g,"wet_g":wet_g,"water_g":water_g,"uptake_g_per_g":uptake_g_per_g,"water_fraction":water_fraction}
    (args.output/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")


if __name__ == "__main__":
    main()
