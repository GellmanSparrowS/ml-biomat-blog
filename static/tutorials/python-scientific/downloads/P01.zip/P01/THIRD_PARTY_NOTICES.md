# Public sources and third-party materials

- Software Carpentry — Variables and Assignment: https://swcarpentry.github.io/python-novice-gapminder/02-variables.html
  CC BY 4.0, https://creativecommons.org/licenses/by/4.0/; adapted instructional structure, original prose/code/figures.
- Python 3.14 Tutorial — An Informal Introduction: https://docs.python.org/3.14/tutorial/introduction.html
  Python Software Foundation documentation license; https://docs.python.org/3.14/license.html
- Python 3.14 — Using the Interpreter: https://docs.python.org/3.14/tutorial/interpreter.html
  PSF documentation license.
- Python FAQ — Why was Python created?: https://docs.python.org/3/faq/general.html#why-was-python-created-in-the-first-place
  PSF documentation license; original historical diagram.
