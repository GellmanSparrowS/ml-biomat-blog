"""Read, inspect, select, and plot real CC0 Palmer penguin measurements."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import ListedColormap

SPECIES = ['Adelie', 'Chinstrap', 'Gentoo']
COLORS = {'Adelie': '#2e6e91', 'Chinstrap': '#b7553d', 'Gentoo': '#37806a'}
MEASUREMENTS = ['bill_length_mm', 'bill_depth_mm', 'flipper_length_mm', 'body_mass_g']
DTYPES = {'species':'string','island':'string','bill_length_mm':'Float64',
          'bill_depth_mm':'Float64','flipper_length_mm':'Int64',
          'body_mass_g':'Int64','sex':'string','year':'Int64'}


def load_table(path):
    raw = pd.read_csv(path, dtype=DTYPES, na_values=['NA'])
    table = raw.copy()
    table.insert(0, 'record_id', [f'PG{i+1:03d}' for i in range(len(table))])
    table = table.set_index('record_id', drop=False)
    table.index.name = 'record_key'
    table['body_mass_kg'] = table['body_mass_g'] / 1000
    return raw, table


def select_records(table, species='all', island='all', minimum_g=0, complete=False):
    mask = pd.Series(True, index=table.index)
    if species != 'all':
        mask &= table['species'].eq(species)
    if island != 'all':
        mask &= table['island'].eq(island)
    if minimum_g > 0:
        mask &= table['body_mass_g'].ge(minimum_g).fillna(False)
    if complete:
        mask &= table[list(DTYPES)].notna().all(axis=1)
    return table.loc[mask].copy()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path('output'))
    parser.add_argument('--language', choices=['zh', 'en'], default='en')
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    input_path = Path(__file__).with_name('penguins.csv')
    raw, table = load_table(input_path)
    missing = raw.isna().sum()
    complete_measurements = table.dropna(subset=MEASUREMENTS)
    complete_all = table.dropna(subset=list(DTYPES))
    selected = select_records(table, 'Adelie', 'Dream', 4000)
    mass_mean = float(table['body_mass_g'].mean())
    wrong_zero_mean = float(table['body_mass_g'].fillna(0).mean())
    ordered = table.sort_values('body_mass_g', ascending=False, kind='stable', na_position='last')
    with input_path.open(encoding='utf8', newline='') as file:
        independent = list(csv.DictReader(file))
    valid_mass = [int(r['body_mass_g']) for r in independent if r['body_mass_g'] != 'NA']
    selected_ids = [f'PG{i+1:03d}' for i,r in enumerate(independent)
                    if r['species']=='Adelie' and r['island']=='Dream'
                    and r['body_mass_g']!='NA' and int(r['body_mass_g'])>=4000]
    assert selected.index.tolist() == selected_ids
    assert len(raw)==344 and len(complete_measurements)==342 and len(complete_all)==333
    assert missing['body_mass_g']==2 and missing['sex']==11 and len(selected)==14
    assert math.isclose(mass_mean, math.fsum(valid_mass)/len(valid_mass))
    assert float(table.loc['PG001','body_mass_kg']) == 3.75
    assert pd.isna(table.loc['PG004','body_mass_g'])
    table.to_csv(args.output/'penguins_with_ids.csv', index=False, na_rep='NA')
    selected.to_csv(args.output/'selected_records.csv', index=False, na_rep='NA')
    records = json.loads(table.to_json(orient='records'))
    (args.output/'lab-records.json').write_text(json.dumps(records,ensure_ascii=False),encoding='utf8')
    zh=args.language=='zh'; tr=lambda z,e:z if zh else e
    fonts={f.name for f in font_manager.fontManager.ttflist}
    family=[f for f in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if f in fonts]
    plt.rcParams.update({'font.family':family if zh else ['DejaVu Sans','Arial'],
                         'font.size':12,'axes.titlesize':14,'axes.titleweight':'bold',
                         'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none',
                         'figure.facecolor':'#fbfaf6','axes.facecolor':'#fbfaf6','text.color':'#172b36'})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg',bbox_inches='tight')
        fig.savefig(args.output/f'{name}-{args.language}.png',dpi=170,bbox_inches='tight')
        plt.close(fig)

    fig=plt.figure(figsize=(12.6,8.3),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1,.95])
    counts=pd.crosstab(raw['species'],raw['year']).reindex(SPECIES)
    ax=fig.add_subplot(gs[0,0]);im=ax.imshow(counts.to_numpy(),cmap='Blues',vmin=0,vmax=60,aspect='auto')
    for i in range(3):
        for j in range(3):ax.text(j,i,str(counts.iloc[i,j]),ha='center',va='center',fontsize=19,color='white' if counts.iloc[i,j]>35 else '#172b36')
    ax.set(xticks=[0,1,2],xticklabels=counts.columns,yticks=[0,1,2],yticklabels=SPECIES,
           xlabel=tr('研究年份标签','Study-year label'),title=tr('a  三次野外季节留下的记录数','a  Records from three field seasons'))
    fig.colorbar(im,ax=ax,pad=.02).set_label(tr('记录数','Records'))
    ax=fig.add_subplot(gs[0,1]);ax.axis('off')
    ax.text(0,.98,tr('测量对象 → 量与单位 → 数据列','Observation → quantity and unit → column'),fontsize=15,weight='bold',va='top')
    descriptions=[('bill_length_mm',tr('喙长：沿喙的长度 / mm','Bill length / mm')),('bill_depth_mm',tr('喙深：喙的上下尺寸 / mm','Bill depth / mm')),('flipper_length_mm',tr('鳍状肢长度 / mm','Flipper length / mm')),('body_mass_g',tr('身体质量 / g','Body mass / g'))]
    for k,(field,label) in enumerate(descriptions):
        y=.77-k*.20;ax.text(0,y,label,fontsize=13);ax.text(0,y-.08,field,fontsize=12,color='#2e6e91')
    ax=fig.add_subplot(gs[1,:]);ax.axis('off')
    rows=[]
    for _,r in table.iloc[:6].iterrows():
        rows.append([r['record_id'],r['species'],r['island'],str(r['year']), 'NA' if pd.isna(r['body_mass_g']) else str(r['body_mass_g']), 'NA' if pd.isna(r['sex']) else r['sex']])
    tab=ax.table(cellText=rows,colLabels=['record_id','species','island','year','body_mass_g','sex'],cellLoc='center',bbox=[0,.08,1,.78]);tab.auto_set_font_size(False);tab.set_fontsize(12)
    for (i,j),cell in tab.get_celld().items():cell.set_edgecolor('#d1dddd');cell.set_facecolor('#e4eeec' if i==0 else '#fbfaf6');cell.set_text_props(color='#b7553d' if i==4 and j in [4,5] else '#172b36')
    ax.text(0,.98,tr('b  每行是一条观测；PG编号保留CSV中的记录位置','b  One observation per row; generated PG labels preserve CSV record positions'),fontsize=14,weight='bold')
    save(fig,'field-records-history')

    fig=plt.figure(figsize=(12.6,7.7),layout='constrained');gs=fig.add_gridspec(1,2,width_ratios=[1,1.15])
    ax=fig.add_subplot(gs[0,0]);fields=MEASUREMENTS+['sex'];labels=[tr('喙长','Bill length'),tr('喙深','Bill depth'),tr('鳍状肢长','Flipper length'),tr('质量','Body mass'),tr('性别','Sex')];values=[int(missing[c]) for c in fields]
    ax.barh(labels,values,color=['#2e6e91']*4+['#b7553d']);ax.invert_yaxis();ax.set(xlim=(0,13),xticks=range(0,13,2),xlabel=tr('缺失记录数（总数344）','Missing records (344 total)'),title=tr('a  每一列缺了多少','a  Missingness by column'));ax.grid(axis='x',alpha=.15)
    for i,v in enumerate(values):ax.text(v+.2,i,f'{v} / 344',va='center')
    ax=fig.add_subplot(gs[0,1]);incomplete=table.loc[table[fields].isna().any(axis=1),fields];matrix=incomplete.isna().to_numpy(dtype=int)
    ax.imshow(matrix,cmap=ListedColormap(['#e3ecea','#b7553d']),vmin=0,vmax=1,aspect='auto')
    for i in range(len(incomplete)):
        for j in range(5):ax.text(j,i,'NA' if matrix[i,j] else '✓',ha='center',va='center',color='white' if matrix[i,j] else '#286b5a',fontsize=12)
    ax.set(xticks=range(5),xticklabels=labels,yticks=range(len(incomplete)),yticklabels=incomplete.index,title=tr('b  缺失是否落在同一条记录','b  Which fields are missing together'))
    ax.tick_params(axis='x',labelsize=10);fig.suptitle(tr('保留观测身份，才能理解一个空格','A missing entry makes sense within its observation'),fontsize=17,weight='bold')
    save(fig,'missing-records')

    fig=plt.figure(figsize=(12.6,7.7),layout='constrained');gs=fig.add_gridspec(2,2,width_ratios=[1.45,1],height_ratios=[1,1])
    ax=fig.add_subplot(gs[:,0])
    for species in SPECIES:
        sub=table.loc[table['species'].eq(species)].dropna(subset=['flipper_length_mm','body_mass_kg'])
        ax.scatter(sub['flipper_length_mm'].to_numpy(dtype=float),sub['body_mass_kg'].to_numpy(dtype=float),s=30,alpha=.65,color=COLORS[species],label=species)
    ax.scatter(selected['flipper_length_mm'].to_numpy(dtype=float),selected['body_mass_kg'].to_numpy(dtype=float),s=100,facecolors='none',edgecolors='#172b36',lw=1.5,label=tr('筛出的14条记录','14 selected records'))
    ax.axhline(4,color='#172b36',ls=':',lw=1);ax.set(xlabel=tr('鳍状肢长度 / mm','Flipper length / mm'),ylabel=tr('身体质量 / kg','Body mass / kg'),xlim=(170,235),ylim=(2.5,6.6),title=tr('a  同一行的两次测量组成一个点','a  Two measurements from one row form a point'));ax.legend(loc='upper left',fontsize=11);ax.grid(alpha=.12)
    ax=fig.add_subplot(gs[0,1]);bins=np.arange(2500,6501,250)
    ax.hist(table['body_mass_g'].dropna().to_numpy(dtype=float),bins=bins,histtype='step',lw=2,color='#9aa9ac',label=tr('全部有效质量','All observed masses'))
    ax.hist(selected['body_mass_g'].to_numpy(dtype=float),bins=bins,color='#2e6e91',alpha=.75,label=tr('筛选结果','Selected'))
    ax.set(xlabel=tr('身体质量 / g','Body mass / g'),ylabel=tr('记录数','Records'),title=tr('b  阈值之外，还限定物种和岛屿','b  Species and island also determine selection'));ax.legend(fontsize=10);ax.grid(axis='y',alpha=.12)
    ax=fig.add_subplot(gs[1,1]);ax.axis('off');ax.text(0,.95,'Adelie  ∩  Dream  ∩  mass ≥ 4000 g',fontsize=13,weight='bold');ax.text(0,.74,tr('344条记录 → 14条满足全部条件','344 records → 14 meet every condition'),fontsize=13)
    ax.text(0,.54,tr('原始位置编号保留，例如：','Original-position labels remain, for example:'),fontsize=12)
    for i,(_,r) in enumerate(selected.head(4).iterrows()):ax.text(0,.37-i*.1,f"{r['record_id']}    {r['flipper_length_mm']} mm    {r['body_mass_g']} g",fontsize=12)
    save(fig,'linked-selection')
    summary={'dataset':'Palmer penguins, CC0','input_sha256':hashlib.sha256(input_path.read_bytes()).hexdigest(),
             'raw_shape':list(raw.shape),'dtypes':{k:str(v) for k,v in raw.dtypes.items()},'missing_counts':{k:int(v) for k,v in missing.items()},
             'measurement_complete_rows':len(complete_measurements),'all_complete_rows':len(complete_all),
             'selected_count':len(selected),'selected_ids':selected_ids,'mass_observed_count':len(valid_mass),
             'mean_mass_g':mass_mean,'zero_filled_mean_mass_g':wrong_zero_mean,
             'first_record_mass_kg':float(table.loc['PG001','body_mass_kg']),
             'heaviest_record':ordered.iloc[0]['record_id'],'heaviest_mass_g':int(ordered.iloc[0]['body_mass_g']),
             'missing_record_ids':incomplete.index.tolist(),'year_counts':json.loads(counts.to_json(orient='index'))}
    (args.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
