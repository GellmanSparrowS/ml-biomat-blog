# Public sources and third-party materials

- pandas: Read and write tabular data: https://pandas.pydata.org/docs/getting_started/intro_tutorials/02_read_write.html
  BSD-3-Clause; original teaching code
- pandas: Select a subset of a DataFrame: https://pandas.pydata.org/docs/getting_started/intro_tutorials/03_subset_data.html
  BSD-3-Clause
- pandas: Working with missing data: https://pandas.pydata.org/pandas-docs/version/3.0/user_guide/missing_data.html
  BSD-3-Clause
- Palmer penguins data: https://allisonhorst.github.io/palmerpenguins/
  CC0 data; no artwork reproduced
- Gorman, Williams & Fraser (2014): https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0090081
  CC BY article; factual context
- McKinney (2010): Data Structures for Statistical Computing in Python: https://doi.org/10.25080/Majora-92bf1922-00a
  CC BY4.0 proceedings article
