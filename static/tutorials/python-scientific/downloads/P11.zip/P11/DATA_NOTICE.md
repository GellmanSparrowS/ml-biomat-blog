Palmer penguins data

The file `penguins.csv` is the simplified eight-column dataset distributed by the palmerpenguins project.

Data: Kristen B. Gorman and Palmer Station Antarctica Long Term Ecological Research.
Package: Allison M. Horst, Alison P. Hill, and Kristen B. Gorman (2020), palmerpenguins, https://allisonhorst.github.io/palmerpenguins/ .
Original research: Gorman, Williams and Fraser (2014), https://doi.org/10.1371/journal.pone.0090081 .

Data license: CC0 1.0, https://creativecommons.org/publicdomain/zero/1.0/ . The project's data-license statement is at https://allisonhorst.github.io/palmerpenguins/ .

Exact input: https://raw.githubusercontent.com/allisonhorst/palmerpenguins/main/inst/extdata/penguins.csv
SHA-256: f204db2c753b0937caac3cb35258562c14f073e4bbc76be24b4c51ce22767a93

The CSV is retained unchanged. PG001–PG344 in the example are generated record labels tied to this file's row order, not original animal identifiers. All figures and teaching code in this example are newly created.
