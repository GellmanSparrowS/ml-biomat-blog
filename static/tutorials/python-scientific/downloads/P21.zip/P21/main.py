"""Follow a conserved three-state conversion with integration and an ODE solver."""
from pathlib import Path
import argparse,json
import numpy as np
import scipy
from scipy.integrate import solve_ivp,quad,trapezoid
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

COLORS=['#28658c','#c26835','#477f67']
K1,K2=.8,.3


def exact(t,k1=K1,k2=K2):
    t=np.asarray(t);a=np.exp(-k1*t)
    b=k1/(k2-k1)*(np.exp(-k1*t)-np.exp(-k2*t))
    return np.array([a,b,1-a-b])


def rhs(t,y,k1=K1,k2=K2):
    a,b,c=y
    return np.array([-k1*a,k1*a-k2*b,k2*b])


def euler(h,k1=K1,k2=K2):
    t=np.linspace(0,10,round(10/h)+1);y=np.zeros((3,len(t)));y[:,0]=[1,0,0]
    for i in range(len(t)-1):y[:,i+1]=y[:,i]+h*rhs(t[i],y[:,i],k1,k2)
    return t,y


def b_integral(end,k1=K1,k2=K2):
    return k1/(k2-k1)*((1-np.exp(-k1*end))/k1-(1-np.exp(-k2*end))/k2)


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
    def tr(a,b):return a if zh else b
    available={f.name for f in font_manager.fontManager.ttflist}
    plt.rcParams.update({'font.family':[f for f in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if f in available],'font.size':12,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'grid.alpha':.15})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg');fig.savefig(args.output/f'{name}-{args.language}.png',dpi=160);plt.close(fig)
    t=np.linspace(0,10,501)
    def peak_b(t,y):return K1*y[0]-K2*y[1]
    peak_b.direction=-1
    solution=solve_ivp(rhs,(0,10),[1.,0.,0.],t_eval=t,rtol=1e-9,atol=1e-11,events=peak_b)
    if not solution.success:raise RuntimeError(solution.message)
    reference=exact(t);area,area_error=quad(lambda time:float(exact(time)[1]),0,10,epsabs=1e-11)
    comparisons={}
    for h in [.1,.5,1.,2.]:
        te,ye=euler(h);comparisons[str(h)]={'max_error':float(np.max(np.abs(ye-exact(te)))),'min_fraction':float(ye.min()),'sum_error':float(np.max(np.abs(ye.sum(axis=0)-1))),
            'first_step':ye[:,1].tolist(),'final':ye[:,-1].tolist(),'left_integral_B_min':float(h*ye[1,:-1].sum())}
    np.savetxt(args.output/'fractions.csv',np.column_stack([t,solution.y.T,reference.T]),delimiter=',',comments='',header='time_min,A_numeric,B_numeric,C_numeric,A_exact,B_exact,C_exact')
    fig,ax=plt.subplots(1,2,figsize=(12,5.8),layout='constrained',gridspec_kw={'width_ratios':[1.5,1]})
    for i,name in enumerate('ABC'):ax[0].plot(t,solution.y[i],color=COLORS[i],lw=2.3,label=name)
    ax[0].set(xlabel=tr('时间 / min','Time / min'),ylabel=tr('状态分数，无量纲','State fraction, dimensionless'),title=tr('A → B → C：中间态先升后降','A → B → C: an intermediate rises and falls'),xlim=(0,10),ylim=(0,1));ax[0].legend(frameon=False);ax[0].grid()
    ax[1].fill_between(t,0,reference[1],color=COLORS[1],alpha=.2);ax[1].plot(t,reference[1],color=COLORS[1],lw=2)
    ax[1].text(.96,.92,tr(f'0–10 min的面积\n{area:.6f} min',f'Area over 0–10 min\n{area:.6f} min'),ha='right',va='top',transform=ax[1].transAxes)
    ax[1].set(xlabel=tr('时间 / min','Time / min'),ylabel=tr('B的分数，无量纲','Fraction in B, dimensionless'),title=tr('面积累计“数量 × 持续时间”','Area accumulates fraction × time'),xlim=(0,10),ylim=(0,.65));ax[1].grid();save(fig,'conversion')
    fig,ax=plt.subplots(1,2,figsize=(12,5.8),layout='constrained')
    for h,color in zip([1.,.5,.1],['#b64a35','#8f8990',COLORS[0]]):
        te,ye=euler(h);ax[0].plot(te,ye[0],'.-',color=color,lw=1.4,label=f'h = {h:g} min')
    ax[0].plot(t,reference[0],'--',color='#20313e',lw=1.8,label=tr('解析曲线','Analytic curve'))
    ax[0].set(xlim=(0,3),ylim=(0,1.02),xlabel=tr('时间 / min','Time / min'),ylabel=tr('A的分数，无量纲','Fraction in A, dimensionless'),title=tr('欧拉步：沿当前斜率向前走','Euler steps: advance along the current slope'));ax[0].legend(frameon=False,fontsize=10);ax[0].grid()
    hvals=np.array([.025,.05,.1,.2,.5,1.]);errors=[]
    for h in hvals:
        te,ye=euler(h);errors.append(np.max(np.abs(ye-exact(te))))
    ax[1].loglog(hvals,errors,'o-',color=COLORS[1],label=tr('三种分数的最大绝对误差','Maximum absolute error across A, B, C'))
    ax[1].loglog(hvals,errors[0]*hvals/hvals[0],':',color='#71808b',label=tr('与步长成正比的参考线','Reference proportional to step size'))
    ax[1].set(xlabel=tr('步长 h / min','Step size h / min'),ylabel=tr('最大绝对误差，无量纲','Maximum absolute error, dimensionless'),title=tr('缩短步长，检验逐步逼近','Reduce the step and inspect convergence'));ax[1].legend(frameon=False,fontsize=9);ax[1].grid(which='both');save(fig,'history')
    fig,ax=plt.subplots(2,1,figsize=(12,7.5),layout='constrained',gridspec_kw={'height_ratios':[1.5,1]})
    te,ye=euler(2.)
    for i,name in enumerate('ABC'):
        ax[0].plot(t,reference[i],color=COLORS[i],alpha=.5,ls='--');ax[0].plot(te,ye[i],'o-',color=COLORS[i],label=name)
    ax[0].axhline(0,color='#20313e',lw=1);ax[0].set(ylabel=tr('状态分数，无量纲','State fraction, dimensionless'),title=tr('h = 2 min：总量保持，个别分数却变成负值','h = 2 min: total is conserved while a fraction becomes negative'));ax[0].legend(frameon=False,ncol=3);ax[0].grid()
    ax[1].plot(te,ye.sum(axis=0),'o-',color='#20313e');ax[1].set(ylim=(.95,1.05),xlabel=tr('时间 / min','Time / min'),ylabel=tr('A + B + C，无量纲','A + B + C, dimensionless'),title=tr('守恒、非负与准确性是三项不同检查','Conservation, positivity, and accuracy are separate checks'));ax[1].grid();save(fig,'checks')
    summary={'versions':{'numpy':np.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__},'rates_per_min':[K1,K2],
        'solver_success':bool(solution.success),'solver_max_error':float(np.max(np.abs(solution.y-reference))),
        'solver_sum_error':float(np.max(np.abs(solution.y.sum(axis=0)-1))),
        'B_peak_time_min':float(solution.t_events[0][0]),'B_peak_time_exact_min':float(np.log(K1/K2)/(K1-K2)),
        'integral_B_min':area,'integral_B_exact_min':float(b_integral(10)),'quad_error_estimate_min':area_error,
        'trapezoid_B_min':float(trapezoid(reference[1],x=t)),'euler':comparisons}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))


if __name__=='__main__':main()
