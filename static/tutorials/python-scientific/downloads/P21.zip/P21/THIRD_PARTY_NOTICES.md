# Public sources and third-party materials

- SciPy: Integration tutorial: https://docs.scipy.org/doc/scipy/tutorial/integrate.html
  BSD-3-Clause; technical reference
- SciPy: solve_ivp: https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.solve_ivp.html
  BSD-3-Clause; technical reference
- SciPy: quad: https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.quad.html
  BSD-3-Clause; technical reference
- Euler Archive: Foundations of integral calculus, volume 1: https://scholarlycommons.pacific.edu/euler-works/342/
  Public-domain original; bibliographic reference
