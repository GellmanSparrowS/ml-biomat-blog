"""Fit concentration trends while preserving experimental batch identity."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import statsmodels
import statsmodels.formula.api as smf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
COLORS={'A':'#28658c','B':'#c26835'}


def data(offset=-10.,perturbation=0.):
    rows=[]
    for batch,levels in [('A',[1.,2.,3.]),('B',[4.,5.,6.])]:
        for concentration in levels:
            for residual in [-.4,0.,.4]:
                rows.append({'specimen':len(rows)+1,'batch':batch,'concentration':concentration,
                    'response':10+2*concentration+(offset if batch=='B' else 0)+residual})
    frame=pd.DataFrame(rows);frame.loc[17,'response']+=perturbation
    return frame


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    zh=args.language=='zh';tr=lambda z,e:z if zh else e;available={f.name for f in font_manager.fontManager.ttflist}
    plt.rcParams.update({'font.family':[f for f in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if f in available],'font.size':12,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'grid.alpha':.15})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg');fig.savefig(args.output/f'{name}-{args.language}.png',dpi=160);plt.close(fig)
    frame=data();pooled=smf.ols('response ~ concentration',data=frame).fit();adjusted=smf.ols('response ~ concentration + C(batch)',data=frame).fit()
    design=adjusted.model.exog;independent=np.linalg.lstsq(design,frame.response.to_numpy(),rcond=None)[0]
    assert np.allclose(independent,adjusted.params.to_numpy())
    centered=frame[['concentration','response']]-frame.groupby('batch')[['concentration','response']].transform('mean')
    centered_slope=float(np.dot(centered.concentration,centered.response)/np.dot(centered.concentration,centered.concentration))
    changed=data(perturbation=6.);changed_fit=smf.ols('response ~ concentration + C(batch)',data=changed).fit();influence=changed_fit.get_influence();without=smf.ols('response ~ concentration + C(batch)',data=changed.iloc[:-1]).fit()
    frame.to_csv(args.output/'specimens.csv',index=False);changed.to_csv(args.output/'perturbed-specimens.csv',index=False)
    diagnostics=pd.DataFrame({'specimen':changed.specimen,'fitted':changed_fit.fittedvalues,'residual':changed_fit.resid,'leverage':influence.hat_matrix_diag,'cooks_distance':influence.cooks_distance[0]});diagnostics.to_csv(args.output/'diagnostics.csv',index=False)
    fig,ax=plt.subplots(1,2,figsize=(12,5.8),layout='constrained')
    for batch,group in frame.groupby('batch'):
        for a in ax:a.scatter(group.concentration,group.response,color=COLORS[batch],label=tr(f'批次{batch}',f'Batch {batch}'),s=45)
        x=np.linspace(group.concentration.min(),group.concentration.max(),100);prediction=adjusted.predict(pd.DataFrame({'concentration':x,'batch':batch}));ax[1].plot(x,prediction,color=COLORS[batch],lw=2)
    x=np.linspace(1,6,200);ax[0].plot(x,pooled.predict(pd.DataFrame({'concentration':x})),color='#20313e',lw=2,label=tr('合并直线','Pooled line'))
    for a in ax:a.set(xlabel=tr('浓度 / mmol·L⁻¹','Concentration / mmol·L⁻¹'),ylabel=tr('响应 / kPa','Response / kPa'),ylim=(6.5,17));a.legend(frameon=False,fontsize=10);a.grid()
    ax[0].set_title(tr('合并所有点：斜率 −0.5714','All points pooled: slope −0.5714'));ax[1].set_title(tr('保留批次：共同斜率 +2','Retain batch: common slope +2'));save(fig,'regression')
    fig,ax=plt.subplots(2,2,figsize=(12,9),layout='constrained')
    for j,model in enumerate([pooled,adjusted]):
        for batch,group in frame.groupby('batch'):ax[0,j].scatter(group.concentration,model.resid.loc[group.index],color=COLORS[batch],s=42,label=batch)
        ax[0,j].axhline(0,color='#20313e',lw=1);ax[0,j].set(xlabel=tr('浓度 / mmol·L⁻¹','Concentration / mmol·L⁻¹'),ylabel=tr('残差 / kPa','Residual / kPa'),title=tr('合并模型的残差','Pooled-model residuals') if j==0 else tr('批次模型的残差','Batch-model residuals'));ax[0,j].legend(frameon=False)
    ax[1,0].bar(changed.specimen,influence.cooks_distance[0],color=[COLORS[b] for b in changed.batch]);ax[1,0].set(xticks=[1,3,6,9,12,15,18],xlabel=tr('试样编号','Specimen index'),ylabel=tr('Cook距离，无量纲','Cook distance, dimensionless'),title=tr('给18号读数增加6 kPa后','After adding 6 kPa to specimen 18'))
    slopes=[adjusted.params['concentration'],changed_fit.params['concentration'],without.params['concentration']]
    ax[1,1].scatter([0,1,2],slopes,s=65,color=['#20313e','#b64a35',COLORS['A']]);ax[1,1].plot([0,1,2],slopes,color='#8f9ca5',lw=1);ax[1,1].set(xlim=(-.5,2.5),xticks=[0,1,2],xticklabels=[tr('原数据','Original'),tr('18号+6','18 + 6'),tr('逐一检查：\n去掉18号','Diagnostic refit:\nleave out 18')],ylabel=tr('浓度系数 / kPa·L·mmol⁻¹','Concentration coefficient / kPa·L·mmol⁻¹'),title=tr('读数影响通过重新拟合核对','Check influence by refitting'))
    for a in ax.flat:a.grid(axis='y')
    save(fig,'diagnostics')
    fig,ax=plt.subplots(1,2,figsize=(12,5.8),layout='constrained')
    for batch,group in frame.groupby('batch'):
        ax[0].scatter(group.concentration,group.response,color=COLORS[batch],label=batch,s=40)
        ax[0].scatter(group.concentration.mean(),group.response.mean(),marker='D',s=100,edgecolor='#20313e',color=COLORS[batch])
        c=centered.loc[group.index];ax[1].scatter(c.concentration,c.response,color=COLORS[batch],s=55 if batch=='A' else 25,marker='o' if batch=='A' else 'x',label=batch)
    ax[0].plot([2,5],[14,10],color='#71808b',ls='--',label=tr('批次均值之间的方向','Direction between batch means'))
    ax[0].set(xlabel=tr('原浓度 / mmol·L⁻¹','Original concentration / mmol·L⁻¹'),ylabel=tr('原响应 / kPa','Original response / kPa'),title=tr('组间位置改变合并趋势','Between-group positions change the pooled trend'))
    ax[1].plot([-1.1,1.1],[-2.2,2.2],color='#20313e',label=tr('批次中心化斜率2','Within-batch centered slope 2'))
    ax[1].set(xlabel=tr('浓度 − 批次均值 / mmol·L⁻¹','Concentration − batch mean / mmol·L⁻¹'),ylabel=tr('响应 − 批次均值 / kPa','Response − batch mean / kPa'),title=tr('减去各批次均值，显出组内变化','Subtract each batch mean to expose within-group change'))
    for a in ax:a.legend(frameon=False,fontsize=9);a.grid()
    save(fig,'history')
    summary={'versions':{'numpy':np.__version__,'pandas':pd.__version__,'statsmodels':statsmodels.__version__,'matplotlib':matplotlib.__version__},'n':len(frame),
        'pooled_slope':float(pooled.params['concentration']),'pooled_intercept':float(pooled.params['Intercept']),'adjusted_slope':float(adjusted.params['concentration']),'adjusted_intercept_A':float(adjusted.params['Intercept']),'batch_B_shift':float(adjusted.params['C(batch)[T.B]']),
        'pooled_sse':float(pooled.ssr),'adjusted_sse':float(adjusted.ssr),'centered_slope':centered_slope,'design_columns':adjusted.model.exog_names,
        'perturbed_slope':float(changed_fit.params['concentration']),'leave18out_slope':float(without.params['concentration']),'specimen18_cook':float(influence.cooks_distance[0][-1]),'specimen18_leverage':float(influence.hat_matrix_diag[-1])}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))


if __name__=='__main__':main()
