# Public sources and third-party materials

- statsmodels 0.14.6: Fitting models using formulas: https://www.statsmodels.org/v0.14.6/example_formulas.html
  BSD-3-Clause; technical reference
- statsmodels: OLS: https://www.statsmodels.org/stable/generated/statsmodels.regression.linear_model.OLS.html
  BSD-3-Clause; technical reference
- statsmodels: OLSInfluence: https://www.statsmodels.org/stable/generated/statsmodels.stats.outliers_influence.OLSInfluence.html
  BSD-3-Clause; technical reference
- Simpson (1951): The Interpretation of Interaction in Contingency Tables: https://doi.org/10.1111/j.2517-6161.1951.tb00088.x
  Copyrighted article; historical reference only
