# Public sources and third-party materials

- SciPy: ttest_1samp: https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ttest_1samp.html
  BSD-3-Clause; technical reference
- SciPy: Student t distribution: https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.t.html
  BSD-3-Clause; technical reference
- SciPy: sem: https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.sem.html
  BSD-3-Clause; technical reference
- Student (1908), The Probable Error of a Mean: https://en.wikisource.org/wiki/The_Probable_Error_of_a_Mean
  Public-domain original; historical reference
