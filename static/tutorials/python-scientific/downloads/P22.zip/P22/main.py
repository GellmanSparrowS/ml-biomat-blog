"""Study sample means, Student intervals, and repeated-sampling coverage."""
from pathlib import Path
import argparse,json
import numpy as np
import scipy
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
SEED=20261114
MU,SIGMA=20.,4.
BLUE,RED,INK='#28658c','#b64a35','#20313e'


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    zh=args.language=='zh';tr=lambda z,e:z if zh else e
    available={f.name for f in font_manager.fontManager.ttflist};plt.rcParams.update({'font.family':[f for f in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if f in available],'font.size':12,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'grid.alpha':.15})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg');fig.savefig(args.output/f'{name}-{args.language}.png',dpi=160);plt.close(fig)
    bank=np.random.default_rng(SEED).normal(MU,SIGMA,size=(200,50));cases={};critical={}
    for n in [5,10,30,50]:
        samples=bank[:,:n];test=stats.ttest_1samp(samples,MU,axis=1)
        for confidence in [.9,.95,.99]:
            interval=test.confidence_interval(confidence_level=confidence);means=samples.mean(axis=1);sem=stats.sem(samples,axis=1);q=float(stats.t.ppf((1+confidence)/2,n-1));critical[f'{n}_{confidence}']=q
            assert np.allclose(interval.low,means-q*sem)
            cases[f'{n}_{confidence}']={'coverage_count':int(np.sum((interval.low<=MU)&(MU<=interval.high))),
                'mean_interval_width_kPa':float(np.mean(interval.high-interval.low)),
                'selected_mean_kPa':float(means[0]),'selected_sem_kPa':float(sem[0]),'selected_low_kPa':float(interval.low[0]),'selected_high_kPa':float(interval.high[0]),
                'selected_t':float(test.statistic[0]),'selected_p':float(test.pvalue[0])}
    hand=np.array([16,18,20,22,24.]);hand_sem=float(stats.sem(hand));hand_q=float(stats.t.ppf(.975,4));hand_test=stats.ttest_1samp(hand,20.)
    np.savetxt(args.output/'samples.csv',bank,delimiter=',',header=','.join(f'specimen_{i+1}' for i in range(50)),comments='')
    bank_data={'samples':bank.tolist(),'critical':critical,'population_mean_kPa':MU,'population_sd_kPa':SIGMA,'seed':SEED}
    (args.output/'sample-bank.json').write_text(json.dumps(bank_data),encoding='utf-8')
    n=10;sample=bank[0,:n];means=bank[:,:n].mean(axis=1);test=stats.ttest_1samp(bank[:,:n],MU,axis=1);ci=test.confidence_interval();covers=(ci.low<=MU)&(MU<=ci.high)
    fig,ax=plt.subplots(1,2,figsize=(12,5.8),layout='constrained')
    ax[0].scatter(np.arange(1,n+1),sample,color=BLUE,s=55);ax[0].axhline(sample.mean(),color=BLUE,label=tr('该组样本均值','This sample mean'));ax[0].axhline(MU,color=INK,ls='--',label=tr('规定总体均值20 kPa','Defined population mean 20 kPa'))
    ax[0].set(xlabel=tr('独立试样编号','Independent specimen index'),ylabel=tr('教学读数 / kPa','Teaching reading / kPa'),title=tr('一组10个试样，保留每个读数','One group of ten specimens, all readings visible'),xticks=[1,3,5,7,10]);ax[0].legend(frameon=False,fontsize=10);ax[0].grid()
    ax[1].hist(means,bins=np.arange(15,25.5,.5),color='#b6d0df',edgecolor='white');ax[1].axvline(MU,color=INK,ls='--');ax[1].axvline(sample.mean(),color=RED,label=tr('左图这一组的均值','Mean of the group shown at left'))
    ax[1].set(xlabel=tr('每组的样本均值 / kPa','Sample mean of each group / kPa'),ylabel=tr('组数','Number of groups'),title=tr('200组独立抽样，形成均值分布','200 independent groups form a mean distribution'));ax[1].legend(frameon=False,fontsize=10);save(fig,'sampling')
    fig,ax=plt.subplots(1,2,figsize=(12,5.8),layout='constrained');x=np.linspace(-5,5,1001)
    ax[0].plot(x,stats.norm.pdf(x),color=INK,ls='--',label=tr('标准正态','Standard normal'))
    for df,color in [(4,RED),(49,BLUE)]:ax[0].plot(x,stats.t.pdf(x,df),color=color,label=f't, df = {df}')
    mask=np.abs(x)>=hand_q;ax[0].fill_between(x,0,stats.t.pdf(x,4),where=mask,color=RED,alpha=.2);ax[0].set(xlabel=tr('标准化统计量，无量纲','Standardized statistic, dimensionless'),ylabel=tr('概率密度','Probability density'),title=tr('Student（1908）：小样本还要估计波动','Student (1908): small samples also estimate spread'));ax[0].legend(frameon=False,fontsize=10)
    ns=np.arange(3,61);qs=stats.t.ppf(.975,ns-1);ax[1].plot(ns,qs,color=RED,lw=2);ax[1].axhline(stats.norm.ppf(.975),color=INK,ls='--');ax[1].scatter([5,50],stats.t.ppf(.975,np.array([4,49])),color=RED)
    ax[1].annotate('n = 5: 2.776',(5,hand_q),xytext=(11,3.2),arrowprops={'arrowstyle':'-','color':RED});ax[1].set(xlabel=tr('每组独立试样数 n','Independent specimens per group, n'),ylabel=tr('95%区间的临界倍数','Critical multiplier for a 95% interval'),title=tr('样本增多，临界倍数逐渐靠近1.96','With more observations, the multiplier approaches 1.96'));ax[1].grid();save(fig,'history')
    fig,ax=plt.subplots(1,2,figsize=(12,8.4),layout='constrained',gridspec_kw={'width_ratios':[1.5,1]})
    for i in range(40):ax[0].plot([ci.low[i],ci.high[i]],[i+1,i+1],color=BLUE if covers[i] else RED,lw=1.8);ax[0].scatter(means[i],i+1,color=BLUE if covers[i] else RED,s=14)
    ax[0].axvline(MU,color=INK,ls='--');ax[0].invert_yaxis();ax[0].set(xlabel=tr('均值与95%置信区间 / kPa','Mean and 95% confidence interval / kPa'),ylabel=tr('独立抽样组编号','Independent sample-group index'),title=tr('展示前40组：区间随样本变化','First 40 groups: intervals vary across samples'))
    counts=[cases[f'{n}_0.95']['coverage_count'] for n in [5,10,30,50]]
    ax[1].bar([0,1,2,3],np.array(counts)/2,color=BLUE,width=.55);ax[1].axhline(95,color=RED,ls='--',label=tr('设定置信水平95%','Nominal confidence 95%'))
    for i,count in enumerate(counts):ax[1].text(i,max(97,count/2+2),f'{count}/200',ha='center',fontsize=11)
    ax[1].set(xticks=[0,1,2,3],xticklabels=[5,10,30,50],ylim=(0,105),xlabel=tr('每组试样数 n','Specimens per group, n'),ylabel=tr('覆盖20 kPa的比例 / %','Intervals covering 20 kPa / %'),title=tr('全部200组的实际覆盖率','Observed coverage over all 200 groups'));ax[1].legend(frameon=False,fontsize=9);save(fig,'coverage')
    summary={'versions':{'numpy':np.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__},'seed':SEED,'groups':200,'cases':cases,
        'hand_mean_kPa':float(hand.mean()),'hand_sd_kPa':float(hand.std(ddof=1)),'hand_sem_kPa':hand_sem,'hand_critical95':hand_q,'hand_halfwidth95_kPa':hand_q*hand_sem,'hand_t':float(hand_test.statistic),'hand_p':float(hand_test.pvalue)}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))


if __name__=='__main__':main()
