"""Create a linked-ready Plotly figure for an analytic cyclic viscoelastic response."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import plotly
import plotly.graph_objects as go
from plotly.subplots import make_subplots

E,AMPLITUDE,FREQUENCY=20.,.05,.25
BLUE,RED,INK='#28658c','#b64a35','#20313e'


def cycle(eta=4.,frequency=FREQUENCY,n=361):
    time=np.linspace(0,1/frequency,n);omega=2*np.pi*frequency
    strain=AMPLITUDE*np.sin(omega*time)
    rate=AMPLITUDE*omega*np.cos(omega*time)
    stress=E*strain+eta*rate
    return time,strain,rate,stress


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
    def tr(a,b):return a if zh else b
    plt.rcParams.update({'font.family':[name for name in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if name in {f.name for f in font_manager.fontManager.ttflist}],'font.size':12,
        'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'grid.alpha':.15})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg');fig.savefig(args.output/f'{name}-{args.language}.png',dpi=160);plt.close(fig)
    time,strain,rate,stress=cycle();eta=4.;omega=2*np.pi*FREQUENCY
    np.savetxt(args.output/'cycle.csv',np.column_stack([time,strain,rate,stress]),delimiter=',',
        header='time_s,strain,strain_rate_per_s,stress_kPa',comments='')
    custom=np.column_stack([np.arange(len(time)),time,strain*100,stress]).tolist()
    plot=make_subplots(rows=2,cols=2,specs=[[{'colspan':2},None],[{},{}]],
        subplot_titles=[tr('应力—应变轨迹','Stress–strain trajectory'),tr('应变随时间变化','Strain over time'),tr('应力随时间变化','Stress over time')],vertical_spacing=.17)
    hover=tr('记录 %{customdata[0]}<br>t=%{customdata[1]:.3f} s<br>应变=%{customdata[2]:.3f}%<br>应力=%{customdata[3]:.4f} kPa<extra></extra>',
             'Record %{customdata[0]}<br>t=%{customdata[1]:.3f} s<br>strain=%{customdata[2]:.3f}%<br>stress=%{customdata[3]:.4f} kPa<extra></extra>')
    for row,col,x,y,color in [(1,1,strain*100,stress,BLUE),(2,1,time,strain*100,BLUE),(2,2,time,stress,RED)]:
        plot.add_trace(go.Scatter(x=x.tolist(),y=y.tolist(),mode='lines',line={'color':color,'width':3},
                        customdata=custom,hovertemplate=hover,showlegend=False),row=row,col=col)
    for row,col,x,y in [(1,1,strain*100,stress),(2,1,time,strain*100),(2,2,time,stress)]:
        plot.add_trace(go.Scatter(x=[float(x[45])],y=[float(y[45])],mode='markers',
            marker={'color':RED,'size':12},customdata=[custom[45]],hovertemplate=hover,
            showlegend=False),row=row,col=col)
    plot.update_xaxes(title_text=tr('应变 / %','Strain / %'),row=1,col=1)
    plot.update_yaxes(title_text=tr('应力 / kPa','Stress / kPa'),row=1,col=1)
    for col in [1,2]:plot.update_xaxes(title_text=tr('时间 / s','Time / s'),row=2,col=col)
    plot.update_yaxes(title_text=tr('应变 / %','Strain / %'),row=2,col=1)
    plot.update_yaxes(title_text=tr('应力 / kPa','Stress / kPa'),row=2,col=2)
    plot.update_layout(template='plotly_white',height=850,font={'size':15},margin={'l':70,'r':30,'t':70,'b':60},
        title=tr('周期加载：同一记录的三种坐标','Cyclic loading: three coordinate views of each record'))
    plot.write_json(args.output/'figure.json')
    linked_click="""
    const graph=document.getElementById('{plot_id}');
    graph.on('plotly_click',event=>{
      const record=event.points[0].customdata;
      if(!record)return;
      Plotly.restyle(graph,{x:[[record[2]],[record[1]],[record[1]]],
        y:[[record[3]],[record[2]],[record[3]]],
        customdata:[[record],[record],[record]]},[3,4,5]);
    });
    """
    plot.write_html(args.output/'interactive.html',include_plotlyjs=True,full_html=True,
                    post_script=linked_click,config={'displaylogo':False,'responsive':True})
    fig,axes=plt.subplot_mosaic([['loop','loop'],['strain','stress']],figsize=(12,9),layout='constrained')
    points=[0,90,180,270]
    axes['loop'].plot(strain*100,stress,color=BLUE,lw=2.5)
    axes['loop'].fill(strain*100,stress,color=BLUE,alpha=.08)
    axes['strain'].plot(time,strain*100,color=BLUE,lw=2);axes['stress'].plot(time,stress,color=RED,lw=2)
    for i in points:
        color=plt.colormaps['viridis'](i/360)
        for key,x,y in [('loop',strain[i]*100,stress[i]),('strain',time[i],strain[i]*100),('stress',time[i],stress[i])]:
            axes[key].scatter([x],[y],color=color,s=45,zorder=5)
            axes[key].annotate(f'{i}°',(x,y),xytext=(8,8),textcoords='offset points',fontsize=10)
    axes['loop'].set(xlabel=tr('应变 / %','Strain / %'),ylabel=tr('应力 / kPa','Stress / kPa'),title=tr('A  闭合轨迹与四个周期位置','A  Closed trajectory and four cycle positions'))
    axes['strain'].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('应变 / %','Strain / %'),title=tr('B  输入的形变','B  Imposed deformation'))
    axes['stress'].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('应力 / kPa','Stress / kPa'),title=tr('C  模型的应力响应','C  Model stress response'))
    for ax in axes.values():ax.grid();ax.margins(.12)
    save(fig,'linked')
    fig,axes=plt.subplots(1,2,figsize=(12,5.5),layout='constrained')
    viscosity_colors=dict(zip([0,2,4,8],plt.colormaps['viridis'](np.linspace(.15,.85,4))))
    for visc,color in viscosity_colors.items():
        tt,eps,rr,sig=cycle(visc);axes[0].plot(eps*100,sig,color=color,lw=2,label=f'η={visc:g} kPa·s')
    axes[0].set(xlabel=tr('应变 / %','Strain / %'),ylabel=tr('应力 / kPa','Stress / kPa'),title=tr('黏性项让加载与卸载分开','Viscosity separates loading and unloading'));axes[0].legend(frameon=False,fontsize=10)
    freq=np.linspace(.05,.5,100)
    for visc in [2,4,8]:
        color=viscosity_colors[visc]
        axes[1].plot(freq,1000*np.pi*visc*2*np.pi*freq*AMPLITUDE**2,color=color,label=f'η={visc:g} kPa·s')
    axes[1].set(xlabel=tr('频率 / Hz','Frequency / Hz'),ylabel=tr('每周期耗散能密度 / J·m⁻³','Dissipated energy per cycle / J·m⁻³'),title=tr('相同振幅下，速度改变耗散','At fixed amplitude, speed changes dissipation'));axes[1].legend(frameon=False,fontsize=10)
    for ax in axes:ax.grid()
    save(fig,'dissipation')
    fig,axes=plt.subplots(1,3,figsize=(13,4.6),layout='constrained')
    selected=45
    for ax,x,y,xlabel,ylabel in [(axes[0],time,strain*100,tr('时间 / s','Time / s'),tr('应变 / %','Strain / %')),
          (axes[1],time,stress,tr('时间 / s','Time / s'),tr('应力 / kPa','Stress / kPa')),
          (axes[2],strain*100,stress,tr('应变 / %','Strain / %'),tr('应力 / kPa','Stress / kPa'))]:
        ax.scatter(x[::5],y[::5],s=10,color='#c4cdd3');ax.scatter([x[selected]],[y[selected]],s=65,color=RED,zorder=5)
        ax.set(xlabel=xlabel,ylabel=ylabel);ax.grid();ax.annotate(tr('记录 45','record 45'),(x[selected],y[selected]),xytext=(0,-30),textcoords='offset points',ha='center',color=RED)
    fig.suptitle(tr('PRIM-9（1974）的交互思想：换坐标，保留同一个数据点','PRIM-9 (1974): change coordinates while retaining point identity'),fontsize=14)
    save(fig,'history')
    exact=np.pi*eta*omega*AMPLITUDE**2
    polygon=float(np.trapezoid(stress,strain));zero=cycle(0)
    summary={'versions':{'numpy':np.__version__,'matplotlib':matplotlib.__version__,'plotly':plotly.__version__},
             'n':len(time),'period_s':1/FREQUENCY,'E_kPa':E,'eta_kPa_s':eta,'strain_amplitude':AMPLITUDE,
             'stress_at_phase0_kPa':float(stress[0]),'stress_at_phase90_kPa':float(stress[90]),
             'loop_work_exact_kPa':float(exact),'loop_work_polygon_kPa':polygon,
             'loop_work_exact_J_m3':float(exact*1000),'relative_quadrature_error':float(abs(polygon-exact)/exact),
             'zero_viscosity_work_kPa':float(np.trapezoid(zero[3],zero[1])),
             'phase_lead_deg':float(np.degrees(np.arctan(eta*omega/E))),
             'plotly_traces':len(plot.data)}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))


if __name__=='__main__':main()
