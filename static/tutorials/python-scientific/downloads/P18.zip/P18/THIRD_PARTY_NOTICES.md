# Public sources and third-party materials

- Plotly: creating and updating figures: https://plotly.com/python/creating-and-updating-figures/
  Plotly.py MIT
- Plotly: hover text and formatting: https://plotly.com/python/hover-text-and-formatting/
  Plotly.py MIT
- Plotly: interactive HTML export: https://plotly.com/python/interactive-html-export/
  Plotly.py MIT
- Plotly.js: event handlers: https://plotly.com/javascript/plotlyjs-events/
  Plotly.js MIT
- Fisherkeller, Friedman & Tukey (1974), PRIM-9: https://www.slac.stanford.edu/pubs/slacpubs/1250/slac-pub-1408.pdf
  Historical reference; original figures here
- NEML2: viscoelasticity: https://applied-material-modeling.github.io/neml2/dev/content/modules/solid_mechanics/viscoelasticity.html
  Technical reference; no copied code or image
