"""Build three scientific figures from one explicitly defined teaching dataset."""
from pathlib import Path
import argparse
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle, FancyArrowPatch

BLUE, RED, INK, GRAY = "#28658c", "#b64a35", "#202e39", "#71808b"


def make_figures(output, language):
    output.mkdir(parents=True, exist_ok=True)
    zh = language == "zh"
    def tr(chinese, english):
        return chinese if zh else english
    plt.rcParams.update({"font.family": [name for name in ['Noto Sans CJK SC','Noto Sans SC','Microsoft YaHei','SimHei','DejaVu Sans'] if name in {f.name for f in font_manager.fontManager.ttflist}],
                         "font.size": 12, "axes.labelsize": 12,
                         "axes.titlesize": 14, "axes.titleweight": "bold",
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.edgecolor": INK, "text.color": INK,
                         "xtick.color": INK, "ytick.color": INK,
                         "svg.fonttype": "none", "svg.hashsalt": "P15",
                         "savefig.facecolor": "white"})
    concentration = np.array([0, .1, .2, .3, .4, .5], dtype=float)
    absorbance = np.array([.032, .111, .205, .296, .389, .481])
    selected = 3
    def save(fig, name):
        fig.savefig(output / f"{name}-{language}.svg", metadata={"Date": None})
        fig.savefig(output / f"{name}-{language}.png", dpi=180)
        plt.close(fig)
    def plot_data(ax, xmax=.6, ymax=.55):
        points = ax.scatter(concentration, absorbance, s=65, color=BLUE,
                            edgecolors="white", linewidths=.8, zorder=3, clip_on=False)
        ax.set(xlim=(0, xmax), ylim=(0, ymax),
               xlabel=tr("浓度 / mmol L⁻¹", "Concentration / mmol L⁻¹"),
               ylabel=tr("吸光度 / 无量纲", "Absorbance / dimensionless"))
        ax.grid(axis="y", color="#dce3e8", linewidth=.7, zorder=0)
        return points

    fig = plt.figure(figsize=(12.4, 6.4))
    fig.patch.set_edgecolor("#bccbd5"); fig.patch.set_linewidth(2)
    ax = fig.add_axes([.09, .18, .54, .67])
    points = plot_data(ax)
    ax.annotate(tr("第4行记录", "Record 4"),
                xy=(concentration[selected], absorbance[selected]),
                xytext=(.1, .43), textcoords="data", color=RED,
                arrowprops={"arrowstyle": "->", "color": RED})
    ax.scatter([concentration[selected]], [absorbance[selected]],
               s=140, facecolors="none", edgecolors=RED, linewidths=1.7, zorder=4)
    fig.text(.09, .94, tr("Figure：组织整张输出", "Figure: the complete output"),
             fontsize=17, weight="bold")
    fig.text(.09, .075, tr("Axes：这块绘图区有自己的数据范围", "Axes: a plotting region with its own data limits"), color=BLUE)
    hierarchy = [("Figure", tr("整张图、尺寸与保存", "Canvas, size, and export")),
                 ("Axes", tr("绘图区与数据坐标", "Plot region and data coordinates")),
                 ("Axis", tr("Axes中的刻度与轴标签对象", "Ticks and axis labels within Axes")),
                 ("Artist", tr("所有可绘制对象的共同基类", "The common base for drawable objects"))]
    for i, (name, detail) in enumerate(hierarchy):
        y = .79 - i * .16
        fig.text(.70, y, name, fontsize=16, weight="bold", color=BLUE if i == 1 else INK)
        fig.text(.70, y - .055, detail, fontsize=11)
        if i == 0:
            fig.add_artist(FancyArrowPatch((.72, y - .075), (.72, y - .113),
                           transform=fig.transFigure, arrowstyle="->", color=GRAY,
                           mutation_scale=12))
    save(fig, "anatomy")

    fig = plt.figure(figsize=(12.4, 5.7))
    signal_ax = fig.add_axes([.07, .25, .35, .57])
    t = np.linspace(0, 2, 400)
    first = .65 * np.sin(2 * np.pi * 3 * t)
    second = .3 * np.sin(2 * np.pi * 5 * t) + .15 * np.cos(2 * np.pi * t)
    signal_ax.plot(t, first + 1.1, color=BLUE, lw=1.7)
    signal_ax.plot(t, second - .65, color=RED, lw=1.7)
    signal_ax.set(xlabel=tr("时间 / s", "Time / s"), yticks=[], xlim=(0, 2), ylim=(-1.2, 2.2))
    signal_ax.set_title(tr("多通道数据提出交互需求", "Multichannel data call for interaction"), loc="left", fontsize=13)
    signal_ax.text(.02, .94, tr("教学信号；振幅为任意单位", "Illustrative signals; arbitrary amplitude"), transform=signal_ax.transAxes, color=GRAY, fontsize=9, va="top")
    fig.text(.48, .65, tr("同一组绘图对象", "One set of plotting objects"), fontsize=14, weight="bold")
    fig.text(.48, .52, "Figure → Axes → Artists", fontsize=12, color=BLUE)
    for y, title, detail in [(.76, tr("交互窗口", "Interactive window"), tr("选择、放大与回看", "Select, zoom, and inspect")),
                              (.31, tr("矢量输出", "Vector output"), tr("坐标、文字和图形\n一起保存", "Save coordinates, text,\nand marks"))]:
        fig.text(.79, y, title, weight="bold", fontsize=14)
        fig.text(.79, y - .09, detail, fontsize=10)
        fig.add_artist(FancyArrowPatch((.67, .57), (.77, y - .025), transform=fig.transFigure,
                        arrowstyle="->", color=GRAY, mutation_scale=16))
    fig.add_artist(FancyArrowPatch((.42, .54), (.47, .54), transform=fig.transFigure,
                    arrowstyle="->", color=GRAY, mutation_scale=16))
    fig.text(.07, .95, tr("从数据探索到可出版图形", "From data exploration to publishable figures"), fontsize=17, weight="bold")
    fig.text(.07, .065, tr("方法关系图；曲线由明确的正弦函数生成。", "Method diagram; signals are generated from defined sine functions."), color=GRAY, fontsize=10)
    save(fig, "history")

    fig, axes = plt.subplots(1, 2, figsize=(12.4, 5.4), layout="constrained")
    for ax, xmax, name in zip(axes, [.6, 1.2], [tr("原坐标范围", "Original limits"), tr("横轴范围扩大一倍", "Twice the horizontal range")]):
        plot_data(ax, xmax=xmax)
        ax.scatter([concentration[selected]], [absorbance[selected]], s=140,
                   facecolors="none", edgecolors=RED, linewidths=1.7, zorder=4)
        ax.vlines(concentration[selected], 0, absorbance[selected], color=RED, linestyle="--", lw=1)
        ax.hlines(absorbance[selected], 0, concentration[selected], color=RED, linestyle="--", lw=1)
        u = concentration[selected] / xmax
        ax.text(.04, .95, f"c = 0.300 mmol L⁻¹\nA = 0.296\nu = {u:.2f}",
                transform=ax.transAxes, ha="left", va="top", fontsize=12)
        ax.set_title(name, loc="left")
    save(fig, "coordinates")
    np.savetxt(output / "calibration.csv", np.c_[concentration, absorbance], delimiter=",",
               header="concentration_mmol_L,absorbance", comments="", fmt="%.6f")
    summary = {"data_kind": "explicitly defined teaching data", "n_records": len(concentration),
               "selected_record_zero_based": selected,
               "concentration_mmol_L": concentration.tolist(), "absorbance": absorbance.tolist(),
               "selected": {"c_mmol_L": float(concentration[selected]), "absorbance": float(absorbance[selected]),
                            "u_original": float(concentration[selected] / .6),
                            "u_expanded": float(concentration[selected] / 1.2),
                            "v": float(absorbance[selected] / .55)},
               "versions": {"numpy": np.__version__, "matplotlib": matplotlib.__version__}}
    (output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("output"))
    parser.add_argument("--language", choices=["zh", "en"], default="en")
    options = parser.parse_args()
    make_figures(options.output, options.language)
