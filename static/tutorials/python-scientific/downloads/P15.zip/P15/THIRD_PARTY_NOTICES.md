# Public sources and third-party materials

- Matplotlib Quick start guide: https://matplotlib.org/stable/users/explain/quick_start.html
  Matplotlib documentation license
- Matplotlib Transformations Tutorial: https://matplotlib.org/stable/users/explain/artists/transforms_tutorial.html
  Matplotlib documentation license
- John D. Hunter: Matplotlib History: https://matplotlib.org/stable/project/history.html
  Matplotlib documentation license
- Matplotlib Introduction to Artists: https://matplotlib.org/stable/users/explain/artists/artist_intro.html
  Matplotlib documentation license
- Matplotlib Figure.savefig: https://matplotlib.org/stable/api/_as_gen/matplotlib.figure.Figure.savefig.html
  Matplotlib documentation license
