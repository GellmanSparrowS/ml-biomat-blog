# Public sources and third-party materials

- Subramani et al. (2020). The Influence of Swelling on Elastic Properties of Polyacrylamide Hydrogels: https://www.frontiersin.org/journals/materials/articles/10.3389/fmats.2020.00212/full
  CC BY 4.0; Figure 4 credited in caption and bundled notice.
- Flory and Rehner (1943). Statistical Mechanics of Cross-Linked Polymer Networks II. Swelling: https://doi.org/10.1063/1.1723792
  Bibliographic reference; no text or figures reproduced.
- Sheth et al. Measurement of Hydrogel Swelling Ratio and Mesh Size: https://bio-protocol.org/exchange/minidetail?id=4024598&type=30
  CC BY as stated for the extracted research method; no figure reused.
- Sheth et al. (2019). Predicting Drug Release From Degradable Hydrogels Using Fluorescence Correlation Spectroscopy and Mathematical Modeling: https://www.frontiersin.org/journals/bioengineering-and-biotechnology/articles/10.3389/fbioe.2019.00410/full
  Technical reference; no assets reproduced.
- SciPy: curve_fit: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html
  Technical reference; example code independently written.
