"""Mass/volume swelling and a constructed time series; includes a licensed published figure."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Rectangle,FancyArrowPatch

def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def uptake(t,initial,equilibrium,time_scale):
    return initial+(equilibrium-initial)*(1-np.exp(-np.asarray(t)/time_scale))

def ratios(dry,wet,rho_polymer=1.2,rho_water=1.):
    mass=wet/dry
    volume=1+rho_polymer/rho_water*(mass-1)
    return {'mass_ratio':mass,'water_per_dry':mass-1,'water_fraction':1-1/mass,
            'volume_ratio':volume,'polymer_volume_fraction':1/volume,'isotropic_stretch':volume**(1/3)}

def main(output,language):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    from matplotlib import font_manager
    fonts={x.name for x in font_manager.fontManager.ttflist};font=next((f for f in ['Microsoft YaHei','Noto Sans CJK SC','SimHei'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[font,'DejaVu Sans'] if language=='zh' else ['DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','axes.prop_cycle':plt.cycler(color=['#186e83','#cd803f','#8160a1','#3c8a6a'])})
    tr=lambda z,e:z if language=='zh' else _label(e)
    def save(fig,name):
        fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    result=ratios(.1,1.)
    rng=np.random.default_rng(101)
    times=np.array([0,5,10,20,30,45,60,90,120,180,240.])
    dry=np.array([.098,.102,.100]);truth=uptake(times,3,10,45)
    wet=dry[:,None]*truth+rng.normal(0,.003,(3,len(times)))
    observed=wet/dry[:,None];mean=observed.mean(0);sd=observed.std(0,ddof=1)
    fit,cov=curve_fit(lambda t,qinf,tau:uptake(t,3,qinf,tau),times,mean,p0=[9,40],bounds=([3,1],[20,1000]))
    prediction=uptake(times,3,*fit);smooth=np.linspace(0,240,400)
    np.savetxt(output/'swelling.csv',np.column_stack([times,*wet,mean,sd,prediction]),delimiter=',',header='time_min,wet_g_1,wet_g_2,wet_g_3,mean_mass_ratio,sd_mass_ratio,fitted_ratio',comments='')
    np.savetxt(output/'dry_masses.csv',dry,delimiter=',',header='dry_mass_g',comments='')
    fig,ax=plt.subplots(1,3,figsize=(12,4.4));nodes=np.array([[0,0],[1,0],[2,0],[0,1],[1,1],[2,1],[0,2],[1,2],[2,2]],float)
    for k,stretch in enumerate([1,1.65,1.65]):
        a=ax[k];a.set_aspect('equal');a.axis('off');coords=nodes*stretch
        if k==2:coords[:,0]=nodes[:,0]
        for i,j in [(0,1),(1,2),(3,4),(4,5),(6,7),(7,8),(0,3),(3,6),(1,4),(4,7),(2,5),(5,8)]:
            a.plot(coords[[i,j],0],coords[[i,j],1],color='#186e83',lw=3)
        a.scatter(*coords.T,s=35,color='#cd803f',zorder=3)
        for x,y in [(0.5,.5),(1.5,.5),(.5,1.5),(1.5,1.5)]:a.add_patch(Circle((x*(stretch if k<2 else 1),y*stretch),.12,color='#a2cdd9'))
        if k==2:a.plot([-.3,2.3],[-.15,-.15],color='#707c82',lw=7)
        a.set(xlim=(-.5,3.8),ylim=(-.6,3.8));a.set_title(tr(['A  制备时的网络','B  自由溶胀','C  底面固定'][k],['A  As-prepared network','B  Free swelling','C  Substrate constraint'][k]),loc='left')
    fig.text(.5,.01,tr('1943：Flory 与 Rehner 将溶剂混合与网络弹性放进同一理论。','1943: Flory and Rehner joined solvent mixing with network elasticity.'),ha='center');save(fig,'network')
    fig,ax=plt.subplots(1,2,figsize=(11,4.5));ax[0].bar(tr(['干聚合物','水'],['Dry polymer','Water']),[.1,.9],color=['#cd803f','#186e83']);ax[0].set(ylabel=tr('质量 / g','Mass / g'),title=tr('A  湿样品 1.00 g 的组成','A  Composition of a 1.00 g wet specimen'))
    labels=tr(['湿 / 干质量','吸水 / 干质量','湿 / 干体积'],['Wet / dry mass','Water / dry mass','Wet / dry volume']);ax[1].barh(labels,[10,9,11.8],color=['#186e83','#3c8a6a','#8160a1']);ax[1].set(xlabel=tr('比值 / 无量纲','Ratio / dimensionless'),title=tr('B  三个分母明确的量','B  Three explicitly defined ratios'),xlim=(0,14))
    for i,v in enumerate([10,9,11.8]):ax[1].text(v+.15,i,f'{v:g}',va='center')
    fig.tight_layout();save(fig,'ratios')
    fig,ax=plt.subplots(2,2,figsize=(11,7.3));ax=ax.ravel()
    for i in range(3):ax[0].plot(times,wet[i],'.-',alpha=.7,label=f'{i+1}: {dry[i]:.3f} g')
    ax[0].set(title=tr('A  三份样品的原始湿质量','A  Raw wet masses of three specimens'),ylabel=tr('湿质量 / g','Wet mass / g'));ax[0].legend(fontsize=9)
    ax[1].errorbar(times,mean,yerr=sd,fmt='o',ms=4,label=tr('均值 ± 样品间 SD','Mean ± between-specimen SD'));ax[1].plot(smooth,uptake(smooth,3,*fit),label=tr('单指数拟合','Single-exponential fit'));ax[1].set(title=tr('B  先逐样品归一化，再汇总','B  Normalize each specimen before averaging'),ylabel=tr('湿 / 干质量比','Wet / dry mass ratio'));ax[1].legend(fontsize=9)
    ax[2].axhline(0,color='#707c82',lw=.8);ax[2].plot(times,mean-prediction,'o-');ax[2].set(title=tr('C  残差检查','C  Residual inspection'),ylabel=tr('观测值 − 拟合值','Observed − fitted'))
    for h in [.5,1,2]:ax[3].plot(smooth,uptake(smooth,3,10,45*h*h),label=f'{h:g} mm')
    ax[3].set(title=tr('D  固定几何假设下的厚度效应','D  Thickness effect under fixed geometry'),ylabel=tr('模型质量比','Model mass ratio'));ax[3].legend()
    for a in ax:a.set_xlabel(tr('时间 / min','Time / min'))
    fig.tight_layout();save(fig,'kinetics')
    fig,ax=plt.subplots(1,2,figsize=(11,4.5));film=np.linspace(0,.05,100);salt=np.linspace(0,.02,100)
    ax[0].plot(film*1000,(1+film)/.1);ax[0].set(xlabel=tr('残留表面液体 / mg','Residual surface liquid / mg'),ylabel=tr('计算质量比','Calculated mass ratio'),title=tr('A  表面液体抬高分子','A  Surface liquid raises the numerator'))
    ax[1].plot(salt*1000,1/(.1+salt),color='#cd803f');ax[1].set(xlabel=tr('干燥后残留盐 / mg','Salt remaining after drying / mg'),ylabel=tr('计算质量比','Calculated mass ratio'),title=tr('B  残留盐抬高分母','B  Residual salt raises the denominator'))
    for a in ax:a.axhline(10,color='#707c82',ls='--');a.grid(alpha=.15)
    fig.tight_layout();save(fig,'artifacts')
    from PIL import Image
    published=np.asarray(Image.open(Path(__file__).with_name('subramani2020-figure4.webp')))
    fig,ax=plt.subplots(figsize=(11,4.8));ax.imshow(published);ax.axis('off');ax.set_title(tr('真实实验：固定在基底上的凝胶随时间溶胀','Published measurements: swelling of substrate-attached gels'),pad=14)
    fig.text(.5,.015,'Subramani et al. (2020), Figure 4 · Frontiers in Materials · CC BY 4.0',ha='center',fontsize=9);save(fig,'published')
    summary={'worked_example':result,'fit':{'equilibrium_mass_ratio':float(fit[0]),'time_scale_min':float(fit[1])},'checks':{'initial_ratio':float(uptake(0,3,10,45)),'one_time_scale_fraction':float((uptake(45,3,10,45)-3)/7),'fourfold_time_scale_at_double_thickness':4.,'surface_20mg_ratio':10.2,'salt_10mg_ratio':1/.11}}
    assert abs(result['volume_ratio']-11.8)<1e-12
    assert abs(result['water_fraction']-.9)<1e-12
    assert abs(summary['checks']['one_time_scale_fraction']-(1-np.exp(-1)))<1e-12
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--language',choices=['zh','en'],default='zh');args=parser.parse_args();main(args.output,args.language)
