# Public sources and third-party materials

- Higuchi (1961). Rate of release of medicaments from ointment bases containing drugs in suspension: https://doi.org/10.1002/jps.2600501018
  Bibliographic reference; no text or figures reproduced.
- Koizumi et al. (1975). Rate of Release of Medicaments from Ointment Bases Containing Drugs in Suspension: https://www.jstage.jst.go.jp/article/cpb1958/23/12/23_12_3288/_article
  Technical reference; no assets reproduced.
- FDA. Compilation of Guidance and Resources for in vitro Dissolution Testing: https://www.fda.gov/animal-veterinary/new-animal-drug-applications/compilation-fda-guidance-and-resources-in-vitro-dissolution-testing-immediate-release-solid-oral-dosage
  Official technical reference; no assets reproduced.
- Sheth et al. (2019). Predicting Drug Release From Degradable Hydrogels Using Fluorescence Correlation Spectroscopy and Mathematical Modeling: https://www.frontiersin.org/journals/bioengineering-and-biotechnology/articles/10.3389/fbioe.2019.00410/full
  CC BY 4.0; Figure 5 reproduced with attribution.
- SciPy documentation: curve_fit: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html
  Technical documentation reference; original example code.
