"""Serial-sampling release accounting and constructed transport diagnostics."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,FancyArrowPatch,Circle

def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def sampled_concentration(cumulative,bath=10.,aliquot=2.):
    removed=0.;concentrations=[]
    for released in cumulative:
        c=(released-removed)/bath;concentrations.append(c);removed+=aliquot*c
    return np.asarray(concentrations)

def correct(concentration,bath=10.,aliquot=2.):
    c=np.asarray(concentration);return bath*c+aliquot*np.r_[0,np.cumsum(c[:-1])]

def main(output,language):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    from matplotlib import font_manager
    fonts={f.name for f in font_manager.fontManager.ttflist};font=next((f for f in ['Microsoft YaHei','Noto Sans CJK SC','SimHei'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[font,'DejaVu Sans'] if language=='zh' else ['DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','axes.prop_cycle':plt.cycler(color=['#186e83','#cd803f','#8160a1','#3c8a6a'])})
    tr=lambda z,e:z if language=='zh' else _label(e)
    def save(fig,n):fig.savefig(output/f'{n}-{language}.svg',bbox_inches='tight');plt.close(fig)
    fig,ax=plt.subplots(1,3,figsize=(12,4.5))
    for a in ax:a.set(xlim=(0,10),ylim=(0,10));a.axis('off')
    for i,a in enumerate(ax[:2]):
        a.add_patch(Rectangle((1,2),8,6,facecolor='#c9e3e9',edgecolor='#186e83',lw=2));a.add_patch(Rectangle((3.3,3),3.4,1.7,facecolor='#8160a1',alpha=.65));a.text(5,3.8,tr('载体','Carrier'),ha='center',va='center',color='white');a.add_patch(FancyArrowPatch((5,5),(5,7),arrowstyle='->',mutation_scale=16,color='#186e83'));a.text(5,1,tr('混匀的接收液','Mixed receiving medium'),ha='center',fontsize=10)
    ax[0].set_title(tr('A  载体中储存的分子','A  Molecules stored in a carrier'));ax[1].set_title(tr('B  取出样液，补入新液','B  Sample out, fresh medium in'))
    for x,direction,label,color in [(2.5,1,tr('取样','Sample'),'#cd803f'),(7.5,-1,tr('补液','Replace'),'#3c8a6a')]:ax[1].add_patch(FancyArrowPatch((x,7 if direction==1 else 9),(x,9 if direction==1 else 7),arrowstyle='->',mutation_scale=15,color=color));ax[1].text(x,9.3,label,ha='center',fontsize=9)
    ax[2].add_patch(Rectangle((1,2),8,6,facecolor='#e6dcc7'));ax[2].add_patch(Rectangle((1,6),8,2,facecolor='#c9e3e9'))
    for x,y in [(2,3),(4,3.4),(7,2.8),(3,4.8),(6,4.7),(8,4)]:ax[2].add_patch(Circle((x,y),.2,color='#8160a1'))
    ax[2].plot([1,9],[5.8,5.8],'--',color='#cd803f');ax[2].text(5,7,tr('已耗尽区域','Depleted region'),ha='center',fontsize=10);ax[2].text(5,1,tr('1961：Higuchi 的移动前沿思想','1961: Higuchi’s moving-front idea'),ha='center',fontsize=9);ax[2].set_title(tr('C  固体药物逐步溶出','C  Solid drug dissolves progressively'));fig.tight_layout();save(fig,'apparatus')
    rng=np.random.default_rng(404);time=np.array([.25,.5,1,2,4,8,12,24]);truth=100*(.2*(-np.expm1(-time/.25))+.8*(-np.expm1(-time/8)));raw=sampled_concentration(truth)
    standards=np.linspace(0,10,7);abs_std=.03+.012*standards+rng.normal(0,.0004,len(standards));slope,intercept=np.polyfit(standards,abs_std,1)
    absorbance=.03+.012*raw+rng.normal(0,.0007,len(raw));estimated=(absorbance-intercept)/slope;corrected=correct(estimated);naive=10*estimated;observed_removed=2*np.r_[0,np.cumsum(estimated[:-1])]
    np.savetxt(output/'release.csv',np.column_stack([time,truth,raw,absorbance,estimated,naive,observed_removed,corrected]),delimiter=',',header='time_h,true_cumulative_ug,true_bath_ug_ml,absorbance,estimated_ug_ml,bath_mass_ug,previously_removed_ug,corrected_cumulative_ug',comments='')
    np.savetxt(output/'calibration.csv',np.column_stack([standards,abs_std]),delimiter=',',header='concentration_ug_ml,absorbance',comments='')
    fig,ax=plt.subplots(2,2,figsize=(11.4,7.3));ax=ax.ravel();ax[0].scatter(standards,abs_std);ax[0].plot(standards,slope*standards+intercept);ax[0].set(xlabel=tr('浓度 / μg mL⁻¹','Concentration / μg mL⁻¹'),ylabel=tr('吸光度','Absorbance'),title=tr('A  同介质标准曲线','A  Matrix-matched calibration'))
    ax[1].plot(time,truth,color='#a4abad',ls='--',label=tr('构造真值','Constructed truth'));ax[1].plot(time,corrected,'o-',label=tr('累计取样校正','Sampling corrected'));ax[1].plot(time,naive,'s-',label=tr('只算当前溶液','Current bath only'));ax[1].set(xlabel=tr('时间 / h','Time / h'),ylabel=tr('药物质量 / μg','Drug mass / μg'),title=tr('B  校正把已取走的量加回来','B  Correction restores removed mass'));ax[1].legend(fontsize=8)
    x=np.arange(len(time));ax[2].bar(x,naive,label=tr('当前溶液','Current bath'));ax[2].bar(x,observed_removed,bottom=naive,label=tr('此前取样','Earlier samples'));ax[2].set(xticks=x,xticklabels=[f'{t:g}' for t in time],xlabel=tr('时间 / h','Time / h'),ylabel=tr('累计质量 / μg','Cumulative mass / μg'),title=tr('C  每个时间点的质量账本','C  Mass ledger at each time'));ax[2].legend(fontsize=8)
    for v in [0,1,2,4]:ax[3].plot(time,10*sampled_concentration(truth,aliquot=v),label=f'{v:g} mL')
    ax[3].set(xlabel=tr('时间 / h','Time / h'),ylabel=tr('未校正的当前质量 / μg','Uncorrected current mass / μg'),title=tr('D  同一释放过程，不同取样体积','D  Same release, different aliquots'));ax[3].legend(title=tr('每次取样','Sample volume'),fontsize=8);fig.tight_layout();save(fig,'sampling')
    tt=np.linspace(0,24,241);single=lambda t,tau:100*(-np.expm1(-t/tau));tau=float(curve_fit(single,time,corrected,p0=[5],bounds=(.01,100))[0][0]);pred=single(time,tau)
    fig,ax=plt.subplots(1,3,figsize=(12,4.2));ax[0].plot(time,corrected,'o',label=tr('构造数据','Constructed data'));ax[0].plot(tt,single(tt,tau),label=tr('单时间尺度拟合','Single-timescale fit'));ax[0].set(xlabel=tr('时间 / h','Time / h'),ylabel=tr('累计释放 / %','Cumulative release / %'),title=tr('A  拟合曲线','A  Fitted curve'));ax[0].legend(fontsize=8)
    ax[1].axhline(0,color='#a4abad');ax[1].plot(time,corrected-pred,'o-');ax[1].set(xlabel=tr('时间 / h','Time / h'),ylabel=tr('数据−拟合 / 百分点','Data − fit / percentage points'),title=tr('B  残差保留了早期快过程','B  Residuals reveal the early fast process'))
    for tau_m in [.5,2,8]:
        tau_c=4.;fraction=1-(tau_c*np.exp(-tt/tau_c)-tau_m*np.exp(-tt/tau_m))/(tau_c-tau_m);ax[2].plot(tt,100*fraction,label=f'{tau_m:g} h')
    ax[2].plot(tt,100*(-np.expm1(-tt/4)),color='#a4abad',ls='--',label=tr('载体自身','Carrier alone'));ax[2].set(xlabel=tr('时间 / h','Time / h'),ylabel=tr('外液累积量 / %','Cumulative outer-bath amount / %'),title=tr('C  透析膜增加第二道传质过程','C  Dialysis adds a transport step'));ax[2].legend(title=tr('膜过程时间尺度','Membrane timescale'),fontsize=8);fig.tight_layout();save(fig,'diagnostics')
    from PIL import Image
    fig,ax=plt.subplots(figsize=(11,4.6));ax.imshow(Image.open(Path(__file__).with_name('sheth2019-figure5.webp')));ax.axis('off');ax.set_title(tr('真实研究：独立测得扩散与厚度，再预测释放','Published study: measured diffusion and thickness predict release'),fontsize=12,pad=12);fig.text(.5,.015,'Sheth et al. (2019), Figure 5 · Frontiers in Bioengineering and Biotechnology · CC BY 4.0',ha='center',fontsize=8.5);save(fig,'published')
    worked=sampled_concentration([20,40,60]);wcorrect=correct(worked);summary={'worked_example':{'concentrations_ug_ml':worked.tolist(),'third_bath_mass_ug':float(10*worked[-1]),'third_removed_ug':float(2*sum(worked[:-1])),'third_corrected_ug':float(wcorrect[-1]),'release_percent':60,'loading_efficiency_percent':80,'loading_content_percent':8,'calibration_concentration_ug_ml':(.09-.03)/.012,'diluted_original_ug_ml':10},'calibration':{'slope':float(slope),'intercept':float(intercept)},'fit':{'single_tau_h':tau,'residual_rmse':float(np.sqrt(np.mean((corrected-pred)**2)))},'mass_balance':{'max_exact_error_ug':float(np.max(np.abs(correct(raw)-truth)))},'final':{'true_ug':float(truth[-1]),'corrected_ug':float(corrected[-1]),'naive_ug':float(naive[-1])}}
    assert abs(wcorrect[-1]-60)<1e-12;assert abs(10*worked[-1]-48.8)<1e-12;assert summary['mass_balance']['max_exact_error_ug']<1e-10
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
