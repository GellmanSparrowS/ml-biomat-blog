# Public sources and third-party materials

- Ramaye et al.: NIST SP260-208, Certification of SRM1992/ERM-FD305: https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.260-208.pdf
  Numerical values from Tables E1.1, 11 and 12 of the joint NIST/JRC report, transcribed and plotted with attribution; original artwork and prose are not reproduced.
- Malvern: Zeta Potential, An Introduction: https://www.malvernpanalytical.com/en/learn/knowledge-center/technical-notes/tn101104zetapotentialintroduction
  Technical or historical reference only; no source artwork or data reproduced.
- IUPAC Gold Book: Electrokinetic Potential: https://goldbook.iupac.org/terms/view/E01968
  Technical or historical reference only; no source artwork or data reproduced.
- Clogston & Vermilya: NCL Method PCC-2, Measuring Zeta Potential of Nanoparticles: https://dctd.cancer.gov/drug-discovery-development/assays/nano/ncl-methods-pcc2.pdf
  Technical or historical reference only; no source artwork or data reproduced.
- Malvern: Measuring Zeta Potential Using PALS: https://www.malvernpanalytical.com/en/learn/knowledge-center/technical-notes/tn101104phaseanalysislightscattering
  Technical or historical reference only; no source artwork or data reproduced.
- Malvern: M3-PALS and Electro-osmosis: https://www.malvernpanalytical.com/en/learn/knowledge-center/application-notes/an101104zetapotentialm3-pals
  Technical or historical reference only; no source artwork or data reproduced.
- Royal Society Archives: Henry (1931) Cataphoresis Paper, RR43/57: https://makingscience.royalsociety.org/items/rr_43_57/referees-report-by-frederick-alexander-lindemann-on-a-paper-the-cataphoresis-of-suspended-particles-part-ithe-equation-of-cataphoresis-by-d-c-henry
  Technical or historical reference only; no source artwork or data reproduced.
