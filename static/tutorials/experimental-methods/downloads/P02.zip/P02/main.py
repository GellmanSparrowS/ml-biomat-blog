"""Zeta potential: from constructed optical phase to mobility and conversion.
Real reference-material aliquot means are bundled in data/mobility.csv.
Run offline: python main.py --output results --language en
"""
from pathlib import Path
import argparse,json,csv as csvlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Rectangle

p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();O=args.output;O.mkdir(parents=True,exist_ok=True)
ZH=args.language=='zh'
def L(z,e):return z if ZH else e
plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.facecolor':'#fcfbf7','figure.facecolor':'#fcfbf7','svg.fonttype':'none','text.color':'#20333e','axes.labelcolor':'#20333e','axes.titleweight':'bold'})
B='#167d9a';R='#d35f47';G='#37967d';Y='#c49b35';K='#20333e'
def save(f,n):
 for e in ['svg','png']:f.savefig(O/f'{n}-{args.language}.{e}',dpi=145,bbox_inches='tight')
 plt.close(f)
def csv(n,heads,cols):np.savetxt(O/n,np.column_stack(cols),delimiter=',',header=','.join(heads),comments='',fmt='%.10g')
eps0=8.8541878128e-12;epsr=78.4;eps=eps0*epsr;eta=.00089;T=298.15;kb=1.380649e-23;e=1.602176634e-19;NA=6.02214076e23
def debye(I_mM):return np.sqrt(eps*kb*T/(2*e**2*NA*np.asarray(I_mM)))
rng=np.random.default_rng(820);zeta=-.025;mu=eps*zeta/eta;vbg=3e-6;q=3e6
fields=np.array([-1500,-1000,-500,500,1000,1500.]);t=np.linspace(0,.25,501);fitted=[];phases=[];residuals=[]
for E in fields:
 velocity=mu*E+vbg;phase=.4+q*velocity*t
 signal=np.exp(1j*phase)+.035*(rng.normal(size=t.size)+1j*rng.normal(size=t.size))
 unwrapped=np.unwrap(np.angle(signal));coef=np.polyfit(t,unwrapped,1);fit=np.polyval(coef,t)
 fitted.append(coef[0]/q);phases.append(unwrapped);residuals.append(unwrapped-fit)
fitted=np.array(fitted);phases=np.array(phases);residuals=np.array(residuals)
mf,bf=np.polyfit(fields,fitted,1);zf=mf*eta/eps
np.savez_compressed(O/'phase_records.npz',time_s=t,fields_V_m=fields,phase_rad=phases,phase_residual_rad=residuals)
csv('field_velocity.csv',['field_V_m','true_velocity_m_s','fitted_velocity_m_s'],[fields,mu*fields+vbg,fitted])
csv('phase_pair.csv',['time_s','phase_minus1000_rad','phase_plus1000_rad'],[t,phases[1],phases[4]])

# A historical principle illustration, not a reconstruction of a named apparatus.
fig,axs=plt.subplots(1,2,figsize=(12.8,5.4),layout='constrained',gridspec_kw={'width_ratios':[1.1,1]})
ax=axs[0];ax.set(xlim=(0,10),ylim=(0,7));ax.axis('off');ax.set_title(L('A  从显微观察到迁移率','A  From microscope observation to mobility'),loc='left')
ax.add_patch(Rectangle((.7,2),8.6,2.4,facecolor='#e6f1f2',edgecolor=B,lw=2))
for x,sign in [(1,'+'),(9,'−')]:ax.plot([x,x],[2.2,4.2],color=R,lw=5);ax.text(x,4.65,sign,ha='center',fontsize=22)
ax.annotate('',xy=(7.6,3.8),xytext=(2.4,3.8),arrowprops={'arrowstyle':'->','color':R,'lw':2});ax.text(5,4.05,L('电场 E','Electric field E'),ha='center',color=R)
for x in [3.8,4.5,5.2]:ax.add_patch(Circle((x,2.9),.16,color=B))
ax.annotate('',xy=(2.4,2.9),xytext=(3.4,2.9),arrowprops={'arrowstyle':'->','color':B,'lw':2});ax.text(5.6,2.85,L('负迁移率颗粒','Negative-mobility particles'),fontsize=10)
ax.plot([4.1,4.1],[5.1,6],color=K,lw=9);ax.plot([3.5,4.7],[5.1,5.1],color=K,lw=3);ax.plot([4.1,4.1],[4.4,5.05],color=K,ls=':');ax.text(4.7,5.6,L('显微镜观察位移','Microscope observes displacement'),fontsize=10)
ax.text(.8,1.35,L('1931 · Henry 将颗粒曲率与双电层尺度\n接入迁移率—电位的关系。','1931 · Henry links particle curvature and\ndouble-layer extent to mobility conversion.'),va='center',fontsize=11)
ax.text(.8,.4,L('原理示意；电极方向与符号明确','Principle illustration; explicit field and sign'),fontsize=10,color='#61717b')
ax=axs[1];x=np.linspace(0,25,400);lam=debye(1)*1e9;psi=-15*np.exp(-x/lam);slip=1.;ax.plot(x,psi,color=B,lw=2.5);ax.fill_between(x,psi,0,color=B,alpha=.08);ax.axvline(slip,color=R,ls='--');ax.scatter([0,slip],[-15,-15*np.exp(-slip/lam)],color=[B,R],zorder=5);ax.axhline(0,color=K,lw=.7)
ax.annotate(L('表面电位 −15 mV','Surface potential −15 mV'),(0,-15),(7,-14.3),arrowprops={'arrowstyle':'->','color':B},color=B)
ax.annotate(L('滑移面处 ζ','ζ at slipping plane'),(slip,-15*np.exp(-slip/lam)),(9,-10.2),arrowprops={'arrowstyle':'->','color':R},color=R)
ax.text(9,-.8,L('远处液体取零电位','Bulk liquid sets zero potential'),fontsize=10)
ax.set(xlabel=L('距表面距离 / nm','Distance from surface / nm'),ylabel=L('电位 / mV','Potential / mV'),title=L('B  运动的边界决定读哪个电位','B  The motion boundary defines which potential'),ylim=(-17,1))
save(fig,'history-interface')

fig,axs=plt.subplots(2,2,figsize=(12.8,9),layout='constrained')
for j,c in [(1,B),(4,R)]:axs[0,0].plot(t,phases[j],color=c,lw=1.2,label=f'E = {fields[j]:.0f} V/m')
axs[0,0].set(xlabel=L('时间 / s','Time / s'),ylabel=L('展开相位 / rad','Unwrapped phase / rad'),title=L('A  构造的光学相位记录','A  Constructed optical phase records'));axs[0,0].legend(frameon=False)
axs[0,1].scatter(fields,fitted*1e6,color=B,s=45,zorder=3);ef=np.linspace(-1600,1600,100);axs[0,1].plot(ef,(mf*ef+bf)*1e6,color=B);axs[0,1].axhline(0,color=K,lw=.7);axs[0,1].axvline(0,color=K,lw=.7);axs[0,1].set(xlabel=L('电场 / V m⁻¹','Electric field / V m⁻¹'),ylabel=L('观测速度 / μm s⁻¹','Observed velocity / μm s⁻¹'),title=L('B  斜率给迁移率，截距给恒定漂移','B  Slope gives mobility; intercept gives drift'));axs[0,1].text(.06,.06,f'μ = {mf/1e-8:.5f} × 10⁻⁸ m²/(V s)\n'+L('漂移','Drift')+f' = {bf*1e6:.4f} μm/s',transform=axs[0,1].transAxes,fontsize=10,bbox={'fc':'#fcfbf7','ec':'none'})
for j,c in [(1,B),(4,R)]:axs[1,0].plot(t,residuals[j],color=c,alpha=.7,lw=.8)
axs[1,0].set(xlabel=L('时间 / s','Time / s'),ylabel=L('相位拟合残差 / rad','Phase-fit residual / rad'),title=L('C  残差揭示记录是否偏离直线','C  Residuals test the straight-line model'))
eo=.5e-8;vals=[mu,mu+eo];labels=L(['恒定背景流已扣除','还存在随电场反向的液流'],['Constant background removed','Field-dependent flow remains']);axs[1,1].barh([1,0],np.array(vals)/1e-8,color=[B,R],height=.55);axs[1,1].set_yticks([1,0],labels);axs[1,1].set(xlim=(-2.2,0),xlabel=L('从场—速度斜率得到的量 / 10⁻⁸ m² V⁻¹ s⁻¹','Field–velocity slope / 10⁻⁸ m² V⁻¹ s⁻¹'),title=L('D  反向电场不会自动消除电渗流','D  Polarity reversal alone does not remove EOF'));axs[1,1].tick_params(axis='y',labelsize=9)
for y,v in zip([1,0],vals):axs[1,1].text(v/1e-8+.05,y,f'{v/1e-8:.4f}',va='center',color='white',fontweight='bold')
save(fig,'phase-to-mobility')

Is=np.logspace(-1,2,200);lams=debye(Is)*1e9;x=np.linspace(0,40,401)
csv('screening.csv',['ionic_strength_mM','Debye_length_nm','zeta_at1nm_mV'],[Is,lams,-15*np.exp(-1/lams)])
fig,axs=plt.subplots(1,3,figsize=(14,4.8),layout='constrained')
axs[0].loglog(Is,lams,color=B,lw=2.5)
for ii in [.1,1,10,100]:axs[0].scatter(ii,debye(ii)*1e9,color=R);axs[0].annotate(f'{debye(ii)*1e9:.2f}',(ii,debye(ii)*1e9),xytext=(0,8),textcoords='offset points',ha='center',fontsize=9)
axs[0].set(xlabel=L('离子强度 / mmol L⁻¹','Ionic strength / mmol L⁻¹'),ylabel=L('Debye长度 / nm','Debye length / nm'),title=L('A  浓度百倍，长度缩短十倍','A  100× concentration gives 10× shorter range'),ylim=(.7,55))
for ii,c in zip([.1,1,10,100],[B,G,Y,R]):
 la=debye(ii)*1e9;axs[1].plot(x,-15*np.exp(-x/la),color=c,label=f'{ii:g} mM')
axs[1].axvline(1,color=K,ls='--',lw=1);axs[1].set(xlabel=L('距表面距离 / nm','Distance from surface / nm'),ylabel=L('电位 / mV','Potential / mV'),title=L('B  固定表面电位的平面模型','B  Planar model at fixed surface potential'),ylim=(-16,1));axs[1].legend(frameon=False,fontsize=9)
aa=np.logspace(0,3,180);kap=aa[:,None]/lams[None,:];im=axs[2].pcolormesh(Is,aa,np.log10(kap),cmap='viridis',shading='auto',vmin=-1.5,vmax=3);cs=axs[2].contour(Is,aa,kap,levels=[1,100],colors='white',linewidths=1.4);axs[2].clabel(cs,fmt={1:'κa = 1',100:'κa = 100'},fontsize=9,manual=[(20,2.15),(5,430)]);axs[2].set(xscale='log',yscale='log',xlabel=L('离子强度 / mmol L⁻¹','Ionic strength / mmol L⁻¹'),ylabel=L('颗粒半径 a / nm','Particle radius a / nm'),title=L('C  模型选择还取决于颗粒半径','C  Model choice also depends on radius'));fig.colorbar(im,ax=axs[2],label='log₁₀(κa)',shrink=.8)
save(fig,'salt-and-scale')

with (Path(__file__).parent/'data/mobility.csv').open(encoding='utf8') as f:rows=list(csvlib.DictReader(f))
names=[r['dataset'] for r in rows];data=np.array([[float(r[f'r{i}']) for i in range(1,7)] for r in rows]);means=data.mean(axis=1);sd=data.std(axis=1,ddof=1);components=np.array([1.39,3.40,.42,1.80]);urel=2*np.linalg.norm(components)
csv('reference_summary.csv',['dataset_index','mean_mobility_1e8','SD_of_six_aliquot_means_1e8'],[np.arange(len(names)),means,sd])
fig,axs=plt.subplots(1,2,figsize=(12.8,7.2),layout='constrained',gridspec_kw={'width_ratios':[1.3,1]});ax=axs[0];yy=np.arange(len(names));ax.axvspan(-4.9,-4.1,color=B,alpha=.1,label=L('认证值 ± U（k=2）','Certified value ± U (k=2)'));ax.axvline(-4.5,color=B,ls='--');ax.errorbar(means,yy,xerr=sd,fmt='o',color=B,ecolor=B,capsize=3,ms=4,label=L('均值 ± 1 SD','Mean ± 1 SD'))
for k in yy:ax.scatter(data[k],k+np.linspace(-.14,.14,6),s=13,color=Y,alpha=.8)
ax.set(yticks=yy,yticklabels=names,xlabel=L('迁移率 / 10⁻⁸ m² V⁻¹ s⁻¹','Mobility / 10⁻⁸ m² V⁻¹ s⁻¹'),title=L('A  真实测量：15组，每组6个取样均值','A  Measured: 15 datasets, six aliquot means each'));ax.invert_yaxis();ax.legend(frameon=False,fontsize=9,loc='lower right')
ax=axs[1];lab=L(['赋值研究','安瓿之间','短期稳定性','长期稳定性'],['Characterization','Between ampoules','Short-term stability','Long-term stability']);ax.barh(np.arange(4),components,color=[B,R,Y,G],height=.5);ax.set_yticks(np.arange(4),lab);ax.set(xlim=(0,4.4),ylim=(-1,5.8),xlabel=L('相对标准不确定度 / %','Relative standard uncertainty / %'),title=L('B  重复性以外的不确定度','B  Uncertainty beyond repeatability'))
for j,v in enumerate(components):ax.text(v+.08,j,f'{v:.2f}%',va='center')
ax.text(.1,4.3,L('认证迁移率：−4.5 ± 0.4\n单位：10⁻⁸ m²/(V s)，k = 2','Certified mobility: −4.5 ± 0.4\nUnit: 10⁻⁸ m²/(V s), k = 2'),fontsize=11,color=B)
ax.text(.1,5.25,L('由迁移率换算：ζ = −58 ± 5 mV','Converted from mobility: ζ = −58 ± 5 mV'),fontsize=11,color=K)
save(fig,'reference-and-uncertainty')

summary={'seed':820,'true_mobility_m2_Vs':mu,'fitted_mobility_m2_Vs':mf,'fitted_zeta_mV':zf*1000,'fitted_constant_drift_um_s':bf*1e6,'EOF_apparent_mobility_m2_Vs':mu+.5e-8,'Debye_length_at1mM_nm':float(debye(1)*1e9),'Debye_ratio_1_to100mM':float(debye(1)/debye(100)),'planar_zeta_at1mM_mV':float(-15*np.exp(-1/(debye(1)*1e9))),'planar_zeta_at100mM_mV':float(-15*np.exp(-1/(debye(100)*1e9))),'reference_dataset_count':len(names),'reference_aliquot_count':int(data.size),'mean_of_reference_dataset_means_1e8':float(means.mean()),'reference_Smoluchowski_mV':-4.5e-8*eta/eps*1000,'reference_Huckel_mV':-4.5e-8*3*eta/(2*eps)*1000,'expanded_relative_from_rounded_components_percent':float(urel),'phase_residual_RMS_rad':float(np.sqrt(np.mean(residuals**2)))}
(O/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
