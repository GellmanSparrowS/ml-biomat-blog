"""Offline western-blot pixels, lane normalization and dynamic-range exercise."""
from pathlib import Path
import argparse,csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image
BLUE='#186e83';AMBER='#cd803f';GREEN='#3c8a6a';PURPLE='#8160a1'
def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def integrated(signal=80.,exposure=1.,ceiling=255.):
    y=np.arange(-20,21);profile=signal*np.exp(-.5*(y/4)**2)
    return float((np.minimum(ceiling,exposure*(profile+20))-exposure*20).sum())
def main(output,language='zh'):
    out=Path(output);out.mkdir(parents=True,exist_ok=True);zh=language=='zh'
    def T(a,b):return a if zh else _label(b)
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5'})
    def save(fig,n):fig.savefig(out/f'{n}-{language}.svg',bbox_inches='tight');plt.close(fig)
    rng=np.random.default_rng(707);yy,xx=np.mgrid[:240,:400];base=20+.025*yy+.01*xx
    target=base.copy();total=base.copy();loads=np.array([1,.8,1.2,1,.8,1.2]);transfers=np.array([1,.9,1.1,.85,1.05,.95]);amount=np.array([1,1,1,2,2,2]);centers=45+60*np.arange(6)
    for i,cx in enumerate(centers):
        shape_x=np.exp(-.5*((xx-cx)/8)**2);factor=loads[i]*transfers[i]
        target+=80*amount[i]*factor*shape_x*np.exp(-.5*((yy-95)/4)**2)
        target+=7*factor*shape_x*np.exp(-.5*((yy-165)/4)**2)
        for y0,a in zip([50,80,110,145,180,210],[18,30,20,26,16,22]):total+=a*factor*shape_x*np.exp(-.5*((yy-y0)/4)**2)
    target+=rng.normal(0,.4,target.shape);total+=rng.normal(0,.4,total.shape);rows=[]
    for i,cx in enumerate(centers):
        mask=(abs(xx-cx)<=16)&(abs(yy-95)<=15)
        bgmask=(abs(xx-cx)<=16)&(((yy>=65)&(yy<=75))|((yy>=115)&(yy<=125)))
        bg=target[bgmask].mean();signal=float(target[mask].sum()-mask.sum()*bg)
        lane=(abs(xx-cx)<=16)&(yy>=30)&(yy<=225)
        side=(abs(xx-(cx+26))<=2)&(yy>=30)&(yy<=225)
        # Correct the known linear x-gradient between adjacent background strip and lane center.
        total_bg=float(total[side].mean()-.01*26)
        total_signal=float(total[lane].sum()-lane.sum()*total_bg)
        rows.append([i+1,'control' if i<3 else 'treated',loads[i],transfers[i],amount[i],signal,total_signal,signal/total_signal])
    with (out/'lanes.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['lane','group','relative_load','relative_transfer','true_target_per_total','target_integral_au','total_protein_integral_au','target_over_total']);w.writerows(rows)
    np.savez_compressed(out/'blots.npz',target=target,total_protein=total,background_plane=base)
    ratio=np.array([r[-1] for r in rows]);normalized=ratio/ratio[:3].mean();rawratio=np.array([r[-3] for r in rows]);rawratio/=rawratio[:3].mean()
    fig,ax=plt.subplots(figsize=(11,5.1));ax.axis('off');ax.set(xlim=(0,12),ylim=(0,7))
    for x0,col,label in [(1.5,BLUE,T('分离后的凝胶','Separated gel')),(6,PURPLE,T('接收蛋白的膜','Receiving membrane'))]:
        ax.add_patch(Rectangle((x0,1.2),2.2,4.7,fc=col,alpha=.13,ec=col))
        for j in range(3):
            for y in [2+j*.3,3.2+j*.2,4.8-j*.3]:ax.plot([x0+.3+j*.55,x0+.7+j*.55],[y,y],color=col,lw=4)
        ax.text(x0+1.1,.6,label,ha='center')
    ax.annotate('',xy=(5.7,3.5),xytext=(4,3.5),arrowprops={'arrowstyle':'->','lw':2});ax.text(4.8,4.1,T('横向电场','Transverse field'),ha='center')
    ax.text(9.8,4.4,T('保留分离位置\n让抗体接近蛋白','Preserve separation\nMake proteins accessible'),ha='center',linespacing=1.7)
    ax.text(6,6.6,T('1979：Towbin、Staehelin、Gordon 的电转移方法','1979: electrophoretic transfer by Towbin, Staehelin and Gordon'),ha='center',fontsize=12)
    fig.text(.5,.02,T('原创示意：条带间的位置关系在转移后保留；不是历史仪器照片。','Original schematic: relative band positions survive transfer; not a historical apparatus photograph.'),ha='center',fontsize=9);save(fig,'history')
    fig,ax=plt.subplots(2,2,figsize=(11,8.4))
    for a,img,title in [(ax[0,0],target,T('A  构造靶标通道','A  Constructed target channel')),(ax[0,1],total,T('B  构造总蛋白通道','B  Constructed total-protein channel'))]:
        a.imshow(img,cmap='gray_r',vmin=15,vmax=200);a.set_title(title);a.set_xticks(centers,range(1,7));a.set_xlabel(T('泳道','Lane'));a.set_yticks([50,95,165,210]);a.set_ylabel(T('纵向位置 / 像素','Vertical position / pixel'))
    for cx in centers:ax[0,0].add_patch(Rectangle((cx-16,80),32,30,fill=False,ec=AMBER,lw=.8))
    profile=target[:,centers[0]-16:centers[0]+17].mean(axis=1);ax[1,0].plot(np.arange(240),profile,color=BLUE);ax[1,0].axvspan(80,110,color=AMBER,alpha=.25);ax[1,0].set(xlabel=T('纵向位置 / 像素','Vertical position / pixel'),ylabel=T('泳道横向平均读数 / a.u.','Lane-width mean signal / a.u.'),title=T('C  积分区域只覆盖指定的靶标峰','C  Integration isolates the selected target peak'))
    ax[1,1].bar(np.arange(6)-.18,rawratio,.35,color=BLUE,label=T('只比较靶标','Target only'));ax[1,1].bar(np.arange(6)+.18,normalized,.35,color=AMBER,label=T('总蛋白归一化','Total-protein normalized'));ax[1,1].set_xticks(range(6),range(1,7));ax[1,1].set(xlabel=T('泳道1–3对照，4–6处理','Lanes1–3control;4–6treated'),ylabel=T('相对各自对照均值','Relative to corresponding control mean'),title=T('D  相同真实倍数，不同加样与转移','D  Shared true fold change, variable loading'));ax[1,1].legend(fontsize=8);fig.tight_layout();save(fig,'pixels')
    fig,ax=plt.subplots(2,2,figsize=(11,8.2));masses=np.array([100,100/np.sqrt(2),50,50/np.sqrt(2),25]);dist=np.array([20,30,40,50,60]);coef=np.polyfit(dist,np.log10(masses),1)
    ax[0,0].plot(dist,masses,'o-',color=BLUE);ax[0,0].set_yscale('log');ax[0,0].set_yticks([25,50,100],[25,50,100]);ax[0,0].set(xlabel=T('迁移距离 / mm','Migration distance / mm'),ylabel=T('表观分子质量 / kDa','Apparent molecular mass / kDa'),title=T('A  构造标尺：对数质量与距离','A  Constructed ladder: log mass and distance'))
    load=np.geomspace(.05,6,100)
    for e,col in [(1,BLUE),(3,AMBER)]:ax[0,1].plot(load,[integrated(80*v,e) for v in load],color=col,label=T(f'曝光{e}倍',f'{e}× exposure'))
    ax[0,1].set(xlabel=T('相对目标量','Relative target amount'),ylabel=T('积分读数 / a.u.','Integrated signal / a.u.'),title=T('B  截顶后信号不再按量增长','B  Clipping breaks proportional response'));ax[0,1].legend(fontsize=8)
    exposures=np.linspace(.2,4,100);fold=[integrated(160,e)/integrated(80,e) for e in exposures]
    ax[1,0].plot(exposures,fold,color=PURPLE);ax[1,0].axhline(2,color=GREEN,ls='--');ax[1,0].set(xlabel=T('曝光倍数','Exposure multiplier'),ylabel=T('测得倍数变化','Measured fold change'),title=T('C  真值2倍在饱和时被压低','C  Saturation compresses a true twofold change'))
    errors=np.linspace(-2,2,50);ax[1,1].plot(errors,100*(800-400*errors)/800,color=BLUE,label=T('弱条带：总净信号800','Weak band: net integral800'));ax[1,1].plot(errors,100*(8000-400*errors)/8000,color=AMBER,label=T('强条带：总净信号8000','Strong band: net integral8000'));ax[1,1].set(xlabel=T('每像素背景高估值 / a.u.','Background overestimate per pixel / a.u.'),ylabel=T('保留下来的净信号 / %','Retained net signal / %'),title=T('D  同一400像素区域的背景敏感性','D  Background sensitivity in400pixels'));ax[1,1].legend(fontsize=8)
    for a in ax.flat:a.grid(alpha=.18)
    fig.tight_layout();save(fig,'diagnostics')
    fig,ax=plt.subplots(figsize=(10,9));ax.imshow(Image.open(Path(__file__).resolve().parent/'taylor2013-figure3.jpg').convert('RGB'));ax.axis('off');ax.set_title(T('真实稀释系列：目标与参照各有工作范围','Measured dilution series: target and reference have distinct ranges'),fontsize=12);fig.text(.5,.015,T('Taylor等，2013，图3；Creative Commons Attribution。\n上、下条带分别为ADH、GAPDH；曲线误差条为4张膜的SEM。','Taylor et al.,2013,Fig.3; Creative Commons Attribution.\nUpper/lower bands: ADH/GAPDH; curve error bars: SEM from4blots.'),ha='center',fontsize=9);fig.tight_layout(rect=[0,.08,1,1]);save(fig,'published')
    assert np.isclose(integrated(160)/integrated(80),2)
    summary={'mass':{'load_volume_ul':20/2,'ladder_midpoint_kDa':float(10**np.polyval(coef,40))},'background':{'corrected_integral':12000-400*20},'normalization':{'raw_ratio':24000/10000,'normalized_fold':(24000/120000)/(10000/100000)},'dynamic':{'linear_fold':integrated(160)/integrated(80),'exposure_three_fold':integrated(160,3)/integrated(80,3)},'pixels':{'mean_control':float(normalized[:3].mean()),'mean_treated':float(normalized[3:].mean()),'individual_normalized':normalized.tolist()}}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
