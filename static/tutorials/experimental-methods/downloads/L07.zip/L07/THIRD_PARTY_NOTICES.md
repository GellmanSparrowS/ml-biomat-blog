# Public sources and third-party materials

- Towbin, Staehelin & Gordon (1979): Electrophoretic transfer of proteins: https://doi.org/10.1073/pnas.76.9.4350
  Bibliographic reference
- Towbin (1988): Citation Classic retrospective: https://garfield.library.upenn.edu/classics1988/A1988M295200001.pdf
  Technical historical reference; no reproduction
- Taylor et al. (2013): A Defined Methodology for Reliable Quantification of Western Blot Data: https://pmc.ncbi.nlm.nih.gov/articles/PMC3840294/
  Creative Commons Attribution, version not stated by article; Fig. 3 reproduced
- Thermo Fisher: Western blot sample preparation: https://www.thermofisher.com/us/en/home/life-science/protein-biology/protein-biology-learning-center/protein-gel-electrophoresis-information/western-blot-protocols/western-blot-sample-preparation.html
  Technical reference
- Thermo Fisher: Total protein normalization: https://www.thermofisher.com/us/en/home/life-science/protein-biology/protein-gel-electrophoresis-western-blot/protein-gel-electrophoresis-western-blot-imaging-analysis/total-protein-normalization.html
  Technical reference
- Uhlén et al. (2016): A proposal for validation of antibodies: https://pmc.ncbi.nlm.nih.gov/articles/PMC10335836/
  Technical reference
- ImageJ: Analyze menu and gel analysis: https://imagej.net/ij/docs/menus/analyze.html#gels
  Technical documentation
