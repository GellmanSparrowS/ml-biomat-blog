"""Rotational rheometry: constructed flow, slip, recovery and critical-gel examples."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Rectangle,FancyArrowPatch


def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def carreau(rate,eta0=10.,eta_inf=.1,time_scale=2.,exponent=.4):
    return eta_inf+(eta0-eta_inf)*(1+(time_scale*np.asarray(rate))**2)**((exponent-1)/2)


def apparent_viscosity(gap_mm,slip_mm=.2,eta=2.):
    return eta*np.asarray(gap_mm)/(np.asarray(gap_mm)+2*slip_mm)


def structure_segment(t,initial,rate,recovery_time=60.,breakdown=.01):
    speed=1/recovery_time+breakdown*rate
    equilibrium=(1/recovery_time)/speed
    return equilibrium+(initial-equilibrium)*np.exp(-speed*np.asarray(t))


def main(output,language):
    from matplotlib import font_manager
    output.mkdir(parents=True,exist_ok=True)
    fonts={f.name for f in font_manager.fontManager.ttflist};font=next((x for x in ['Microsoft YaHei','Noto Sans CJK SC','SimHei'] if x in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[font,'DejaVu Sans'] if language=='zh' else ['DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','axes.prop_cycle':plt.cycler(color=['#186e83','#cd803f','#8160a1','#3c8a6a'])})
    tr=lambda z,e:z if language=='zh' else _label(e)
    def save(fig,name):fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    rate=np.geomspace(.001,1000,181);true_eta=carreau(rate)
    observed_eta=true_eta*np.exp(np.random.default_rng(808).normal(0,.025,rate.size))
    def model(lograte,*p):return np.log(carreau(np.exp(lograte),np.exp(p[0]),np.exp(p[1]),np.exp(p[2]),p[3]))
    fit,cov=curve_fit(model,np.log(rate),np.log(observed_eta),p0=[np.log(10),np.log(.1),np.log(2),.4],bounds=([np.log(1),np.log(.001),np.log(.01),.05],[np.log(100),np.log(1),np.log(100),.95]))
    fit_values=[*np.exp(fit[:3]),fit[3]];predicted=carreau(rate,*fit_values)
    t1=np.linspace(0,60,121,endpoint=False);l1=structure_segment(t1,1,.1)
    start2=float(structure_segment(60,1,.1));t2=np.linspace(60,90,61,endpoint=False);l2=structure_segment(t2-60,start2,100)
    start3=float(structure_segment(30,start2,100));t3=np.linspace(90,240,301);l3=structure_segment(t3-90,start3,.1)
    times=np.r_[t1,t2,t3];structure=np.r_[l1,l2,l3];rates=np.r_[np.full(t1.size,.1),np.full(t2.size,100),np.full(t3.size,.1)];eta_time=.1+9.9*structure
    summary={'data_kind':'independent constructed teaching models','carreau_zero_rate_eta_Pa_s':float(carreau(0)),'carreau_eta_at_1_Pa_s':float(carreau(1)),
     'apparent_eta_1mm_Pa_s':float(apparent_viscosity(1)),'slip_fraction_1mm':.2/1.4,'critical_gel_tan_delta_n04':float(np.tan(.4*np.pi/2)),
     'structure_at_90s':start3,'structure_at_240s':float(l3[-1]),'fitted':dict(zip(['eta0_Pa_s','eta_inf_Pa_s','time_scale_s','exponent'],map(float,fit_values)))}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    np.savetxt(output/'flow.csv',np.c_[rate,true_eta,observed_eta,predicted,rate*observed_eta],delimiter=',',comments='',header='shear_rate_s_inverse,true_eta_Pa_s,observed_eta_Pa_s,fitted_eta_Pa_s,observed_stress_Pa')
    np.savetxt(output/'recovery.csv',np.c_[times,rates,structure,eta_time],delimiter=',',comments='',header='time_s,shear_rate_s_inverse,structure_fraction,viscosity_Pa_s')

    fig,axes=plt.subplots(1,3,figsize=(12,4.5),layout='constrained')
    for ax in axes:ax.set(xlim=(0,10),ylim=(0,10));ax.axis('off')
    a,b,c=axes
    a.set_title(tr('A  平行板','A  Parallel plates'),loc='left',fontweight='bold')
    for y in [3,6]:a.add_patch(Rectangle((1,y),8,.6,facecolor='#85969e'))
    a.add_patch(Rectangle((1,3.6),8,2.4,facecolor='#c0ddda',alpha=.85));a.add_patch(FancyArrowPatch((2,7.5),(8,7.5),arrowstyle='-|>',mutation_scale=16,color='#cc803f',lw=2))
    a.text(5,1.6,tr('间隙可调；剪切速率随半径变化','Adjustable gap; shear rate varies with radius'),ha='center',fontsize=9)
    b.set_title(tr('B  锥板','B  Cone and plate'),loc='left',fontweight='bold')
    b.add_patch(Rectangle((1,3),8,.6,facecolor='#85969e'));b.add_patch(Polygon([[1,4.8],[5,4],[9,4.8]],facecolor='#85969e'))
    b.add_patch(Polygon([[1,3.6],[9,3.6],[9,4.8],[5,4],[1,4.8]],facecolor='#c0ddda',alpha=.8));b.text(5,1.6,tr('小锥角；理想条件下剪切近均匀','Small cone angle; nearly uniform ideal shear'),ha='center',fontsize=9)
    c.set_title(tr('C  同轴圆筒与生物流体','C  Concentric cylinders and biofluids'),loc='left',fontweight='bold')
    c.add_patch(Rectangle((1.5,2.8),7,4.8,facecolor='#c0ddda',edgecolor='#85969e',lw=3));c.add_patch(Rectangle((3.4,4),3.2,4.2,facecolor='#85969e'));c.plot([5,5],[8.2,9],color='#85969e',lw=5)
    c.text(5,1.3,tr('1923：du Noüy 关注血清等小体积样品','1923: du Noüy studied small-volume biofluids'),ha='center',fontsize=9)
    fig.suptitle(tr('现代测量几何与生物流体黏度研究的联系','Modern measurement geometries and their connection to biofluid viscosity'),fontsize=10,y=-.01)
    save(fig,'geometry')

    fig,axs=plt.subplots(1,2,figsize=(12,4.7),layout='constrained')
    axs[0].loglog(rate,observed_eta,'o',ms=3,alpha=.5,label=tr('构造观测','Constructed observations'));axs[0].loglog(rate,predicted,lw=2,label=tr('Carreau 拟合','Carreau fit'))
    axs[0].set(xlabel=tr('剪切速率 / s⁻¹','Shear rate / s⁻¹'),ylabel=tr('黏度 / Pa·s','Viscosity / Pa·s'),title=tr('A  降低的黏度与两个平台','A  Falling viscosity and two plateaus'));axs[0].legend(frameon=False,fontsize=9)
    axs[1].loglog(rate,rate*true_eta,lw=2,label=tr('同一材料的应力','Stress for the same material'));axs[1].loglog(rate,rate*10,ls='--',lw=1.5,label=tr('10 Pa·s 牛顿参照','Newtonian reference, 10 Pa·s'))
    axs[1].set(xlabel=tr('剪切速率 / s⁻¹','Shear rate / s⁻¹'),ylabel=tr('剪切应力 / Pa','Shear stress / Pa'),title=tr('B  黏度下降时，应力仍可上升','B  Stress can rise while viscosity falls'));axs[1].legend(frameon=False,fontsize=9)
    for ax in axs:ax.grid(alpha=.13)
    save(fig,'flow')

    fig,axs=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
    y=np.linspace(0,1,101);b=.2;h=1.;vel=(b+y*h)/(h+2*b)
    axs[0].plot(y,y,'--',label=tr('无滑移','No slip'),color='#9aabb0');axs[0].plot(vel,y,lw=3,label=tr('两壁滑移','Slip at both walls'))
    axs[0].plot([0,vel[0]],[0,0],color='#cc803f',lw=4);axs[0].plot([vel[-1],1],[1,1],color='#cc803f',lw=4)
    axs[0].set(xlabel=tr('流体速度 / 上壁速度','Fluid velocity / top-wall velocity'),ylabel=tr('高度 / 间隙','Height / gap'),title=tr('A  运动分给了界面与体相','A  Motion is shared by interfaces and bulk'));axs[0].legend(frameon=False,fontsize=9)
    gaps=np.linspace(.2,2,201)
    for slip in [0,.1,.2,.4]:axs[1].plot(gaps,apparent_viscosity(gaps,slip),lw=2,label=f'b={slip} mm')
    axs[1].set(xlabel=tr('间隙 / mm','Gap / mm'),ylabel=tr('表观黏度 / Pa·s','Apparent viscosity / Pa·s'),title=tr('B  真实黏度相同，间隙依赖不同','B  Same bulk viscosity, different gap dependence'));axs[1].legend(frameon=False,fontsize=9)
    save(fig,'slip')

    fig,axs=plt.subplots(2,1,figsize=(11,6.4),sharex=True,layout='constrained',gridspec_kw={'height_ratios':[1,2]})
    axs[0].step(times,rates,where='post',color='#cc803f',lw=2);axs[0].set_yscale('log');axs[0].set(ylabel=tr('剪切速率 / s⁻¹','Shear rate / s⁻¹'),title=tr('A  低剪切—高剪切—低剪切','A  Low shear – high shear – low shear'))
    axs[1].plot(times,eta_time,lw=2.5);axs[1].axvspan(60,90,color='#cc803f',alpha=.1)
    axs[1].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('模型黏度 / Pa·s','Model viscosity / Pa·s'),title=tr('B  恢复有自己的时间尺度','B  Recovery has its own timescale'))
    save(fig,'recovery')

    fig,axes=plt.subplots(1,3,figsize=(12,4.2),layout='constrained');w=np.geomspace(.1,100,150)
    for ax,n in zip(axes,[.4,.5,.7]):
        gp=100*w**n*np.cos(n*np.pi/2);gpp=100*w**n*np.sin(n*np.pi/2)
        ax.loglog(w,gp,lw=2,label='G′');ax.loglog(w,gpp,'--',lw=2,label='G″');ax.set(xlabel=tr('角频率 / rad·s⁻¹','Angular frequency / rad·s⁻¹'),ylabel=tr('模量 / Pa','Modulus / Pa'),title=f'n={n}; tan δ={np.tan(n*np.pi/2):.3f}');ax.legend(frameon=False,fontsize=9)
    fig.suptitle(tr('临界凝胶的频率判据：同一幂律，不要求处处 G′=G″','Critical-gel frequency criterion: a common power law, not universal G′=G″'),fontsize=13)
    save(fig,'gel')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();main(a.output,a.language)
