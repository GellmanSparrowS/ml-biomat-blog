# Public sources and third-party materials

- TA Instruments — Core Rheometry: Yield Stress, Time-dependency, and Rheometry Tips: https://www.tainstruments.com/applications-notes/core-rheometry-yield-stress-time-dependency-and-rheometry-tips-rh146/
  Technical or historical reference; original chapter illustrations and code.
- TA Instruments — Yield Stress and Time-Dependency: Practical Rheology: https://www.tainstruments.com/applications-notes/yield-stress-time-dependency-practical-rheology-rh151/
  Technical or historical reference; original chapter illustrations and code.
- Anton Paar — Avoid Measurement Errors in Rheometry: https://wiki.anton-paar.com/ie-en/avoid-measurement-errors-in-rheometry/
  Technical or historical reference; original chapter illustrations and code.
- P. Lecomte du Noüy (1923) — A New Viscometer: https://pmc.ncbi.nlm.nih.gov/articles/PMC2140572/
  Technical or historical reference; original chapter illustrations and code.
- Winter and Chambon (1986) — Analysis of Linear Viscoelasticity of a Crosslinking Polymer at the Gel Point: https://doi.org/10.1122/1.549853
  Technical or historical reference; original chapter illustrations and code.
- Yucel et al. — Direct Observation of Early-Time Hydrogelation in β-Hairpin Peptide Self-Assembly: https://pmc.ncbi.nlm.nih.gov/articles/PMC2630258/
  Technical or historical reference; original chapter illustrations and code.
- RepTate — LVE Theories: https://reptate.readthedocs.io/manual/Applications/LVE/Theory/theory.html
  Technical or historical reference; original chapter illustrations and code.
- SciPy — curve_fit: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html
  Technical or historical reference; original chapter illustrations and code.
