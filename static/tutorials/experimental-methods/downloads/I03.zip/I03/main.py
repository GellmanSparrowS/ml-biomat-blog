"""SEM/EDS: signal origins, a public-domain SEM image, and peak overlap.

Image: CDC/Janice Carr, PHIL 5609, public domain.
Spectra are constructed teaching data, not an analysis of the pollen image.
"""
from pathlib import Path
import argparse,csv,json
import numpy as np
from PIL import Image
from scipy.optimize import nnls
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Ellipse

def main(output,language):
    output.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','Noto Sans CJK SC','DejaVu Sans'],'svg.fonttype':'none','font.size':11,'axes.titleweight':'bold','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','text.color':'#243b45','axes.labelcolor':'#243b45'})
    tr=lambda a,b:a if language=='zh' else b
    green,blue,red,gray='#168477','#3474a8','#bd624b','#788b90'
    def save(fig,name):
        fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');fig.savefig(output/f'{name}-{language}.png',dpi=140,bbox_inches='tight');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,6),layout='constrained')
    ax=axes[0];ax.set(xlim=(0,10),ylim=(0,10));ax.axis('off');ax.set_title(tr('A  扫描位置与探测器信号配对','A  Pair scanning position with detector signal'))
    ax.add_patch(Rectangle((3.8,3.5),2.4,5.5,fc='#e2e8e5',ec=gray));ax.text(5,8.5,tr('电子源','Electron source'),ha='center')
    for y in [6.8,5,3.8]:ax.add_patch(Ellipse((5,y),2,.45,fc='#bfd4dc',ec=blue))
    ax.plot([5,5],[8,2.5],color=blue,lw=2);ax.text(6.7,6.6,tr('透镜与光阑','Lenses and apertures'));ax.text(6.7,4.7,tr('扫描线圈','Scan coils'))
    ax.add_patch(Rectangle((2,1.5),6,.8,fc='#c7b5a1'));ax.text(5,1.8,tr('样品台','Specimen stage'),ha='center')
    ax.add_patch(Rectangle((.5,3),1.6,1,fc='#c8e1d8',ec=green));ax.text(.3,4.3,tr('SE探测器','SE detector'))
    ax.annotate('',(1.4,3.4),(5,2.5),arrowprops={'arrowstyle':'->','lw':2,'color':green})
    ax.text(.3,.3,tr('1965：Stereoscan走向系列化生产\n扫描坐标决定像素位置，信号决定亮度','1965: Stereoscan enters series production\nScan coordinates locate pixels; signals set brightness'),fontsize=10)
    ax=axes[1];ax.set(xlim=(-4,4),ylim=(-4,4));ax.axis('off');ax.set_title(tr('B  同一束电子产生不同信号','B  One incident beam, several signals'))
    ax.add_patch(Rectangle((-4,-4),8,4,fc='#e6dfd1'));ax.plot([-4,4],[0,0],color=gray,lw=2)
    ax.add_patch(Ellipse((0,-1.6),3.5,3.1,fc='#abc6d0',alpha=.55));ax.add_patch(Ellipse((0,-.15),1.1,.3,fc=green,alpha=.6))
    ax.annotate('',(0,0),(0,3.6),arrowprops={'arrowstyle':'->','color':blue,'lw':3});ax.text(.2,2.8,tr('入射电子','Incident electrons'))
    ax.annotate('',(-2.8,1.6),(-.2,-.1),arrowprops={'arrowstyle':'->','color':green,'lw':2});ax.text(-3.9,2,tr('SE：近表面','SE: near surface'))
    ax.annotate('',(2.8,1.4),(.1,-1),arrowprops={'arrowstyle':'->','color':blue,'lw':2});ax.text(1.7,1.9,tr('BSE：散射返回','BSE: returning electrons'))
    ax.plot([.2,.6,1,1.4,1.8,2.2,2.6],[ -2,-1.9,-1.5,-1.6,-1.2,-1.3,-.9],color=red,lw=2);ax.text(1.4,-2.5,tr('X射线：元素信息','X-rays: elemental information'))
    ax.text(-3.8,-3.7,tr('范围取决于能量与材料；示意不按比例','Ranges depend on energy and material; not to scale'),fontsize=10)
    save(fig,'signals')
    photo=np.asarray(Image.open(Path(__file__).parent/'data/pollen-cdc5609.jpg'))
    fig,ax=plt.subplots(figsize=(10,7.5),layout='constrained');ax.imshow(photo,cmap='gray');ax.axis('off');ax.set_title(tr('真实SEM：花粉表面的纹理与几何','Real SEM: texture and geometry of pollen surfaces'))
    fig.text(.5,.01,'CDC / Janice Carr · PHIL 5609 · Public domain · wwwn.cdc.gov/phil',ha='center',fontsize=10)
    save(fig,'pollen')
    energy=np.arange(1.6,2.5001,.005);centers=np.array([2.00,2.14]);areas=np.array([6000.,3000.])
    def basis(fwhm):
        sigma=fwhm/np.sqrt(8*np.log(2))
        g=np.exp(-.5*((energy[:,None]-centers)/sigma)**2)
        return g/g.sum(axis=0)
    fwhm=.16;G=basis(fwhm);background=8.;expectation=G@areas+background
    rng=np.random.default_rng(1703);counts=rng.poisson(expectation)
    design=np.column_stack([G,np.ones(len(energy))]);coef,_=nnls(design,counts);fit=design@coef
    exact,_=nnls(design,expectation)
    fig,axes=plt.subplots(2,2,figsize=(11,8),layout='constrained')
    for width,color in [(.08,green),(.16,red),(.24,blue)]:axes[0,0].plot(energy,basis(width)@areas+background,color=color,label=f'FWHM {width*1000:.0f} eV',lw=2)
    axes[0,0].set(xlabel=tr('能量 / keV','Energy / keV'),ylabel=tr('期望计数 / 能道','Expected counts / channel'),title=tr('A  分辨率改变峰的重叠','A  Resolution changes peak overlap'));axes[0,0].legend(frameon=False)
    axes[0,1].step(energy,counts,where='mid',color=gray,lw=1,label=tr('教学计数','Teaching counts'));axes[0,1].plot(energy,fit,color=red,lw=2,label=tr('固定峰位联合拟合','Joint fit with fixed centers'))
    for i,color in enumerate([green,blue]):axes[0,1].plot(energy,G[:,i]*coef[i],ls='--',color=color,label=f'Peak {i+1}')
    axes[0,1].set(xlabel=tr('能量 / keV','Energy / keV'),ylabel=tr('计数 / 能道','Counts / channel'),title=tr('B  同时处理峰与背景','B  Fit peaks and background together'));axes[0,1].legend(frameon=False,fontsize=9)
    residual=(counts-fit)/np.sqrt(np.maximum(fit,1));axes[1,0].plot(energy,residual,color=green,lw=1);axes[1,0].axhline(0,color=gray);axes[1,0].axhspan(-2,2,color=gray,alpha=.12)
    axes[1,0].set(xlabel=tr('能量 / keV','Energy / keV'),ylabel=tr('计数残差 / √拟合计数','Count residual / √fitted count'),title=tr('C  残差检验模型遗漏','C  Residuals reveal model mismatch'))
    n=np.logspace(1,5,100);axes[1,1].loglog(n,100/np.sqrt(n),color=blue,lw=2)
    axes[1,1].set(xlabel=tr('无背景的净计数','Net counts without background'),ylabel=tr('泊松相对标准差 / %','Poisson relative SD / %'),title=tr('D  计数增加四倍，相对噪声减半','D  Four times the counts halves relative noise'))
    save(fig,'eds')
    with (output/'data.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['energy_keV','expected_counts','observed_teaching_counts','fitted_counts','standardized_residual']);w.writerows(zip(energy,expectation,counts,fit,residual))
    summary={'energy_channels':len(energy),'peak_separation_keV':.14,'noiseless_area1':float(exact[0]),'noiseless_area2':float(exact[1]),'noiseless_background':float(exact[2]),'fitted_area1':float(coef[0]),'fitted_area2':float(coef[1]),'fitted_background':float(coef[2]),'electron_count_100pA_1s':100e-12/1.602176634e-19,'scale_um_per_px_10um_180px':10/180,'poisson_relative_sd_10000':.01,'image_shape':list(photo.shape),'data_origin':'Real public-domain CDC SEM image; EDS spectrum independently constructed, not measured from that image.'}
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
