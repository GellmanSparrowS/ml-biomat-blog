# Public sources and third-party materials

- CDC PHIL 5609 — pollen SEM: https://wwwn.cdc.gov/phil/Details.aspx?pid=5609
  Public domain; CDC / Janice Carr.
- JEOL — secondary electron: https://www.jeol.com/words/semterms/20121024.070758.php
  Technical reference.
- JEOL — backscattered electron: https://www.jeol.com/words/semterms/20121024.072858.php
  Technical reference.
- University of Cambridge — Stereoscan: https://www-g.eng.cam.ac.uk/125/1950-1975/sem2.html
  Historical institutional reference; diagram original.
- MyScope — SEM image artefacts: https://myscope.training/SEM_Image_artefacts_and_trouble_shooting
  Site educational text CC BY-SA 4.0 unless otherwise stated; linked reading.
- Newbury & Ritchie — quantitative SEM/SDD-EDS: https://link.springer.com/article/10.1007/s10853-014-8685-2
  Open-access article CC BY 4.0; linked reading.
