"""Creep and recovery: a reproducible constructed experiment in SI units."""
from pathlib import Path
import argparse, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch
from scipy.optimize import curve_fit


def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def compliance(t, j0, j1, tau, eta):
    t = np.asarray(t, dtype=float)
    return j0 + j1 * (-np.expm1(-t / tau)) + t / eta


def response(t, stress, hold, pars):
    """Right-continuous response: a negative stress step begins at hold."""
    t = np.asarray(t, dtype=float)
    result = stress * compliance(t, *pars)
    unload = t >= hold
    result[unload] -= stress * compliance(t[unload] - hold, *pars)
    return result


def fit_loading(t, strain, stress, noise):
    def model(times, *log_parameters):
        return stress * compliance(times, *np.exp(log_parameters))
    logs, covariance = curve_fit(
        model, t, strain, p0=np.log([2e-5, 4e-5, 40, 2e7]),
        sigma=np.full(t.size, noise), absolute_sigma=True,
        bounds=(np.log([1e-7, 1e-7, 0.5, 1e5]),
                np.log([1e-2, 1e-2, 2e4, 1e11])), maxfev=20000)
    parameters = np.exp(logs)
    standard_error = parameters * np.sqrt(np.diag(covariance))
    return parameters, standard_error


def setup(language):
    from matplotlib import font_manager
    names = {f.name for f in font_manager.fontManager.ttflist}
    cjk = next((n for n in ['Microsoft YaHei', 'Noto Sans CJK SC', 'SimHei'] if n in names), 'DejaVu Sans')
    plt.rcParams.update({'font.family': cjk if language == 'zh' else 'DejaVu Sans',
        'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False,
        'axes.labelcolor': '#213342', 'text.color': '#213342',
        'axes.prop_cycle': plt.cycler(color=['#176c83', '#d4813d', '#7d5ea4', '#3c8a6a']),
        'svg.fonttype': 'none', 'figure.facecolor': '#faf9f5',
        'axes.facecolor': '#faf9f5', 'savefig.facecolor': '#faf9f5',
        'axes.unicode_minus': False})
    return lambda zh, en: zh if language == 'zh' else _label(en)


def main(output, language):
    output.mkdir(parents=True, exist_ok=True)
    tr = setup(language)
    seed, stress, hold, noise = 604, 500., 180., 0.0001
    parameters = np.array([2e-5, 4e-5, 40., 2e7])
    times = np.r_[np.linspace(0, hold, 121, endpoint=False), np.linspace(hold, 420, 121)]
    truth = response(times, stress, hold, parameters)
    observed = truth + np.random.default_rng(seed).normal(0, noise, times.size)
    loading = times < hold
    fitted, errors = fit_loading(times[loading], observed[loading], stress, noise)
    predicted = response(times, stress, hold, fitted)
    residual = observed - predicted
    np.savetxt(output / 'data.csv', np.c_[times, np.where(loading, stress, 0), truth, observed],
        delimiter=',', header='time_s,stress_Pa,theoretical_strain,observed_strain', comments='')
    peak = float(stress * compliance(hold, *parameters))
    summary = {'data_kind': 'constructed teaching experiment', 'seed': seed,
        'instantaneous_strain': float(stress*parameters[0]),
        'peak_strain_before_unload': peak,
        'permanent_strain': float(stress*hold/parameters[3]),
        'retardation_fraction_at_tau': float(1-np.exp(-1)),
        'fitted': dict(zip(['j0_Pa_inverse','j1_Pa_inverse','tau_s','eta_Pa_s'], map(float,fitted))),
        'local_standard_errors': dict(zip(['j0_Pa_inverse','j1_Pa_inverse','tau_s','eta_Pa_s'], map(float,errors))),
        'recovery_rmse_strain': float(np.sqrt(np.mean(residual[~loading]**2)))}
    (output/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf8')

    def save(fig, name):
        fig.savefig(output / f'{name}-{language}.svg', bbox_inches='tight')
        plt.close(fig)

    # Original conceptual drawing: history and mechanical response share symbols.
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), layout='constrained', gridspec_kw={'width_ratios':[1.05,1.25]})
    a, b = axes
    for ax in axes: ax.set(xlim=(0,10),ylim=(0,10));ax.axis('off')
    a.set_title(tr('A  从恒力到长度变化','A  Constant force, changing length'),loc='left',fontweight='bold')
    a.add_patch(Rectangle((2,8),4,.45,color='#7b8990'))
    a.add_patch(Rectangle((3.25,3.5),1.5,4.5,facecolor='#b9d7d9',edgecolor='#176c83',lw=2))
    a.add_patch(Rectangle((2.5,2.8),3,.6,color='#7b8990'))
    a.add_patch(FancyArrowPatch((4,2.7),(4,.7),arrowstyle='-|>',mutation_scale=19,lw=2,color='#d4813d'))
    a.annotate(tr('固定端','Fixed grip'),(6.1,8.2),fontsize=11)
    a.annotate(tr('试样标距','Gauge length'),(5.2,5.8),fontsize=11)
    a.annotate(tr('载荷传感器','Load cell'),(5.8,3.0),fontsize=11)
    a.text(4,.3,tr('控制力，记录伸长与时间','Control force; record extension and time'),ha='center',fontsize=10)
    b.set_title(tr('B  三种响应的机械语言','B  A mechanical language for three responses'),loc='left',fontweight='bold')
    def spring(x1,x2,y,color):
        xs=np.linspace(x1,x2,17);ys=np.full(17,y);ys[1:-1]=y+np.tile([.35,-.35],8)[:15]
        b.plot(xs,ys,color=color,lw=2)
    def dashpot(x1,x2,y,color):
        b.plot([x1,x1+.6],[y,y],color=color,lw=2)
        b.plot([x1+.6,x1+.6,x2-.5,x2-.5],[y+.4,y-.4,y-.4,y+.4],color=color,lw=2)
        b.plot([x1+1,x1+1],[y-.3,y+.3],color=color,lw=2)
        b.plot([x1+1,x2],[y,y],color=color,lw=2)
    spring(.3,2.3,6.8,'#176c83'); b.text(1.3,8,tr('立即弹性','Immediate elasticity'),ha='center')
    b.plot([2.3,3,3],[6.8,6.8,7.8],color='#213342'); b.plot([3,3],[6.8,5.8],color='#213342')
    spring(3,5.3,7.8,'#7d5ea4');dashpot(3,5.3,5.8,'#7d5ea4')
    b.plot([5.3,5.3,6],[7.8,6.8,6.8],color='#213342');b.plot([5.3,5.3],[5.8,6.8],color='#213342')
    dashpot(6,8.5,6.8,'#d4813d')
    b.text(4.2,9.1,tr('延迟恢复','Delayed recovery'),ha='center');b.text(7.3,8,tr('持续流动','Ongoing flow'),ha='center')
    b.text(.4,3.6,tr('十九世纪：弹性与黏性模型','19th century: elastic and viscous models'),fontsize=11)
    b.annotate('',(8.7,2.7),(.4,2.7),arrowprops={'arrowstyle':'->','color':'#7b8990'})
    b.text(.4,1.7,tr('1929：流变学会成立','1929: Society of Rheology founded'),fontsize=11)
    b.text(.4,.45,tr('原创概念示意；串联单元的变形相加','Original conceptual diagram; series deformations add'),fontsize=9,color='#62747d')
    save(fig,'mechanism')

    fig, axs = plt.subplots(1,2,figsize=(12,4.7),layout='constrained')
    t=np.linspace(0,hold,301)
    components=[np.full_like(t,stress*parameters[0]*100),stress*parameters[1]*(-np.expm1(-t/parameters[2]))*100,stress*t/parameters[3]*100]
    labels=[tr('立即弹性','Immediate elastic'),tr('延迟恢复部分','Delayed recoverable'),tr('黏性流动','Viscous flow')]
    axs[0].stackplot(t,*components,labels=labels,alpha=.7)
    axs[0].set(xlabel=tr('加载时间 / s','Loading time / s'),ylabel=tr('应变 / %','Strain / %'),title=tr('A  卸载前的三部分贡献','A  Three contributions before unloading'))
    axs[0].legend(frameon=False,fontsize=9,loc='upper left')
    axs[1].plot(times,truth*100,lw=2.5);axs[1].axvline(hold,color='#777',ls=':',lw=1)
    axs[1].axhline(summary['permanent_strain']*100,color='#d4813d',ls='--',label=tr('长期残余 0.450%','Long-time residual 0.450%'))
    axs[1].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('应变 / %','Strain / %'),title=tr('B  蠕变与卸载恢复','B  Creep and recovery'))
    axs[1].legend(frameon=False,fontsize=9); save(fig,'components')

    fig,axs=plt.subplots(2,1,figsize=(11,6.3),layout='constrained',sharex=True,gridspec_kw={'height_ratios':[2,1]})
    axs[0].scatter(times[::3],observed[::3]*100,s=13,color='#899b9e',label=tr('构造观测值','Constructed observations'))
    axs[0].plot(times[loading],predicted[loading]*100,color='#176c83',lw=2,label=tr('加载段拟合','Fit to loading'))
    axs[0].plot(times[~loading],predicted[~loading]*100,color='#d4813d',lw=2,label=tr('恢复段预测','Predicted recovery'))
    axs[0].set(ylabel=tr('应变 / %','Strain / %'),title=tr('A  用加载段预测恢复段','A  Predict recovery from the loading fit'))
    axs[0].legend(frameon=False,ncols=3,fontsize=9)
    axs[1].axhspan(-noise*200,noise*200,color='#176c83',alpha=.1,label=tr('±2 倍设定噪声标准差','±2 prescribed noise standard deviations'))
    axs[1].axhline(0,color='#738087',lw=1);axs[1].scatter(times,residual*100,s=10,color='#176c83')
    axs[1].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('残差 / 百分点','Residual / percentage points'))
    axs[1].legend(frameon=False,fontsize=9); save(fig,'diagnostics')

    fig,axs=plt.subplots(1,2,figsize=(12,4.6),layout='constrained')
    for st in [250,500,750]:
        axs[0].plot(t,st*compliance(t,*parameters)*100,lw=2,label=f'{st} Pa')
    axs[0].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('应变 / %','Strain / %'),title=tr('A  线性模型中的载荷比例','A  Stress proportionality in the linear model'));axs[0].legend(frameon=False)
    for tau,col in [(20,'#176c83'),(40,'#d4813d'),(80,'#7d5ea4')]:
        p=parameters.copy();p[2]=tau;axs[1].plot(times,response(times,stress,hold,p)*100,lw=2,color=col,label=f'τ = {tau} s')
    axs[1].set(xlabel=tr('时间 / s','Time / s'),ylabel=tr('应变 / %','Strain / %'),title=tr('B  改变时间尺度，残余极限相同','B  Different retardation times, same residual limit'));axs[1].legend(frameon=False)
    save(fig,'design')
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en')
    args=parser.parse_args();main(args.output,args.language)
