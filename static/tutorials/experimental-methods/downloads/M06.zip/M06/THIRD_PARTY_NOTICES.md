# Public sources and third-party materials

- David Roylance — Linear Viscoelasticity: https://eng.libretexts.org/Bookshelves/Mechanical_Engineering/Mechanics_of_Materials_(Roylance)/05:_General_Stress_Analysis/5.04:_Linear_Viscoelasticity
  Reference reading; page marked CC BY-NC-SA 4.0; figures not reproduced.
- RepTate — Creep Theories: https://reptate.readthedocs.io/manual/Applications/Creep/Theory/theory.html
  Technical reference; original example implementation.
- RepTate — Tutorial Creep Application: https://reptate.readthedocs.io/manual/Applications/Creep/Tutorial/tutorialGUICreep.html
  Technical reference.
- Society of Rheology — History: https://www.societyofrheology.org/history
  Historical reference; original illustration.
- SciPy — curve_fit: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html
  Technical reference; SciPy software is BSD-3-Clause.
- RepTate — TTS Theories: https://reptate.readthedocs.io/manual/Applications/TTS/Theory/theory.html
  Technical reference.
