# Public sources and third-party materials

- Molecular Probes Handbook: Introduction to Fluorescence Techniques: https://www.thermofisher.com/us/en/home/references/molecular-probes-the-handbook/introduction-to-fluorescence-techniques.html
  Technical reference; no source figures copied.
- Molecular Expressions: Introduction to Fluorescence: https://micro.magnet.fsu.edu/primer/techniques/fluorescence/fluorescenceintro.html
  Technical reference; original diagrams.
- Ormö et al.: Crystal structure of GFP; PDB 1EMA: https://www.rcsb.org/structure/1EMA
  PDB archive coordinates CC0; entry paper DOI 10.1126/science.273.5280.1392.
- RCSB PDB: Data usage policies: https://www.rcsb.org/pages/policies
  PDB archive data CC0.
- NISTIR 7457: Recommendations and Guidelines for Standardization of Fluorescence Spectroscopy: https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir7457.pdf
  US government technical reference.
- Margineanu: Calibration approaches for fluorescence lifetime applications using time-domain measurements: https://pmc.ncbi.nlm.nih.gov/articles/PMC11969142/
  CC BY 4.0 article; no source figures reproduced.
