# PDB 1EMA

Atomic coordinates downloaded from https://files.rcsb.org/download/1EMA.pdb .
Entry: https://www.rcsb.org/structure/1EMA .

Ormö M, Cubitt AB, Kallio K, Gross LA, Tsien RY, Remington SJ (1996).
Crystal structure of the Aequorea victoria green fluorescent protein.
Science 273:1392–1395. https://doi.org/10.1126/science.273.5280.1392

The PDB archive data are available under CC0, as described at
https://www.rcsb.org/pages/policies . The original coordinate file is preserved.
This entry is an engineered structure, determined at 1.90 Å resolution; consult
the entry and coordinate records for sequence and chemical-component details.

The accompanying photon-counting curves are constructed teaching datasets.
They are not experimental fluorescence measurements of this crystal structure.
