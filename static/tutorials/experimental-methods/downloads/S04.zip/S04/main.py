"""Fluorescence: real PDB structure and explicitly constructed photon-count data.

Run: python main.py --output results --language en
Dependencies: numpy, scipy, matplotlib. No network access is needed.
1EMA coordinates: PDB archive CC0; Ormo et al., Science (1996),
https://doi.org/10.1126/science.273.5280.1392 .
"""
from pathlib import Path
import argparse
import json
import numpy as np
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

P = argparse.ArgumentParser()
P.add_argument("--output", type=Path, default=Path("results"))
P.add_argument("--language", choices=["zh", "en"], default="en")
args = P.parse_args()
OUT = args.output
OUT.mkdir(parents=True, exist_ok=True)
ZH = args.language == "zh"
def tr(zh, en): return zh if ZH else en
plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Microsoft YaHei", "DejaVu Sans"],
    "font.size": 11, "axes.spines.top": False, "axes.spines.right": False,
    "axes.labelcolor": "#263d49", "text.color": "#263d49", "axes.edgecolor": "#9bacb1",
    "figure.facecolor": "#fbfaf6", "axes.facecolor": "#fbfaf6", "svg.fonttype": "path"})
BLUE, TEAL, CORAL, GOLD, GRAY = "#265f85", "#078579", "#d6604d", "#ba8e2f", "#81949a"
def save(fig, name):
    fig.savefig(OUT / f"{name}-{args.language}.svg", bbox_inches="tight")
    fig.savefig(OUT / f"{name}-{args.language}.png", dpi=155, bbox_inches="tight")
    plt.close(fig)
def panel(ax, letter, title):
    ax.set_title(f"{letter}  {title}", loc="left", weight="bold", pad=14)

# Preserve the real coordinate file; the plotted traces stop at sequence gaps.
atoms, chromophore = [], []
for line in (Path(__file__).parent / "data" / "1EMA.pdb").read_text().splitlines():
    if line[:6].strip() not in {"ATOM", "HETATM"} or line[21] != "A":
        continue
    xyz = [float(line[30:38]), float(line[38:46]), float(line[46:54])]
    if line[17:20] == "CRO": chromophore.append(xyz)
    if line[12:16].strip() == "CA": atoms.append((int(line[22:26]), xyz))
ca = np.array([a[1] for a in atoms]); seq = np.array([a[0] for a in atoms])
cro = np.array(chromophore)
center = ca.mean(axis=0)
# A principal-coordinate projection shows the architecture without inventing atoms.
_, _, basis = np.linalg.svd(ca - center, full_matrices=False)
ca_p = (ca - center) @ basis.T; cro_p = (cro - center) @ basis.T
fig, axs = plt.subplots(1, 2, figsize=(11.6, 5.3))
for ax, dims, letter, title in zip(axs, [(0,1),(1,2)], ["A","B"],
    [tr("沿长轴展开的侧视", "Side view along the long dimension"), tr("沿长轴观察的端视", "End view along the long dimension")]):
    for i in range(len(seq)-1):
        if seq[i+1]-seq[i] == 1:
            ax.plot(ca_p[i:i+2,dims[0]], ca_p[i:i+2,dims[1]], lw=2.1, alpha=.8,
                    color=plt.cm.viridis(i/(len(seq)-1)))
    ax.scatter(cro_p[:,dims[0]], cro_p[:,dims[1]], s=42, color=CORAL, edgecolor="white", lw=.4,
               label=tr("发色团原子", "Chromophore atoms"), zorder=5)
    ax.set_aspect("equal"); ax.set_xlabel(tr("投影坐标 / Å", "Projected coordinate / Å")); ax.set_ylabel(tr("投影坐标 / Å", "Projected coordinate / Å"))
    panel(ax, letter, title); ax.legend(loc="lower left", fontsize=9)
fig.suptitle(tr("GFP 结构 1EMA：真实坐标，原创投影 · 1996", "GFP structure 1EMA: real coordinates, original projection · 1996"), fontsize=15, weight="bold")
fig.text(.5,.01,tr("链 A 的 Cα 轨迹；缺失或非连续残基处断开。CRO 以原子点显示。", "Chain-A Cα trace; gaps are not bridged. CRO is shown as atomic positions."),ha="center",fontsize=10)
fig.tight_layout(rect=[0,.10,1,.94]); save(fig,"structure")

# A conceptual energy diagram: its level spacings are not measured GFP energies.
fig, axs=plt.subplots(1,2,figsize=(11.6,5.2),gridspec_kw={"width_ratios":[1.15,1]})
ax=axs[0];ax.set_xlim(0,10);ax.set_ylim(-.4,5.2);ax.axis("off")
for y in [0,.4,.8]:ax.plot([.5,4.5],[y,y],color=BLUE,lw=2)
for y in [3,3.4,3.8,4.2]:ax.plot([.5,7.8],[y,y],color=BLUE,lw=2)
def arrow(a,b,c):ax.annotate("",xy=b,xytext=a,arrowprops={"arrowstyle":"-|>","color":c,"lw":2.5})
arrow((1.2,0),(1.2,4.2),BLUE);arrow((1.8,4.2),(3.5,3),GOLD);arrow((4.2,3),(4.2,.4),TEAL)
yy=np.linspace(3,0,150);xx=6.5+.16*np.sin(np.linspace(0,10*np.pi,150));ax.plot(xx,yy,color=CORAL,lw=2.3)
ax.text(.05,-.2,r"$S_0$",fontsize=14);ax.text(.05,4.7,r"$S_1$",fontsize=14)
ax.text(.95,2,tr("吸收", "Absorb"),rotation=90,ha="right",color=BLUE)
ax.text(2.1,4.5,tr("振动弛豫", "Vibrational relaxation"),fontsize=10,color=GOLD)
ax.text(4.45,1.5,tr("荧光", "Fluorescence"),rotation=90,va="center",color=TEAL)
ax.text(7.1,1.5,tr("非辐射\n失能", "Nonradiative\nrelaxation"),va="center",fontsize=10,color=CORAL)
panel(ax,"A",tr("Stokes 位移的能量路径", "Energy paths behind the Stokes shift"))
w=np.linspace(380,680,500);exc=np.exp(-.5*((w-470)/22)**2);emi=np.exp(-.5*((w-535)/30)**2)
axs[1].fill_between(w,exc,color=BLUE,alpha=.17);axs[1].plot(w,exc,color=BLUE,label=tr("激发", "Excitation"))
axs[1].fill_between(w,emi,color=TEAL,alpha=.17);axs[1].plot(w,emi,color=TEAL,label=tr("发射", "Emission"))
axs[1].annotate("",xy=(535,1.05),xytext=(470,1.05),arrowprops={"arrowstyle":"<->","color":GRAY})
axs[1].text(502.5,1.1,tr("65 nm（示意）", "65 nm (schematic)"),ha="center",fontsize=10)
axs[1].set(xlim=(380,680),ylim=(0,1.3),xlabel=tr("波长 / nm", "Wavelength / nm"),ylabel=tr("归一化谱强度", "Normalized spectral intensity"));axs[1].legend(frameon=False)
panel(axs[1],"B",tr("分开照明与发射", "Separate illumination and emission"))
fig.text(.5,.01,tr("原理模型；不代表 1EMA 的实测光谱。纵向能级位置表示相对能量。", "Conceptual model, not measured spectra of 1EMA. Vertical energy levels show relative energy."),ha="center",fontsize=10)
fig.tight_layout(rect=[0,.06,1,1]);save(fig,"pathways")

# Two constructed experiments. Time is in ns. The IRF is normalized discretely.
rng=np.random.default_rng(540)
t=np.arange(0,30.0001,.05)
irf=np.exp(-.5*((t-.6)/.12)**2);irf/=irf.sum()
lifetimes=[4.,2.];counts=[];fits=[];sensitivity=[]
def tail(x, amplitude, lifetime, background):return amplitude*np.exp(-(x-.6)/lifetime)+background
for tau in lifetimes:
    expected=np.convolve(1800*np.exp(-t/tau),irf,mode="full")[:len(t)]+5
    observed=rng.poisson(expected);counts.append(observed)
    results=[]
    for start in [.35,.6,.9,1.2,2,4,6]:
        mask=t>=start
        p,cov=curve_fit(tail,t[mask],observed[mask],p0=[1800,tau,5],sigma=np.sqrt(np.maximum(observed[mask],1)),
            absolute_sigma=True,bounds=([0,.1,0],[10000,20,100]),maxfev=15000)
        results.append([start,p[1],np.sqrt(cov[1,1])])
        if start==1.2:fits.append(p)
    sensitivity.append(np.array(results))
fig,axs=plt.subplots(2,2,figsize=(11.6,8.1))
for i,(tau,y,p,col) in enumerate(zip(lifetimes,counts,fits,[TEAL,CORAL])):
    label=tr(f"设定 {tau:g} ns；拟合 {p[1]:.3f} ns",f"Set {tau:g} ns; fit {p[1]:.3f} ns")
    axs[0,0].scatter(t[::3],y[::3],s=9,alpha=.4,color=col)
    mask=t>=1.2;axs[0,0].plot(t[mask],tail(t[mask],*p),color=col,lw=2,label=label)
    norm=(y-p[2])/p[0];axs[0,1].plot(t,norm,color=col,alpha=.7,label=tr(f"{tau:g} ns 组",f"{tau:g} ns group"))
    residual=(y[mask]-tail(t[mask],*p))/np.sqrt(np.maximum(y[mask],1));axs[1,0].plot(t[mask],residual,color=col,alpha=.65,lw=.7)
    ss=sensitivity[i];axs[1,1].errorbar(ss[:,0],ss[:,1],yerr=ss[:,2],color=col,marker="o",capsize=3,label=label)
    axs[1,1].axhline(tau,color=col,ls=":",alpha=.5)
axs[0,0].axvspan(0,1.2,color=GRAY,alpha=.1);axs[0,0].legend(fontsize=9,frameon=False)
axs[0,0].set(xlabel=tr("延迟 / ns","Delay / ns"),ylabel=tr("每时间格计数","Counts per time bin"),xlim=(0,25))
axs[0,1].set(xlabel=tr("延迟 / ns","Delay / ns"),ylabel=tr("扣背景后除以拟合振幅","Background-subtracted / fitted amplitude"),xlim=(0,15));axs[0,1].legend(fontsize=9,frameon=False)
axs[1,0].axhline(0,color=GRAY,lw=1);axs[1,0].set(xlabel=tr("延迟 / ns","Delay / ns"),ylabel=tr("残差 / 估计计数标准差","Residual / estimated count SD"))
axs[1,1].set(xlabel=tr("拟合起点 / ns","Fit starting time / ns"),ylabel=tr("拟合寿命 / ns","Fitted lifetime / ns"));axs[1,1].legend(fontsize=9,frameon=False)
for ax,l,z,e in zip(axs.flat,"ABCD",["保留光子量级","比较衰减形状","检查加权残差","改变拟合起点"],["Retain the count scale","Compare decay shape","Inspect weighted residuals","Change the fit start"]):panel(ax,l,tr(z,e))
fig.tight_layout();save(fig,"decays")

q=np.linspace(0,.1,200);ratio=1+20*q
c=np.linspace(0,50,200);ideal=c*.6;observed=ideal*10**(-(.05*c+.02*c)/2)
fig,axs=plt.subplots(1,2,figsize=(11.6,4.8))
axs[0].plot(q,ratio,color=TEAL,lw=3,label=tr("动态：强度比与寿命比","Dynamic: intensity and lifetime ratios"))
axs[0].plot(q,np.ones_like(q),color=CORAL,lw=2,ls="--",label=tr("纯光学衰减：寿命比","Pure optical attenuation: lifetime ratio"))
axs[0].set(xlabel=tr("猝灭剂浓度 / mol L$^{-1}$","Quencher / mol L$^{-1}$"),ylabel=tr("无猝灭值 / 当前值","Unquenched value / current value"));axs[0].legend(fontsize=9,frameon=False)
axs[1].plot(c,ideal,color=GRAY,ls="--",label=tr("理想浓度响应","Ideal concentration response"));axs[1].plot(c,observed,color=BLUE,lw=3,label=tr("加入内滤的中点近似","With midpoint inner-filter approximation"))
axs[1].set(xlabel=tr("浓度 / μmol L$^{-1}$","Concentration / μmol L$^{-1}$"),ylabel=tr("相对荧光信号","Relative fluorescence signal"));axs[1].legend(fontsize=9,frameon=False)
panel(axs[0],"A",tr("强度与寿命是否一起改变？","Do intensity and lifetime change together?"));panel(axs[1],"B",tr("浓度增加也可能变暗","More concentrated can become dimmer"))
fig.tight_layout();save(fig,"diagnostics")
np.savetxt(OUT/"decay_counts.csv",np.column_stack([t,*counts]),delimiter=",",header="delay_ns,counts_tau4,counts_tau2",comments="")
np.savetxt(OUT/"fit_sensitivity.csv",np.vstack([np.column_stack([np.full(len(s),tau),s]) for tau,s in zip(lifetimes,sensitivity)]),delimiter=",",header="true_tau_ns,start_ns,fitted_tau_ns,standard_error_ns",comments="")
np.savetxt(OUT/"inner_filter.csv",np.column_stack([c,ideal,observed]),delimiter=",",header="concentration_uM,ideal_relative_signal,attenuated_relative_signal",comments="")
summary={"tau_unquenched_ns":1/(.15+.1),"yield_unquenched":.15/(.15+.1),"tau_quenched_ns":1/(.15+.1+5*.05),
    "yield_quenched":.15/(.15+.1+5*.05),"fit_tau4_ns":float(fits[0][1]),"fit_tau2_ns":float(fits[1][1]),
    "chromophore_atoms":len(cro),"backbone_CA_atoms":len(ca),"inner_filter_factor_A04_A02":10**(-.3),
    "data_kind":{"structure":"real crystallographic PDB 1EMA coordinates","decays":"constructed Poisson teaching data"}}
(OUT/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf8")
print(json.dumps(summary,indent=2))
