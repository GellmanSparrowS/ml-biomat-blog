# Public sources and third-party materials

- Binnig, Quate & Gerber — Atomic Force Microscope (1986): https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.56.930
  Primary paper; original explanatory figure here.
- APS Physics — AFM landmark: https://physics.aps.org/articles/v5/106
  Publisher historical account; no image reused.
- Gwyddion — Tip Convolution Artefacts: https://gwyddion.net/documentation/user-guide-en/tip-convolution-artefacts.html
  Guide GPL v2+ or GFDL v1.2+; linked reference, figures original.
- Gwyddion — Data Levelling and Background Subtraction: https://gwyddion.net/documentation/user-guide-en/leveling-and-background.html
  Guide GPL v2+ or GFDL v1.2+; linked reference.
- Gwyddion — Statistical Analysis: https://gwyddion.net/documentation/user-guide-en/statistical-analysis.html
  Guide GPL v2+ or GFDL v1.2+; linked reference.
- JPK / Bruker — A practical guide to AFM force spectroscopy: https://www.bruker.com/en/products-and-solutions/microscopes/bioafm/resource-library/a-practical-guide-to-afm-force-spectroscopy-and-data-analysis/_jcr_content/root/sections/section/sectionpar/twocolumns/contentpar-2/calltoaction.download-asset.pdf/primaryButton/jpk-tech-force-spectroscopy.14-2.pdf
  Technical reference; copyrighted figures not reused.
