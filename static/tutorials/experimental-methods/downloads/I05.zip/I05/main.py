"""AFM teaching models: probe broadening, levelling and Hertz indentation.

All arrays are constructed teaching data. No experimental surface or cell is claimed.
"""
from pathlib import Path
import argparse,json,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Polygon

def hertz(delta,E,R,nu):return 4/3*E/(1-nu**2)*np.sqrt(R)*delta**1.5
def broadening(x,radius,height=10,width=20):
    distance=np.maximum(np.abs(x)-width/2,0)
    return np.maximum(height-distance**2/(2*radius),0)

def main(output,language):
    output.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'svg.fonttype':'none','font.size':11,'axes.titleweight':'bold','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','text.color':'#243b45','axes.labelcolor':'#243b45'})
    tr=lambda a,b:a if language=='zh' else b
    green,blue,red,gray='#168477','#3474a8','#bd624b','#788b90'
    def save(fig,name):
        fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');fig.savefig(output/f'{name}-{language}.png',dpi=140,bbox_inches='tight');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,5.5),layout='constrained')
    for ax in axes:ax.set(xlim=(0,10),ylim=(0,8));ax.axis('off')
    ax=axes[0];ax.set_title(tr('A  1986：用悬臂弯曲读取微小力','A  1986: cantilever bending senses force'))
    ax.add_patch(Rectangle((1,3.8),6,.15,fc='#d6b664'));ax.add_patch(Rectangle((.8,3),.5,2,fc=gray));ax.add_patch(Polygon([[6.5,3.8],[7,3.8],[6.75,3]],fc=blue));ax.add_patch(Rectangle((1,1.5),8,.4,fc='#c8d6ca'))
    ax.add_patch(Polygon([[6.4,6.5],[7.1,6.5],[6.75,4.3]],fc=red));ax.text(6.75,7,tr('STM读取悬臂位移','STM reads cantilever displacement'),ha='center',fontsize=10)
    ax.text(3.5,4.4,tr('金属悬臂','Metal cantilever'),ha='center');ax.text(7.2,2.9,tr('金刚石探针','Diamond tip'),fontsize=10);ax.text(4.7,.8,tr('压电位置控制','Piezo position control'),ha='center');ax.annotate('',(6.75,3),(6.75,2),arrowprops={'arrowstyle':'<->','color':green})
    ax=axes[1];ax.set_title(tr('B  常用光杠杆读出与反馈','B  Common optical-lever readout and feedback'))
    ax.add_patch(Rectangle((1,3.8),6,.15,fc=gray));ax.add_patch(Polygon([[6.4,3.8],[7,3.8],[6.7,2.9]],fc=blue));ax.add_patch(Rectangle((1,1.7),8,.3,fc='#c8d6ca'))
    ax.plot([2,6.5,8.8],[7,3.95,6.8],color=red,lw=2);ax.text(1.6,7.4,tr('激光','Laser'));ax.add_patch(Rectangle((8.2,6.5),1.2,.6,fc='#d5e5eb',ec=blue));ax.text(7.1,7.5,tr('分区探测器','Split detector'),fontsize=10)
    ax.text(3,5,tr('悬臂弯曲 → 光斑移动','Bending → spot displacement'),ha='center',fontsize=10);ax.text(5,.6,tr('反馈调节z位置，使相互作用接近设定值','Feedback changes z to maintain the interaction setpoint'),ha='center',fontsize=10)
    save(fig,'principle')
    x=np.linspace(-80,80,801);truth=np.where(np.abs(x)<=10,10.,0.)
    grid=np.linspace(-250,250,129);X,Y=np.meshgrid(grid,grid);surface=2*np.cos(2*np.pi*X/500)+np.cos(4*np.pi*Y/500);plane=.025*X-.015*Y+7;raw=surface+plane
    design=np.column_stack([X.ravel(),Y.ravel(),np.ones(X.size)]);coef=np.linalg.lstsq(design,raw.ravel(),rcond=None)[0];level=raw-(design@coef).reshape(X.shape)
    sq=lambda a:float(np.sqrt(np.mean((a-a.mean())**2)))
    fig,axes=plt.subplots(2,2,figsize=(11,8),layout='constrained');ax=axes[0,0];ax.fill_between(x,truth,color=gray,alpha=.3,label=tr('真实台阶','True step'))
    for radius,color in [(5,green),(20,red),(60,blue)]:ax.plot(x,broadening(x,radius),color=color,lw=2,label=f'R={radius} nm')
    ax.set(xlabel='x / nm',ylabel=tr('高度 / nm','Height / nm'),title=tr('A  更钝的针尖使横向轮廓更宽','A  Blunter probes broaden lateral outlines'));ax.legend(frameon=False,fontsize=9)
    for ax,a,title in [(axes[0,1],raw,tr('B  原始高度：表面加倾斜','B  Raw height: surface plus tilt')),(axes[1,0],level,tr('C  减去拟合平面','C  Subtract a fitted plane'))]:
        im=ax.imshow(a,extent=(-250,250,-250,250),origin='lower',cmap='cividis');ax.set(xlabel='x / nm',ylabel='y / nm',title=title);cb=fig.colorbar(im,ax=ax,shrink=.8);cb.set_label(tr('高度 / nm','Height / nm'))
    axes[1,1].plot(grid,raw[64],color=red,label=tr('原始剖面','Raw profile'));axes[1,1].plot(grid,level[64],color=green,label=tr('调平后剖面','Levelled profile'));axes[1,1].set(xlabel='x / nm',ylabel=tr('高度 / nm','Height / nm'),title=tr('D  倾斜改变粗糙度统计','D  Tilt changes roughness statistics'));axes[1,1].legend(frameon=False);axes[1,1].text(.04,.06,f'Sq: {sq(raw):.3f} → {sq(level):.3f} nm',transform=axes[1,1].transAxes)
    save(fig,'topography')
    delta_nm=np.linspace(2,100,100);delta=delta_nm*1e-9;E=20e3;R=1e-6;nu=.45;clean=hertz(delta,E,R,nu);rng=np.random.default_rng(1705);observed=clean+rng.normal(0,8e-12,len(delta));basis=hertz(delta,1,R,nu);Efit=np.dot(basis,observed)/np.dot(basis,basis);fit=basis*Efit
    fig,axes=plt.subplots(1,3,figsize=(13,4.5),layout='constrained')
    axes[0].scatter(delta_nm,observed*1e9,s=12,color=gray,label=tr('构造观测数据','Constructed observations'));axes[0].plot(delta_nm,fit*1e9,color=green,lw=2,label=tr('赫兹拟合','Hertz fit'));axes[0].set(xlabel=tr('压入深度 / nm','Indentation / nm'),ylabel=tr('力 / nN','Force / nN'),title=tr('A  球形探针弹性接触','A  Spherical elastic contact'));axes[0].legend(frameon=False,fontsize=9)
    axes[1].plot(delta_nm,(observed-fit)*1e12,color=blue);axes[1].axhline(0,color=gray);axes[1].set(xlabel=tr('压入深度 / nm','Indentation / nm'),ylabel=tr('残差 / pN','Residual / pN'),title=tr('B  检查拟合剩余结构','B  Inspect remaining structure'))
    assumed=np.linspace(.5,2,100);estimates=Efit*np.sqrt(1/assumed);axes[2].plot(assumed,estimates/1000,color=red,lw=2);axes[2].axvline(1,color=gray,ls='--');axes[2].set(xlabel=tr('假定探针半径 / μm','Assumed probe radius / μm'),ylabel=tr('拟合模量 / kPa','Fitted modulus / kPa'),title=tr('C  半径标定影响模量','C  Radius calibration changes modulus'))
    save(fig,'force')
    with (output/'data.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['indentation_nm','true_force_nN','constructed_observation_nN','fitted_force_nN','residual_pN']);w.writerows(zip(delta_nm,clean*1e9,observed*1e9,fit*1e9,(observed-fit)*1e12))
    np.savez_compressed(output/'topography.npz',x_nm=grid,raw_nm=raw,levelled_nm=level,true_nm=surface)
    exact=np.dot(basis,clean)/np.dot(basis,basis)
    summary={'force_02Npm_5nm_nN':1.,'width_halfheight_R20_H10_W20_nm':20+2*np.sqrt(20*10),'sq_raw_nm':sq(raw),'sq_levelled_nm':sq(level),'sq_true_nm':sq(surface),'hertz_force_50nm_nN':float(hertz(50e-9,E,R,nu)*1e9),'fitted_E_kPa':float(Efit/1000),'noiseless_E_kPa':float(exact/1000),'plane_slope_x':float(coef[0]),'plane_slope_y':float(coef[1]),'data_origin':'Constructed AFM geometry, surface and indentation teaching data.'}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
