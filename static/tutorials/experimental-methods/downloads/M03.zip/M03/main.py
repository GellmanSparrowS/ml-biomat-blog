"""Fracture analysis: elastic DCB compliance and a separate pure-shear gel model.
All records are constructed with specified mechanics and a fixed random seed.
python main.py --output results --language en
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Polygon,Ellipse

E=70000.;B=20.;h=2.;a0=30.;Gc=.3
def compliance(a):return 8*np.asarray(a)**3/(E*B*h**3)
def release(P,a):return 12*np.asarray(P)**2*np.asarray(a)**2/(E*B**2*h**3)
def force_critical(a):return np.sqrt(Gc*E*B**2*h**3/(12*np.asarray(a)**2))
def gel_stress(lam,mu=10.):return mu*(np.asarray(lam,dtype=float)-np.asarray(lam,dtype=float)**-3)
def gel_energy(lam,mu=10.):return .5*mu*(np.asarray(lam,dtype=float)**2+np.asarray(lam,dtype=float)**-2-2)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);p.add_argument('--language',choices=['zh','en'],default='en');v=p.parse_args();o=v.output;o.mkdir(parents=True,exist_ok=True);tr=lambda z,e:z if v.language=='zh' else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#fbfcfc','savefig.facecolor':'#fbfcfc','text.color':'#18344a'})
    blue='#186c94';green='#188777';orange='#d27839';purple='#8a5d92'
    def save(f,n):f.savefig(o/f'{n}-{v.language}.svg',bbox_inches='tight');f.savefig(o/f'{n}-{v.language}.png',bbox_inches='tight',dpi=150);plt.close(f)
    rng=np.random.default_rng(1903);acal=np.linspace(25,65,9);Csys=.003;Cobs=(compliance(acal)+Csys)*(1+rng.normal(0,.007,len(acal)));kfit,cfit=np.linalg.lstsq(np.c_[acal**3,np.ones_like(acal)],Cobs,rcond=None)[0]
    d0=float(force_critical(a0)*compliance(a0));delta=np.linspace(.05,8,400);crack=np.maximum(a0,(3*E*h**3*delta**2/(16*Gc))**.25);force=delta/compliance(crack);stage=delta+Csys*force
    Pobs=force+rng.normal(0,.15,len(force));dobs=delta+rng.normal(0,.003,len(delta));aobs=crack+rng.normal(0,.12,len(crack));Gobs=Pobs**2/(2*B)*3*kfit*aobs**2*1000;Gexact=release(force,crack)*1000
    post=delta>=d0;Gmean=float(np.mean(Gobs[post]));naive=3*force*stage/(2*B*crack)*1000
    lam=np.linspace(1,2.5,601);sig=gel_stress(lam);critical=lam<=2;Wnum=float(np.trapezoid(sig[critical],lam[critical]));Ggel=Wnum*10
    summary={'analytic_C30_mm_N':float(compliance(30)),'analytic_Pinit_N':float(force_critical(30)),'analytic_delta_init_mm':d0,'specified_Gc_J_m2':300.,'fitted_compliance_cubic_mm_m2N':float(kfit),'fitted_system_compliance_mm_N':float(cfit),'mean_propagation_G_J_m2':Gmean,'naive_G_at_initiation_J_m2':float(3*force_critical(a0)*(d0+Csys*force_critical(a0))/(2*B*a0)*1000),'gel_energy_density_at_lambda2_kPa':float(gel_energy(2)),'gel_G_exact_J_m2':112.5,'gel_G_numeric_J_m2':Ggel,'critical_stress_a1mm_MPa':float(np.sqrt(500*3e9/(np.pi*.001))/1e6),'critical_stress_a4mm_MPa':float(np.sqrt(500*3e9/(np.pi*.004))/1e6)}
    (o/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');np.savetxt(o/'data.csv',np.c_[delta,stage,Pobs,dobs,aobs,Gobs,Gexact,naive],delimiter=',',header='specimen_opening_mm,stage_travel_mm,observed_load_N,observed_opening_mm,observed_crack_mm,estimated_G_J_m2,exact_G_J_m2,uncorrected_stage_G_J_m2',comments='');np.savetxt(o/'compliance.csv',np.c_[acal,Cobs,compliance(acal)+Csys,kfit*acal**3+cfit],delimiter=',',header='crack_mm,observed_total_compliance_mm_N,true_total_compliance_mm_N,fitted_total_compliance_mm_N',comments='');np.savetxt(o/'gel.csv',np.c_[lam,sig,gel_energy(lam),gel_energy(lam)*10],delimiter=',',header='stretch,nominal_stress_kPa,stored_energy_kPa,pure_shear_G_J_m2',comments='')
    f,ax=plt.subplots(1,3,figsize=(13,4.7))
    for x in ax:x.set(xlim=(0,10),ylim=(0,9));x.axis('off')
    ax[0].add_patch(Rectangle((1,2),8,5,facecolor='#d6e8ef',edgecolor=blue,lw=2));ax[0].plot([3,7],[4.5,4.5],color='#233f51',lw=3)
    for xx in [2,5,8]:
        ax[0].annotate('',(xx,8),(xx,7),arrowprops={'arrowstyle':'->','color':orange});ax[0].annotate('',(xx,1),(xx,2),arrowprops={'arrowstyle':'->','color':orange})
    ax[0].text(5,.2,tr('1921  Griffith：裂纹与能量','1921  Griffith: cracks and energy'),ha='center',fontsize=10);ax[0].set_title(tr('a  小缺口改变破坏载荷','a  A flaw changes failure load'),fontsize=12)
    ax[1].add_patch(Rectangle((1,2),8,5,facecolor='#d0e9e2',edgecolor=green,lw=2));ax[1].add_patch(Polygon([(1,4),(5,4.5),(1,5)],facecolor='white'));ax[1].plot([1,5,1],[4,4.5,5],color='#233f51',lw=2);ax[1].text(5,.2,tr('1953  Rivlin–Thomas：撕裂能','1953  Rivlin–Thomas: tearing energy'),ha='center',fontsize=10);ax[1].set_title(tr('b  大变形橡胶也能算能量','b  Energy for large rubber deformation'),fontsize=11)
    for xx in np.linspace(1.5,8.5,6):
        yy=np.linspace(2,7,100);ax[2].plot(xx+.15*np.sin(yy*5),yy,color=green,lw=1.6)
    for yy in [3,4,5,6]:ax[2].plot([1.5,8.5],[yy,yy],color=blue,alpha=.6)
    ax[2].add_patch(Polygon([(1,4),(5,4.5),(1,5)],facecolor='#fbfcfc'));ax[2].plot([1,5,1],[4,4.5,5],color='#233f51',lw=2);ax[2].add_patch(Ellipse((5.7,4.5),3.2,4,facecolor=orange,alpha=.13,edgecolor=orange));ax[2].text(5,.2,tr('网络桥联与周围耗散','Network bridging and surrounding dissipation'),ha='center',fontsize=10);ax[2].set_title(tr('c  裂尖附近不只产生新表面','c  More than new surfaces at a tip'),fontsize=11);f.tight_layout();save(f,'history')
    f,ax=plt.subplots(1,2,figsize=(12,4.8));x=ax[0];x.set(xlim=(0,11),ylim=(-3.5,3.5));x.axis('off');s=np.linspace(0,7,120);bend=(7-s)**2*(14+s)/686
    x.fill_between(s,.15+bend,.7+bend,color=blue,alpha=.3);x.fill_between(s,-.15-bend,-.7-bend,color=blue,alpha=.3);x.add_patch(Rectangle((7,-.7),3,1.4,facecolor='#d0e9e2',edgecolor=green));x.plot([0,7],[.15,-.0],color='#657f8d',ls='--');x.plot([0,7],[-.15,0],color='#657f8d',ls='--')
    for sign in [-1,1]:
        x.annotate('',(0,sign*3),(0,sign*1.7),arrowprops={'arrowstyle':'->','color':orange});x.text(.2,sign*2.5,'P',color=orange)
    x.annotate('',(0,-2.5),(7,-2.5),arrowprops={'arrowstyle':'<->','color':'#18344a'});x.text(3.5,-2.9,'a',ha='center');x.annotate('',(.5,1.15),(.5,-1.15),arrowprops={'arrowstyle':'<->'});x.text(.8,0,'δ',va='center');x.text(8.5,1.4,tr('每臂厚 h；出平面宽 B','Arm thickness h; out-of-plane width B'),ha='center',fontsize=9);x.set_title(tr('a  双悬臂梁：P 是每一侧的力','a  DCB: P is the force on each arm'),fontsize=12)
    xx=np.linspace(0,d0,100);yy=xx/compliance(a0);ax[1].fill_between(xx,0,yy,color=blue,alpha=.2);ax[1].plot(xx,yy,color=blue);ax[1].text(.45,12,tr('储能 = 三角形面积','Stored energy = triangular area'));ax[1].set(xlabel=tr('相对开口 δ / mm','Relative opening δ / mm'),ylabel=tr('载荷 P / N','Load P / N'),title=tr('b  裂纹不增长时，梁像弹簧','b  Before growth, the beams act as a spring'));f.tight_layout();save(f,'geometry')
    f,ax=plt.subplots(2,2,figsize=(12,8));fine=np.linspace(25,65,150);ax[0,0].scatter(acal,Cobs,color=orange,label=tr('构造观测','Constructed observations'));ax[0,0].plot(fine,kfit*fine**3+cfit,color=blue,label=tr('立方项 + 系统柔度','Cubic term + system compliance'));ax[0,0].set(xlabel=tr('裂纹长度 a / mm','Crack length a / mm'),ylabel=tr('总柔度 / mm/N','Total compliance / mm/N'),title=tr('a  标定裂纹与柔度','a  Calibrate crack length and compliance'));ax[0,0].legend(fontsize=9)
    ax[0,1].plot(delta,Pobs,color=blue,lw=1,label=tr('构造力观测','Constructed force observations'));ax[0,1].axvline(d0,color=orange,ls='--',label=tr('起裂','Initiation'));ax[0,1].set(xlabel=tr('试样开口 / mm','Specimen opening / mm'),ylabel=tr('载荷 / N','Load / N'),title=tr('b  力下降时裂纹仍在增长','b  Crack growth accompanies falling load'));ax[0,1].legend(fontsize=9)
    ax[1,0].plot(delta,aobs,color=green,lw=1);ax[1,0].axvline(d0,color=orange,ls='--');ax[1,0].set(xlabel=tr('试样开口 / mm','Specimen opening / mm'),ylabel=tr('裂纹长度 / mm','Crack length / mm'),title=tr('c  与力同步的裂纹记录','c  Crack record synchronised with load'))
    ax[1,1].scatter(aobs[post]-a0,Gobs[post],s=8,color=blue,alpha=.45,label=tr('柔度导数法','Compliance derivative'));ax[1,1].plot(crack[post]-a0,naive[post],color=orange,label=tr('误用横梁位移','Uncorrected stage travel'));ax[1,1].axhline(300,color=green,ls='--',label=tr('规定阻力','Specified resistance'));ax[1,1].set(xlabel=tr('裂纹增量 / mm','Crack extension / mm'),ylabel='G / J m⁻²',title=tr('d  稳定扩展的能量分析','d  Energy during stable propagation'));ax[1,1].legend(fontsize=9);f.tight_layout();save(f,'analysis')
    f,ax=plt.subplots(1,2,figsize=(12,4.8));aa=np.linspace(20,75,250);Pc=force_critical(a0);Gload=release(Pc,aa)*1000;Gdisp=release(d0/compliance(aa),aa)*1000;ax[0].plot(aa,Gload,color=orange,label=tr('保持起裂载荷','Hold initiation load'));ax[0].plot(aa,Gdisp,color=blue,label=tr('保持起裂开口','Hold initiation opening'));ax[0].axhline(300,color=green,ls='--',label=tr('阻力300 J/m²','Resistance 300 J/m²'));ax[0].scatter([30],[300],color='#18344a');ax[0].set(xlim=(25,60),ylim=(0,1300),xlabel=tr('裂纹长度 / mm','Crack length / mm'),ylabel='G / J m⁻²',title=tr('a  加载控制决定增长趋势','a  Loading control changes the trend'));ax[0].legend(fontsize=9)
    flaw=np.linspace(.1,5,250);sc=np.sqrt(500*3e9/(np.pi*flaw/1000))/1e6;ax[1].plot(flaw,sc,color=purple);ax[1].scatter([1,4],np.sqrt(500*3e9/(np.pi*np.array([.001,.004])))/1e6,color=orange);ax[1].set(xlabel=tr('中心裂纹半长 a / mm','Centre-crack half-length a / mm'),ylabel=tr('临界远场应力 / MPa','Critical remote stress / MPa'),title=tr('b  E=3 GPa，Gc=500 J/m²，Y=1','b  E=3 GPa, Gc=500 J/m², Y=1'));f.tight_layout();save(f,'stability')
    f,ax=plt.subplots(1,2,figsize=(12,4.8));ax[0].plot(lam,sig,color=green);ax[0].fill_between(lam[critical],0,sig[critical],color=green,alpha=.25);ax[0].axvline(2,color=orange,ls='--');ax[0].set(xlabel=tr('伸长比 λ','Stretch λ'),ylabel=tr('名义拉应力 / kPa','Nominal tensile stress / kPa'),title=tr('a  无缺口纯剪切条带的储能','a  Stored energy in an unnotched strip'));ax[0].text(1.12,2,'W(2) = 11.25 kPa')
    ax[1].plot(lam,gel_energy(lam)*10,color=blue);ax[1].axhline(112.5,color=orange,ls='--');ax[1].scatter([2],[112.5],color=orange);ax[1].set(xlabel=tr('缺口试样临界伸长比 λc','Critical stretch of notched strip λc'),ylabel=tr('能量释放率 / J m⁻²','Energy release rate / J m⁻²'),title=tr('b  H₀=10 mm，G=H₀W','b  H₀=10 mm, G=H₀W'));f.tight_layout();save(f,'gel')
    print(json.dumps(summary))
if __name__=='__main__':main()
