# Public sources and third-party materials

- Griffith — The phenomena of rupture and flow in solids (1921): https://doi.org/10.1098/rsta.1921.0006
  Bibliographic history reference; no scanned figure reused.
- Rivlin and Thomas — Rupture of rubber I (1953): https://imechanica.egr.uh.edu/sites/default/files/1953%20Rupture%20of%20rubber%20characteristic%20energy%20for%20tearing.pdf
  Research reading; no figures or data reused.
- Bower — Energy methods in fracture mechanics: https://solidmechanics.org/Text/Chapter9_4/Chapter9_4.php
  Author textbook reference; original calculations and figures here.
- NASA — Mode-I fracture toughness with the nDCB test: https://www.nasa.gov/centers-and-facilities/nesc/mode-i-fracture-toughness-of-complex-materials-with-the-ndcb-test/
  Official technical account; no images reused.
- Macon — J-integral analysis of tapered double-cantilever beams: https://ntrs.nasa.gov/api/citations/20060026038/downloads/20060026038.pdf
  NASA-hosted technical paper; no figures or data reused.
- Sun et al. — Highly stretchable and tough hydrogels (2012): https://www.nature.com/articles/nature11409
  Publisher abstract consulted; no figures or data reused.
