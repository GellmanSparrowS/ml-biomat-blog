"""A constructed CCK-8 plate experiment: matched blanks and independent days.

All assay values are simulated for teaching; no biological measurements are
claimed. Each of three days has its own response, and each condition has three
technical wells. Output includes raw well-level data and day-level summaries.
"""
from pathlib import Path
import argparse,csv,json
import numpy as np
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Rectangle,FancyArrowPatch

BLUE,RED,GOLD,GREY='#12687b','#be6047','#b18a35','#758893'

def response(dose,bottom,top,half,hill):
    return bottom+(top-bottom)/(1+(np.asarray(dose)/half)**hill)

def blank_correct(sample,sample_blank,control,control_blank):
    denominator=np.asarray(control)-np.asarray(control_blank)
    if np.any(denominator<=0):raise ValueError('A positive control signal is required.')
    return 100*(np.asarray(sample)-np.asarray(sample_blank))/denominator

def run(out,lang):
    out.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],
        'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#b8c9cf',
        'svg.fonttype':'none','axes.unicode_minus':False,'savefig.facecolor':'white'})
    t=lambda z,e:z if lang=='zh' else e
    def save(fig,name):fig.savefig(out/f'{name}-{lang}.svg',bbox_inches='tight');plt.close(fig)
    def arrow(ax,start,end):ax.add_patch(FancyArrowPatch(start,end,arrowstyle='->',mutation_scale=16,lw=2,color=BLUE))
    rng=np.random.default_rng(83)
    doses=np.array([0,.5,1,2,5,10,20,50.])
    records=[];day_ratios=[];naive_ratios=[];means_by_day=[]
    for day in range(3):
        top_signal=.8*(1+.06*(day-1));half=8*(1+.12*(day-1))
        expected=response(doses,15,100,half,1.4)/100
        blank=.04+.0025*doses
        sample=top_signal*expected[:,None]+blank[:,None]+rng.normal(0,.012,(8,3))
        acellular=blank[:,None]+rng.normal(0,.004,(8,3))
        sample_mean=sample.mean(axis=1);blank_mean=acellular.mean(axis=1)
        ratios=blank_correct(sample_mean,blank_mean,sample_mean[0],blank_mean[0])
        naive=100*(sample_mean-blank_mean[0])/(sample_mean[0]-blank_mean[0])
        day_ratios.append(ratios);naive_ratios.append(naive);means_by_day.append((sample_mean,blank_mean))
        positions=rng.choice(96,size=48,replace=False);cursor=0
        for i,dose in enumerate(doses):
            for kind,array in [('cells',sample),('matched_blank',acellular)]:
                for rep in range(3):
                    pos=int(positions[cursor]);cursor+=1
                    records.append({'day':day+1,'well':chr(65+pos//12)+str(pos%12+1),
                        'row':pos//12,'column':pos%12,'dose_ug_ml':dose,'kind':kind,
                        'technical_replicate':rep+1,'absorbance':float(array[i,rep])})
    ratios=np.array(day_ratios);naive=np.array(naive_ratios)
    mean=ratios.mean(axis=0);sd=ratios.std(axis=0,ddof=1)
    parameters,covariance=curve_fit(response,doses,mean,p0=[15,100,8,1.4],
        bounds=([0,90,.01,.2],[50,110,100,4]),maxfev=10000)
    bottom,top,half,hill=parameters
    absolute_50=half*((top-50)/(50-bottom))**(1/hill) if bottom<50<top else None
    dense=np.geomspace(.2,80,300)

    fig,axs=plt.subplots(1,2,figsize=(12.7,5.4),layout='constrained')
    for ax in axs:ax.set(xlim=(0,10),ylim=(0,7));ax.axis('off')
    ax=axs[0];ax.set_title(t('A  MTT：1983年的微孔板比色思路','A  MTT: a microplate color assay in 1983'),loc='left',pad=20)
    ax.add_patch(Circle((2,4.5),1.1,fc='#d9e9e3',ec=BLUE,lw=2));ax.text(2,4.5,t('细胞内\n还原过程','Cellular\nreduction'),ha='center',va='center')
    arrow(ax,(3.2,4.5),(4.7,4.5));ax.text(3.8,5,t('MTT','MTT'),ha='center')
    for x,y in [(5.4,4.6),(5.9,4.2),(6.3,4.7),(5.4,4.0)]:ax.plot(x,y,marker='D',ms=14,color='#765080')
    ax.text(5.9,3.1,t('不溶性甲臜结晶','Insoluble formazan crystals'),ha='center',fontsize=10)
    arrow(ax,(6.8,4.5),(8.3,4.5));ax.add_patch(Rectangle((8.4,3.5),1,2,fc='#baa1c7',ec=GREY));ax.text(8.9,2.7,t('溶解后读数','Dissolve, then read'),ha='center',fontsize=10)
    ax.text(.4,.9,t('把大量平行样品放进一块板里比较\n颜色产生的速度仍与细胞状态有关','Compare many parallel specimens in one plate\nColor production still depends on cellular state'),fontsize=11)
    ax=axs[1];ax.set_title(t('B  WST-8：把产物留在溶液里','B  WST-8: keep the product in solution'),loc='left',pad=20)
    ax.add_patch(Circle((2,4.5),1.1,fc='#d9e9e3',ec=BLUE,lw=2));ax.text(2,4.5,t('细胞还原力','Cellular\nreducing power'),ha='center',va='center')
    arrow(ax,(3.2,4.5),(4.5,4.5));ax.text(4.8,5.4,t('电子介体','Electron mediator'),ha='center',fontsize=10)
    ax.add_patch(Circle((5,4.5),.42,fc=GOLD));arrow(ax,(5.6,4.5),(7.2,4.5))
    ax.add_patch(Rectangle((7.3,3.5),1.5,2,fc='#e8b66c',ec=GREY));ax.text(8,2.7,t('可溶性甲臜','Soluble formazan'),ha='center',fontsize=10)
    ax.text(.4,.9,t('CCK-8通常在450 nm读取\n示意图关注测量链，不表示反应位置的全部细节','CCK-8 is commonly read at 450 nm\nA measurement-chain diagram, not every reaction site'),fontsize=11)
    save(fig,'history-chemistry')

    fig,axs=plt.subplots(1,2,figsize=(12.7,5.8),layout='constrained')
    plate=np.full((8,12),np.nan);kinds={}
    for rec in records:
        if rec['day']==1:plate[rec['row'],rec['column']]=rec['absorbance'];kinds[(rec['row'],rec['column'])]=rec['kind']
    cmap=plt.colormaps['YlOrBr'].copy();cmap.set_bad('#edf1f3')
    im=axs[0].imshow(plate,cmap=cmap,vmin=0,vmax=.9,aspect='equal')
    for (r,c),kind in kinds.items():
        if kind=='matched_blank':axs[0].plot(c,r,marker='o',ms=4,mfc='none',mec=BLUE)
    axs[0].set(xticks=np.arange(12),xticklabels=np.arange(1,13),yticks=np.arange(8),yticklabels=list('ABCDEFGH'),title=t('A  第一次实验的48个随机排布读数','A  Forty-eight randomized wells on day 1'))
    fig.colorbar(im,ax=axs[0],shrink=.7,label=t('吸光度','Absorbance'))
    axs[0].text(.5,-.16,t('圆圈：无细胞匹配空白；灰格：未使用','Circles: matched cell-free blanks; grey: unused'),ha='center',transform=axs[0].transAxes,fontsize=10)
    ax=axs[1]
    a,b=means_by_day[0]
    ax.plot(doses,a,'o-',color=RED,label=t('细胞 + 材料 + 试剂','Cells + material + reagent'))
    ax.plot(doses,b,'o-',color=GOLD,label=t('材料 + 试剂，无细胞','Material + reagent, no cells'))
    ax.plot(doses,a-b,'o-',color=BLUE,label=t('相减后的细胞相关信号','Cell-associated difference'))
    ax.set(xlabel=t('材料浓度 / μg·mL$^{-1}$','Material concentration / μg/mL'),ylabel=t('吸光度','Absorbance'),title=t('B  匹配空白随材料浓度改变','B  Matched blanks change with material dose'));ax.legend(fontsize=9);ax.grid(alpha=.13)
    save(fig,'plate-controls')

    fig,axs=plt.subplots(2,2,figsize=(12.7,8.1),layout='constrained')
    ax=axs[0,0];n=np.linspace(0,20000,200)
    for time,col in [(1,BLUE),(2,RED),(4,GOLD)]:
        signal=1.5*(1-np.exp(-.00004*n*time/1.5))
        ax.plot(n,signal,color=col,label=f'{time} h')
    ax.set(xlabel=t('每孔细胞数','Cells per well'),ylabel=t('构造的校正吸光度','Constructed corrected absorbance'),title=t('A  铺板数量与孵育时间共同影响响应','A  Cell number and incubation time act together'));ax.legend()
    ax=axs[0,1];xx=np.linspace(0,4,200)
    ax.plot(xx,.2*xx,color=BLUE,label=t('数量×单细胞活性：1×1','Number × per-cell activity: 1 × 1'))
    ax.plot(xx,.2*xx,color=RED,ls='--',lw=3,label=t('数量×单细胞活性：0.5×2','Number × per-cell activity: 0.5 × 2'))
    ax.set(xlabel=t('显色时间 / h','Color-development time / h'),ylabel=t('理想线性吸光度','Ideal linear absorbance'),title=t('B  不同细胞数量可能给出相同信号','B  Different cell counts can give the same signal'));ax.legend(fontsize=9)
    ax=axs[1,0]
    for day,col in enumerate([BLUE,RED,GOLD]):ax.plot(doses,ratios[day],'.-',color=col,alpha=.9,label=t(f'独立实验 {day+1}',f'Independent day {day+1}'))
    ax.plot(doses,naive.mean(0),'s--',color=GREY,label=t('只减共同空白','Common blank only'))
    ax.set(xlabel=t('浓度 / μg·mL$^{-1}$','Concentration / μg/mL'),ylabel=t('相对代谢响应 / %','Relative metabolic response / %'),title=t('C  每次实验先校正，再比较重复','C  Correct each day before comparing repeats'));ax.legend(fontsize=9)
    ax=axs[1,1]
    ax.errorbar(doses[1:],mean[1:],yerr=sd[1:],fmt='o',color=BLUE,capsize=4,label=t('日均值 ± 日间SD，n=3','Day means ± between-day SD, n=3'))
    ax.plot(dense,response(dense,*parameters),color=BLUE,lw=2)
    midpoint=(top+bottom)/2
    ax.axhline(midpoint,color=GOLD,ls=':',label=t('拟合动态范围的中点','Halfway through fitted dynamic range'))
    ax.axhline(50,color=RED,ls='--',label=t('对照信号的50%','50% of control signal'))
    ax.set(xscale='log',xlabel=t('浓度 / μg·mL$^{-1}$（对数轴）','Concentration / μg/mL (log axis)'),ylabel=t('相对代谢响应 / %','Relative metabolic response / %'),title=t('D  两种“50%”对应不同浓度','D  Two meanings of “50%” give different concentrations'));ax.legend(fontsize=8)
    save(fig,'response-diagnostics')

    with (out/'well-data.csv').open('w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    np.savetxt(out/'day-summary.csv',np.c_[doses,ratios.T,mean,sd,naive.mean(0)],delimiter=',',
        header='dose_ug_ml,day1_percent,day2_percent,day3_percent,mean_percent,between_day_sd,common_blank_only_percent',comments='')
    summary={'origin':'Constructed teaching data, seed 83; 3 independent days × 8 doses × 2 well types × 3 technical wells',
        'well_count':len(records),'independent_days':3,'technical_wells_per_condition':3,
        'worked_example_corrected_percent':float(blank_correct(.54,.14,.84,.04)),
        'worked_example_common_blank_percent':100*(.54-.04)/(.84-.04),
        'corrected_high_dose_percent':float(mean[-1]),'common_blank_high_dose_percent':float(naive.mean(0)[-1]),
        'fitted':{'bottom_percent':float(bottom),'top_percent':float(top),'half_dynamic_range_ug_ml':float(half),'hill':float(hill),'absolute_50_control_ug_ml':float(absolute_50)},
        'known_true_half_dynamic_range_ug_ml':8.0,'control_percent_each_day':ratios[:,0].tolist()}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    assert len(records)==144 and np.allclose(ratios[:,0],100)
    assert np.isclose(summary['worked_example_corrected_percent'],50,atol=1e-12)
    assert 6<half<10 and absolute_50>half
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();run(a.output,a.language)
