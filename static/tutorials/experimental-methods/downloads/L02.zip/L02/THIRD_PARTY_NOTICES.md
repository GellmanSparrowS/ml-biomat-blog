# Public sources and third-party materials

- Mosmann (1983): Rapid colorimetric assay for cellular growth and survival: https://pubmed.ncbi.nlm.nih.gov/6606682/
  Technical reference; figures and teaching datasets are original.
- Assay Guidance Manual: Cell Viability Assays: https://www.ncbi.nlm.nih.gov/sites/books/NBK144065/?report=classic
  Technical reference; figures and teaching datasets are original.
- Dojindo: Cell Counting Kit-8 product manual: https://www.dojindo.com/manual/CK04/
  Technical reference; figures and teaching datasets are original.
- Dojindo: Measuring Cell Viability / Cytotoxicity: https://www.dojindo.com/products/pdf/Protocol/Cell_Counting_Kit-8.pdf
  Technical reference; figures and teaching datasets are original.
- GraphPad: Relative versus absolute IC50: https://www.graphpad.com/guides/prism/latest/curve-fitting/reg_50_of_what__relative_vs_absolu.htm
  Technical reference; figures and teaching datasets are original.
- SciPy: curve_fit: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.curve_fit.html
  Technical reference; figures and teaching datasets are original.
- Cell Viability Assays for 3D Cellular Constructs: https://pubmed.ncbi.nlm.nih.gov/37142936/
  Technical reference; figures and teaching datasets are original.
- Huyck et al. (2012): XTT measurements in three-dimensional matrices: https://pmc.ncbi.nlm.nih.gov/articles/PMC3419859/
  Technical reference; no figure reproduced.
