"""SEC/GPC: porous exclusion, calibration, mass weighting and real NBS data.

Run: python main.py --output results --language en
Dependencies: numpy, scipy, matplotlib. Only bundled data are read.
All chromatograms are constructed teaching models. The cumulative SRM curve
is a transcription of the published NBS 1972 table, identified in data/README.md.
"""
from pathlib import Path
import argparse, csv, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, FancyArrowPatch

P=argparse.ArgumentParser();P.add_argument('--output',type=Path,required=True);P.add_argument('--language',choices=['zh','en'],default='en');args=P.parse_args()
O=args.output;O.mkdir(parents=True,exist_ok=True);L=args.language
def t(z,e):return z if L=='zh' else e
plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#25364a','text.color':'#25364a','axes.titleweight':'bold','figure.facecolor':'#fcfbf7','axes.facecolor':'#fcfbf7','svg.fonttype':'none','savefig.facecolor':'#fcfbf7'})
blue='#167d9a';red='#d35f47';gold='#c49b35';dark='#25364a';green='#37967d'
def save(fig,n):
    fig.savefig(O/f'{n}-{L}.svg',bbox_inches='tight');fig.savefig(O/f'{n}-{L}.png',dpi=145,bbox_inches='tight');plt.close(fig)
def gauss(x,m,s):return np.exp(-.5*((x-m)/s)**2)/(s*np.sqrt(2*np.pi))
def csvsave(n,h,a):np.savetxt(O/n,a,delimiter=',',header=','.join(h),comments='',fmt='%.10g')

# Original mechanism drawing. Side pores hold solvent; macromolecules exchange
# with accessible pore volume. They are not forced through a sieve membrane.
fig,axs=plt.subplots(1,3,figsize=(14.4,4.5),gridspec_kw={'width_ratios':[1.1,1,1]},layout='constrained')
ax=axs[0];ax.set(xlim=(0,10),ylim=(0,8));ax.axis('off')
ax.add_patch(Rectangle((.4,1),9.1,5.5,facecolor='#e8f0f0',edgecolor='#9aafaf',lw=1.5))
for x,y in [(2,2.4),(5,5),(8,2.4)]:
    ax.add_patch(Circle((x,y),1.1,facecolor='#d6dfd9',edgecolor='#829a8b'))
    for dx,dy in [(-.3,.3),(.35,.1),(0,-.4)]:ax.add_patch(Circle((x+dx,y+dy),.20,facecolor='#fcfbf7',edgecolor='#b4c5bb'))
ax.plot([.5,2,3.3,4,6,7.2,9.3],[4,4,4,3.3,3.3,4.6,4.6],color=red,lw=3)
ax.scatter([.7,9],[4,4.6],s=120,color=red,zorder=5)
ax.plot([.5,2,2,3.4,5,5,6.4,8,8,9.3],[3.4,3.4,2.3,3.4,3.4,4.7,3.6,3.6,2.3,3.6],color=blue,lw=1.8,ls='--')
ax.scatter([.7,9],[3.4,3.55],s=20,color=blue,zorder=5)
ax.text(.5,7.25,t('A  多孔填料中的两种可达空间','A  Two accessible solvent spaces'),weight='bold')
ax.text(.55,.35,t('大分子：孔外较多  /  小分子：也进入孔内','Large: mostly outside  /  Small: also inside'),fontsize=10)
v=np.linspace(0,22,1000);ax=axs[1]
ax.plot(v,gauss(v,8,.6),color=red,label=t('大分子','Macromolecule'));ax.plot(v,gauss(v,16,.8),color=blue,label=t('小分子盐','Small solute / salt'))
ax.axvspan(6,10,color=red,alpha=.09);ax.set(xlabel=t('洗脱体积 / mL','Elution volume / mL'),ylabel=t('归一化检测信号 / mL⁻¹','Normalized signal / mL⁻¹'),title=t('B  脱盐：先收集大分子','B  Desalting: collect the first band'));ax.legend(frameon=False,fontsize=9)
ax=axs[2];vol=np.linspace(3,18,100);ax.plot(vol,(vol-3)/15,color=green,lw=2.5)
ax.scatter([3,9,18],[0,.4,1],color=[red,gold,blue],zorder=5);ax.set(xlabel=t('洗脱体积 / mL','Elution volume / mL'),ylabel=t('孔体积可达比例 Kav','Accessible fraction Kav'),ylim=(-.06,1.1),title=t('C  在两个参照体积之间','C  Between two reference volumes'))
ax.annotate(t('完全排阻','Excluded'),(3,0),(5,.07),arrowprops={'arrowstyle':'-','color':dark},fontsize=9);ax.annotate(t('完全进入','Fully included'),(18,1),(12,.82),arrowprops={'arrowstyle':'-','color':dark},fontsize=9)
save(fig,'pores')

# Constructed narrow-standard calibration and lognormal molecular population.
a,b=7.,.25;standards=np.array([1e3,3e3,1e4,3e4,1e5,3e5,1e6]);ve=(a-np.log10(standards))/b
mu,s=4.2,.35;ln10=np.log(10);mass_mu=mu+ln10*s*s
V=np.linspace(2,20,6001);M=10**(a-b*V);ideal=gauss(V,(a-mass_mu)/b,s/b)
def moments(signal):
    area=np.trapezoid(signal,V)
    return float(area/np.trapezoid(signal/M,V)),float(np.trapezoid(signal*M,V)/area)
Mn=10**mu*np.exp(.5*(ln10*s)**2);Mw=10**mu*np.exp(1.5*(ln10*s)**2);disp=Mw/Mn
sig=.25;observed=gauss(V,(a-mass_mu)/b,np.sqrt((s/b)**2+sig**2));mn_obs,mw_obs=moments(observed)
fig,axs=plt.subplots(2,2,figsize=(12.8,8),layout='constrained')
ax=axs[0,0];ax.plot(ve,standards,'o-',color=blue);ax.set_yscale('log');ax.set(xlabel=t('标准样峰位 / mL','Standard peak volume / mL'),ylabel=t('摩尔质量 / (g/mol)','Molar mass / (g/mol)'),title=t('A  先校准位置','A  Calibrate position first'));ax.text(.04,.1,'log₁₀ M = 7 − 0.25 V',transform=ax.transAxes)
ax=axs[0,1];ax.plot(V,observed,color=blue);ax.fill_between(V,observed,where=(V>10)&(V<11),color=gold,alpha=.5);ax.set(xlim=(4,17),xlabel=t('洗脱体积 / mL','Elution volume / mL'),ylabel=t('质量响应 / mL⁻¹','Mass response / mL⁻¹'),title=t('B  面积切片包含质量','B  Each slice contains mass'))
x=np.linspace(2.5,6.5,1000);ax=axs[1,0];ax.plot(x,gauss(x,mu,s),color=green,label=t('按链数归一化','Number density'));ax.plot(x,gauss(x,mass_mu,s),color=red,label=t('按质量归一化','Mass density'));ax.set(xlabel=t('log₁₀ [M / (g/mol)]','log₁₀ [M / (g/mol)]'),ylabel=t('每单位 log₁₀ M 的概率密度','Density per unit log₁₀ M'),title=t('C  同一群链，两种加权','C  Same chains, two weightings'));ax.legend(frameon=False)
ax=axs[1,1];ax.plot(V,np.cumsum(observed)/np.sum(observed)*100,color=blue);ax.set(xlim=(4,17),xlabel=t('洗脱体积 / mL','Elution volume / mL'),ylabel=t('已流出质量 / %','Eluted mass / %'),title=t('D  先流出的是大分子','D  Larger molecules elute first'));ax.text(.03,.84,t('此累计方向：大 → 小','This cumulative direction: large → small'),transform=ax.transAxes)
save(fig,'calibration')
csvsave('calibration.csv',['elution_volume_mL','molar_mass_g_per_mol'],np.c_[ve,standards])
csvsave('constructed_chromatogram.csv',['elution_volume_mL','assigned_molar_mass_g_per_mol','ideal_mass_response_per_mL','broadened_mass_response_per_mL'],np.c_[V,M,ideal,observed])

raw=np.genfromtxt(Path(__file__).parent/'data/srm1475_table4.csv',delimiter=',',names=True)
logm=raw['log10_molar_mass_g_per_mol'];cdf=raw['cumulative_mass_percent'];median=10**np.interp(50,cdf,logm)
assert np.all(np.diff(logm)>0) and np.all(np.diff(cdf)>=0) and cdf[0]==0 and cdf[-1]==100
fig,axs=plt.subplots(1,2,figsize=(12.8,4.9),layout='constrained')
ax=axs[0];ax.semilogx(10**logm,cdf,'o-',color=blue,ms=3);ax.axhline(50,color=gold,ls='--',lw=1);ax.axvline(median,color=gold,ls='--',lw=1)
ax.set(xlabel=t('摩尔质量 / (g/mol)','Molar mass / (g/mol)'),ylabel=t('低于横坐标的累计质量 / %','Cumulative mass below M / %'),title=t('A  真实公开数据：聚乙烯 SRM 1475','A  Published data: polyethylene SRM 1475'),ylim=(-2,103))
ax.text(.05,.68,t('1972 年 NBS，表 4\n按质量的中位数 ≈ ','NBS 1972, Table 4\nMass median ≈ ')+f'{median:,.0f} g/mol',transform=ax.transAxes,fontsize=10)
ax=axs[1];xx=np.arange(2);nw=np.array([.9,.1]);ww=np.array([.9*1e4,.1*1e5]);ww/=ww.sum()
ax.bar(xx-.18,nw*100,.34,color=green,label=t('链数占比','Number fraction'));ax.bar(xx+.18,ww*100,.34,color=red,label=t('质量占比','Mass fraction'))
ax.set_xticks(xx,['10,000 g/mol','100,000 g/mol']);ax.set(ylim=(0,110),ylabel=t('占比 / %','Fraction / %'),title=t('B  构造例：90 条短链与 10 条长链','B  Constructed: 90 short and 10 long chains'));ax.legend(frameon=False,ncol=2,loc='upper right',fontsize=9)
for p in ax.patches:ax.text(p.get_x()+p.get_width()/2,p.get_height()+2,f'{p.get_height():.1f}',ha='center',fontsize=10)
save(fig,'mass-distribution')

widths=np.linspace(0,1.2,61);factor=np.exp((ln10*b*widths)**2);rows=[]
fig,axs=plt.subplots(2,2,figsize=(12.8,8),layout='constrained')
ax=axs[0,0]
for w,c in zip([0,.6,1.2],[blue,gold,red]):
    y=gauss(V,(a-mass_mu)/b,np.sqrt((s/b)**2+w*w));ax.plot(V,y,color=c,label=f'σV = {w:.1f} mL')
ax.set(xlim=(4,17),xlabel=t('洗脱体积 / mL','Elution volume / mL'),ylabel=t('质量响应 / mL⁻¹','Mass response / mL⁻¹'),title=t('A  仪器把同一分布展宽','A  Instrument broadening'));ax.legend(frameon=False,fontsize=9)
ax=axs[0,1];ax.plot(widths,disp*factor,color=red);ax.axhline(disp,color=green,ls='--',label=t('真实分散系数','True dispersity'));ax.set(xlabel=t('额外展宽 σV / mL','Extra broadening σV / mL'),ylabel=t('表观分散系数','Apparent dispersity'),title=t('B  展宽被误读为链长差异','B  Width becomes apparent heterogeneity'));ax.legend(frameon=False)
shifts=np.linspace(0,1.2,100);ax=axs[1,0];ax.plot(shifts,100*10**(-b*shifts),color=blue);ax.set(xlabel=t('向后移动的峰位 / mL','Later elution shift / mL'),ylabel=t('表观质量 / 真值 × 100%','Apparent / true mass × 100%'),title=t('C  同一质量，构象变紧凑','C  Same mass, more compact conformation'),ylim=(45,105))
ax=axs[1,1];cuts=np.linspace(12,18,70);mns=[];mws=[]
for cut in cuts:
    keep=V<=cut;ar=np.trapezoid(ideal[keep],V[keep]);mns.append(ar/np.trapezoid((ideal/M)[keep],V[keep]));mws.append(np.trapezoid((ideal*M)[keep],V[keep])/ar)
ax.plot(cuts,np.array(mns)/Mn,color=green,label='Mn');ax.plot(cuts,np.array(mws)/Mw,color=red,label='Mw');ax.axhline(1,color=dark,lw=.8,ls='--');ax.set(xlabel=t('积分终点 / mL','Integration endpoint / mL'),ylabel=t('截取值 / 完整值','Truncated / full value'),title=t('D  删掉小分子尾部的代价','D  Cost of deleting the low-mass tail'));ax.legend(frameon=False)
save(fig,'diagnostics')
csvsave('broadening.csv',['extra_sigma_mL','apparent_dispersity_analytic'],np.c_[widths,disp*factor])
csvsave('integration_sensitivity.csv',['integration_endpoint_mL','Mn_g_per_mol','Mw_g_per_mol'],np.c_[cuts,mns,mws])
toy_mn=.9*1e4+.1*1e5;toy_mw=(.9*1e8+.1*1e10)/toy_mn
summary={'Kav_example':.4,'toy_Mn_g_per_mol':toy_mn,'toy_Mw_g_per_mol':toy_mw,'toy_dispersity':toy_mw/toy_mn,'lognormal_true_Mn':float(Mn),'lognormal_true_Mw':float(Mw),'lognormal_true_dispersity':float(disp),'broadened_Mn':mn_obs,'broadened_Mw':mw_obs,'broadened_dispersity':mw_obs/mn_obs,'NBS_table_rows':len(raw),'NBS_mass_median_log_interpolation_g_per_mol':float(median),'NBS_reported_Mn_g_per_mol':17900,'NBS_reported_Mw_g_per_mol':52900,'NBS_reported_dispersity':52900/17900,'half_mL_shift_mass_ratio':10**(-.25*.5)}
assert abs(toy_mn-19000)<1e-8 and abs(toy_mw-57368.42105263158)<1e-7
assert abs(mn_obs/(Mn*np.exp(-.5*(ln10*b*sig)**2))-1)<1e-5
assert abs(mw_obs/(Mw*np.exp(.5*(ln10*b*sig)**2))-1)<1e-5
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
