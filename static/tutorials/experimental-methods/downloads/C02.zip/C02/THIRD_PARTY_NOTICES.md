# Public sources and third-party materials

- Waters: Calibration of the GPC system: https://www.waters.com/nextgen/us/en/education/primers/beginners-guide-to-size-exclusion-chromatography/calibration-of-the-gpc-system1.html
  Technical/historical reference only; no source artwork reproduced.
- Cytiva: Size exclusion chromatography selection guide: https://cdn.cytivalifesciences.com/api/public/content/digi-13947-pdf
  Technical/historical reference only; no source artwork reproduced.
- Porath: Citation Classic retrospective on gel filtration: https://garfield.library.upenn.edu/classics1981/A1981LM54000002.pdf
  Technical/historical reference only; no source artwork reproduced.
- NIST author manuscript: Size-exclusion chromatography: https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=933552
  Technical/historical reference only; no source artwork reproduced.
- Malvern Panalytical: An introduction to SEC/GPC: https://www.malvernpanalytical.com/en/learn/knowledge-center/whitepapers/wp150625introtosecgpc
  Technical/historical reference only; no source artwork reproduced.
- Ross and Frolen (1972): Polyethylene SRM 1475, gel permeation chromatography: https://nvlpubs.nist.gov/nistpubs/jres/76A/jresv76An2p163_A1b.pdf
  NBS government-authored numerical table; reproduced with attribution under NIST public-information policy.
