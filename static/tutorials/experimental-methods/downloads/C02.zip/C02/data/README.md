# Polyethylene SRM 1475 published cumulative distribution

Numerical transcription of Table 4, p.169, in Gaylon Ross and Lois Frolen, “The Characterization of Linear Polyethylene SRM 1475. X. Gel Permeation Chromatography,” Journal of Research of the National Bureau of Standards 76A (1972), pp.163–170.

Public source: https://nvlpubs.nist.gov/nistpubs/jres/76A/jresv76An2p163_A1b.pdf

The two authors were at the National Bureau of Standards. NIST public-information reuse statement: https://www.nist.gov/copyrights-disclaimers . Numerical data are reproduced with attribution. No publisher artwork is included. Table and author names were checked against rendered pages. Original printed log M=4.776 at 75.1% is retained as printed; the neighboring steps are not made uniform. Final log M printed 5.87 is represented as 5.870. This is the reported aggregate cumulative mass distribution, not a raw detector trace, number distribution or a new certification of the material.

The paper reports Mn=17,900 g/mol and Mw=52,900 g/mol for this cumulative distribution. Its mean of individually calculated run moments is different (Mn=18,310 and Mw=53,070 g/mol). The example quotes the former and does not infer exact moments from sparsely rounded cumulative data. Code estimates a median by linear interpolation in log M and reports that operation explicitly.
