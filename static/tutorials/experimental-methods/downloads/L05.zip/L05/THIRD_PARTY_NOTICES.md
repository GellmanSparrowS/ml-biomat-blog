# Public sources and third-party materials

- Coons, Creech & Jones (1941): Immunological Properties of an Antibody Containing a Fluorescent Group: https://www.ebm-journal.org/journals/experimental-biology-and-medicine/articles/10.3181/00379727-47-13084p/pdf
  Technical reference; original figure not reproduced
- Abcam: Immunocytochemistry protocol: https://www.abcam.com/en-us/technical-resources/protocols/icc-protocol
  Technical reference
- Thermo Fisher: Application Verification Testing for Immunofluorescence: https://www.thermofisher.com/us/en/home/life-science/antibodies/antibodies-learning-center/antibodies-resource-library/antibody-application-testing-protocols/immunofluorescence-protocol-adherent-suspension-application-testing.html
  Technical reference
- Uhlén et al. (2016): A proposal for validation of antibodies: https://pmc.ncbi.nlm.nih.gov/articles/PMC10335836/
  Technical reference; no figure reproduced
- Human Protein Atlas v26: VIM subcellular localization: https://v26.proteinatlas.org/ENSG00000026025-VIM/subcellular
  CC BY 4.0; images credited to Human Protein Atlas
- Thul et al. (2017): A subcellular map of the human proteome: https://doi.org/10.1126/science.aal3321
  Technical reference
- ImageJ: Colocalization Analysis: https://imagej.net/imaging/colocalization-analysis
  Technical reference
- Human Protein Atlas: Licence and citation: https://www.proteinatlas.org/about/licence
  CC BY 4.0 for HPA copyrighted content, with stated third-party exceptions
