"""Antibody binding, nuclear localization and image measurement: offline example."""
from pathlib import Path
import argparse,csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Ellipse,FancyArrowPatch
from PIL import Image

BLUE='#186e83';AMBER='#cd803f';PURPLE='#8160a1';GREEN='#3c8a6a'
def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text).replace('ASC52 telo', 'ASC52telo')


def response(exposure=1.,background=25.,contamination=0.):
    nucleus=(1-contamination)*120+contamination*60
    n=min(255,exposure*(nucleus+background));c=min(255,exposure*(60+background))
    return (n-exposure*background)/(c-exposure*background)

def main(output,language='zh'):
    out=Path(output);out.mkdir(parents=True,exist_ok=True);zh=language=='zh'
    def T(a,b):return a if zh else _label(b)
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5'})
    def save(fig,name):fig.savefig(out/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,5.2))
    for ax,indirect in zip(axes,[False,True]):
        ax.set(xlim=(0,10),ylim=(0,8));ax.axis('off')
        ax.add_patch(Ellipse((5,1.8),3,1,fc=BLUE,ec='none'))
        ax.text(5,.8,T('靶蛋白与可及的表位','Target and accessible epitope'),ha='center')
        ax.plot([5,5,4,5,6],[2.3,3.8,4.8,3.8,4.8],color=AMBER,lw=5)
        if indirect:
            for x in [4.,6.]:
                ax.plot([x,x,x-.6,x,x+.6],[4.8,5.8,6.4,5.8,6.4],color=PURPLE,lw=4)
                ax.scatter([x-.6,x+.6],[6.4,6.4],s=100,marker='*',color=GREEN)
            ax.text(5,7.2,T('间接：一抗识别，带标二抗报告','Indirect: primary recognition, labeled secondary'),ha='center',fontsize=10)
        else:
            ax.scatter([4,6],[4.8,4.8],s=150,marker='*',color=GREEN)
            ax.text(5,6.8,T('直接：识别与发光位于同一抗体','Direct: recognition and label on one antibody'),ha='center',fontsize=10)
            ax.text(5,5.8,T('1941：Coons、Creech、Jones\n荧光化学与特异识别相遇','1941: Coons, Creech and Jones\nFluorescent chemistry meets specific recognition'),ha='center',fontsize=10)
    fig.text(.5,.015,T('原创原理示意；星号代表荧光团，数量不代表真实标记度。','Original mechanism schematic; stars are fluorophores, not measured labeling stoichiometry.'),ha='center',fontsize=9)
    save(fig,'history')
    # Constructed raw images: masks define geometry independently of protein intensity.
    rng=np.random.default_rng(505);yy,xx=np.mgrid[:220,:345]
    cells=np.zeros(xx.shape,int);nuclei=np.zeros(xx.shape,int);truth=np.zeros(xx.shape,float)
    rows=[]
    for i in range(40):
        cy=25+(i//8)*42;cx=25+(i%8)*42
        cell=(xx-cx)**2+(yy-cy)**2<=18**2;nuc=(xx-cx)**2+(yy-cy)**2<=8**2;cyto=cell&~nuc
        ratio=(.6 if i<20 else 2.)*np.exp(rng.normal(0,.12))
        total=10000.;c=total/(cyto.sum()+ratio*nuc.sum());n=c*ratio
        cells[cell]=i+1;nuclei[nuc]=i+1;truth[cyto]=c;truth[nuc]=n
        rows.append([i+1,'control' if i<20 else 'stimulated',ratio,total,int(nuc.sum()),int(cyto.sum())])
    raw=25+truth+rng.normal(0,.8,xx.shape);background=float(raw[cells==0].mean())
    result=[]
    for row in rows:
        i=row[0];nmask=nuclei==i;cmask=(cells==i)&~nmask
        n=raw[nmask].mean()-background;c=raw[cmask].mean()-background
        result.append(row+[float(n),float(c),float(n/c),float((raw[cells==i]-background).sum())])
    with (out/'localization.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['cell_id','group','true_NC_ratio','true_total_au','nuclear_pixels','cytoplasmic_pixels','nuclear_mean_au','cytoplasmic_mean_au','measured_NC_ratio','corrected_total_au']);w.writerows(result)
    np.savez_compressed(out/'images.npz',raw=raw,cell_masks=cells,nuclear_masks=nuclei,true_signal=truth)
    fig,ax=plt.subplots(2,2,figsize=(11,8.2))
    im=ax[0,0].imshow(raw,cmap='magma',vmin=25,vmax=55);ax[0,0].set_title(T('A  构造靶蛋白通道：原始数值','A  Constructed target channel: raw values'))
    ax[0,0].plot([20,70],[200,200],color='white',lw=3);ax[0,0].text(45,191,'50 μm',ha='center',color='white',fontsize=9)
    fig.colorbar(im,ax=ax[0,0],label=T('强度 / a.u.','Intensity / a.u.'),fraction=.035)
    masks=np.zeros((*raw.shape,3));masks[cells>0]=[.8,.5,.24];masks[nuclei>0]=[.18,.5,.65]
    ax[0,1].imshow(masks);ax[0,1].set_title(T('B  独立区域：核（蓝）与胞质（橙）','B  Independent masks: nucleus and cytoplasm'))
    for a in ax[0]:a.axis('off')
    ratios=np.array([r[-2] for r in result]);totals=np.array([r[-1] for r in result])
    for j,colour in enumerate([BLUE,AMBER]):
        indices=np.arange(j*20,(j+1)*20);jitter=np.linspace(-.15,.15,20)
        ax[1,0].scatter(j+jitter,ratios[indices],color=colour,alpha=.8)
        ax[1,1].scatter(j+jitter,totals[indices],color=colour,alpha=.8)
    for a in ax[1]:a.set_xticks([0,1],[T('对照','Control'),T('刺激','Stimulated')]);a.grid(axis='y',alpha=.2)
    ax[1,0].set(ylabel=T('核 / 胞质平均强度比','Nuclear / cytoplasmic mean ratio'),title=T('C  每个点是一枚构造细胞','C  Each point is one constructed cell'))
    ax[1,1].set(ylabel=T('扣背景积分强度 / a.u.','Background-corrected integrated intensity / a.u.'),title=T('D  总量相近，位置改变','D  Similar total, different location'),ylim=(9500,10500))
    fig.tight_layout();save(fig,'localization')
    fig,ax=plt.subplots(2,2,figsize=(11,8.2));c=np.geomspace(.05,100,200);bound=c/(2+c);background_curve=8+.8*c
    ax[0,0].semilogx(c,bound,color=BLUE);ax[0,0].set(xlabel=T('游离抗体浓度 / nM','Free antibody concentration / nM'),ylabel=T('结合占据率','Bound fraction'),title=T('A  单一位点平衡模型，Kd = 2 nM','A  One-site equilibrium model, Kd = 2 nM'))
    ax[0,1].semilogx(c,100*bound/background_curve,color=GREEN);ax[0,1].set(xlabel=T('抗体浓度 / nM','Antibody concentration / nM'),ylabel=T('特异信号 / 背景','Specific signal / background'),title=T('B  背景也随浓度上升的例子','B  Example with concentration-dependent background'))
    exposure=np.linspace(.2,4,200);ax[1,0].plot(exposure,[response(e) for e in exposure],color=AMBER);ax[1,0].axhline(2,color=BLUE,ls='--');ax[1,0].set(xlabel=T('曝光倍数','Exposure multiplier'),ylabel=T('测得核 / 胞质比','Measured N/C ratio'),title=T('C  饱和把真实比值 2 压向 1','C  Clipping compresses a true ratio of 2'))
    q=np.linspace(0,.5,100);ax[1,1].plot(q,[response(contamination=v) for v in q],color=PURPLE);ax[1,1].set(xlabel=T('核区域中混入的胞质比例','Cytoplasm fraction in nuclear region'),ylabel=T('测得核 / 胞质比','Measured N/C ratio'),title=T('D  区域边界也是测量条件','D  Region boundaries affect measurement'))
    for a in ax.flat:a.grid(alpha=.2)
    fig.tight_layout();save(fig,'diagnostics')
    here=Path(__file__).resolve().parent
    fig,ax=plt.subplots(1,2,figsize=(11,6.2))
    for a,name,title in zip(ax,['hpa-vim-asc.jpg','hpa-vim-asc-green.jpg'],[T('A  三通道合并','A  Three-channel merge'),T('B  靶蛋白 VIM：绿色通道','B  Target VIM: green channel')]):
        a.imshow(Image.open(here/name));a.axis('off');a.set_title(title)
    fig.text(.5,.06,T('ASC52telo；HPA001762；绿：VIM，红：微管，蓝：细胞核。\nHuman Protein Atlas v26，图像 582878；CC BY 4.0。','ASC52telo; HPA001762; green: VIM, red: microtubules, blue: nuclei.\nHuman Protein Atlas v26, image 582878; CC BY 4.0.'),ha='center',fontsize=9)
    fig.tight_layout(rect=[0,.14,1,1]);save(fig,'published')
    assert response()==2 and response(4)==1
    assert np.isclose(response(2),205/120)
    summary={'binding':{'half':2/(2+2),'ninety_percent':18/(2+18)},'dilution':{'stock_ul':2*500/1000},'ratios':{'corrected':response(),'raw':145/85,'clipped_two':response(2),'clipped_four':response(4),'contamination_quarter':response(contamination=.25)},'constructed':{'cells':40,'estimated_background':background,'control_median':float(np.median(ratios[:20])),'stimulated_median':float(np.median(ratios[20:])),'mean_total':float(totals.mean())},'correlation':{'proportional':float(np.corrcoef([1,2,3,4],[2,4,6,8])[0,1])}}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
