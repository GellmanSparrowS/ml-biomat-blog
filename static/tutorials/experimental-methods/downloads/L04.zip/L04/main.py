"""EdU pulse coverage, nuclear image measurements and labeling decisions."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,FancyArrowPatch,Circle

def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def pulse_overlap(phase,duration,s_start=8.,s_end=16.,cycle=24.):
    phase=np.asarray(phase);overlap=np.zeros_like(phase,dtype=float)
    for k in range(int(np.ceil(duration/cycle))+2):overlap+=np.maximum(0,np.minimum(phase+duration,s_end+k*cycle)-np.maximum(phase,s_start+k*cycle))
    return overlap

def main(output,language):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    from matplotlib import font_manager
    fonts={f.name for f in font_manager.fontManager.ttflist};font=next((f for f in ['Microsoft YaHei','Noto Sans CJK SC','SimHei'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[font,'DejaVu Sans'] if language=='zh' else ['DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','axes.prop_cycle':plt.cycler(color=['#186e83','#cd803f','#8160a1','#3c8a6a'])})
    tr=lambda z,e:z if language=='zh' else _label(e)
    def save(fig,name):fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    rng=np.random.default_rng(404);n=480;cycling=360;phase=(np.arange(cycling)+.5)*24/cycling;overlap=np.r_[pulse_overlap(phase,2),np.zeros(n-cycling)];true_signal=60*overlap;ideal_labeled=overlap>0;ideal_detected=true_signal>=15
    final_phase=np.r_[(phase+2)%24,np.zeros(n-cycling)];dna=np.where(final_phase<8,2,np.where(final_phase<16,2+(final_phase-8)/4,4));order=rng.permutation(n);true_signal=true_signal[order];dna=dna[order];overlap=overlap[order];ideal_labeled=ideal_labeled[order];ideal_detected=ideal_detected[order]
    positions=np.array([(15+24*x,15+24*y) for y in range(20) for x in range(24)],float)+rng.uniform(-2,2,(n,2));yy,xx=np.mgrid[:490,:590];nuclei=np.full(xx.shape,20.);edu=np.full(xx.shape,20.);labels=np.zeros(xx.shape,int)
    for i,((x,y),signal,d) in enumerate(zip(positions,true_signal,dna)):
        kern=np.exp(-((xx-x)**2+(yy-y)**2)/(2*3.4**2));nuclei+=d*35*kern;edu+=signal*kern;labels[(xx-x)**2+(yy-y)**2<2**2]=i+1
    nuclei+=rng.normal(0,1,nuclei.shape);edu+=rng.normal(0,1,edu.shape);measured=np.array([edu[labels==i+1].mean()-20 for i in range(n)]);measured_dna=np.array([nuclei[labels==i+1].mean()-20 for i in range(n)])/35
    detected=measured>=15;np.savetxt(output/'nuclei.csv',np.column_stack([np.arange(1,n+1),overlap,dna,true_signal,measured,detected.astype(int)]),delimiter=',',header='nucleus,overlap_h,relative_DNA_content,true_EdU_au,measured_EdU_au,positive',comments='');np.savez_compressed(output/'nuclear_images.npz',nuclei_raw=nuclei,edu_raw=edu,roi_labels=labels,pixel_um=1.)
    fig,ax=plt.subplots(2,1,figsize=(10.8,7.4));a=ax[0];a.axis('off');a.set(xlim=(0,10),ylim=(0,3));a.text(.4,2.65,tr('活细胞：掺入小标签','Live cells: incorporate a small tag'),fontsize=12);a.text(5.6,2.65,tr('检测阶段：连接荧光标记','Detection: attach a fluorescent reporter'),fontsize=12)
    for left in [.6,5.9]:
        a.plot([left,left+3],[1.15,1.15],color='#186e83',lw=3);a.plot([left,left+3],[1.75,1.75],color='#186e83',lw=3)
        for x in np.linspace(left+.2,left+2.8,7):a.plot([x,x],[1.15,1.75],color='#91bac7',lw=2);a.scatter([x,x],[1.15,1.75],color='#186e83',s=32)
        a.scatter([left+1.5],[1.75],color='#cd803f',s=80,zorder=5)
    a.plot([2.1,2.1],[1.75,2.15],color='#cd803f',lw=2);a.text(2.1,2.28,'EdU',color='#aa6529',ha='center',fontsize=10);a.add_patch(FancyArrowPatch((3.9,1.45),(5.4,1.45),arrowstyle='->',mutation_scale=22));a.text(4.65,1.95,'Cu(I)',ha='center',fontsize=10);a.plot([7.4,7.4,8.05],[1.75,2.1,2.1],color='#8160a1',lw=2);a.scatter([8.05],[2.1],marker='*',s=230,color='#8160a1');a.text(5,.35,tr('DNA 梯形为核苷位置示意；星号为后来连接的荧光探针。','DNA ladder depicts nucleotide positions; the star marks the reporter attached later.'),ha='center',fontsize=10);a.text(5,.05,tr('2008 年 Salic 与 Mitchison：将 DNA 掺入与小分子点击检测相连接。','Salic and Mitchison, 2008: connect DNA incorporation with small-molecule click detection.'),ha='center',fontsize=10)
    a=ax[1];stages=[(0,8,'G1'),(8,8,'S'),(16,6,'G2'),(22,2,'M')];colors=['#b9d8e2','#3c8a6a','#d8c7e5','#d6aa81']
    for (start,width,name),c in zip(stages,colors):a.barh(1.25,width,left=start,height=.3,color=c);a.text(start+width/2,1.25,name,ha='center',va='center')
    for y,start,over in [(.8,6,0),(.5,9,2),(.2,15,1)]:
        a.barh(y,2,left=start,height=.15,color='#e2c5a9')
        if over:a.barh(y,over,left=max(start,8),height=.15,color='#3c8a6a')
        a.text(start+2.4,y,tr(f'2 h 脉冲；重叠 {over} h',f'2 h pulse; overlap {over} h'),fontsize=10,va='center')
    a.set(xlim=(0,24),ylim=(0,1.65),yticks=[],xlabel=tr('构造周期中的位置 / h','Position in a constructed cycle / h'));fig.tight_layout();save(fig,'history')
    fig,ax=plt.subplots(2,2,figsize=(11,8));a=ax[0,0];a.imshow(nuclei,cmap='Blues_r',origin='lower',vmin=20,vmax=160,extent=[0,590,0,490]);a.set_title(tr('A  全部核：独立建立分母','A  All nuclei establish the denominator'));a.set(xlabel='x / μm',ylabel='y / μm')
    a=ax[0,1];a.imshow(edu,cmap='magma',origin='lower',vmin=20,vmax=145,extent=[0,590,0,490]);a.set_title(tr('B  EdU：记录脉冲内的掺入','B  EdU records incorporation during the pulse'));a.plot([430,530],[35,35],color='white',lw=3);a.text(480,50,'100 μm',color='white',ha='center',fontsize=9);a.set(xlabel='x / μm',ylabel='y / μm')
    a=ax[1,0];a.scatter(measured_dna,measured,c=np.where(detected,'#8160a1','#8aa0a8'),s=12,alpha=.65);a.axhline(15,color='#cd803f',ls='--');a.set(xlabel=tr('相对 DNA 信号','Relative DNA signal'),ylabel=tr('核内 EdU 均值 / a.u.','Mean nuclear EdU / a.u.'),title=tr('C  脉冲末端的 DNA 与 EdU','C  DNA and EdU at the end of the pulse'))
    a=ax[1,1];a.hist(measured,bins=40,color='#186e83');a.axvline(15,color='#cd803f',ls='--');a.set(xlabel=tr('扣背景核内 EdU / a.u.','Background-corrected nuclear EdU / a.u.'),ylabel=tr('核数','Nuclei'),title=tr('D  阈值与短暂进入 S 期的弱信号','D  Threshold and weak signal from brief S-phase overlap'));fig.suptitle(tr('固定相位群体的构造图像；每个核定位区域已知','Constructed fixed-cohort images; nuclear measurement regions are known'),fontsize=11);fig.tight_layout();save(fig,'nuclei')
    fig,ax=plt.subplots(2,2,figsize=(11.2,7.5));duration=np.linspace(.05,20,200)
    for fraction in [.5,.75,1.]:ax[0,0].plot(duration,100*fraction*np.minimum(1,(8+duration)/24),label=f'g={fraction}')
    ax[0,0].set(xlabel=tr('脉冲长度 / h','Pulse duration / h'),ylabel=tr('几何覆盖比例 / %','Geometric coverage / %'),title=tr('A  固定追踪单位的相位覆盖模型','A  Phase coverage of fixed tracking units'));ax[0,0].legend(fontsize=9)
    qs=np.linspace(1,125,125);ax[0,1].plot(qs,[100*np.mean(measured>=q) for q in qs]);ax[0,1].axhline(31.25,ls=':',color='#8160a1',label=tr('有任意掺入的比例','Any-incorporation fraction'));ax[0,1].axvline(15,ls='--',color='#cd803f');ax[0,1].set(xlabel=tr('判定阈值 / a.u.','Decision threshold / a.u.'),ylabel=tr('检出阳性比例 / %','Detected positive fraction / %'),title=tr('B  掺入与检出之间的差别','B  Incorporation versus detection'));ax[0,1].legend(fontsize=8)
    divisions=np.arange(5);ax[1,0].plot(divisions,100/2.**divisions,'o-');ax[1,0].set(xticks=divisions,xlabel=tr('理想对称分裂次数','Ideal symmetric divisions'),ylabel=tr('每个后代细胞的平均标记 / %','Mean label per descendant / %'),title=tr('C  脉冲后追踪中的标记稀释','C  Label dilution during a chase'))
    ax[1,1].bar([tr('条件甲','Condition A'),tr('条件乙','Condition B')],[200,100],label=tr('总核数','Total nuclei'),color='#b9d8e2');ax[1,1].bar([tr('条件甲','Condition A'),tr('条件乙','Condition B')],[60,40],label=tr('EdU 阳性核','EdU-positive nuclei'),color='#8160a1');ax[1,1].text(0,210,'30%',ha='center');ax[1,1].text(1,110,'40%',ha='center');ax[1,1].set(ylabel=tr('核数','Nuclei'),ylim=(0,270),title=tr('D  阳性比例与阳性数量同时阅读','D  Read positive fraction and count together'));ax[1,1].legend(fontsize=8);fig.tight_layout();save(fig,'pulse')
    fig,ax=plt.subplots(figsize=(8.2,12.5));ax.imshow(plt.imread(Path(__file__).with_name('ligasova2015-figure2.png')));ax.axis('off');ax.set_title(tr('真实实验：浓度、细胞身份与竞争底物改变掺入信号','Measured example: concentration and competing substrate affect labeling'),fontsize=11);fig.text(.5,.06,tr('Ligasová 等，2015，图 2，CC BY 4.0；均值±SEM。\nA 为 8 h，B 为 2 h 标记；见正文的信号定义。','Ligasová et al., 2015, Fig. 2, CC BY 4.0; mean ± SEM.\nA uses 8 h; B uses 2 h; signal definitions in text.'),ha='center',fontsize=9);save(fig,'published')
    summary={'cohort':{'total':n,'cycling':cycling,'any_incorporation':int(ideal_labeled.sum()),'ideal_detected':int(ideal_detected.sum()),'observed_detected':int(detected.sum()),'any_percent':float(ideal_labeled.mean()*100),'observed_percent':float(detected.mean()*100)},'geometry':{'two_hour_fraction':.75*(8+2)/24,'eight_hour_fraction':.75*(8+8)/24,'sixteen_hour_fraction':.75},'dilution':{'stock_10mM_to_5ml_20uM_ul':10.,'final_after_equal_mix_uM':10.},'chase':{'two_division_fraction':.25,'four_division_fraction':.0625},'comparison':{'a_fraction':.3,'b_fraction':.4,'a_positive':60,'b_positive':40}}
    assert ideal_labeled.sum()==150 and ideal_detected.sum()==142 and abs(pulse_overlap(np.array([6.,7.,8.,15.,16.]),2)-np.array([0.,1.,2.,1.,0.])).max()<1e-10
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(summary))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();main(a.output,a.language)
