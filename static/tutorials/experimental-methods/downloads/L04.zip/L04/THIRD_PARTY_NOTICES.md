# Public sources and third-party materials

- Salic and Mitchison (2008): A chemical method for fast and sensitive detection of DNA synthesis in vivo: https://salic.med.harvard.edu/sites/salic.med.harvard.edu/files/publications/Salic_2008_Proc%20Natl%20Acad%20Sci%20U%20S%20A.pdf
  Technical/historical reference; no original text, image or code reproduced.
- Thermo Fisher: Click-iT EdU Imaging Cell Proliferation Protocol: https://www.thermofisher.com/us/en/home/references/protocols/cell-and-tissue-analysis/protocols/click-it-edu-imaging-protocol.html
  Technical/historical reference; no original text, image or code reproduced.
- Thermo Fisher: Click-iT Plus EdU Cell Proliferation Imaging Kits Protocol: https://www.thermofisher.com/us/en/home/references/protocols/cell-and-tissue-analysis/protocols/click-it-plus-edu-imaging-protocol.html
  Technical/historical reference; no original text, image or code reproduced.
- Ligasová et al. (2015): A Fatal Combination: A Thymidylate Synthase Inhibitor with DNA Damaging Activity: https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0117459
  CC BY 4.0; Figure 2 reproduced intact with attribution and outer teaching title.
- ImageJ: Principles of Scientific Imaging: https://imagej.net/imaging/principles
  Technical/historical reference; no original text, image or code reproduced.
