NIST indium calibration data

Values transcribed without modification from Table 4, printed page 17 (PDF page 25), in:
Fortin, T.J.; Herman, T.K.; Koepke, A.A.; Splett, J.D. (2024).
Certification of Standard Reference Material 2232a: Indium for DSC Temperature and Enthalpy Calibration.
NIST Special Publication 260-242. https://doi.org/10.6028/NIST.SP.260-242
https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.260-242.pdf

These are published hierarchical-model posterior means and uncertainty summaries, not individual raw measurements. The zero-rate estimate is an extrapolated equilibrium value, not a DSC scan performed at zero heating rate. The chapter redraws the five means and their published 95% credible bounds. Numerical asymmetry is retained.

Rights: NIST-authored U.S. government publication; NIST information may be copied with credit except material separately marked copyrighted. Table 4 is the authors' own results, not third-party artwork. See https://www.nist.gov/copyrights-disclaimers . No NIST logo or implied endorsement is used.
Accessed 2026-11-17. All other data in this example are explicitly constructed teaching data.
