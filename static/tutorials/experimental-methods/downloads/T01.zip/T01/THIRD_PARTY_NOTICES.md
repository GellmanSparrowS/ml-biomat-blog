# Public sources and third-party materials

- Watson & O’Neill: Differential microcalorimeter, US3263484A: https://patents.google.com/patent/US3263484A/en
  Technical/historical reference; no source artwork reproduced.
- TA Instruments: Interpreting Unexpected Events and Transitions in DSC Results, TA039: https://www.tainstruments.com/pdf/literature/TA039.pdf
  Technical/historical reference; no source artwork reproduced.
- TA Instruments: DSC and MDSC Online Training, Applications: https://www.tainstruments.com/wp-content/uploads/2020-DSC-Online-Training-Part-2-1.pdf
  Technical/historical reference; no source artwork reproduced.
- TA Instruments: Determination of Polymer Crystallinity by DSC, TA123: https://www.tainstruments.com/applications-notes/thermal-analysis-application-brief-determination-of-polymer-crystallinity-by-dsc/
  Technical/historical reference; no source artwork reproduced.
- Malvern: DSC Theory and Practice: https://www.malvernpanalytical.com/en/learn/knowledge-center/whitepapers/wp140701-dsc-theory-and-practice
  Technical/historical reference; no source artwork reproduced.
- Fortin et al. (2024): NIST SP260-242, Indium SRM2232a: https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.260-242.pdf
  NIST-authored U.S. government research; Table 4 numeric values redrawn with credit, no third-party artwork reused.
- NIST: Copyrights and Disclaimers: https://www.nist.gov/copyrights-disclaimers
  Technical/historical reference; no source artwork reproduced.
