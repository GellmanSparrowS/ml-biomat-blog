"""DSC: constructed heat-flow analysis plus published NIST indium estimates."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.special import expit
from scipy.optimize import curve_fit
from scipy.signal import lfilter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle

def gaussian(x,center,width):return np.exp(-.5*((x-center)/width)**2)/(width*np.sqrt(2*np.pi))
def cp_model(t,a,b,step,tg,width):return a+b*(t-20)+step*expit((t-tg)/width)
def lagged_peak(t,rate,mass_mg=5,heat=45,tau=8):
 beta=rate/60;ideal=mass_mg*beta*heat*gaussian(t,165,5);alpha=np.exp(-(t[1]-t[0])/beta/tau);return ideal,lfilter([1-alpha],[1,-alpha],ideal)
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);T=lambda z,e:z if a.language=='zh' else e
 plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.titlesize':12,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fcfbf7','axes.facecolor':'#fcfbf7','savefig.facecolor':'#fcfbf7'})
 B,R,G,Y='#167d9a','#d35f47','#37967d','#c49b35'
 def save(f,n):f.savefig(a.output/f'{n}-{a.language}.svg');f.savefig(a.output/f'{n}-{a.language}.png',dpi=145);plt.close(f)
 t=np.linspace(20,200,3601);mass=.005;beta=10/60;cp=cp_model(t,1.2,.002,.35,60,1.5);instrument=.03+.0001*t;baseline=1000*mass*beta*cp;cc=-20*gaussian(t,110,7);melt=45*gaussian(t,165,5);rng=np.random.default_rng(710);raw=instrument+baseline+1000*mass*beta*(cc+melt)+rng.normal(0,.002,len(t));corrected=raw-instrument
 mask=(t>=40)&(t<=80);params,_=curve_fit(cp_model,t[mask],corrected[mask]/(1000*mass*beta),p0=[1.2,.002,.35,60,1.5]);estimated_cp=cp_model(t,*params)
 # Local baselines use transition-free sidebands. The ideal heat-capacity trend is linear well above Tg.
 side=((t>=85)&(t<=90))|((t>=132)&(t<=138))|((t>=140)&(t<=145))|((t>=185)&(t<=195));poly=np.polyfit(t[side],corrected[side],1);local=np.polyval(poly,t);excess=corrected-local
 mcc=(t>=90)&(t<=132);mm=(t>=145)&(t<=185);hcc=-np.trapezoid(excess[mcc],t[mcc])/(1000*mass*beta);hm=np.trapezoid(excess[mm],t[mm])/(1000*mass*beta);xc=(hm-hcc)/(.8*100)*100
 f,axes=plt.subplots(1,2,figsize=(13.7,5.4),layout='constrained')
 for ax in axes:ax.set(xlim=(0,10),ylim=(0,8));ax.axis('off')
 ax=axes[0];ax.set_title(T('A  1962：分别调节功率，保持两侧等温','A  1962: Adjust power to equalize temperatures'),loc='left');ax.add_patch(Rectangle((.7,1.8),8.6,5,fc='#edf0ee',ec='#7e929d'))
 for x,label,col in [(1.5,T('样品','Sample'),R),(6,T('参比','Reference'),B)]:
  ax.add_patch(Rectangle((x,4),2.5,1.3,fc='#e0e7e8',ec=col));ax.text(x+1.25,4.65,label,ha='center');ax.plot([x+.2,x+.6,x+1,x+1.4,x+1.8,x+2.2],[3,3.5,3,3.5,3,3.5],c=col,lw=2);ax.annotate('',xy=(x+1.25,4),xytext=(x+1.25,3.55),arrowprops={'arrowstyle':'->','color':col});ax.text(x+1.25,2.4,T('独立加热器','Separate heater'),ha='center',fontsize=10)
 ax.text(5,6.1,T('温度反馈 → 差分功率','Temperature feedback → differential power'),ha='center',fontsize=11);ax.text(5,.6,T('Watson 与 O’Neill 的功率补偿思想\n原创原理图，非专利图复制','Watson and O’Neill: power-compensation concept\nOriginal schematic, not a patent-figure reproduction'),ha='center',fontsize=10)
 ax=axes[1];ax.set_title(T('B  另一种实现：共同热源与热流通路','B  Another implementation: shared source and heat paths'),loc='left');ax.add_patch(Rectangle((1,1.8),8,1,fc='#ead4ba',ec=Y));ax.text(5,2.3,T('受程序控制的热源','Programmed heat source'),ha='center')
 for x,label,col in [(1.5,T('样品','Sample'),R),(6,T('参比','Reference'),B)]:
  ax.add_patch(Rectangle((x,4.2),2.5,1.3,fc='#e0e7e8',ec=col));ax.text(x+1.25,4.85,label,ha='center');ax.annotate('',xy=(x+1.25,4.2),xytext=(x+1.25,2.9),arrowprops={'arrowstyle':'->','color':col,'lw':3})
 ax.text(5,6.4,T('测量温差，经标定得到热流差','Measure temperature difference; calibrate to heat flow'),ha='center',fontsize=10);ax.text(5,.6,T('热流型 DSC：原理示意，尺寸不按比例','Heat-flux DSC: principle schematic, not to scale'),ha='center',fontsize=10);save(f,'instrument-history')
 f,axes=plt.subplots(2,2,figsize=(13.7,8.4),layout='constrained');ax=axes[0,0];ax.plot(t,raw,c=B,label=T('原始构造信号','Constructed raw signal'));ax.plot(t,baseline+instrument,c='#6b7f8a',ls='--',label=T('无转变热的基线','Baseline without transition heat'));ax.set(xlabel=T('温度 / °C','Temperature / °C'),ylabel=T('热流 / mW；吸热向上','Heat flow / mW; endothermic up'),title=T('A  台阶、放热峰与吸热峰','A  Step, exotherm and endotherm'));ax.legend(fontsize=9)
 ax=axes[0,1];ax.scatter(t[mask][::8],corrected[mask][::8]/(1000*mass*beta),s=8,c=Y,label=T('表观比热','Apparent specific heat'));ax.plot(t[mask],estimated_cp[mask],c=B,label=T('台阶拟合','Step fit'));ax.axvline(params[3],c=R,ls='--');ax.set(xlabel=T('温度 / °C','Temperature / °C'),ylabel=T('比热 / J/(g·K)','Specific heat / J/(g·K)'),title=T(f'B  玻璃化台阶中点 {params[3]:.2f} °C',f'B  Glass-step midpoint {params[3]:.2f} °C'));ax.legend(fontsize=9)
 ax=axes[1,0];ax.plot(t,excess,c=B);ax.fill_between(t,0,excess,where=mcc,color=G,alpha=.3,label=T(f'冷结晶 {hcc:.2f} J/g',f'Cold crystallization {hcc:.2f} J/g'));ax.fill_between(t,0,excess,where=mm,color=R,alpha=.3,label=T(f'熔融 {hm:.2f} J/g',f'Melting {hm:.2f} J/g'));ax.set(xlim=(80,195),xlabel=T('温度 / °C','Temperature / °C'),ylabel=T('扣基线热流 / mW','Baseline-subtracted heat flow / mW'),title=T('C  积分面积需除以升温速率','C  Temperature-axis area needs the heating rate'));ax.legend(fontsize=9)
 ax=axes[1,1];labels=[T('熔融直接比值','Melting alone'),T('扣冷结晶，样品基准','Subtract cold\ncrystallization'),T('再按聚合物质量归一','Polymer-mass\nnormalization')];vals=[hm/100*100,(hm-hcc)/100*100,xc];ax.bar(range(3),vals,color=[R,Y,B],width=.58);ax.set_xticks(range(3),labels,fontsize=9);ax.set(ylabel=T('计算结果 / %','Calculated result / %'),ylim=(0,65),title=T('D  分母改变，物理含义也改变','D  The denominator changes the meaning'))
 for i,v in enumerate(vals):ax.text(i,v+1,f'{v:.2f}%',ha='center',fontsize=10)
 save(f,'heat-flow-analysis')
 nist=np.genfromtxt(Path(__file__).parent/'data/nist_indium_table4.csv',delimiter=',',names=True);f,axes=plt.subplots(1,2,figsize=(13.7,5.5),layout='constrained');rate_rows=[]
 for rate,col in [(5,G),(10,B),(20,R)]:
  ideal,measured=lagged_peak(t,rate);peak=float(t[np.argmax(measured)]);heat=float(np.trapezoid(measured,t)/(1000*mass*(rate/60)));rate_rows.append([rate,peak,heat]);axes[0].plot(t,measured,c=col,label=T(f'{rate} °C/min；峰 {peak:.2f} °C',f'{rate} °C/min; peak {peak:.2f} °C'))
 axes[0].set(xlim=(145,190),xlabel=T('程序温度 / °C','Program temperature / °C'),ylabel=T('转变热流 / mW','Transition heat flow / mW'),title=T('A  构造模型：8 s 热响应滞后','A  Constructed model: 8-second thermal response'));axes[0].legend(fontsize=9)
 ax=axes[1];mean=nist['posterior_mean_J_per_g'];ax.errorbar(nist['heating_rate_C_per_min'],mean,yerr=[mean-nist['lower95_J_per_g'],nist['upper95_J_per_g']-mean],fmt='o',color=B,capsize=4);ax.axhline(28.58,c=G,ls=':',label=T('零速率外推 28.58 J/g','Zero-rate extrapolation: 28.58 J/g'));ax.set(xlabel=T('名义升温速率 / °C/min','Nominal heating rate / °C/min'),ylabel=T('熔融焓估计 / J/g','Estimated fusion enthalpy / J/g'),title=T('B  真实公开结果：NIST 铟标准物质','B  Published results: NIST indium reference material'));ax.legend(fontsize=9,loc='upper left');ax.text(.25,.05,T('表 4 后验均值与 95% 可信区间\n不是五条原始扫描的峰面积','Table 4 posterior means and 95% credible intervals\nNot peak areas from five individual scans'),transform=ax.transAxes,fontsize=9);save(f,'scan-rate-calibration')
 pt=np.linspace(20,100,1601);kel=pt+273.15;H=200000.;Tm=333.15;gas=8.31446261815324;frac=expit(-H/gas*(1/kel-1/Tm));cex=H**2/(gas*kel**2)*frac*(1-frac)/1000;integral=np.trapezoid(cex,pt)
 f,axes=plt.subplots(1,2,figsize=(13.7,5.4),layout='constrained');ax=axes[0];ax.plot(pt,frac,c=B,label=T('展开比例','Unfolded fraction'));ax.axvline(60,c='#71818b',ls=':');ax.axhline(.5,c='#71818b',ls=':');ax.set(xlabel=T('温度 / °C','Temperature / °C'),ylabel=T('展开分子比例','Fraction unfolded'),title=T('A  构造的可逆两态平衡','A  Constructed reversible two-state equilibrium'));ax.legend(fontsize=10)
 ax=axes[1];ax.plot(pt,cex,c=R,label=T('首次扫描 / 完全恢复后的复扫','First scan / rescan after full recovery'));ax.plot(pt,.2*cex,c=B,ls='--',label=T('仅 20% 分子恢复的复扫示意','Illustrative rescan with only 20% recovered'));ax.fill_between(pt,0,cex,color=R,alpha=.1);ax.set(xlabel=T('温度 / °C','Temperature / °C'),ylabel=T('过量摩尔热容 / kJ/(mol·K)','Excess molar heat capacity / kJ/(mol·K)'),title=T('B  面积计热，复扫考察恢复','B  Area measures heat; rescanning probes recovery'));ax.legend(fontsize=8);ax.text(.04,.65,T(f'20–100 °C 积分：{integral:.2f} kJ/mol\n参数 ΔH=200 kJ/mol；ΔCp=0',f'Integral, 20–100 °C: {integral:.2f} kJ/mol\nModel ΔH=200 kJ/mol; ΔCp=0'),transform=ax.transAxes,fontsize=9);save(f,'protein-unfolding')
 np.savetxt(a.output/'polymer_scan.csv',np.c_[t,(t-20)/beta,raw,instrument,corrected,baseline,local,excess],delimiter=',',header='temperature_C,time_s,raw_mW,instrument_mW,corrected_mW,true_cp_baseline_mW,fitted_local_baseline_mW,excess_mW',comments='');np.savetxt(a.output/'scan_rate.csv',rate_rows,delimiter=',',header='rate_C_per_min,peak_temperature_C,integrated_heat_J_per_g',comments='');np.savetxt(a.output/'protein.csv',np.c_[pt,frac,cex,.2*cex],delimiter=',',header='temperature_C,unfolded_fraction,excess_Cp_kJ_per_mol_K,rescan20percent_kJ_per_mol_K',comments='')
 summary={'glass_midpoint_C':float(params[3]),'specific_heat_step_J_per_g_K':float(params[2]),'melting_heat_J_per_g_sample':float(hm),'cold_crystallization_heat_J_per_g_sample':float(hcc),'initial_polymer_crystallinity_percent':float(xc),'ideal_initial_polymer_crystallinity_percent':31.25,'baseline_offset_heat_error_J_per_g':.01/1000*40/beta/mass,'protein_unfolded_fraction_at_60C':float(frac[np.argmin(abs(pt-60))]),'protein_integrated_heat_kJ_per_mol':float(integral),'nist_zero_rate_enthalpy_J_per_g':float(mean[0]),'rate_peak_temperatures_C':[row[1] for row in rate_rows],'rate_integrals_J_per_g':[row[2] for row in rate_rows]};(a.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
