"""Counting-volume arithmetic, sampling variation and comparable culture starts."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,FancyArrowPatch

def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def main(output,language):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    from matplotlib import font_manager
    fonts={f.name for f in font_manager.fontManager.ttflist};font=next((f for f in ['Microsoft YaHei','Noto Sans CJK SC','SimHei'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[font,'DejaVu Sans'] if language=='zh' else ['DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','axes.prop_cycle':plt.cycler(color=['#186e83','#cd803f','#8160a1','#3c8a6a'])})
    tr=lambda z,e:z if language=='zh' else _label(e)
    def save(fig,n):fig.savefig(output/f'{n}-{language}.svg',bbox_inches='tight');plt.close(fig)
    rng=np.random.default_rng(1010);live=np.array([72,81,76,79]);dead=np.array([8,9,7,8]);dilution=2;volume=1e-4;live_c=live.mean()*dilution/volume;total_c=(live+dead).mean()*dilution/volume;viability=100*live.sum()/(live+dead).sum()
    np.savetxt(output/'counts.csv',np.column_stack([np.arange(1,5),live,dead,live+dead]),delimiter=',',header='square,membrane_intact_count,stained_count,total_count',comments='',fmt='%d')
    fig,ax=plt.subplots(1,2,figsize=(11.3,4.4))
    for a in ax:a.set(xlim=(0,10),ylim=(0,8));a.axis('off')
    for a,ratio in zip(ax,[2,8]):
        a.add_patch(Rectangle((.5,3),2,2,facecolor='#a2cdd9'));a.text(1.5,4,tr('起始细胞','Starting cells'),ha='center',va='center',fontsize=9);a.add_patch(FancyArrowPatch((2.8,4),(5,4),arrowstyle='->',mutation_scale=20));a.add_patch(Rectangle((5.5,2),4,4,facecolor='#a2cdd9'));a.text(7.5,4,tr(f'扩增 {ratio} 倍',f'{ratio}-fold expansion'),ha='center',va='center');a.set_title(tr(f'一次传代，分配比例 1:{ratio}',f'One passage, split ratio 1:{ratio}'));a.text(5,1,tr(f'理想净群体倍增数：{np.log2(ratio):g}',f'Ideal net population doublings: {np.log2(ratio):g}'),ha='center');
    fig.text(.5,.01,tr('1961 年 Hayflick 与 Moorhead 的有限增殖研究，让培养历史成为生物学变量。','Hayflick and Moorhead’s 1961 finite-proliferation work made culture history a biological variable.'),ha='center',fontsize=10);save(fig,'history')
    fig,ax=plt.subplots(1,2,figsize=(10.6,4.8));a=ax[0]
    for z in np.linspace(0,1,5):a.axvline(z,color='#a6b8bf');a.axhline(z,color='#a6b8bf')
    pos=rng.uniform(.03,.97,(45,2));a.scatter(pos[:,0],pos[:,1],s=40,facecolor='#a2cdd9',edgecolor='#186e83');a.scatter([.2,.66,.84],[.3,.57,.8],s=45,color='#8160a1');a.set(xlim=(-.1,1.1),ylim=(-.1,1.1),aspect='equal',xlabel=tr('宽度 / mm','Width / mm'),ylabel=tr('高度 / mm','Height / mm'),title=tr('A  一大格面积为 1 mm²','A  One large square has area 1 mm²'))
    a.plot([0,1],[1,1],color='#3c8a6a',lw=3);a.plot([0,0],[0,1],color='#3c8a6a',lw=3);a.plot([0,1],[0,0],color='#cd803f',lw=3);a.plot([1,1],[0,1],color='#cd803f',lw=3)
    a=ax[1];a.axis('off');a.add_patch(Rectangle((.1,.35),.8,.2,facecolor='#c9e3e9',edgecolor='#186e83'));a.plot([.05,.95],[.57,.57],color='#8160a1',lw=5);a.text(.5,.7,tr('盖玻片固定深度：0.1 mm','Coverslip fixes depth: 0.1 mm'),ha='center',fontsize=11);a.text(.5,.2,'1 mm × 1 mm × 0.1 mm\n= 0.1 mm³ = 10⁻⁴ mL',ha='center',fontsize=14);a.set_title(tr('B  从面积到已知体积','B  From area to a known volume'));fig.tight_layout();save(fig,'chamber')
    fig,ax=plt.subplots(1,3,figsize=(12,4.4));ax[0].bar(np.arange(1,5),live,label=tr('未染色','Unstained'));ax[0].bar(np.arange(1,5),dead,bottom=live,label=tr('染色','Stained'));ax[0].set(xlabel=tr('计数大格','Counting square'),ylabel=tr('细胞计数','Cell count'),title=tr('A  四格的原始计数','A  Raw counts in four squares'));ax[0].legend(fontsize=9)
    events=np.array([25,100,400,1600]);ax[1].plot(events,100/np.sqrt(events),'o-');ax[1].set(xscale='log',xlabel=tr('累计计入的细胞数','Total counted cells'),ylabel=tr('理想相对标准差 / %','Ideal relative SD / %'),title=tr('B  随机计数的不确定性尺度','B  Scale of random counting uncertainty'))
    fraction=np.array([.1,.25,.5,1]);truth=1.7e6*fraction;biased=truth/(1+truth/3e6);ax[2].plot(fraction,truth/1e6,'o-',label=tr('成比例响应','Proportional response'));ax[2].plot(fraction,biased/1e6,'s-',label=tr('构造的高密度漏计','Constructed crowding undercount'));ax[2].set(xlabel=tr('原液所占体积分数','Stock fraction in dilution'),ylabel=tr('计数浓度 / 10⁶ mL⁻¹','Counted concentration / 10⁶ mL⁻¹'),title=tr('C  稀释检验响应是否成比例','C  Dilution tests proportionality'));ax[2].legend(fontsize=8);fig.tight_layout();save(fig,'counting')
    t=np.linspace(0,120,241);exp=20000*2**(t/24);logistic=200000/(1+9*np.exp(np.log(2)*(-t)/24));fig,ax=plt.subplots(2,2,figsize=(11.2,7.2));ax=ax.ravel();ax[0].plot(t,exp,label=tr('持续指数增长','Continued exponential growth'));ax[0].plot(t,logistic,label=tr('构造的容量受限增长','Constructed capacity-limited growth'));ax[0].set(xlabel=tr('培养时间 / h','Culture time / h'),ylabel=tr('细胞数','Cell number'),title=tr('A  同一起点，不同后期条件','A  Same start, different later conditions'));ax[0].legend(fontsize=8)
    ax[1].semilogy([0,24,48,72],[20000,40000,80000,160000],'o-');ax[1].set(xlabel=tr('培养时间 / h','Culture time / h'),ylabel=tr('细胞数（对数轴）','Cell number (log scale)'),title=tr('B  等时间倍增在半对数图上成直线','B  Equal-time doubling gives a straight semilog line'))
    plate=np.ones((8,12));plate[[0,-1],:]=1.15;plate[:,[0,-1]]=1.15;plate+=rng.normal(0,.025,plate.shape);im=ax[2].imshow(plate,cmap='cividis',vmin=.9,vmax=1.2);fig.colorbar(im,ax=ax[2],label=tr('相对读数','Relative readout'));ax[2].set(xticks=range(12),xticklabels=range(1,13),yticks=range(8),yticklabels=list('ABCDEFGH'),title=tr('C  构造的板边位置效应','C  Constructed plate-edge position effect'))
    treatments=np.tile(np.arange(4),24);rng.shuffle(treatments);layout=treatments.reshape(8,12);ax[3].imshow(layout,cmap=plt.colormaps['Set2'].resampled(4),vmin=-.5,vmax=3.5)
    for row in range(8):
        for col in range(12):ax[3].text(col,row,'ABCD'[layout[row,col]],ha='center',va='center',fontsize=8)
    ax[3].set(xticks=range(12),xticklabels=range(1,13),yticks=range(8),yticklabels=list('ABCDEFGH'),title=tr('D  处理组分散到不同位置','D  Treatments distributed across positions'));fig.tight_layout();save(fig,'culture')
    from PIL import Image
    fig,ax=plt.subplots(figsize=(9,5.9));ax.imshow(Image.open(Path(__file__).with_name('hemocytometer-todd.jpg')));ax.axis('off');ax.set_title(tr('真实计数板：精确体积来自玻璃结构与盖玻片','A real counting chamber: geometry and coverslip define volume'),fontsize=12,pad=10);fig.text(.5,.01,'Todd · Hemocytometer · Wikimedia Commons · CC BY-SA 2.0',ha='center',fontsize=9);save(fig,'instrument')
    final_volume=12*.1*1.1;stock_volume=final_volume*1e5/live_c;summary={'counting':{'volume_per_square_ml':volume,'mean_live_per_square':float(live.mean()),'live_concentration_ml':float(live_c),'total_concentration_ml':float(total_c),'viability_percent':float(viability),'live_cells_in_2ml':float(live_c*2)},'seeding':{'target_per_well':10000,'final_volume_ml':final_volume,'stock_volume_ul':float(stock_volume*1000),'medium_volume_ml':float(final_volume-stock_volume)},'growth':{'initial_cells':20000,'cells_at_48h':80000,'doublings':2,'doubling_time_h':24},'sampling':{'relative_sd_100':.1,'relative_sd_400':.05},'dilution':{'true_stock_ml':1700000,'crowded_stock_measured_ml':float(biased[-1])}}
    assert abs(live_c-1540000)<1e-8;assert abs(stock_volume*live_c-final_volume*1e5)<1e-8;assert abs(np.log2(80000/20000)-2)<1e-12
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
