# Public sources and third-party materials

- ATCC: Animal Cell Culture Guide: https://www.atcc.org/resources/culture-guides/animal-cell-culture-guide
  Technical/historical reference; no source text, figure or code reproduced.
- ATCC: Cell Line Authentication Test Recommendations: https://www.atcc.org/resources/technical-documents/cell-line-authentication-test-recommendations
  Technical/historical reference; no source text, figure or code reproduced.
- ATCC: Mycoplasma Contamination: https://www.atcc.org/the-science/authentication/mycoplasma-contamination
  Technical/historical reference; no source text, figure or code reproduced.
- Thermo Fisher: Manually Counting Cells in a Hemocytometer: https://www.thermofisher.com/us/en/home/references/gibco-cell-culture-basics/cell-culture-protocols/counting-cells-in-a-hemacytometer.html
  Technical/historical reference; no source text, figure or code reproduced.
- Sarkar et al. (2017): Evaluating the quality of a cell counting measurement process via a dilution series experimental design: https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=921053
  Technical/historical reference; no source text, figure or code reproduced.
- Hayflick and Moorhead (1961): The serial cultivation of human diploid cell strains: https://doi.org/10.1016/0014-4827(61)90192-6
  Technical/historical reference; no source text, figure or code reproduced.
- Hayflick: Citation Classic retrospective: https://garfield.library.upenn.edu/classics1978/A1978FC39200002.pdf
  Technical/historical reference; no source text, figure or code reproduced.
- Todd: Hemocytometer photograph: https://commons.wikimedia.org/wiki/File:Hemocytometer.jpg
  CC BY-SA 2.0 photograph by Todd; composed figure also CC BY-SA 2.0.
