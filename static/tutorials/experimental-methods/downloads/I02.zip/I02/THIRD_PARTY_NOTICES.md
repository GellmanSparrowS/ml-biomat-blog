# Public sources and third-party materials

- Minsky — US3013467A, Microscopy apparatus: https://patents.google.com/patent/US3013467A/en
  Historical primary source; original explanatory figure here.
- Nikon MicroscopyU — Introductory Confocal Concepts: https://www.microscopyu.com/techniques/confocal/introductory-confocal-concepts
  Technical reference.
- Nikon MicroscopyU — Specimen Preparation and Imaging: https://www.microscopyu.com/techniques/confocal/specimen-preparation-and-imaging
  Technical reference.
- Nikon MicroscopyU — Critical Aspects of Confocal Microscopy: https://www.microscopyu.com/techniques/confocal/critical-aspects-of-confocal-microscopy
  Technical reference.
- Introduction to Bioimage Analysis — Microscopes & detectors: https://bioimagebook.github.io/chapters/3-fluorescence/4-microscope_types/microscope_types.html
  Book original content CC BY 4.0; linked reading.
- scikit-image — kidney dataset: https://scikit-image.org/docs/stable/api/skimage.data.html#skimage.data.kidney
  Image: Genevieve Buckley / Monash Micro Imaging, 2018, CC0.
