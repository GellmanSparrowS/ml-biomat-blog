"""Confocal microscopy: real optical sections, projections and 3D sampling.

The bundled kidney TIFF is CC0, acquired by Genevieve Buckley,
Monash Micro Imaging (2018), and distributed by scikit-image.
Axes are (z, channel, y, x); spatial steps are 1.25, 1.24, 1.24 um.
"""
from pathlib import Path
import argparse,csv,json
import numpy as np
from PIL import Image,ImageSequence
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse,Rectangle

def load_stack():
    with Image.open(Path(__file__).parent/'data/kidney.tif') as im:
        pages=np.stack([np.asarray(page).astype(np.uint16) for page in ImageSequence.Iterator(im)])
    if pages.shape!=(48,512,512):raise ValueError(f'Unexpected TIFF dimensions {pages.shape}')
    return pages.reshape(16,3,512,512)

def main(output,language):
    output.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','Noto Sans CJK SC','DejaVu Sans'],'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'font.size':11,'axes.titleweight':'bold','text.color':'#243b45','axes.labelcolor':'#243b45','figure.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5'})
    zh=language=='zh';tr=lambda a,b:a if zh else b
    green,blue,red,gray='#168477','#3574a8','#bd624b','#73848a'
    def save(fig,name):
        fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');fig.savefig(output/f'{name}-{language}.png',dpi=140,bbox_inches='tight');plt.close(fig)
    fig,ax=plt.subplots(figsize=(11,6),layout='constrained');ax.set(xlim=(0,12),ylim=(0,7));ax.axis('off')
    ax.set_title(tr('从点照明到针孔检测：共轭平面之间的空间筛选','From point illumination to pinhole detection: spatial selection'))
    for x in [1,2,3]:ax.plot([x,x],[1,4.3],color='#c6d2ce',lw=8,alpha=.65)
    ax.text(.7,5,tr('样品的不同深度','Different specimen depths'))
    ax.add_patch(Ellipse((4.4,2.7),.35,4.3,fc='#d8e8ef',ec=blue))
    ax.text(3.8,5.1,tr('检测光学','Detection optics'))
    for y in [.8,4.6]:
        ax.plot([2,4.4,7.5],[2.7,y,2.7],color=green,lw=2)
        defocused_end=2.7+(2.7-y)*(7.5-6.65)/(6.65-4.4)
        ax.plot([1,4.4,6.65,7.5],[2.7,y,2.7,defocused_end],color=red,lw=1.4,ls='--')
    ax.add_patch(Rectangle((7.4,.3),.25,2.15,fc=gray));ax.add_patch(Rectangle((7.4,2.95),.25,2.2,fc=gray))
    ax.text(6.6,5.4,tr('针孔所在平面','Pinhole plane'))
    ax.add_patch(Rectangle((9,2.1),1.3,1.2,fc='#dde7e3',ec=gray))
    ax.annotate('',(9,2.7),(7.7,2.7),arrowprops={'arrowstyle':'->','color':green,'lw':2})
    ax.text(8.7,3.7,tr('探测器','Detector'));ax.text(8.5,1.5,tr('焦平面光通过\n离焦光大部分被挡住','In-focus light passes\nMuch defocused light is blocked'))
    ax.scatter([2,1],[2.7,2.7],color=[green,red],s=80,zorder=10)
    ax.text(.8,.2,tr('绿色：焦平面；红色虚线：另一深度。光线为原理示意，不按比例。','Green: focal plane; red dashes: another depth. Schematic rays, not to scale.'),fontsize=10)
    ax.text(.8,6.2,tr('1957年申请，1961年授权：明斯基的扫描与双重聚焦构想','Filed 1957, granted 1961: Minsky’s scanning and double-focusing concept'),fontsize=11)
    save(fig,'pinhole')
    stack=load_stack();dz,dy,dx=1.25,1.24,1.24
    volume=stack[:,1].astype(float);z=np.arange(16)*dz
    vmax=3000;extent=[0,512*dx,512*dy,0]
    fig,axes=plt.subplots(2,2,figsize=(10,9),layout='constrained')
    for ax,i in zip(axes.ravel(),[0,5,10,15]):
        im=ax.imshow(volume[i],cmap='magma',vmin=0,vmax=vmax,extent=extent)
        ax.set(xlabel='x / μm',ylabel='y / μm',title=tr(f'层 {i}：z={z[i]:.2f} μm',f'Slice {i}: z={z[i]:.2f} μm'))
    cb=fig.colorbar(im,ax=axes,shrink=.7);cb.set_label(tr('原始数字量，共同显示范围','Raw digital number, common display range'))
    save(fig,'sections')
    projection_max=volume.max(axis=0);projection_mean=volume.mean(axis=0)
    fractions=(volume>1000).mean(axis=(1,2));means=volume.mean(axis=(1,2))
    thresholds=np.arange(500,2001,100);vf=np.array([(volume>t).mean() for t in thresholds])
    fig,axes=plt.subplots(2,2,figsize=(11,9),layout='constrained')
    axes[0,0].imshow(projection_max,cmap='magma',vmin=0,vmax=vmax,extent=extent)
    axes[0,0].set(xlabel='x / μm',ylabel='y / μm',title=tr('A  最大强度投影：保留沿z最亮值','A  Maximum projection: brightest value along z'))
    axes[0,1].imshow(projection_mean,cmap='magma',vmin=0,vmax=vmax,extent=extent)
    axes[0,1].set(xlabel='x / μm',ylabel='y / μm',title=tr('B  平均投影：沿z平均信号','B  Mean projection: average signal along z'))
    for c,color in enumerate([blue,green,red]):
        axes[1,0].plot(z,stack[:,c].mean(axis=(1,2)),'o-',color=color,label=tr(f'通道{c+1}',f'Channel {c+1}'))
    axes[1,0].set(xlabel='z / μm',ylabel=tr('平面平均数字量','Plane-mean digital number'),title=tr('C  各通道沿深度的强度变化','C  Intensity across depth in each channel'));axes[1,0].legend(frameon=False)
    axes[1,1].plot(thresholds,vf*100,'o-',color=green)
    axes[1,1].set(xlabel=tr('阈值 / 数字量','Threshold / digital number'),ylabel=tr('超过阈值的体素比例 / %','Voxels above threshold / %'),title=tr('D  分割结果依赖阈值','D  Segmented fraction depends on threshold'))
    save(fig,'projections')
    nz,nc,ny,nx=stack.shape
    voxel_volume=dx*dy*dz;selected=int(np.count_nonzero(volume>1000))
    summary={'shape_zcyx':[nz,nc,ny,nx],'voxel_volume_um3':voxel_volume,'first_last_center_distance_um':(nz-1)*dz,'voxel_extent_z_um':nz*dz,'threshold':1000,'selected_voxels':selected,'selected_volume_um3':selected*voxel_volume,'selected_fraction':selected/volume.size,'nominal_frame_s':512*512*2e-6*2,'nominal_three_channel_stack_s':512*512*2e-6*2*16*3,'max_projection_mean':float(projection_max.mean()),'mean_projection_mean':float(projection_mean.mean()),'slice_mean_values':means.tolist(),'data_origin':'Real CC0 kidney confocal image, Genevieve Buckley / Monash Micro Imaging, via scikit-image'}
    with (output/'data.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['slice_index','z_um','channel2_mean_digital_number','fraction_above1000']);w.writerows(zip(np.arange(nz),z,means,fractions))
    np.savez_compressed(output/'projections.npz',maximum=projection_max,mean=projection_mean,z_um=z)
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in summary.items() if k!='slice_mean_values'},ensure_ascii=False))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='zh');a=p.parse_args();main(a.output,a.language)
