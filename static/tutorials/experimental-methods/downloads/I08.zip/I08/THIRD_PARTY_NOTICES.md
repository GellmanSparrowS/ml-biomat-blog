# Public sources and third-party materials

- scikit-image — Radon transform example: https://scikit-image.org/docs/stable/auto_examples/transform/plot_radon_transform.html
  BSD-licensed open-source project; independent original implementation and figures here.
- ASTRA Toolbox — 2D geometries: https://astra-toolbox.com/docs/geom2d.html
  Public technical reference; no code or figure copied.
- Bruker — Overview of NRecon, method note MCT-62: https://www.bruker.com/content/dam/bruker/int/en/resources/bbio/pci-community/microct-notes/MN062_NRecon%20overview.pdf
  Public manufacturer manual; figures not reproduced.
- IBSI — Image processing: https://ibsi.readthedocs.io/en/latest/02_Image_processing.html
  Public technical reference; no image reproduced.
- Nobel Foundation — 1979 CT development perspective: https://www.nobelprize.org/prizes/medicine/1979/perspectives/?print=1
  Historical institutional account; original illustration used.
- Kak and Slaney — Principles of Computerized Tomographic Imaging: https://www.slaney.org/pct/pct-toc.html
  Authors permit personal use of electronic book; link only, no book pages or figures reused.
