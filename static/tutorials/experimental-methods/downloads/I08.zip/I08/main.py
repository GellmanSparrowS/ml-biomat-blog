"""Original parallel-beam CT and porous-volume teaching experiment.
Run: python main.py --output results --language en
All specimens and signals in this example are constructed, with known geometry.
"""
from pathlib import Path
import argparse,json
import numpy as np
from scipy import ndimage
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Rectangle

def make_volume(sigma=1.0):
    z,y,x=np.indices((48,48,48));radius=np.where((z>=22)&(z<=25),1.2,4.)
    channel=(x-16)**2+(y-20)**2<=radius**2
    branch=(y-20)**2+(z-12)**2<=3**2
    isolated=(x-35)**2+(y-35)**2+(z-35)**2<=4**2
    pores=channel|branch|isolated
    field=ndimage.gaussian_filter((~pores).astype(float),sigma=sigma,mode='nearest')
    field+=np.random.default_rng(1708).normal(0,.015,field.shape)
    return np.rint(np.clip(field,0,1)*255).astype(np.uint8),pores

def metrics(gray,threshold=128):
    pore=gray<threshold
    labels,n=ndimage.label(pore,structure=ndimage.generate_binary_structure(3,1))
    connected=np.intersect1d(np.unique(labels[0]),np.unique(labels[-1]));connected=connected[connected>0]
    spans=np.isin(labels,connected);count=int(pore.sum())
    return {'pore_voxels':count,'porosity':float(pore.mean()),'components':int(n),
       'spanning_fraction':float(spans.sum()/count) if count else 0.,
       'pore_volume_mm3':count*.01**3},spans

def project(detector,angles,circles):
    result=np.zeros((len(detector),len(angles)))
    for cx,cy,r,mu in circles:
        distances=detector[:,None]-cx*np.cos(angles)-cy*np.sin(angles)
        result+=2*mu*np.sqrt(np.maximum(r*r-distances**2,0))
    return result

def reconstruct(sino,detector,angles,X,Y,filtered=True):
    if filtered:
        nfft=2**int(np.ceil(np.log2(len(detector)*2)))
        frequency=np.fft.rfftfreq(nfft,d=detector[1]-detector[0])
        filtered_sino=np.fft.irfft(np.fft.rfft(sino,n=nfft,axis=0)*2*np.abs(frequency[:,None]),n=nfft,axis=0)[:len(detector)]
    else:filtered_sino=sino
    recon=np.zeros(X.shape)
    for k,theta in enumerate(angles):
        recon+=np.interp((X*np.cos(theta)+Y*np.sin(theta)).ravel(),detector,filtered_sino[:,k],left=0,right=0).reshape(X.shape)
    return recon*np.pi/(2*len(angles))

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args()
    out=args.output;out.mkdir(parents=True,exist_ok=True);tr=lambda z,e:z if args.language=='zh' else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fbfcfc','savefig.facecolor':'#fbfcfc','text.color':'#18344a'})
    def save(f,n):
        f.savefig(out/f'{n}-{args.language}.svg',bbox_inches='tight');f.savefig(out/f'{n}-{args.language}.png',bbox_inches='tight',dpi=150);plt.close(f)
    blue='#186c94';orange='#d27839';green='#188777'
    coord=(np.arange(128)-63.5)*.01;X,Y=np.meshgrid(coord,coord)
    circles=[(0,0,.45,1),(-.16,.08,.12,-.8),(.2,-.12,.08,.6)]
    truth=np.zeros(X.shape)
    for cx,cy,r,mu in circles:truth+=mu*((X-cx)**2+(Y-cy)**2<=r*r)
    detector=(np.arange(256)-127.5)*.01;angles=np.arange(180)*np.pi/180
    sino=project(detector,angles,circles)
    full=reconstruct(sino,detector,angles,X,Y);sparse=reconstruct(sino[:,::15],detector,angles[::15],X,Y)
    back=reconstruct(sino,detector,angles,X,Y,False)
    gray,pores=make_volume(1.);stats,spans=metrics(gray)
    series=[]
    for sigma in [.5,1.,1.5]:
        g,_=make_volume(sigma)
        for t in range(50,206,5):series.append([sigma,t,*[metrics(g,t)[0][k] for k in ['porosity','spanning_fraction','components']]])
    np.savetxt(out/'data.csv',series,delimiter=',',header='blur_sigma_voxels,threshold_uint8,porosity,spanning_fraction,components',comments='')
    np.savez_compressed(out/'volume.npz',gray=gray,truth_pores=pores,voxel_spacing_mm=.01)
    np.savez_compressed(out/'tomography.npz',truth=truth,sinogram=sino,angles_rad=angles,detector_mm=detector,reconstruction=full)
    summary={**stats,'truth_porosity':float(pores.mean()),'fbp_rmse_180':float(np.sqrt(np.mean((full-truth)**2))),
       'fbp_rmse_12':float(np.sqrt(np.mean((sparse-truth)**2))),
       'slab_transmission':float(np.exp(-.4*2)),'slab_log_projection':.8,
       'voxel_volume_mm3':.01**3,'roi_volume_mm3':(48*.01)**3,
       'analytic_disk_center_projection':float(project(np.array([0.]),np.array([0.]),[(0,0,.45,1)])[0,0]),
       'specimen':'Constructed teaching geometries; not a measured CT scan'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    fig,axs=plt.subplots(1,2,figsize=(12,4.7));a,b=axs
    a.set_xlim(-1,8);a.set_ylim(-2,2);a.axis('off');a.add_patch(Circle((3,0),1,facecolor='#cee3e7',edgecolor=blue))
    for yy in [-.65,0,.65]:a.annotate('',xy=(6.5,yy),xytext=(0,yy),arrowprops={'arrowstyle':'->','color':blue})
    a.add_patch(Rectangle((6.5,-1),.3,2,color=orange));a.text(3,1.4,tr('平移 + 改变方向','Translate + change direction'),ha='center')
    a.text(3,-1.45,tr('早期逐线测量的思想','Early line-by-line acquisition'),ha='center');a.set_title(tr('A  从叠影到断层：1970年代','A  From superposition to sections: 1970s'),loc='left')
    b.set_xlim(-1,8);b.set_ylim(-2,2);b.axis('off');b.scatter([0],[0],s=80,color=orange)
    b.add_patch(Circle((3,0),.7,facecolor='#cee3e7',edgecolor=blue));b.plot([6.7,6.7],[-1.7,1.7],lw=5,color=blue)
    for yy in np.linspace(-1.5,1.5,7):b.plot([0,6.7],[0,yy],color=orange,lw=1,alpha=.65)
    b.annotate('',xy=(3.7,.8),xytext=(2.3,.8),arrowprops={'arrowstyle':'->','connectionstyle':'arc3,rad=-.5','color':green})
    b.text(3,-1.35,tr('样品旋转','Rotating sample'),ha='center');b.set_title(tr('B  实验室锥束几何的侧视','B  Side view of laboratory cone-beam geometry'),loc='left',fontsize=11)
    save(fig,'geometry')
    fig,ax=plt.subplots(2,3,figsize=(13,8));extent=[-.64,.64,-.64,.64]
    items=[(truth,'A  已知衰减分布','A  Known attenuation'),(sino,'B  多角度投影：正弦图','B  Angular projections: sinogram'),(back,'C  未滤波反投影','C  Unfiltered backprojection'),(sparse,'D  12方向滤波重建','D  FBP: 12 directions'),(full,'E  180方向滤波重建','E  FBP: 180 directions'),(full-truth,'F  重建减真值','F  Reconstruction minus truth')]
    for k,(a,(arr,z,e)) in enumerate(zip(ax.ravel(),items)):
        if k==1:im=a.imshow(arr,extent=[0,180,detector[-1],detector[0]],aspect='auto',cmap='magma');a.set_xlabel(tr('方向 / °','Direction / °'));a.set_ylabel(tr('探测位置 / mm','Detector coordinate / mm'))
        else:
            kw={'cmap':'coolwarm','vmin':-.25,'vmax':.25} if k==5 else {'cmap':'gray','vmin':0,'vmax':float(back.max()) if k==2 else 1.6}
            im=a.imshow(arr,extent=extent,origin='lower',**kw);a.set_xlabel('x / mm');a.set_ylabel('y / mm')
        a.set_title(tr(z,e),loc='left',fontsize=11)
        cb=fig.colorbar(im,ax=a,shrink=.7);cb.set_label('1' if k in [1,2] else 'mm⁻¹')
    fig.tight_layout();save(fig,'reconstruction')
    fig,ax=plt.subplots(2,2,figsize=(11,9));a,b,c,d=ax.ravel()
    a.imshow(gray[:,20,:],origin='lower',extent=[0,.48,0,.48],cmap='gray',vmin=0,vmax=255);a.set_title(tr('A  y=20截面：窄颈与分支','A  Section y=20: throat and branch'),loc='left');a.set_xlabel('x / mm');a.set_ylabel('z / mm')
    colors=np.zeros(gray.shape+(3,));colors[gray<128]=[.82,.47,.22];colors[spans]=[.09,.53,.47]
    b.imshow(colors[:,20,:],origin='lower',extent=[0,.48,0,.48]);b.set_title(tr('B  绿色孔隙连接z两端','B  Green pores connect both z faces'),loc='left');b.set_xlabel('x / mm');b.set_ylabel('z / mm')
    series=np.asarray(series)
    for sig,color in zip([.5,1,1.5],[blue,green,orange]):
        r=series[series[:,0]==sig];c.plot(r[:,1],r[:,2]*100,color=color,label=f'σ={sig:g} voxel');d.plot(r[:,1],r[:,3],color=color,label=f'σ={sig:g} voxel')
    c.axhline(pores.mean()*100,color='#a1abb2',ls=':',label=tr('构造真值','Constructed truth'));c.set_xlabel(tr('灰度阈值','Gray threshold'));c.set_ylabel(tr('孔隙率 / %','Porosity / %'));c.legend(fontsize=9);c.set_title(tr('C  体积分数随分割变化','C  Volume fraction changes with segmentation'),loc='left')
    d.set_xlabel(tr('灰度阈值','Gray threshold'));d.set_ylabel(tr('贯通孔隙 / 全部孔隙','Spanning pore volume / all pore volume'));d.set_ylim(-.03,1.03);d.legend(fontsize=9);d.set_title(tr('D  窄颈连接可突然改变','D  Throat connectivity can change abruptly'),loc='left')
    fig.tight_layout();save(fig,'porosity')
    print(json.dumps(summary))

if __name__=='__main__':main()
