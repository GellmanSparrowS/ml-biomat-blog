"""TGA mass accounting, derivatives, hydrate stoichiometry and rate effects.

All traces are constructed teaching models, not measurements of a real specimen.
Run: python main.py --output results --language en
"""
from pathlib import Path
import argparse
import json
import numpy as np
from scipy.special import expit
from scipy.signal import savgol_filter
from scipy.integrate import cumulative_trapezoid
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon

P=argparse.ArgumentParser();P.add_argument('--output',type=Path,required=True)
P.add_argument('--language',choices=['zh','en'],default='en');args=P.parse_args()
OUT=args.output;OUT.mkdir(parents=True,exist_ok=True);ZH=args.language=='zh'
def L(z,e):return z if ZH else e
plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],
 'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
 'axes.facecolor':'#fcfbf7','figure.facecolor':'#fcfbf7','svg.fonttype':'none',
 'axes.labelcolor':'#20333e','text.color':'#20333e','axes.titleweight':'bold'})
B='#167d9a';R='#d35f47';G='#37967d';Y='#c49b35';K='#20333e'
def save(fig,name):
 for ext in ['svg','png']:fig.savefig(OUT/f'{name}-{args.language}.{ext}',dpi=145,bbox_inches='tight')
 plt.close(fig)
def csv(name,headers,cols):np.savetxt(OUT/name,np.column_stack(cols),delimiter=',',header=','.join(headers),comments='',fmt='%.10g')
def frac(x,center,width):
 a=expit((x-center)/width);a0=expit((x[0]-center)/width)
 return (a-a0)/(1-a0)

rng=np.random.default_rng(720)
t=np.arange(0,95.0001,.05);T=np.minimum(25+10*t,600)
water=frac(T,95,12);pyro=frac(T,350,18)
burn=np.where(t>=70,1-np.exp(-.5*np.maximum(t-70,0)),0)
true=10-.8*water-5.4*pyro-1.8*burn
blank=.028+.00008*(T-25)+.00012*t+.025*np.exp(-np.maximum(t-70,0)/.25)*(t>=70)
raw=true+blank+rng.normal(0,.0015,t.size)
blank_record=blank+rng.normal(0,.001,t.size);corrected=raw-blank_record
m0=10.0 # Independent initial mass, mg; every percentage uses this denominator.
plateau=lambda mask:float(np.mean(corrected[mask]))
dry=plateau((T>=180)&(T<=220));inert=plateau((t>=60)&(t<=68));ash=plateau(t>=90)
losses=np.array([m0-dry,dry-inert,inert-ash,ash])/m0*100
dtg={w:-savgol_filter(corrected,w,3,deriv=1,delta=.05)/m0*100 for w in [7,21,61]}
polymer=(dry-inert)/.9;carbon=inert-ash-.1*polymer
csv('tga_scan.csv',['time_min','temperature_C','true_mass_mg','raw_mass_mg','blank_mass_mg','corrected_mass_mg','dtg_window7_percent_per_min','dtg_window21_percent_per_min','dtg_window61_percent_per_min'],[t,T,true,raw,blank_record,corrected,dtg[7],dtg[21],dtg[61]])

# Figure 1: original explanatory apparatus, not a historical reconstruction.
fig,axs=plt.subplots(1,2,figsize=(12,4.9),gridspec_kw={'width_ratios':[1.1,1]},layout='constrained')
a=axs[0];a.set(xlim=(0,10),ylim=(0,8));a.axis('off')
a.add_patch(Rectangle((3.7,1.1),3.2,3.6,fill=False,ec=R,lw=3))
a.add_patch(Rectangle((4,1.4),2.6,3,fill=False,ec=R,lw=1,ls='--'))
a.plot([2,7.5],[6.4,6.4],color=K,lw=3)
a.add_patch(Polygon([[4.4,5.9],[5,6.4],[5.6,5.9]],color=K))
a.plot([2.4,2.4],[6.4,5.3],color=K);a.add_patch(Rectangle((1.7,4.9),1.4,.4,color=B))
a.plot([5.3,5.3],[6.4,3.6],color=K,lw=1.5)
a.add_patch(Polygon([[4.7,3.6],[4.9,3.2],[5.7,3.2],[5.9,3.6]],fc=Y,ec=K))
a.annotate('',xy=(4.2,2.1),xytext=(2.1,2.1),arrowprops={'arrowstyle':'->','color':G,'lw':2})
a.annotate('',xy=(8.4,4.2),xytext=(6.7,4.2),arrowprops={'arrowstyle':'->','color':G,'lw':2})
a.text(1.9,1.4,L('受控气体入口','Controlled gas'),color=G,ha='center')
a.text(8,4.7,L('排出气体','Evolved gas'),color=G,ha='center')
a.text(2.4,7,L('质量读数','Mass readout'),ha='center')
a.text(5.3,2.7,L('坩埚与样品','Pan + specimen'),ha='center',fontsize=9)
a.text(7.2,2.5,L('炉体','Furnace'),color=R)
a.text(5,.25,L('连续称量：把“加热后再称”变为一条轨迹\n原理示意；联系 Honda 与 Saito 的早期热天平工作','Continuous weighing replaces interrupted heat–cool–weigh cycles\nPrinciple diagram; early thermobalance work of Honda and Saito'),ha='center',fontsize=9)
a.set_title(L('A  质量、温度、气氛同时记录','A  Mass, temperature and atmosphere'))
a=axs[1];a.plot(t,T,color=R,lw=2);a.set(xlabel=L('时间 / min','Time / min'),ylabel=L('程序温度 / °C','Programmed temperature / °C'),ylim=(0,670))
a.axvspan(0,70,color=B,alpha=.08);a.axvspan(70,95,color=G,alpha=.12)
a.axvline(70,color=G,ls='--');a.text(25,110,L('氮气','Nitrogen'),color=B);a.text(79,110,L('空气','Air'),color=G)
a.annotate(L('600 °C 保温','600 °C hold'),xy=(65,600),xytext=(38,470),arrowprops={'arrowstyle':'->','color':K})
a.set_title(L('B  构造样品的实验程序','B  Program for the teaching specimen'));save(fig,'balance-history')

fig,axs=plt.subplots(2,2,figsize=(12,8.4),layout='constrained')
a=axs[0,0];a.plot(t,100*raw/m0,color=Y,lw=1,label=L('原始','Raw'));a.plot(t,100*corrected/m0,color=B,lw=1.2,label=L('减去空坩埚','Blank corrected'))
a.axvline(70,color=G,ls='--');a.set(xlabel=L('时间 / min','Time / min'),ylabel=L('剩余质量 / 初始质量 %','Remaining mass / initial mass %'),title=L('A  同时保留原始与校正轨迹','A  Preserve raw and corrected traces'));a.legend(frameon=False)
a=axs[0,1];a.plot(t,blank_record,color=Y,lw=1);a.axvline(70,color=G,ls='--');a.set(xlim=(66,75),xlabel=L('时间 / min','Time / min'),ylabel=L('空坩埅读数 / mg','Empty-pan reading / mg'),title=L('B  换气也会推动天平读数','B  A gas switch also moves the balance'))
a=axs[1,0]
for w,c in [(7,'#a8b8bf'),(21,B),(61,R)]:a.plot(t,dtg[w],color=c,lw=1,label=L(f'{(w-1)*.05:.1f} min 窗口',f'{(w-1)*.05:.1f} min window'))
a.set(xlim=(66,78),xlabel=L('时间 / min','Time / min'),ylabel=L('失重速率 / % 初始质量·min⁻¹','Mass-loss rate / % initial mass min⁻¹'),title=L('C  导数放大噪声，平滑改变尖锐转折','C  Derivatives amplify noise; smoothing changes corners'));a.legend(frameon=False,fontsize=9)
a=axs[1,1];labels=L(['低温失重','氮气热解','空气中失重','最终残余'],['Low-T loss','N₂ pyrolysis','Air-stage loss','Final residue'])
a.bar(labels,losses,color=[B,R,K,Y]);a.set(ylabel=L('初始质量的百分比 / %','Percent of initial mass / %'),ylim=(0,65),title=L('D  先得到操作定义的四份质量','D  Four operationally defined mass fractions'))
for i,v in enumerate(losses):a.text(i,v+1,f'{v:.2f}',ha='center')
save(fig,'mass-derivative')

y=np.linspace(0,.25,151);inferred_poly=54/(1-y);inferred_carbon=18-y*inferred_poly
fig,axs=plt.subplots(1,2,figsize=(12,5),layout='constrained')
a=axs[0];parts=[(8,B,L('水 8','Water 8')),(54,R,L('挥发产物 54','Volatile products 54')),(6,'#bfa5a0',L('新生成炭 6','New char 6')),(12,K,L('原有炭黑 12','Added carbon 12')),(20,Y,L('矿物残余 20','Mineral residue 20'))]
left=0
for value,c,label in parts:a.barh(.5,value,left=left,color=c,height=.35);a.text(left+value/2,.76,label,rotation=45,ha='left',fontsize=9);left+=value
a.set(xlim=(0,105),ylim=(0,1.65),yticks=[],xlabel=L('初始质量的百分比 / %','Percent of initial mass / %'),title=L('A  60% 聚合物留下了 6% 炭','A  60% polymer leaves 6% char'))
a.annotate(L('空气阶段一起烧掉：18%','Consumed together in air: 18%'),xy=(70,.30),xytext=(43,.06),arrowprops={'arrowstyle':'->','color':K},fontsize=9)
a=axs[1];a.plot(y,inferred_poly,color=R,lw=2,label=L('推算聚合物','Inferred polymer'));a.plot(y,inferred_carbon,color=K,lw=2,label=L('推算原有炭黑','Inferred added carbon'));a.axvline(.1,color=B,ls='--');a.scatter([.1,.1],[60,12],c=[R,K]);a.set(xlabel=L('独立给定的聚合物残炭比例 y','Independently specified polymer char yield y'),ylabel=L('初始样品质量的百分比 / %','Percent of initial specimen mass / %'),ylim=(0,76),title=L('B  相同失重分配，可有不同原始组成','B  Same stage losses, different original compositions'));a.legend(frameon=False)
save(fig,'char-composition')

# Stoichiometry uses rounded standard atomic weights, g/mol.
Ca,C,O,H=40.078,12.011,15.999,1.008
MW=Ca+2*C+5*O+2*H;waterMW=2*H+O;coMW=C+O;co2MW=C+2*O;oxideMW=Ca+O
stoich=np.array([waterMW,coMW,co2MW,oxideMW])/MW*100
Th=np.linspace(25,900,1751)
hm=100-stoich[0]*frac(Th,170,12)-stoich[1]*frac(Th,500,18)-stoich[2]*frac(Th,750,22)
csv('hydrate.csv',['temperature_C','constructed_remaining_percent'],[Th,hm])
fig,axs=plt.subplots(1,2,figsize=(12,5),layout='constrained')
a=axs[0];a.plot(Th,hm,color=B,lw=2);a.set(xlabel=L('温度 / °C','Temperature / °C'),ylabel=L('初始质量的百分比 / %','Percent of initial mass / %'),ylim=(30,105),title=L('A  化学计量规定台阶高度','A  Stoichiometry fixes step heights'))
for x,z,lab in [(220,91,'H₂O'),(560,72,'CO'),(810,48,'CO₂')]:a.text(x,z,lab,color=R)
a.text(75,40,L('曲线为构造模型，转变温度并非测量结果','Constructed curve; transition temperatures are not measurements'),fontsize=8)
a=axs[1];a.axis('off');a.set(xlim=(0,1),ylim=(0,1));a.set_title(L('B  从反应式核对每一份质量','B  Account for every portion by reaction'))
for yy,formula,note,c in [(.86,'CaC₂O₄·H₂O',f'{MW:.3f} g/mol',K),(.64,'CaC₂O₄',L(f'失水 {stoich[0]:.3f}%',f'Water loss {stoich[0]:.3f}%'),B),(.42,'CaCO₃',L(f'释放 CO：{stoich[1]:.3f}%',f'CO loss: {stoich[1]:.3f}%'),R),(.20,'CaO',L(f'释放 CO₂：{stoich[2]:.3f}%；余 {stoich[3]:.3f}%',f'CO₂ loss: {stoich[2]:.3f}%; residue {stoich[3]:.3f}%'),Y)]:
 a.text(.06,yy,formula,fontsize=17,color=c,va='center');a.text(.06,yy-.07,note,fontsize=10)
 if yy>.2:a.annotate('',xy=(.82,yy-.14),xytext=(.82,yy),arrowprops={'arrowstyle':'->','color':K})
save(fig,'hydrate-stoichiometry')

Ea=140000.;Af=1e10;Rg=8.314462618
Tk=np.linspace(298.15,923.15,6251);Tc=Tk-273.15;k=Af*np.exp(-Ea/(Rg*Tk))
rates={};metrics={}
for rate in [5,10,20]:
 hazard=cumulative_trapezoid(k/rate,Tk,initial=0);alpha=-np.expm1(-hazard);rates[rate]=alpha
 metrics[str(rate)]={'T5_C':float(np.interp(.05,alpha,Tc)),'peak_C':float(Tc[np.argmax(k*(1-alpha))])}
ti=np.linspace(0,360,721);ki=Af*np.exp(-Ea/(Rg*573.15));ai=-np.expm1(-ki*ti)
csv('kinetics.csv',['temperature_C','conversion_5Kmin','conversion_10Kmin','conversion_20Kmin'],[Tc,rates[5],rates[10],rates[20]])
csv('isothermal.csv',['time_min','conversion_at300C'],[ti,ai])
fig,axs=plt.subplots(1,2,figsize=(12,5),layout='constrained')
a=axs[0]
for rate,c in [(5,B),(10,R),(20,G)]:a.plot(Tc,100*(1-rates[rate]),color=c,lw=2,label=f'{rate} °C/min')
a.set(xlim=(300,520),ylim=(0,105),xlabel=L('温度 / °C','Temperature / °C'),ylabel=L('未反应份额 / %','Unreacted fraction / %'),title=L('A  同一动力学，快扫曲线更靠右','A  Same kinetics; faster ramps shift right'));a.legend(frameon=False)
a=axs[1];a.plot(ti,100*ai,color=B,lw=2);a.scatter([60,360],100*(-np.expm1(-ki*np.array([60,360]))),color=R);a.set(xlabel=L('在 300 °C 保持的时间 / min','Hold time at 300 °C / min'),ylabel=L('转化比例 / %','Converted fraction / %'),title=L('B  较低温度也会累积反应','B  A lower temperature still accumulates reaction'));a.text(15,100*ai[-1]*.73,L('单步一阶构造模型\nA = 10¹⁰ min⁻¹，Eₐ = 140 kJ/mol','Constructed single-step first-order model\nA = 10¹⁰ min⁻¹; Eₐ = 140 kJ/mol'),fontsize=9)
save(fig,'rate-and-hold')

summary={'data_kind':'constructed teaching datasets','seed':720,'initial_mass_mg':m0,
 'dry_plateau_mg':dry,'inert_plateau_mg':inert,'final_plateau_mg':ash,
 'water_loss_percent':float(losses[0]),'pyrolysis_loss_percent':float(losses[1]),'air_loss_percent':float(losses[2]),'residue_percent':float(losses[3]),
 'char_corrected_polymer_percent':float(polymer/m0*100),'char_corrected_added_carbon_percent':float(carbon/m0*100),
 'ideal_dry_basis_residue_percent':2/9.2*100,'hydrate_water_loss_percent':float(stoich[0]),'hydrate_total_mass_percent':float(stoich.sum()),
 'hydrate_formula_mass_g_per_mol':MW,'hydrate_water_number':float((stoich[0]/100)*(MW-waterMW)/(waterMW*(1-stoich[0]/100))),
 'T5_5Kmin_C':metrics['5']['T5_C'],'T5_10Kmin_C':metrics['10']['T5_C'],'T5_20Kmin_C':metrics['20']['T5_C'],
 'isothermal_rate_at300C_per_min':float(ki),'isothermal_60min_conversion_percent':float(-np.expm1(-ki*60)*100),'isothermal_360min_conversion_percent':float(ai[-1]*100),
 'char_ambiguity_upper_y':18/(54+18)}
assert abs(sum(losses)-100)<1e-12
assert abs(polymer-6)<.03 and abs(carbon-1.2)<.03
assert abs(stoich.sum()-100)<1e-12 and abs(summary['hydrate_water_number']-1)<1e-12
assert metrics['5']['T5_C']<metrics['10']['T5_C']<metrics['20']['T5_C']
assert np.all(np.diff(ai)>=0)
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
