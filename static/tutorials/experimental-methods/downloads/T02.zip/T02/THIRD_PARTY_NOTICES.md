# Public sources and third-party materials

- Saito: A New Method of Studying Thermal Decomposition of Substances: https://www.jstage.jst.go.jp/article/pjab1912/2/2/2_2_58/_pdf/-char/en
  Technical/historical reference only; no source artwork or measured data reproduced.
- Sircar: Composition Analysis of Rubber by Thermogravimetry, TA083: https://www.tainstruments.com/pdf/literature/TA083.pdf
  Technical/historical reference only; no source artwork or measured data reproduced.
- NETZSCH: TGA Measurements by Means of the BeFlat Correction: https://analyzing-testing.netzsch.com/en-AU/application-literature/tga-measurements-by-means-of-the-beflat-correction/
  Technical/historical reference only; no source artwork or measured data reproduced.
- NETZSCH: TGA Measurements on Calcium Oxalate Monohydrate: https://analyzing-testing.netzsch.com/en/application-literature/tga-measurements-on-calcium-oxalate-monohydrate
  Technical/historical reference only; no source artwork or measured data reproduced.
- Suzanne et al.: A Round-Robin Study on Decomposition of Calcium Oxalate Monohydrate by Thermogravimetry: https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=935144
  Technical/historical reference only; no source artwork or measured data reproduced.
- NETZSCH Kinetics Neo: Master Plot Verification: https://kinetics.netzsch.com/en/learn/master-plot
  Technical/historical reference only; no source artwork or measured data reproduced.
- NETZSCH Kinetics Neo: Conversion for Incomplete Measured Data: https://kinetics.netzsch.com/en/learn/how-to-calculate-conversion-for-incomplete-measured-data
  Technical/historical reference only; no source artwork or measured data reproduced.
- TA Instruments: High Resolution Thermogravimetric Analysis, TA023: https://www.tainstruments.com/pdf/literature/TA023.pdf
  Technical/historical reference only; no source artwork or measured data reproduced.
