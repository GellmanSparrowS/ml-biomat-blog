"""Surface-tension measurements: plate forces, pendant shape and surface age.
All measured-looking points are constructed teaching observations.
Water reference: IAPWS R1-76(2014), https://iapws.org/technical-guidance/release/Surf-H2O
Run: python main.py --output results --language en
"""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle

def water_tension(temperature_c):
    tau=1-(np.asarray(temperature_c)+273.15)/647.096
    return 235.8*tau**1.256*(1-.625*tau)

def plate(gamma_mNm,theta_deg,depth_mm):
    width=.010;thickness=.0001;perimeter=2*(width+thickness)
    capillary=(gamma_mNm/1000)*perimeter*np.cos(np.deg2rad(theta_deg))
    buoyancy=1000*9.81*width*thickness*(np.asarray(depth_mm)/1000)
    return (capillary-buoyancy)*1000

def pendant(z_mm,gamma_mNm=50.,apex_radius_mm=1.):
    """Axisymmetric pendant interface: z upward from bottom apex, arc length s.
    dr/ds=cos(phi), dz/ds=sin(phi). Pressure decreases upward, giving
    dphi/ds=2/b-(Delta_rho*g/gamma)*z-sin(phi)/r.
    All numerical lengths here are mm; coefficient converts SI to mm^-2.
    """
    b=apex_radius_mm;k=1000*9.81/(gamma_mNm/1000)*1e-6;eps=1e-5
    def fun(s,y):
        r,z,phi=y
        return [np.cos(phi),np.sin(phi),2/b-k*z-np.sin(phi)/max(r,1e-10)]
    zmax=float(np.max(z_mm))+.01
    def stop(s,y):return y[1]-zmax
    stop.terminal=True;stop.direction=1
    sol=solve_ivp(fun,[eps,6*b],[eps,eps*eps/(2*b),eps/b],events=stop,max_step=.01,rtol=1e-8,atol=1e-10)
    return np.interp(z_mm,sol.y[1],sol.y[0])

def dynamic(age_s):return 35+37*np.exp(-np.asarray(age_s)/2)

def breakpoint_fit(logc,y):
    knots=np.linspace(-.5,.5,401);loss=[];coeffs=[]
    for k in knots:
        X=np.column_stack([np.ones(len(logc)),np.minimum(logc-k,0)])
        coeff=np.linalg.lstsq(X,y,rcond=None)[0];loss.append(np.sum((X@coeff-y)**2));coeffs.append(coeff)
    j=int(np.argmin(loss));return knots[j],coeffs[j],knots,np.asarray(loss)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args()
    out=args.output;out.mkdir(parents=True,exist_ok=True);tr=lambda z,e:z if args.language=='zh' else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fbfcfc','savefig.facecolor':'#fbfcfc','text.color':'#18344a'})
    blue='#186c94';green='#188777';orange='#d27839'
    def save(f,n):f.savefig(out/f'{n}-{args.language}.svg',bbox_inches='tight');f.savefig(out/f'{n}-{args.language}.png',bbox_inches='tight',dpi=150);plt.close(f)
    rng=np.random.default_rng(1804);depth=np.linspace(0,5,31);forces=plate(50,0,depth)+rng.normal(0,.003,len(depth));coeff=np.polyfit(depth,forces,1)
    fitted_gamma=coeff[1]/.0202
    z=np.linspace(.08,1.6,70);r=pendant(z);r_obs=r+rng.normal(0,.003,len(z))
    fit=least_squares(lambda p:pendant(z,p[0],p[1])-r_obs,[48,1.02],bounds=([20,.8],[90,1.2]),xtol=1e-10,ftol=1e-10,gtol=1e-10)
    gamma_fit,b_fit=fit.x;pred=pendant(z,gamma_fit,b_fit)
    logc=np.linspace(-2,1,45);c=10**logc;gamma_true=35-18.5*np.minimum(logc,0);gamma_obs=gamma_true+rng.normal(0,.3,len(c));k,bc,knots,loss=breakpoint_fit(logc,gamma_obs)
    noiseless_k,*_=breakpoint_fit(logc,gamma_true)
    summary={'plate_gamma_fit_mNm':float(fitted_gamma),'plate_intercept_mN':float(coeff[1]),'plate_slope_mN_per_mm':float(coeff[0]),
       'plate_force_50_zero_mN':float(plate(50,0,0)),'plate_force_50_5mm_mN':float(plate(50,0,5)),
       'plate_30deg_naive_mNm':float(50*np.cos(np.pi/6)),
       'pendant_gamma_fit_mNm':float(gamma_fit),'pendant_apex_radius_fit_mm':float(b_fit),
       'pendant_residual_rms_um':float(np.sqrt(np.mean((r_obs-pred)**2))*1000),
       'cmc_fit_mM':float(10**k),'cmc_noiseless_mM':float(10**noiseless_k),
       'surface_age_2s_mNm':float(dynamic(2)),'water20_mNm':float(water_tension(20)),
       'data_kind':'Constructed plate/drop/surfactant observations; IAPWS water reference calculation'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    np.savetxt(out/'data.csv',np.column_stack([depth,forces,np.polyval(coeff,depth)]),delimiter=',',header='depth_mm,force_mN,fit_mN',comments='')
    np.savetxt(out/'pendant.csv',np.column_stack([z,r_obs,pred]),delimiter=',',header='height_above_bottom_mm,observed_radius_mm,fitted_radius_mm',comments='')
    np.savetxt(out/'concentration.csv',np.column_stack([c,gamma_obs,gamma_true]),delimiter=',',header='concentration_mM,observed_tension_mNm,specified_tension_mNm',comments='')
    fig,axs=plt.subplots(1,2,figsize=(12,4.7));a,b=axs
    a.set_xlim(0,10);a.set_ylim(0,5);a.axis('off');a.add_patch(Rectangle((.5,.8),9,3,facecolor='#d2e9eb',edgecolor=blue,lw=2));a.add_patch(Rectangle((6,.8),.22,3,color=orange))
    for x in np.linspace(1,5.5,9):a.scatter(x,2.2+.45*np.sin(x*2),s=35,color=green)
    a.annotate('',xy=(4.8,4.2),xytext=(6.1,4.2),arrowprops={'arrowstyle':'->','color':orange,'lw':2});a.text(5,4.65,tr('移动隔板，压缩受限表面','Move a barrier; compress a confined surface'),ha='center',fontsize=10)
    a.plot([2.5,2.5],[2.5,4.1],color='#455b6b');a.add_patch(Circle((2.5,2.5),.25,facecolor='white',edgecolor=blue));a.text(5,.3,tr('Pockels：控制面积与表面污染','Pockels: area and surface contamination'),ha='center',fontsize=10);a.set_title(tr('A  1891年的表面研究思想','A  Surface experiments reported in 1891'),loc='left')
    b.set_xlim(-3,3);b.set_ylim(-2.4,2.3);b.axis('off')
    for sign in [-1,1]:
        xx=np.linspace(.3,3,150);yy=.5*np.exp(-((xx-.3)/.35)**.5)
        b.fill_between(sign*xx,-2.4,yy,color='#d2e9eb');b.plot(sign*xx,yy,color=blue)
    b.add_patch(Rectangle((-.3,-1),.6,2.6,facecolor='#b0bdc5',edgecolor='#455b6b'));b.plot([0,0],[1.6,2.2],color='#455b6b')
    for x in [-.3,.3]:b.annotate('',xy=(x,-.65),xytext=(x,.45),arrowprops={'arrowstyle':'->','color':orange,'lw':2})
    b.annotate('',xy=(0,.15),xytext=(0,-1.5),arrowprops={'arrowstyle':'->','color':green,'lw':2});b.text(.7,-.65,tr('毛细力\n向下','Capillary force\ndownward'),fontsize=10);b.text(.4,-1.7,tr('浮力向上','Buoyancy upward'),fontsize=10);b.set_title(tr('B  Wilhelmy板：读出界面力','B  Wilhelmy plate: read interfacial force'),loc='left',fontsize=11);save(fig,'principle')
    fig,axs=plt.subplots(1,2,figsize=(12,4.8));a,b=axs
    a.scatter(depth,forces,color=blue,s=25,label=tr('构造观测','Constructed observations'));a.plot(depth,np.polyval(coeff,depth),color=orange,label=tr('线性拟合','Linear fit'));a.set_xlabel(tr('浸入深度 / mm','Immersion depth / mm'));a.set_ylabel(tr('扣除干板重量的力 / mN','Force after dry-weight tare / mN'));a.legend();a.set_title(tr('A  零深度截距分离浮力','A  Zero-depth intercept separates buoyancy'),loc='left')
    theta=np.linspace(0,70,200);b.plot(theta,50*np.cos(np.deg2rad(theta)),color=orange);b.axhline(50,color=green,ls='--',label=tr('规定真实张力50 mN/m','Specified true tension 50 mN/m'));b.set_xlabel(tr('实际接触角 / °','Actual contact angle / °'));b.set_ylabel(tr('假定完全润湿得到的张力 / mN/m','Tension inferred assuming complete wetting / mN/m'));b.legend(fontsize=9);b.set_title(tr('B  把接触角误当作零','B  Incorrectly treating contact angle as zero'),loc='left');fig.tight_layout();save(fig,'plate')
    fig,axs=plt.subplots(1,2,figsize=(11.5,5.5));a,b=axs
    zfull=np.linspace(0,1.8,240);rfull=pendant(zfull,gamma_fit,b_fit)
    for sign in [-1,1]:a.scatter(sign*r_obs,z,color=blue,s=13);a.plot(sign*rfull,zfull,color=orange,lw=2)
    a.set_aspect('equal');a.set_xlabel(tr('径向位置 / mm','Radial position / mm'));a.set_ylabel(tr('距底端顶点的高度 / mm','Height above bottom apex / mm'));a.set_title(tr('A  Young–Laplace：悬滴下段轮廓','A  Young–Laplace: lower pendant profile'),loc='left',fontsize=11)
    b.scatter(z,(r_obs-pred)*1000,s=20,color=blue);b.axhline(0,color='#a1abb2');b.set_xlabel(tr('距底端顶点的高度 / mm','Height above bottom apex / mm'));b.set_ylabel(tr('径向残差 / μm','Radial residual / μm'));b.set_title(tr('B  同时估计张力与顶点半径','B  Fit tension and apex radius together'),loc='left');fig.tight_layout();save(fig,'pendant')
    fig,axs=plt.subplots(2,2,figsize=(11.5,8.7));a,b,d,e=axs.ravel();time=np.logspace(-2,2,200)
    a.semilogx(time,dynamic(time),color=blue);a.axhline(35,color=green,ls='--');a.set_xlabel(tr('表面年龄 / s','Surface age / s'));a.set_ylabel('γ / mN/m');a.set_title(tr('A  规定的动态吸附教学曲线','A  Prescribed dynamic teaching curve'),loc='left')
    b.semilogx(c,gamma_obs,'o',color=blue,ms=4);b.semilogx(c,bc[0]+bc[1]*np.minimum(logc-k,0),color=orange);b.axvline(10**k,color=green,ls='--');b.set_xlabel(tr('浓度 / mmol/L','Concentration / mmol/L'));b.set_ylabel('γ / mN/m');b.set_title(tr('B  转折与平台，构造数据','B  Break and plateau, constructed data'),loc='left')
    d.plot(10**knots,loss,color=orange);d.set_xlabel(tr('候选转折浓度 / mmol/L','Candidate break concentration / mmol/L'));d.set_ylabel(tr('残差平方和 / (mN/m)²','Residual sum of squares / (mN/m)²'));d.set_title(tr('C  检查转折选择的代价','C  Inspect the cost of breakpoint choices'),loc='left')
    temp=np.linspace(1,90,100);e.plot(temp,water_tension(temp),color=green);e.scatter([20],[water_tension(20)],color=orange);e.set_xlabel(tr('温度 / °C','Temperature / °C'));e.set_ylabel('γ / mN/m');e.set_title(tr('D  IAPWS纯水–水蒸气参考计算','D  IAPWS water–vapor reference calculation'),loc='left',fontsize=11);fig.tight_layout();save(fig,'dynamic')
    print(json.dumps(summary))

if __name__=='__main__':main()
