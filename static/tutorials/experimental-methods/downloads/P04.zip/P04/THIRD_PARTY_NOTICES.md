# Public sources and third-party materials

- Agnes Pockels historical correspondence archive: https://www.uni-kiel.de/anorg/lagaly/group/klausSchiver/pockels.pdf
  Historical facts paraphrased; no archive figures reproduced.
- KRÜSS — Surface tension: https://www.kruss-scientific.com/en/know-how/glossary/surface-tension
  Technical reference; no figures reused.
- KRÜSS — Wilhelmy plate method: https://www.kruss-scientific.com/en/know-how/glossary/wilhelmy-plate-method
  Technical reference; no figures reused.
- KRÜSS — Pendant drop: https://www.kruss-scientific.com/en/know-how/glossary/pendant-drop
  Technical reference; no figures reused.
- KRÜSS — Surface age: https://www.kruss-scientific.com/en/know-how/glossary/surface-age
  Technical reference; no figures reused.
- KRÜSS — Bubble pressure tensiometer: https://www.kruss-scientific.com/en/know-how/glossary/bubble-pressure-tensiometer
  Technical reference; no figures reused.
- KRÜSS — Critical micelle concentration: https://www.kruss-scientific.com/en/know-how/glossary/critical-micelle-concentration-cmc-and-surfactant-concentration
  Technical reference; no figures reused.
- IAPWS — Revised Release on Surface Tension of Ordinary Water Substance: https://iapws.org/technical-guidance/release/Surf-H2O
  Reference relation cited; original plots calculated here.
