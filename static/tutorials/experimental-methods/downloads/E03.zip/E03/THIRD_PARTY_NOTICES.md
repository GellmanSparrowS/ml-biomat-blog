# Public sources and third-party materials

- Grizzi et al. (1995). Hydrolytic degradation of devices based on poly(DL-lactic acid) size-dependence: https://pubmed.ncbi.nlm.nih.gov/7772670/
  Abstract reference; no figures reproduced.
- Höglund et al. (2012). Crucial Differences in the Hydrolytic Degradation between Industrial Polylactide and Laboratory-Scale Poly(L-lactide): https://pmc.ncbi.nlm.nih.gov/articles/PMC3359772/
  Technical reference; no figures reproduced.
- Tsuji et al. (2011). Synthesis and Hydrolytic Degradation of Substituted Poly(DL-Lactic Acid)s: https://www.mdpi.com/1996-1944/4/8/1384
  Technical reference; no figures reproduced.
- Yin et al. (2023). Physical properties and cellular responses of gelatin methacryloyl bulk hydrogels and highly ordered porous hydrogels: https://www.frontiersin.org/journals/soft-matter/articles/10.3389/frsfm.2022.1101680/full
  CC BY 4.0; Figure 4 reproduced with attribution.
- OECD (1992). Test No. 301: Ready Biodegradability: https://www.oecd.org/en/publications/test-no-301-ready-biodegradability_9789264070349-en.html
  Official method reference; no assets reproduced.
