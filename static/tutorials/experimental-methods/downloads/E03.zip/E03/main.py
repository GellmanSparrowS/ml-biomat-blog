"""Constructed random-chain scission, dry-mass retention, and carbon accounting."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,FancyArrowPatch

def _label(text):
    """Readable English labels without changing numbers or scientific identifiers."""
    import re
    if not isinstance(text, str):
        return [_label(x) for x in text] if isinstance(text, list) else text
    return re.sub(r'(?<=[a-z])(?=\d)|(?<=\d)(?=[a-zμµ])|(?<=%)(?=[A-Za-z])', ' ', text)


def fragment_distribution(probability,length=100):
    """Expected fragment counts per initial linear chain; independent identical bond cuts."""
    p=float(probability);l=np.arange(1,length+1);counts=np.empty(length)
    counts[:-1]=((length-l[:-1]-1)*p*p+2*p)*(1-p)**(l[:-1]-1)
    counts[-1]=(1-p)**(length-1)
    return l,counts

def response(time,rate=.003,cutoff=8,length=100):
    probability=1-np.exp(-rate*time);l,c=fragment_distribution(probability,length)
    keep=l>cutoff;mass=np.sum(l[keep]*c[keep]);number=np.sum(c[keep])
    return {'cut_probability':float(probability),'remaining_mass_percent':float(100*mass/length),'all_DP':float(length/c.sum()),'retained_DP':float(mass/number) if number>0 else 0.}

def main(output,language):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    from matplotlib import font_manager
    fonts={x.name for x in font_manager.fontManager.ttflist};font=next((f for f in ['Microsoft YaHei','Noto Sans CJK SC','SimHei'] if f in fonts),'DejaVu Sans')
    plt.rcParams.update({'font.family':[font,'DejaVu Sans'] if language=='zh' else ['DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','savefig.facecolor':'#faf9f5','axes.prop_cycle':plt.cycler(color=['#186e83','#cd803f','#8160a1','#3c8a6a'])})
    tr=lambda z,e:z if language=='zh' else _label(e)
    def save(fig,name):fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    fig,ax=plt.subplots(1,3,figsize=(12,4.6))
    for a in ax:a.set(xlim=(0,10),ylim=(0,8));a.axis('off')
    for row,(cut,title) in enumerate([(False,tr('链尚未切断','Uncut chain')),(True,tr('切一次：链数加一','One cut adds one chain'))]):
        xx=np.linspace(1,9,12);yy=np.full(12,6-row*3,dtype=float)
        for i in range(11):
            if cut and i==5:continue
            ax[0].plot(xx[i:i+2],yy[i:i+2],color='#186e83',lw=3)
        ax[0].scatter(xx,yy,color='#186e83',s=30);ax[0].text(5,4.8-row*3,title,ha='center',fontsize=10)
    ax[0].set_title(tr('A  断链先改变分子数量','A  Scission first changes molecule count'))
    for a,r,label in [(ax[1],2.2,tr('内部产物较难排出','Products retained in the interior')),(ax[2],.9,tr('较短的扩散路径','Shorter diffusion paths'))]:
        a.add_patch(Circle((5,4.4),r,color='#a2cdd9'));a.add_patch(Circle((5,4.4),r*.48,color='#cd803f',alpha=.75))
        for ang in [0,np.pi/2,np.pi,3*np.pi/2]:
            start=(5+r*.65*np.cos(ang),4.4+r*.65*np.sin(ang));end=(5+(r+1.1)*np.cos(ang),4.4+(r+1.1)*np.sin(ang));a.add_patch(FancyArrowPatch(start,end,arrowstyle='->',mutation_scale=12,color='#186e83'))
        a.text(5,1.1,label,ha='center',fontsize=9)
    ax[1].set_title(tr('B  大尺度样品','B  Larger specimen'));ax[2].set_title(tr('C  小尺度样品','C  Smaller specimen'))
    fig.text(.5,.02,tr('1995：Grizzi 等通过不同尺寸的聚乳酸器件研究反应与扩散的耦合。','1995: Grizzi and colleagues investigated reaction–diffusion coupling across PLA device sizes.'),ha='center',fontsize=10);save(fig,'mechanism')
    time=np.linspace(0,120,241);records=[response(t) for t in time];remaining=np.array([r['remaining_mass_percent'] for r in records]);all_dp=np.array([r['all_DP'] for r in records]);ret_dp=np.array([r['retained_DP'] for r in records]);np.savetxt(output/'degradation.csv',np.column_stack([time,remaining,all_dp,ret_dp]),delimiter=',',header='time_day,remaining_mass_percent,all_fragments_number_average_DP,retained_fragments_number_average_DP',comments='')
    fig,ax=plt.subplots(2,2,figsize=(11.6,7.3));ax=ax.ravel();ax[0].plot(time,remaining,label=tr('剩余聚合物质量','Remaining polymer mass'));ax[0].plot(time,all_dp,label=tr('全部片段的平均链长','Mean length of all fragments'));ax[0].plot(time,ret_dp,label=tr('仅残留片段的平均链长','Mean length of retained fragments'));ax[0].set(xlabel=tr('时间 / d','Time / d'),ylabel=tr('相对初始值 / %','Relative to initial value / %'),title=tr('A  质量与平均链长分开变化','A  Mass and mean chain length change differently'));ax[0].legend(fontsize=8)
    for t in [10,30,90]:
        l,c=fragment_distribution(1-np.exp(-.003*t));ax[1].plot(l,l*c/100,label=f'{t} d')
    ax[1].axvspan(1,8,color='#cd803f',alpha=.12);ax[1].set(xscale='log',xlabel=tr('片段长度 / 重复单元数','Fragment length / repeat units'),ylabel=tr('初始质量的比例 / 每种长度','Initial mass fraction / length class'),title=tr('B  短片段到达可溶范围','B  Short fragments enter the soluble range'));ax[1].legend(fontsize=9)
    for threshold in [4,8,12]:ax[2].plot(time,[response(t,cutoff=threshold)['remaining_mass_percent'] for t in time],label=f'{threshold}')
    ax[2].set(xlabel=tr('时间 / d','Time / d'),ylabel=tr('剩余聚合物质量 / %','Remaining polymer mass / %'),title=tr('C  改变溶解阈值，不改变断链速率','C  Change solubility threshold, keep scission rate'));ax[2].legend(title=tr('最大可溶长度','Maximum soluble length'),fontsize=9)
    for radius in [.5,1,2]:ax[3].plot(time,100*np.maximum(1-.005*time/radius,0)**3,label=f'{radius:g} mm')
    ax[3].set(xlabel=tr('时间 / d','Time / d'),ylabel=tr('剩余质量 / %','Remaining mass / %'),title=tr('D  独立的球体表面侵蚀模型','D  Separate spherical surface-erosion model'));ax[3].legend(title=tr('初始半径','Initial radius'),fontsize=9)
    fig.tight_layout();save(fig,'kinetics')
    fig,ax=plt.subplots(1,2,figsize=(11,4.8));labels=tr(['剩余固体','溶解有机物','生物量','二氧化碳中的碳'],['Remaining solid','Dissolved organics','Biomass','Carbon in CO₂']);values=[10,15,7,18]
    left=0
    for label,value,color in zip(labels,values,['#186e83','#cd803f','#8160a1','#3c8a6a']):ax[0].barh([0],value,left=left,label=label,color=color);left+=value
    ax[0].set(xlabel=tr('碳质量 / mg','Carbon mass / mg'),yticks=[],xlim=(0,50),title=tr('A  50 mg 初始碳的四条去向','A  Four destinations for 50 mg initial carbon'));ax[0].legend(loc='upper center',bbox_to_anchor=(.5,-.15),fontsize=9,ncol=2)
    ax[1].bar(tr(['测得总量','接种物空白','样品净贡献','理论完全转化'],['Measured total','Inoculum blank','Net specimen','Theoretical total']),[80,14,66,50*44/12],color=['#8160a1','#a8b4b9','#3c8a6a','#186e83']);ax[1].tick_params(axis='x',labelrotation=20);ax[1].set(ylabel=tr('CO₂ 质量 / mg','CO₂ mass / mg'),title=tr('B  扣空白后矿化比例为 36%','B  Blank-corrected mineralization is 36%'));fig.tight_layout();save(fig,'carbon')
    from PIL import Image
    img=np.asarray(Image.open(Path(__file__).with_name('yin2023-figure4.webp')));fig,ax=plt.subplots(figsize=(11,8));ax.imshow(img);ax.axis('off');ax.set_title(tr('真实研究：酶作用下的凝胶形态与湿质量变化','Published study: gel morphology and wet-mass change under enzyme exposure'),fontsize=12,pad=12);fig.text(.5,.015,'Yin et al. (2023), Figure 4 · Frontiers in Soft Matter · CC BY 4.0',ha='center',fontsize=9);save(fig,'published')
    l,c=fragment_distribution(.1);r30=response(30);summary={'worked_example':{'initial_dry_mg':100,'remaining_dry_mg':80,'mass_loss_percent':20,'one_cut_DP_ratio':.5,'one_cut_retained_mass_percent':100},'distribution':{'mass_conserved_units':float(np.sum(l*c)),'expected_fragment_count':float(c.sum()),'mean_DP_at_p_point1':float(100/c.sum()),'retained_mass_at_p_point1_percent':float(np.sum(l[8:]*c[8:]))},'at_day30':r30,'carbon':{'theoretical_CO2_mg':50*44/12,'net_CO2_mg':66,'mineralized_percent':36},'surface':{'radius1_day100_percent':100*(1-.005*100)**3}}
    assert abs(sum(l*c)-100)<1e-10;assert abs(sum(c)-10.9)<1e-10;assert abs(summary['surface']['radius1_day100_percent']-12.5)<1e-12
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--language',choices=['zh','en'],default='zh');args=parser.parse_args();main(args.output,args.language)
