"""ICP-OES: reproducible teaching models and actual NIST certificate values.

All spectra, calibration observations and QC sequences are constructed examples.
The four SRM rows are certified numerical facts, not measurements made here.
Run: python main.py --output results --language en
"""
from pathlib import Path
import argparse
import csv
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon, Ellipse, FancyArrowPatch

BLUE, GREEN, ORANGE, PURPLE = '#236d96', '#18877d', '#d57b39', '#8863a4'


def fixed_noise(n, seed=804):
    """Specified LCG + Box-Muller, shared exactly with the browser laboratory."""
    out = []
    while len(out) < n:
        seed = (1664525 * seed + 1013904223) & 0xffffffff
        u = (seed + .5) / 4294967296
        seed = (1664525 * seed + 1013904223) & 0xffffffff
        v = (seed + .5) / 4294967296
        out.extend([np.sqrt(-2*np.log(u))*np.cos(2*np.pi*v),
                    np.sqrt(-2*np.log(u))*np.sin(2*np.pi*v)])
    return np.array(out[:n])


def spectral_model(separation=.018, width=.014, interference=.6, matrix=.8):
    x = np.linspace(-.06, .06, 241)
    sigma = width / np.sqrt(8*np.log(2))
    g = np.exp(-.5*(x/sigma)**2)
    h = np.exp(-.5*((x-separation)/sigma)**2)
    baseline = 250 + 800*x
    y = baseline + matrix*12000*.8*(g+interference*h) + 20*fixed_noise(len(x))
    bg = np.column_stack([np.ones(len(x)), x])
    gp = g-bg@np.linalg.lstsq(bg, g, rcond=None)[0]
    hp = h-bg@np.linalg.lstsq(bg, h, rcond=None)[0]
    rho = float(gp@hp/np.sqrt((gp@gp)*(hp@hp)))
    identifiable = abs(rho) < 1-1e-12
    condition = np.sqrt((1+abs(rho))/(1-abs(rho))) if identifiable else None
    design = np.column_stack([g, h, np.ones(len(x)), x])
    if identifiable:
        coef = np.linalg.lstsq(design, y, rcond=None)[0]
        se = 20*np.sqrt(np.linalg.inv(design.T@design)[0, 0])/(12000*matrix)
        external, corrected = coef[0]/12000, coef[0]/(12000*matrix)
    else:
        combined = np.column_stack([g, np.ones(len(x)), x])
        c = np.linalg.lstsq(combined, y, rcond=None)[0]
        coef = np.array([c[0], 0, c[1], c[2]])
        external = corrected = se = None
    fit = design@coef
    return {'x':x, 'y':y, 'fit':fit, 'g':g, 'h':h, 'baseline':baseline,
            'coef':coef, 'identifiable':identifiable,
            'condition':float(condition) if identifiable else None,
            'external_mg_L':float(external) if identifiable else None,
            'corrected_mg_L':float(corrected) if identifiable else None,
            'standard_error_mg_L':float(se) if identifiable else None,
            'residual_rms':float(np.sqrt(np.mean((y-fit)**2))),
            'center_naive_mg_L':float((y[120]-baseline[120])/12000)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path('results'))
    parser.add_argument('--language', choices=['zh','en'], default='en')
    args = parser.parse_args()
    out, lang = args.output, args.language
    out.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],
                         'font.size':11, 'axes.spines.top':False,
                         'axes.spines.right':False, 'svg.fonttype':'none',
                         'axes.labelcolor':'#293c49','text.color':'#293c49',
                         'axes.titleweight':'bold','figure.facecolor':'#fffdf9'})
    def t(zh,en): return zh if lang=='zh' else en
    def save(fig,name):
        fig.savefig(out/f'{name}-{lang}.svg', bbox_inches='tight')
        fig.savefig(out/f'{name}-{lang}.png', dpi=150, bbox_inches='tight')
        plt.close(fig)
    def csvsave(name, header, rows):
        with (out/name).open('w',encoding='utf-8',newline='') as f:
            w=csv.writer(f); w.writerow(header); w.writerows(rows)

    # 1: original historical/mechanistic drawing, not a copied historical apparatus.
    fig=plt.figure(figsize=(14,10),layout='constrained')
    gs=fig.add_gridspec(2,2,height_ratios=[1,1.7])
    ax=fig.add_subplot(gs[0,0]); ax.set(xlim=(0,10),ylim=(0,5)); ax.axis('off')
    ax.set_title(t('A  从火焰颜色到可分辨谱线','A  From flame colour to resolved lines'),loc='left')
    ax.add_patch(Polygon([[.8,1],[1.3,3.3],[1.8,1]],color=ORANGE,alpha=.8))
    ax.add_patch(Rectangle((.8,.6),1,.4,color='#8a949d'))
    ax.add_patch(Rectangle((3,.7),.15,1.18,color='#293c49'))
    ax.add_patch(Rectangle((3,2.12),.15,1.28,color='#293c49'))
    ax.add_patch(Polygon([[5,1],[5.7,3.2],[6.4,1]],facecolor='#cae8ec',edgecolor=BLUE))
    ax.plot([1.4,5.5],[2,2],color=ORANGE,lw=2)
    for yy,col in [(1.2,PURPLE),(2,GREEN),(2.8,ORANGE)]:
        ax.plot([5.5,8.6],[2,yy],color=col,lw=2); ax.plot([8.7,8.7],[yy-.2,yy+.2],color=col,lw=3)
    ax.text(.4,.1,t('火焰','Flame')); ax.text(2.5,.1,t('狭缝','Slit')); ax.text(5,.1,t('棱镜','Prism'))
    ax.text(.3,4,t('1860：基尔霍夫与本生的光谱分析','1860: Kirchhoff and Bunsen — spectral analysis'),fontsize=11)
    ax=fig.add_subplot(gs[0,1]); ax.set(xlim=(0,10),ylim=(0,5)); ax.axis('off')
    ax.set_title(t('B  1964年的问题：同样的钙，为什么变暗？','B  The 1964 question: why does calcium look dimmer?'),loc='left')
    for xpos,height,label in [(2,2.1,t('钙溶液','Calcium solution')),(6,1.1,t('钙 + 磷 / 铝','Calcium + P / Al'))]:
        ax.add_patch(Rectangle((xpos,.8),1,height,color=ORANGE,alpha=.7))
        ax.text(xpos+.5,.4,label,ha='center',fontsize=10)
    ax.text(.3,4,t('火焰中的化学干扰 → 探索高温感应等离子体','Chemical interference in flames → induction plasma'),fontsize=11)
    ax.text(.3,3.2,t('概念图；柱高不是历史测量数据','Conceptual illustration; bar heights are not historical data'),fontsize=10,color='#687782')
    ax=fig.add_subplot(gs[1,:]); ax.set(xlim=(0,16),ylim=(0,6)); ax.axis('off')
    ax.set_title(t('C  一滴样品怎样成为元素的光','C  How a droplet becomes elemental light'),loc='left')
    ax.add_patch(Rectangle((.35,1.4),1.15,1.4,facecolor='#ecf5f7',edgecolor=BLUE,lw=1.5))
    ax.add_patch(Rectangle((.38,1.43),1.09,.7,facecolor='#99d0dc',alpha=.7))
    ax.plot([.92,.92,2.0,2.0],[1.7,3.2,3.2,2.9],color=BLUE,lw=2)
    ax.text(.9,1.05,t('样品瓶','Sample'),ha='center')
    ax.add_patch(Polygon([[1.85,2.6],[2.7,2.8],[1.85,3]],facecolor='#bedae6',edgecolor=BLUE))
    ax.text(2.2,3.65,t('雾化器','Nebulizer'),ha='center')
    ax.annotate(t('氩气','Argon'),xy=(1.9,2.65),xytext=(1.6,2.05),arrowprops={'arrowstyle':'->','color':GREEN},fontsize=10)
    ax.add_patch(Polygon([[2.8,1.9],[3.4,1.6],[5.8,1.6],[6.3,2.2],[6.3,3.5],[3.2,3.5],[2.8,3.1]],facecolor='#eef5f7',edgecolor=BLUE,lw=1.5))
    ax.text(4.5,3.85,t('雾室：筛去大液滴','Spray chamber: remove large drops'),ha='center',fontsize=11)
    ax.scatter([3,3.3,3.5,3.8,4.1,4.5,5,5.5,5.9],[2.8,2.7,2.95,2.8,2.9,2.82,2.86,2.87,2.9],s=[30,20,12,8,6,5,4,4,3],color=BLUE)
    ax.scatter([3.4,4.2,4.6],[2.3,2.05,1.85],s=[45,70,55],color=BLUE,alpha=.65)
    ax.plot([4.6,4.6],[1.6,.95],color=BLUE,lw=2)
    ax.annotate('',xy=(4.6,.65),xytext=(4.6,1.3),arrowprops={'arrowstyle':'->','color':BLUE})
    ax.text(4.65,.35,t('大液滴与废液','Large drops / drain'),ha='center',fontsize=10)
    ax.plot([6.3,7.5],[2.9,2.9],color=BLUE,lw=3)
    for height,start,end in [(1.8,7.4,11.1),(1.25,7.6,10.5),(.45,7.4,10.0)]:
        ax.plot([start,end],[2.9-height/2]*2,color='#8dafbf',lw=2)
        ax.plot([start,end],[2.9+height/2]*2,color='#8dafbf',lw=2)
    for xcoil in [8.3,8.65,9,9.35]:
        ax.add_patch(Ellipse((xcoil,2.9),.28,2.1,facecolor='none',edgecolor=ORANGE,lw=2.8))
    ax.add_patch(Ellipse((10.5,2.9),2.4,1.05,facecolor=PURPLE,alpha=.22))
    ax.add_patch(Ellipse((10.3,2.9),1.8,.6,facecolor=ORANGE,alpha=.24))
    ax.annotate('',xy=(10.7,2.9),xytext=(6.6,2.9),arrowprops={'arrowstyle':'->','color':BLUE,'lw':1.8})
    ax.annotate('',xy=(9.8,3.62),xytext=(7.5,3.62),arrowprops={'arrowstyle':'->','color':GREEN,'lw':1.5})
    ax.text(7.7,4.25,t('石英同心炬管','Concentric quartz torch'),ha='center',fontsize=11)
    ax.text(8.8,1.35,t('外绕射频线圈','External RF coil'),ha='center',color=ORANGE,fontsize=11)
    ax.text(8.9,.85,t('中心：样品气溶胶','Centre: sample aerosol'),ha='center',fontsize=10)
    ax.text(10.8,1.65,t('氩等离子体','Argon plasma'),ha='center',fontsize=11)
    ax.annotate('',xy=(13.5,2.9),xytext=(11.7,2.9),arrowprops={'arrowstyle':'->','color':PURPLE,'lw':2})
    ax.text(12.8,2.45,t('轴向看光','Axial light'),ha='center',color=PURPLE,fontsize=10)
    ax.annotate('',xy=(10.8,4.75),xytext=(10.8,3.45),arrowprops={'arrowstyle':'->','color':GREEN,'lw':2})
    ax.text(11.05,4.05,t('径向看光','Radial light'),color=GREEN,fontsize=10)
    ax.plot([10.8,13.4],[4.75,4.75],color=GREEN,lw=1.5,ls='--')
    ax.plot([13.5,13.5],[2.9,4.75],color=PURPLE,lw=1.5,ls='--')
    ax.add_patch(Rectangle((13.5,4.15),2.2,1.2,facecolor='#f0edf5',edgecolor=PURPLE))
    ax.text(14.6,4.75,t('分光光学系统\n与检测器','Spectrometer\nand detector'),ha='center',va='center',fontsize=11)
    ax.text(.3,5.25,t('原理剖面示意；两条光路表示可选择的观察方向','Functional cross-section; two light paths represent alternative viewing directions'),fontsize=11)
    ax.text(12.5,.45,t('去溶剂 → 原子化 → 激发 / 电离','Desolvation → atoms → excitation / ionization'),ha='center',fontsize=10)
    save(fig,'light-path')

    # 2: spectral overlap and identifiability. Line centre is NIST air wavelength.
    sp=spectral_model()
    fig,axs=plt.subplots(2,2,figsize=(13,8.5),layout='constrained')
    ax=axs[0,0]; xx=317.9332+sp['x']
    ax.plot(xx,sp['y'],color='#86939c',lw=1,label=t('构造观测','Constructed observations'))
    ax.plot(xx,sp['fit'],color=BLUE,lw=2,label=t('联合拟合','Joint fit'))
    ax.set(title=t('A  两条谱线与背景','A  Two lines and a background'),ylabel=t('信号 / a.u.','Signal / a.u.'))
    ax.legend(fontsize=9);ax.ticklabel_format(useOffset=False,axis='x')
    ax=axs[1,0]
    ax.plot(xx,sp['coef'][0]*sp['g'],color=GREEN,label=t('Ca II 分量','Ca II component'))
    ax.plot(xx,sp['coef'][1]*sp['h'],color=ORANGE,label=t('模拟干扰峰','Constructed interference'))
    ax.plot(xx,sp['coef'][2]+sp['coef'][3]*sp['x'],color=PURPLE,label=t('拟合背景','Fitted background'))
    ax.set(xlabel=t('空气波长 / nm','Air wavelength / nm'),ylabel=t('信号 / a.u.','Signal / a.u.'),title=t('B  分开核对每一项','B  Inspect each contribution'))
    ax.legend(fontsize=9);ax.ticklabel_format(useOffset=False,axis='x')
    ax=axs[0,1];ax.plot(sp['x'],sp['y']-sp['fit'],color=BLUE,lw=1)
    ax.axhspan(-40,40,color=BLUE,alpha=.08);ax.axhline(0,color='#9eaaaf',lw=1)
    ax.set(xlabel=t('距钙线中心 / nm','Offset from calcium line / nm'),ylabel=t('观测 − 拟合 / a.u.','Observed − fitted / a.u.'),title=t('C  小残差仍需配合可辨识性','C  Small residuals need an identifiability check'))
    sep=np.linspace(.00015,.04,160)
    cond=np.array([spectral_model(separation=s)['condition'] for s in sep])
    ax=axs[1,1];ax.semilogy(sep/.014,cond,color=PURPLE,lw=2)
    ax.axvline(.018/.014,color=ORANGE,ls='--',label=t('当前示例','Current example'))
    ax.set(xlabel=t('峰间距 / 半高全宽','Separation / FWHM'),ylabel=t('投影后条件数 κ','Projected condition number κ'),title=t('D  靠近时噪声被放大','D  Approaching lines amplify noise'));ax.legend(fontsize=9)
    save(fig,'spectral-separation')
    csvsave('spectrum.csv',['air_wavelength_nm','constructed_signal','fitted_signal','residual'],zip(xx,sp['y'],sp['fit'],sp['y']-sp['fit']))

    # 3: calibrations and the complete solid-to-solution calculation.
    rng=np.random.default_rng(805)
    cx=np.repeat([0,.25,.5,1,2],3)
    cy=150+12000*cx+rng.normal(0,30,len(cx))
    slope,intercept=np.polyfit(cx,cy,1)
    uy=150+12000*.8+rng.normal(0,18,3)
    uc=(uy-intercept)/slope
    c=float(uc.mean()); mass=c*10*.05000/.0002500
    residual=cy-(slope*cx+intercept)
    blank=150+12*fixed_noise(10,808)
    sd=float(np.std(blank,ddof=1)); lod=3*sd/slope;loq=10*sd/slope
    fig=plt.figure(figsize=(13,8.6),layout='constrained');gs=fig.add_gridspec(2,2)
    ax=fig.add_subplot(gs[0,0]);ax.scatter(cx,cy,color=BLUE,s=25)
    ax.plot([0,2],[intercept,intercept+2*slope],color=BLUE,lw=1)
    ax.scatter([c],[uy.mean()],color=ORANGE,s=70,zorder=4,label=t('未知液，三次进样均值','Unknown, mean of three injections'))
    ax.set(xlabel=t('标准浓度 / mg L⁻¹','Standard concentration / mg L⁻¹'),ylabel=t('净谱线信号 / a.u.','Net line signal / a.u.'),title=t('A  五个水平，各三次观测','A  Five levels, three observations each'));ax.legend(fontsize=9)
    ax=fig.add_subplot(gs[1,0]);ax.scatter(cx,residual,color=GREEN,s=25);ax.axhline(0,color='#85949c',lw=1)
    ax.set(xlabel=t('标准浓度 / mg L⁻¹','Standard concentration / mg L⁻¹'),ylabel=t('校准残差 / a.u.','Calibration residual / a.u.'),title=t('B  检查弯曲与低端散布','B  Look for curvature and low-end scatter'))
    ax=fig.add_subplot(gs[:,1]);ax.axis('off')
    steps=[t('干基复合材料 0.2500 g','Dry composite specimen: 0.2500 g'),t('完整消解，定容至 50.00 mL','Complete digestion; make to 50.00 mL'),t('消解液再稀释 10 倍','Dilute digest a further tenfold'),t(f'进样液测得 {c:.4f} mg/L',f'Measured solution: {c:.4f} mg/L'),t(f'样品总钙 {mass:.1f} mg/kg',f'Total Ca in specimen: {mass:.1f} mg/kg')]
    for j,label in enumerate(steps):
        y=.88-j*.18;ax.text(.5,y,label,ha='center',va='center',transform=ax.transAxes,fontsize=13,bbox={'boxstyle':'round,pad=.6','fc':'#e9f1f4','ec':'none'})
        if j<4: ax.annotate('',xy=(.5,y-.12),xytext=(.5,y-.05),xycoords='axes fraction',arrowprops={'arrowstyle':'->','color':BLUE})
    ax.set_title(t('C  保存体积与质量，才能回到材料','C  Retain volumes and mass to return to the material'),loc='left')
    save(fig,'calibration-mass')
    csvsave('calibration.csv',['concentration_mg_L','constructed_signal','fitted_signal','residual'],zip(cx,cy,slope*cx+intercept,residual))
    csvsave('unknown.csv',['injection','constructed_signal','concentration_mg_L'],zip(range(1,4),uy,uc))

    # 4: matrix physics and QC. The values here are exact constructed relationships.
    added=np.array([0,.4,.8,1.2]); add_signal=.8*12000*(.8+added)
    add_slope,add_intercept=np.polyfit(added,add_signal,1)
    seq=np.arange(1,17);gain=1-.15*(seq-1)/15
    # Deliberate response mismatch in the last four solutions illustrates limits.
    target_response=gain.copy(); target_response[-4:]*=.92
    fig,axs=plt.subplots(2,2,figsize=(13,8.4),layout='constrained')
    ax=axs[0,0];labels=[t('真实','True'),t('外标','External'),t('内标比值','Internal ratio')]
    ax.bar(labels,[.8,.64,.8],color=[GREEN,ORANGE,BLUE]);ax.set(ylim=(0,1),ylabel=t('浓度 / mg L⁻¹','Concentration / mg L⁻¹'),title=t('A  两条通道共同降为 80%','A  Both channels fall to 80%'))
    ax=axs[0,1];ax.plot(added,add_signal,'o-',color=GREEN);ax.plot([-.8,0],[0,add_intercept],color=GREEN,ls='--');ax.axhline(0,color='#9da7ac',lw=1);ax.axvline(-.8,color=ORANGE,ls=':')
    ax.set(xlabel=t('终体积中加入的钙 / mg L⁻¹','Added calcium in final volume / mg L⁻¹'),ylabel=t('背景扣除信号 / a.u.','Background-corrected signal / a.u.'),title=t('B  标准加入：横截距 −0.800','B  Standard additions: intercept −0.800'))
    ax=axs[1,0];ax.plot(seq,target_response,'o-',color=ORANGE,label=t('外标','External'));ax.plot(seq,target_response/gain,'o-',color=BLUE,label=t('内标校正','Internal correction'));ax.axhline(1,color=GREEN,ls=':')
    ax.axvspan(12.5,16.5,color=PURPLE,alpha=.07);ax.set(xlabel=t('检查液顺序','Check solution sequence'),ylabel=t('测得浓度 / 已知浓度','Measured / known concentration'),ylim=(.7,1.05),title=t('C  最后四份：目标元素额外抑制 8%','C  Last four: extra 8% analyte suppression'));ax.legend(fontsize=9)
    ax=axs[1,1];ax.axis('off');ax.set_title(t('D  校正需要追踪同一种变化','D  Correction must track the same change'),loc='left')
    text=t('共同雾化 / 传输变化\n目标信号 ÷ 内标信号 → 可抵消\n\n额外谱线、消解损失、不同响应\n需要换线、验证制样或改变基体\n\n消解后加标：0.50 mg/L\n外标增量：0.40 mg/L → 回收率 80%',
           'Shared nebulization / transport change\nAnalyte ÷ internal signal → cancels\n\nExtra lines, digestion losses, unequal response\nChange line, validate preparation or matrix\n\nPost-digestion spike: 0.50 mg/L\nExternal increment: 0.40 mg/L → 80% recovery')
    ax.text(.03,.9,text,va='top',linespacing=1.7,fontsize=12,transform=ax.transAxes)
    save(fig,'matrix-quality')
    csvsave('standard_additions.csv',['added_mg_L','constructed_signal'],zip(added,add_signal))
    csvsave('quality_control.csv',['sequence','shared_gain','external_ratio','internal_corrected_ratio'],zip(seq,gain,target_response,target_response/gain))

    # 5: actual NIST certificate values, with element-specific expanded uncertainty.
    with (Path(__file__).parent/'data'/'srm1643f.csv').open(encoding='utf-8') as f:
        cert=list(csv.DictReader(f))
    names=[r['element'] for r in cert]
    values=np.array([float(r['concentration_ug_L'])/1000 for r in cert])
    uncertainty=np.array([float(r['expanded_uncertainty_ug_L'])/1000 for r in cert])
    factors=np.array([float(r['coverage_factor']) for r in cert])
    fig,axs=plt.subplots(1,2,figsize=(13,5.5),layout='constrained');yp=np.arange(4)
    ax=axs[0];ax.errorbar(values,yp,xerr=uncertainty,fmt='o',color=BLUE,capsize=5,ms=7)
    ax.set(xscale='log',yticks=yp,yticklabels=names,xlabel=t('认证质量浓度 / mg L⁻¹（对数轴）','Certified mass concentration / mg L⁻¹ (log scale)'),title=t('A  NIST SRM 1643f 的四个元素','A  Four elements in NIST SRM 1643f'))
    ax.invert_yaxis();ax.grid(axis='x',alpha=.15)
    ax=axs[1];ax.barh(yp,100*uncertainty/values,color=[BLUE,GREEN,PURPLE,ORANGE]);ax.set(yticks=yp,yticklabels=names,xlabel=t('相对扩展不确定度 / %','Relative expanded uncertainty / %'),title=t('B  误差线各有自己的覆盖因子','B  Each interval has its own coverage factor'));ax.invert_yaxis()
    for i,(u,v,k) in enumerate(zip(uncertainty,values,factors)):
        ax.text(100*u/v+.1,i,f'{100*u/v:.2f}%   k={k:.1f}',va='center',fontsize=10)
    ax.set_xlim(0,8.5)
    fig.suptitle(t('证书值与约 95% 扩展不确定度；不是本例的实测重复','Certificate values and ≈95% expanded uncertainty; not replicate measurements in this example'),fontsize=12)
    save(fig,'certified-reference')
    csvsave('certificate_mg_L.csv',['element','concentration_mg_L','expanded_uncertainty_mg_L','k'],zip(names,values,uncertainty,factors))
    summary={'photon_400nm_eV':6.62607015e-34*299792458/(400e-9)/1.602176634e-19,
             'ideal_mass_mg_kg':.8*10*.05000/.0002500,
             'calibration':{'slope':float(slope),'intercept':float(intercept)},
             'unknown_mg_L':c,'sample_Ca_mg_kg':mass,
             'blank_signal_sd':sd,'noise_scale_3s_mg_L':lod,'noise_scale_10s_mg_L':loq,
             'standard_addition_native_mg_L':float(add_intercept/add_slope),
             'post_digest_external_recovery_percent':(.8*1.3-.8*.8)/.5*100,
             'shared_matrix_external_mg_L':.64,'shared_matrix_internal_mg_L':.8,
             'certificate_Ca_mg_L':float(values[0]),'certificate_Sr_relative_U_percent':float(100*uncertainty[2]/values[2]),
             'spectral_default':{k:v for k,v in sp.items() if not isinstance(v,np.ndarray)},
             'model_labels':{'calibration':'constructed','spectra':'constructed','quality_control':'constructed','certificate':'NIST certified facts'}}
    assert abs(summary['ideal_mass_mg_kg']-1600)<1e-9
    assert abs(summary['standard_addition_native_mg_L']-.8)<1e-12
    assert abs(summary['post_digest_external_recovery_percent']-80)<1e-10
    assert spectral_model(separation=0)['identifiable'] is False
    assert .78<c<.82 and 1500<mass<1700
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
