# Public sources and third-party materials

- EPA SW-846 Method 6010D, Revision 5 (2018): https://www.epa.gov/sites/default/files/2015-12/documents/6010d.pdf
  Technical reference; original diagrams, no EPA figure copied.
- EPA Method 200.7, Revision 4.4: https://www.epa.gov/sites/default/files/2015-08/documents/method_200-7_rev_4-4_1994.pdf
  Technical reference; no figures or performance tables reproduced.
- Kirchhoff and Bunsen (1860): Chemical Analysis by Observation of Spectra: https://www.chemteam.info/Chem-History/Kirchhoff-Bunsen-1860.html
  Historical technical reference; no web image or extended quotation reused.
- Greenfield, Jones and Berry (1964), Analyst 89, 713–720: https://masspec.scripps.edu/learn/ms/pdf/1964_GreenfieldS.pdf
  Historical article hosted by an institutional repository; cited as a technical reference. Chapter diagrams are original.
- NIST Handbook: Strong Lines of Calcium: https://physics.nist.gov/PhysRefData/Handbook/Tables/calciumtable2.htm
  Three factual wavelength entries cited; no database compilation or figure reproduced.
- NIST SRM 1643f: Trace Elements in Water, Certificate: https://tsapps.nist.gov/srmext/certificates/1643f.pdf
  Four non-SRD certificate facts transcribed with attribution under NIST non-SRD data policy; original replot; μg/L converted to mg/L.
- EPA: Method Detection Limit Procedure, Revision 2: https://www.epa.gov/sites/default/files/2016-12/documents/mdl-procedure_rev2_12-13-2016.pdf
  Technical reference; chapter diagrams are original.
- NIST: Copyright, Fair Use and Licensing Statements: https://www.nist.gov/open/copyright-fair-use-and-licensing-statements-srd-data-software-and-technical-series-publications
  Rights reference; non-SRD terms are not generalized to all SRD databases.
