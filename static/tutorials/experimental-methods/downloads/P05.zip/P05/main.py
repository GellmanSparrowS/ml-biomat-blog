"""Protein adsorption: reversible kinetics, referencing and hydrated mass.
Constructed observations are distinct from the bundled published summary table.
Run: python main.py --output results --language en
"""
from pathlib import Path
import argparse,json,csv
import numpy as np
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Ellipse,Circle

def coverage(time,concentration,kon=.02,koff=.002,capacity=300.,injection=180.):
    t=np.asarray(time,dtype=float);rate=kon*concentration+koff
    eq=capacity*kon*concentration/rate
    end=eq*(-np.expm1(-rate*injection))
    return np.where(t<0,0,np.where(t<=injection,eq*(-np.expm1(-rate*np.maximum(t,0))),end*np.exp(-koff*np.maximum(t-injection,0))))

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();o=a.output;o.mkdir(parents=True,exist_ok=True)
    tr=lambda z,e:z if a.language=='zh' else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','figure.facecolor':'#fbfcfc','savefig.facecolor':'#fbfcfc','text.color':'#18344a'})
    blue='#186c94';green='#188777';orange='#d27839';purple='#8a5d92'
    def save(f,n):f.savefig(o/f'{n}-{a.language}.svg',bbox_inches='tight');f.savefig(o/f'{n}-{a.language}.png',bbox_inches='tight',dpi=150);plt.close(f)
    rng=np.random.default_rng(1805);time=np.arange(-60,602,2.);conc=np.array([.025,.05,.1,.2,.4]);truth=np.array([coverage(time,c) for c in conc]);bulk=np.array([25*(c/.1)*((time>=0)&(time<180)) for c in conc]);drift=.008*(time+60)
    reference=bulk+drift+rng.normal(0,.8,truth.shape);raw=truth+bulk+drift+rng.normal(0,1.2,truth.shape)
    corrected=raw-reference;corrected-=corrected[:,time<0].mean(axis=1,keepdims=True)
    def residual(logp):
        k1,k2,cap=np.exp(logp);return (np.array([coverage(time,c,k1,k2,cap) for c in conc])-corrected).ravel()
    fit=least_squares(residual,np.log([.015,.003,280.]));kon,koff,cap=np.exp(fit.x);pred=np.array([coverage(time,c,kon,koff,cap) for c in conc])
    noiseless=least_squares(lambda x:(np.array([coverage(time,c,*np.exp(x)) for c in conc])-truth).ravel(),np.log([.015,.003,280.]))
    base=coverage(time,.1);hydration=1.5;acoustic=base*(1+hydration);df5=-5*acoustic/17.7
    summary={'fit_kon_uM_inv_s_inv':float(kon),'fit_koff_s_inv':float(koff),'fit_capacity_ng_cm2':float(cap),'fit_KD_uM':float(koff/kon),'fit_rmse_ng_cm2':float(np.sqrt(np.mean((pred-corrected)**2))),
    'specified_KD_uM':.1,'equilibrium_at_KD_ng_cm2':150.,'mass_at_180s_ng_cm2':float(coverage(180,.1)),'mass_at_600s_ng_cm2':float(coverage(600,.1)),
    'rinse_half_life_s':float(np.log(2)/.002),'sauerbrey_5th_minus50Hz_ng_cm2':177.,'hydrated_mass_for_200_ng_cm2':500.,
    'noiseless_fit_kon':float(np.exp(noiseless.x[0])),'noiseless_fit_koff':float(np.exp(noiseless.x[1])),'noiseless_fit_capacity':float(np.exp(noiseless.x[2])),'data_kind':'Constructed kinetics; published table summarized separately'}
    (o/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    rows=np.vstack([np.column_stack([np.full(len(time),c),time,raw[i],reference[i],corrected[i],pred[i],truth[i]]) for i,c in enumerate(conc)])
    np.savetxt(o/'data.csv',rows,delimiter=',',header='concentration_uM,time_s,raw_equivalent_ng_cm2,reference_equivalent_ng_cm2,corrected_ng_cm2,fit_ng_cm2,specified_ng_cm2',comments='')
    np.savetxt(o/'acoustic.csv',np.column_stack([time,base,acoustic,df5]),delimiter=',',header='time_s,protein_ng_cm2,rigid_limit_coupled_ng_cm2,delta_f5_Hz',comments='')
    tab=list(csv.DictReader((Path(__file__).parent/'data/kobayashi2018-table2.csv').open(encoding='utf8')))
    fig,axs=plt.subplots(1,3,figsize=(14.5,4.5))
    for ax in axs:ax.set_xlim(0,10);ax.set_ylim(0,6);ax.axis('off')
    ax=axs[0];ax.add_patch(Rectangle((.4,1),9.2,.6,facecolor='#a7b8c0'))
    for j in range(8):
        ax.add_patch(Rectangle((.7+j*1.1,1.6),.85,.45,facecolor='white',edgecolor=blue))
        if j in [0,2,3,6]:ax.add_patch(Circle((1.1+j*1.1,2.45),.4,color=green))
    ax.annotate('',xy=(5.6,2.3),xytext=(5.6,4.1),arrowprops={'arrowstyle':'<->','color':orange,'lw':2});ax.text(5,5,tr('Langmuir：有限位置与动态平衡','Langmuir: finite sites and exchange'),ha='center',fontsize=10);ax.text(5,.25,tr('位置可空出，也可被占据','Sites can be empty or occupied'),ha='center',fontsize=10)
    ax=axs[1];ax.add_patch(Rectangle((.5,1),9,.6,facecolor='#a7b8c0'));ax.add_patch(Ellipse((3,2.3),3,.9,angle=10,facecolor=green));ax.add_patch(Ellipse((7,2.7),1.4,2.1,facecolor=orange))
    for x,y in [(2,2.8),(3,3),(4,2.7),(6.3,3.6),(7,3.9),(7.7,3.5)]:ax.add_patch(Circle((x,y),.17,color='#82c5df'))
    ax.text(5,5,tr('Vroman，1962：吸附改变润湿','Vroman, 1962: adsorption alters wetting'),ha='center',fontsize=9);ax.text(5,.25,tr('取向、暴露基团与周围水','Orientation, exposed groups and water'),ha='center',fontsize=9)
    ax=axs[2];ax.add_patch(Rectangle((1,1.4),8,.6,facecolor='#b6cbd1'));ax.add_patch(Rectangle((1,2),8,.15,color=orange));
    for x in [2,4,6,8]:ax.add_patch(Ellipse((x,2.5),1.1,.6,facecolor=green))
    ax.annotate('',xy=(8,1),xytext=(2,1),arrowprops={'arrowstyle':'<->','color':blue,'lw':2});ax.text(5,5,tr('Sauerbrey，1959：频率与附加质量','Sauerbrey, 1959: frequency and added mass'),ha='center',fontsize=9);ax.text(5,.25,tr('石英作剪切振动，膜随其运动','Quartz shears; coupled film moves with it'),ha='center',fontsize=9);save(fig,'history')
    fig,axs=plt.subplots(2,2,figsize=(12,8.7));aa,bb,cc,dd=axs.ravel();i=2
    aa.plot(time,raw[i],color=blue,label=tr('样品通道','Sample channel'));aa.plot(time,reference[i],color=orange,label=tr('参考通道','Reference channel'));aa.legend(fontsize=9);aa.set_title(tr('A  体相阶跃与漂移叠加','A  Bulk step and drift are superposed'),loc='left');aa.set_ylabel(tr('等效面密度 / ng/cm²','Equivalent areal mass / ng/cm²'))
    for j,c in enumerate(conc):bb.scatter(time[::5],corrected[j,::5],s=9,alpha=.55);bb.plot(time,pred[j],label=f'{c:g} μM')
    bb.legend(fontsize=8,ncol=2);bb.set_title(tr('B  多浓度共享动力学参数','B  Concentrations share kinetic parameters'),loc='left');bb.set_ylabel(tr('蛋白质面密度 / ng/cm²','Protein areal mass / ng/cm²'))
    for j in range(5):cc.plot(time,corrected[j]-pred[j],lw=.7,alpha=.65)
    cc.axhline(0,color='#a1abb2');cc.set_title(tr('C  保留全部拟合残差','C  Retain all fit residuals'),loc='left');cc.set_ylabel(tr('残差 / ng/cm²','Residual / ng/cm²'))
    dd.plot(time,base,color=green,label=tr('蛋白质质量','Protein mass'));dd.plot(time,acoustic,color=blue,label=tr('刚性极限耦合质量','Rigid-limit coupled mass'));dd.legend(fontsize=9);dd.set_title(tr('D  耦合水改变声学质量定义','D  Coupled water changes acoustic mass'),loc='left');dd.set_ylabel(tr('面密度 / ng/cm²','Areal mass / ng/cm²'))
    for ax in axs.ravel():ax.axvline(0,color='#b3bec4',ls=':');ax.axvline(180,color='#b3bec4',ls=':');ax.set_xlabel(tr('时间 / s','Time / s'))
    fig.tight_layout();save(fig,'sensorgrams')
    fig,axs=plt.subplots(1,3,figsize=(14,4.5));cc=np.logspace(-3,1,200);axs[0].semilogx(cc,cc/(cc+.1),color=blue);axs[0].axvline(.1,color=orange,ls='--');axs[0].axhline(.5,color='#a1abb2',ls=':');axs[0].set_xlabel(tr('浓度 / μmol/L','Concentration / μmol/L'));axs[0].set_ylabel(tr('平衡覆盖分数','Equilibrium occupied fraction'));axs[0].set_title(tr('A  半占据对应KD','A  Half occupancy at KD'),loc='left')
    for k,col in [(.001,blue),(.002,orange),(.006,green)]:axs[1].plot(time,coverage(time,.1,k*10,k)/300,color=col,label=f'koff={k:g} s⁻¹')
    axs[1].set_xlabel(tr('时间 / s','Time / s'));axs[1].set_ylabel(tr('占据分数','Occupied fraction'));axs[1].set_title(tr('B  相同KD，不同速度','B  Same KD, different rates'),loc='left');axs[1].legend(fontsize=8)
    rinse=np.linspace(0,600,200)
    for k,col in [(.001,blue),(.002,orange),(.006,green)]:axs[2].plot(rinse,np.exp(-k*rinse),color=col)
    axs[2].set_xlabel(tr('冲洗经过时间 / s','Elapsed rinse time / s'));axs[2].set_ylabel(tr('相对冲洗开始的保留分数','Fraction retained from start of rinse'));axs[2].set_title(tr('C  冲洗读取离开速度','C  Rinse reads the departure rate'),loc='left');fig.tight_layout();save(fig,'kinetics')
    fig,axs=plt.subplots(1,2,figsize=(11.8,4.8))
    for ax,protein in zip(axs,['BSA','FN']):
        rr=[r for r in tab if r['protein']==protein];x=np.array([float(r['temperature_C']) for r in rr]);y=np.array([float(r['thickness_mean_nm']) for r in rr]);err=np.array([float(r['thickness_sd_nm']) for r in rr]);ax.errorbar(x,y,yerr=err,fmt='o',ms=9,capsize=5,color=green if protein=='BSA' else blue);ax.set_xticks([20,37]);ax.set_xlim(15,42);ax.set_ylim(0,16);ax.set_xlabel(tr('温度 / °C','Temperature / °C'));ax.set_ylabel(tr('Voigt模型厚度 / nm','Voigt-model thickness / nm'));ax.set_title(protein+' · '+tr('氧化聚苯乙烯','Oxidized polystyrene'),loc='left');ax.text(.04,.08,tr('均值±标准差；n=3','Mean ± SD; n=3'),transform=ax.transAxes,fontsize=10)
    fig.suptitle(tr('Kobayashi等，2018，表2数据重绘 · CC BY 4.0','Kobayashi et al., 2018, Table 2 redrawn · CC BY 4.0'),fontsize=12);fig.tight_layout();save(fig,'published')
    print(json.dumps(summary))

if __name__=='__main__':main()
