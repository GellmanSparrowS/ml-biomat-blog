# Public sources and third-party materials

- Irving Langmuir — Surface Chemistry, Nobel lecture (1932): https://www.nobelprize.org/uploads/2018/06/langmuir-lecture.pdf
  Historical facts paraphrased; no lecture figures reproduced.
- Leo Vroman — Effect of Adsorbed Proteins on the Wettability of Hydrophilic and Hydrophobic Solids (1962): https://www.nature.com/articles/196476a0
  Bibliographic record and publisher abstract; no figures reused.
- NPTEL — Langmuir adsorption assumptions: https://archive.nptel.ac.in/content/storage2/courses/103104045/lecture25/25_6.htm
  Technical reference; original diagrams drawn here.
- Biolin Scientific — QCM-D measurement: https://www.biolinscientific.com/measurements/qcm-d
  Technical reference; no figures reused.
- Biolin Scientific — The QCM-D principle: https://www.biolinscientific.com/faq/the-qcm-d-principle
  Technical reference; no figures reused.
- Biolin Scientific — Sauerbrey equation: https://www.biolinscientific.com/blog/what-is-the-sauerbrey-equation
  Technical reference; no figures reused.
- Cytiva — Kinetics and affinity measurements with Biacore systems: https://cdn.cytivalifesciences.com/api/public/content/digi-33041-pdf
  Technical reference; no figures reused.
- Harvard CMI — Surface plasmon resonance: https://cmi.hms.harvard.edu/surface-plasmon-resonance
  Technical reference; no figures reused.
- Kobayashi et al. — Temperature and serum protein adsorption (2018): https://pmc.ncbi.nlm.nih.gov/articles/PMC5983614/
  CC BY 4.0; numeric table transcribed and bilingual chart redrawn; attribution and licence included.
