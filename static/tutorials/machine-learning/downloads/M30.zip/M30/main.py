"""Inspect CART, bootstrap diversity and honest stacking on seeded data."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification,make_moons
from sklearn.tree import DecisionTreeClassifier,plot_tree
from sklearn.ensemble import BaggingClassifier,RandomForestClassifier,ExtraTreesClassifier,VotingClassifier,StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split,GridSearchCV,StratifiedKFold
from sklearn.metrics import accuracy_score,log_loss
from sklearn.inspection import permutation_importance

def main(output,language):
 out=Path(output);out.mkdir(parents=True,exist_ok=True);zh=language=='zh';rng=np.random.default_rng(30)
 plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
 def t(z,e):return z if zh else e
 def save(f,n):f.savefig(out/f'{n}-{language}.svg',bbox_inches='tight');plt.close(f)
 Xm,ym=make_moons(n_samples=200,noise=.22,random_state=30);small=DecisionTreeClassifier(max_depth=2,random_state=30).fit(Xm,ym)
 fig,ax=plt.subplots(figsize=(12,5.6),layout='constrained');annotations=plot_tree(small,feature_names=['x₀','x₁'],class_names=['0','1'],filled=True,rounded=True,fontsize=11,ax=ax)
 if zh:
  for annotation in annotations:annotation.set_text(annotation.get_text().replace('gini','基尼').replace('samples','样本数').replace('value','类别计数').replace('True','是').replace('False','否').replace('class','预测类'))
 save(fig,'tree')
 gx,gy=np.meshgrid(np.linspace(-1.7,2.7,160),np.linspace(-1.2,1.7,140));grid=np.c_[gx.ravel(),gy.ravel()];fig,axs=plt.subplots(1,2,figsize=(11,4.2),layout='constrained');axs[0].contourf(gx,gy,small.predict_proba(grid)[:,1].reshape(gx.shape),levels=np.linspace(0,1,11),cmap='RdBu_r',alpha=.6);axs[0].scatter(*Xm.T,c=ym,cmap='RdBu_r',s=15,edgecolor='white',lw=.3);axs[0].set(xlabel='x₀',ylabel='x₁',title=t('深度2分类树的矩形区域','Rectangular regions of a depth 2 tree'))
 xr=np.arange(1,7);yr=np.array([1.,1.,2.,6.,7.,7.]);cuts=np.arange(1.5,6,1);loss=[]
 for cut in cuts:
  left=yr[xr<=cut];right=yr[xr>cut];loss.append(float(np.sum((left-left.mean())**2)+np.sum((right-right.mean())**2)))
 axs[1].plot(cuts,loss,'o-',color='#167d87');axs[1].set(xlabel=t('回归树候选阈值','Regression-tree candidate threshold'),ylabel=t('两侧平方残差和','Within-child squared-error sum'),xticks=cuts);axs[1].axvline(3.5,color='#d48745',ls='--');fig.colorbar(axs[0].collections[0],ax=axs[0],shrink=.8,label=t('正类概率','Positive probability'));save(fig,'splits')
 X,y=make_classification(n_samples=1000,n_features=8,n_informative=4,n_redundant=2,n_clusters_per_class=2,class_sep=1.,flip_y=.04,shuffle=False,random_state=30);X=np.c_[X,X[:,0]+rng.normal(0,.03,len(X))];tr,te=train_test_split(np.arange(1000),test_size=.25,stratify=y,random_state=30)
 cv=StratifiedKFold(3,shuffle=True,random_state=30);full=DecisionTreeClassifier(random_state=30).fit(X[tr],y[tr]);alphas=full.cost_complexity_pruning_path(X[tr],y[tr]).ccp_alphas;subset=np.unique(np.quantile(alphas,np.linspace(0,.9,12)))
 search=GridSearchCV(DecisionTreeClassifier(random_state=30),{'ccp_alpha':subset},cv=cv,scoring='accuracy');search.fit(X[tr],y[tr]);pruned=search.best_estimator_
 base=[('lr',make_pipeline(StandardScaler(),LogisticRegression(max_iter=1500))),('knn',make_pipeline(StandardScaler(),KNeighborsClassifier(n_neighbors=15))),('rf',RandomForestClassifier(n_estimators=80,max_features=3,random_state=30,n_jobs=1))]
 models={'Tree':full,'Pruned tree':pruned,'Bagging':BaggingClassifier(estimator=DecisionTreeClassifier(),n_estimators=120,oob_score=True,random_state=30,n_jobs=1),'Random forest':RandomForestClassifier(n_estimators=120,max_features=3,oob_score=True,random_state=30,n_jobs=1),'Extra Trees':ExtraTreesClassifier(n_estimators=120,max_features=3,random_state=30,n_jobs=1),'Soft vote':VotingClassifier(estimators=base,voting='soft',n_jobs=1),'Stacking':StackingClassifier(estimators=base,final_estimator=LogisticRegression(),cv=cv,n_jobs=1)}
 results={}
 for name,m in models.items():
  m.fit(X[tr],y[tr]);p=m.predict_proba(X[te]);results[name]={'test_accuracy':float(accuracy_score(y[te],p.argmax(1))),'test_log_loss':float(log_loss(y[te],p)),'oob_accuracy':float(m.oob_score_) if hasattr(m,'oob_score_') else None}
 diversity=[]
 for mf in [1,3,9]:
  rf=RandomForestClassifier(n_estimators=120,max_features=mf,oob_score=True,random_state=30,n_jobs=1).fit(X[tr],y[tr]);errs=np.array([e.predict(X[te])!=y[te] for e in rf.estimators_],dtype=float);cc=np.corrcoef(errs);pair=float(cc[np.triu_indices_from(cc,1)].mean());diversity.append({'max_features':mf,'mean_tree_accuracy':float(1-errs.mean()),'error_correlation':pair,'forest_accuracy':float(rf.score(X[te],y[te])),'oob_accuracy':float(rf.oob_score_)})
 fig,axs=plt.subplots(1,2,figsize=(11,4.2),layout='constrained');positions=np.arange(len(results));axs[0].barh(positions,[r['test_accuracy'] for r in results.values()],color=['#a1b7c3','#a1b7c3','#167d87','#167d87','#167d87','#d48745','#d48745']);axs[0].set_yticks(positions,list(results));axs[0].set(xlim=(0,1.03),xlabel=t('独立测试准确率','Held-out accuracy'));axs[0].invert_yaxis()
 for key,label,col in [('mean_tree_accuracy',t('单树平均准确率','Mean individual accuracy'),'#d48745'),('forest_accuracy',t('森林准确率','Forest accuracy'),'#167d87'),('error_correlation',t('树错误相关系数','Tree-error correlation'),'#795e86')]:axs[1].plot([d['max_features'] for d in diversity],[d[key] for d in diversity],'o-',label=label,color=col)
 axs[1].set(xlabel=t('每个节点候选特征数','Candidate features per node'),ylabel=t('无量纲','Dimensionless'),xticks=[1,3,9],ylim=(0,1));axs[1].legend();save(fig,'ensemble')
 rf=models['Random forest'];perm=permutation_importance(rf,X[te],y[te],n_repeats=10,random_state=30,scoring='accuracy',n_jobs=1);joint=[]
 for _ in range(10):xp=X[te].copy();order=rng.permutation(len(te));xp[:,[0,8]]=xp[order][:,[0,8]];joint.append(rf.score(X[te],y[te])-rf.score(xp,y[te]))
 oob=np.zeros(len(tr),int)
 for sample in models['Bagging'].estimators_samples_:oob+=~np.isin(np.arange(len(tr)),sample)
 fig,axs=plt.subplots(1,2,figsize=(11,4.2),layout='constrained');j=np.arange(9);axs[0].bar(j-.2,rf.feature_importances_,.4,label=t('不纯度贡献','Impurity contribution'),color='#167d87');axs[0].bar(j+.2,perm.importances_mean,.4,yerr=perm.importances_std,label=t('测试置换准确率下降','Test permutation accuracy drop'),color='#d48745');axs[0].set(xlabel=t('特征编号（x₈近似复制x₀）','Feature index (x₈ nearly copies x₀)'),ylabel=t('各自定义的无量纲量','Dimensionless, different definitions'),xticks=j);axs[0].legend(fontsize=9)
 axs[1].hist(oob,bins=np.arange(oob.min()-.5,oob.max()+1.5,2),color='#167d87');expected=120*(1-1/len(tr))**len(tr);axs[1].axvline(expected,color='#d48745',ls='--',label=t('理论期望','Expected count'));axs[1].set(xlabel=t('一条训练记录的袋外树数','OOB trees for a training observation'),ylabel=t('训练记录数','Training observations'));axs[1].legend();save(fig,'importance')
 summary={'train_n':len(tr),'test_n':len(te),'features':X.shape[1],'models':results,'pruning_alpha':float(search.best_params_['ccp_alpha']),'full_leaves':int(full.get_n_leaves()),'pruned_leaves':int(pruned.get_n_leaves()),'diversity':diversity,'mean_oob_trees':float(oob.mean()),'expected_oob_trees':expected,'joint_x0_x8_permutation_drop':float(np.mean(joint)),'individual_x0_drop':float(perm.importances_mean[0]),'individual_x8_drop':float(perm.importances_mean[8]),'regression_split_losses':loss,'best_regression_split':float(cuts[np.argmin(loss)]),'best_regression_sse':min(loss)}
 (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');np.savez(out/'experiment_data.npz',X=X,y=y,train=tr,test=te,moon_X=Xm,moon_y=ym,oob_counts=oob,permutation_drops=perm.importances,regression_x=xr,regression_y=yr)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--language',choices=['zh','en'],default='en');a=ap.parse_args();main(a.output,a.language)
