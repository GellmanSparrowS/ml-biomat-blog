# Public sources and third-party materials

- scikit-learn — Decision Trees: https://scikit-learn.org/stable/modules/tree.html
  BSD-3-Clause
- scikit-learn — Ensemble Methods: https://scikit-learn.org/stable/modules/ensemble.html
  BSD-3-Clause
- Breiman (2001), Random Forests: https://www.stat.berkeley.edu/~breiman/randomforest2001.pdf
  Reference
