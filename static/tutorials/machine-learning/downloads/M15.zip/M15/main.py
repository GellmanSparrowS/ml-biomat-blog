"""Remember a marked first observation with RNN, LSTM, and GRU.

Synthetic task: the first channel starts with a random sign; subsequent values
are distractors. The second channel marks the first observation. Predict its sign
after the whole sequence. CPU training and all plots are self-contained.
"""
from pathlib import Path
import argparse,copy,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import torch
from torch import nn


def make_data(n,length,seed):
    rng=np.random.default_rng(seed)
    labels=rng.integers(0,2,n)
    x=np.zeros((n,length,2),dtype=np.float32)
    x[:,:,0]=rng.normal(0,.3,(n,length))
    x[:,0,0]=2*labels-1
    x[:,0,1]=1
    return torch.from_numpy(x),torch.tensor(labels,dtype=torch.float32)


class Remember(nn.Module):
    def __init__(self,kind):
        super().__init__()
        self.recurrent=getattr(nn,kind)(2,16,batch_first=True)
        self.readout=nn.Linear(16,1)
    def forward(self,x):
        output,_=self.recurrent(x)
        return self.readout(output[:,-1,:]).squeeze(-1)


def run(output,language):
    output.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    zh=language=='zh';tr=lambda a,b:a if zh else b
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,
                         'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    train_x,train_y=make_data(800,16,151)
    val_x,val_y=make_data(300,16,152)
    models={};histories={};metrics={};colors={'RNN':'#0072B2','LSTM':'#D58500','GRU':'#008675'}
    lengths=[8,16,32,64]
    for kind in ['RNN','LSTM','GRU']:
        torch.manual_seed(153)
        model=Remember(kind);opt=torch.optim.Adam(model.parameters(),lr=.01)
        criterion=nn.BCEWithLogitsLoss();history=[];best=float('inf');best_state=None;best_epoch=0
        generator=torch.Generator().manual_seed(154)
        for epoch in range(1,81):
            model.train();order=torch.randperm(len(train_x),generator=generator)
            for indices in order.split(100):
                opt.zero_grad(set_to_none=True)
                loss=criterion(model(train_x[indices]),train_y[indices])
                loss.backward();nn.utils.clip_grad_norm_(model.parameters(),max_norm=1.0);opt.step()
            model.eval()
            with torch.no_grad():
                vl=criterion(model(val_x),val_y).item()
                tl=criterion(model(train_x),train_y).item()
            history.append([epoch,tl,vl])
            if vl<best:best=vl;best_epoch=epoch;best_state=copy.deepcopy(model.state_dict())
        model.load_state_dict(best_state);model.eval();models[kind]=model;histories[kind]=np.array(history)
        accuracies=[]
        with torch.no_grad():
            for length in lengths:
                tx,ty=make_data(500,length,160+length)
                accuracies.append(float(((model(tx)>=0)==ty.bool()).float().mean()))
        metrics[kind]={'parameters':sum(p.numel() for p in model.parameters()),'best_epoch':best_epoch,
                       'validation_loss':best,'test_accuracy_by_length':dict(zip(map(str,lengths),accuracies))}
        torch.save(model.state_dict(),output/f'{kind}.pt')

    # Exact single-cell arithmetic with controlled gates, independent of training.
    f,i,o,g,c_prev=.9,.2,.7,-.5,.8
    c=f*c_prev+i*g;h=o*np.tanh(c)
    assert abs(c-.62)<1e-12
    # PyTorch LSTM gate order: input, forget, candidate, output.
    sample,_=make_data(1,16,999)
    cell=models['LSTM'].recurrent;H=torch.zeros(1,16);C=torch.zeros(1,16);trace=[]
    with torch.no_grad():
        for t in range(16):
            pre=sample[:,t]@cell.weight_ih_l0.T+cell.bias_ih_l0+H@cell.weight_hh_l0.T+cell.bias_hh_l0
            ip,fp,gp,op=pre.chunk(4,dim=1)
            I,F,G,O=torch.sigmoid(ip),torch.sigmoid(fp),torch.tanh(gp),torch.sigmoid(op)
            C=F*C+I*G;H=O*torch.tanh(C)
            trace.append(np.stack([F[0].numpy(),I[0].numpy(),O[0].numpy(),C[0].numpy()]))
        full,_=cell(sample)
        manual_error=float(torch.max(torch.abs(full[:,-1,:]-H)))
    assert manual_error<1e-6
    trace=np.stack(trace)
    # Choose the unit with greatest absolute terminal cell value; selection is explicit.
    unit=int(np.argmax(np.abs(trace[-1,3])))
    # Hold the same first signs fixed while reading every prefix of a 64-step set.
    # Removing distractor amplitudes isolates learned state dynamics from noise.
    diagnostic_x,diagnostic_y=make_data(500,64,4242)
    diagnostic_zero=diagnostic_x.clone();diagnostic_zero[:,1:,0]=0
    prefix_diagnostics={}
    with torch.no_grad():
        for kind,model in models.items():
            for condition,dx in [('noise',diagnostic_x),('zero_suffix',diagnostic_zero)]:
                hidden,_=model.recurrent(dx)
                predictions=model.readout(hidden).squeeze(-1)>=0
                accuracy=(predictions==diagnostic_y[:,None].bool()).float().mean(0)
                prefix_diagnostics[f'{kind}_{condition}']=accuracy.numpy().tolist()

    fig=plt.figure(figsize=(12,7),layout='constrained');gs=fig.add_gridspec(2,3)
    ax=fig.add_subplot(gs[0,:2])
    for kind in models:ax.plot(histories[kind][:,0],histories[kind][:,2],color=colors[kind],label=kind)
    ax.set(xlabel=tr('训练轮数','Epoch'),ylabel=tr('验证交叉熵','Validation cross entropy'));ax.legend()
    ax=fig.add_subplot(gs[0,2])
    for kind in models:ax.plot(lengths,[metrics[kind]['test_accuracy_by_length'][str(t)] for t in lengths],'-o',color=colors[kind],label=kind)
    ax.axvline(16,color='#66737a',ls='--',lw=1);ax.axhline(.5,color='#8c989f',ls=':',lw=1)
    ax.set(xticks=lengths,ylim=(0,1.03),xlabel=tr('测试序列长度','Test sequence length'),ylabel=tr('准确率','Accuracy'))
    ax=fig.add_subplot(gs[1,:])
    probe,probe_y=make_data(1,64,999)
    with torch.no_grad():
        for kind,model in models.items():
            hidden,_=model.recurrent(probe)
            prob=torch.sigmoid(model.readout(hidden)).numpy().ravel()
            correct=prob if int(probe_y[0])==1 else 1-prob
            ax.plot(np.arange(1,65),correct,color=colors[kind],label=kind)
    ax.axvline(16,color='#66737a',ls='--',lw=1)
    ax.set(xticks=[1,8,16,32,48,64],ylim=(0,1.03),xlabel=tr('读到的时间步（离散索引）','Observed time steps (discrete index)'),ylabel=tr('真实首项类别的读出概率','Readout probability of the true first class'));ax.legend(ncol=3)
    fig.savefig(output/f'recall-{language}.svg');plt.close(fig)

    fig=plt.figure(figsize=(12,5.4),layout='constrained');gs=fig.add_gridspec(1,2,width_ratios=[1.5,1])
    ax=fig.add_subplot(gs[0,0]);im=ax.imshow(trace[:,:,unit].T,aspect='auto',origin='lower',cmap='viridis',vmin=0,vmax=1)
    # Show gate rows only because cell state is not constrained to [0,1].
    ax.clear();im=ax.imshow(trace[:,:3,unit].T,aspect='auto',origin='lower',cmap='viridis',vmin=0,vmax=1)
    ax.set(yticks=[0,1,2],yticklabels=[tr('遗忘门 f','Forget f'),tr('输入门 i','Input i'),tr('输出门 o','Output o')],
           xticks=[0,3,7,11,15],xticklabels=[1,4,8,12,16],xlabel=tr('时间步','Time step'))
    fig.colorbar(im,ax=ax,label=tr('门值（0–1）','Gate value (0–1)'),shrink=.7)
    ax=fig.add_subplot(gs[0,1]);ax.plot(np.arange(1,17),trace[:,3,unit],'-o',color=colors['LSTM'])
    ax.set(xlabel=tr('时间步','Time step'),ylabel=tr(f'细胞状态（单元{unit}）',f'Cell state (unit {unit})'))
    fig.savefig(output/f'gates-{language}.svg');plt.close(fig)

    fig,axes=plt.subplots(1,2,figsize=(11.5,4.4),layout='constrained')
    steps=np.arange(0,41)
    for gain in [.8,1,1.2]:axes[0].semilogy(steps,gain**steps,label=f'a={gain}')
    axes[0].set(xlabel=tr('跨越步数','Number of steps'),ylabel=tr('简化线性链的梯度倍率','Gradient multiplier in a linear chain'));axes[0].legend()
    for keep in [.5,.9,.99]:axes[1].plot(steps,keep**steps,label=f'f={keep}')
    axes[1].set(xlabel=tr('跨越步数','Number of steps'),ylabel=tr('固定门、无新写入时保留比例','Retained fraction: fixed gate, no new input'));axes[1].legend()
    fig.savefig(output/f'memory-{language}.svg');plt.close(fig)
    fig,ax=plt.subplots(figsize=(12,4.3),layout='constrained')
    keys=list(prefix_diagnostics)
    im=ax.imshow(np.array([prefix_diagnostics[k] for k in keys]),aspect='auto',cmap='viridis',vmin=0,vmax=1)
    labels=[k.replace('_zero_suffix',tr('：后续全零',': zero suffix')).replace('_noise',tr('：有干扰',': distractors')) for k in keys]
    ax.set(yticks=range(6),yticklabels=labels,xticks=[0,7,15,23,31,39,47,55,63],xticklabels=[1,8,16,24,32,40,48,56,64],xlabel=tr('同一组序列的前缀长度','Prefix length of the same sequence set'))
    ax.axvline(15,color='white',ls='--',lw=1)
    fig.colorbar(im,ax=ax,label=tr('500条序列的分类准确率','Classification accuracy over 500 sequences'),shrink=.8)
    fig.savefig(output/f'prefix-{language}.svg');plt.close(fig)
    summary={'train_size':800,'validation_size':300,'test_per_length':500,'training_length':16,
             'epochs':80,'hidden_size':16,'models':metrics,'manual_cell':{'f':f,'i':i,'o':o,'g':g,'c_previous':c_prev,'c':c,'h':float(h)},
             'manual_lstm_vs_module_error':manual_error,'plotted_unit':unit,
             'linear_gradient_20':{'0.8':.8**20,'1.2':1.2**20},'prefix_diagnostics':prefix_diagnostics,'torch_version':torch.__version__}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    np.savez(output/'experiment.npz',sample=sample.numpy(),trace=trace,**{f'history_{k}':v for k,v in histories.items()})
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'))
    p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();run(a.output,a.language)
