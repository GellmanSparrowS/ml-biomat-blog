# Public sources and third-party materials

- Dive into Deep Learning — Long Short-Term Memory: https://d2l.ai/chapter_recurrent-modern/lstm.html
  CC BY-SA 4.0 text/figures; code Apache 2.0
- Dive into Deep Learning — Gated Recurrent Units: https://d2l.ai/chapter_recurrent-modern/gru.html
  CC BY-SA 4.0
- Learning Phrase Representations using RNN Encoder–Decoder for Statistical Machine Translation: https://arxiv.org/abs/1406.1078
  Linked as primary research; no figure copied
- PyTorch — LSTM: https://docs.pytorch.org/docs/2.15/generated/torch.nn.LSTM.html
  PyTorch documentation; technical reference
- PyTorch — GRU: https://docs.pytorch.org/docs/2.15/generated/torch.nn.GRU.html
  PyTorch documentation; technical reference
- Dive into Deep Learning — Sequence to Sequence Learning: https://d2l.ai/chapter_recurrent-modern/seq2seq.html
  CC BY-SA 4.0
