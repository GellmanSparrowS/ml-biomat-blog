# Public sources and third-party materials

- Language Modeling from Scratch: https://cs336.stanford.edu/
  Technical reference; all chapter figures and teaching code are original.
- Hugging Face — BPE tokenization: https://huggingface.co/learn/llm-course/chapter6/5
  Technical reference; all chapter figures and teaching code are original.
- LoRA: Low-Rank Adaptation of Large Language Models: https://arxiv.org/abs/2106.09685
  Technical reference; all chapter figures and teaching code are original.
- Hugging Face PEFT — LoRA: https://huggingface.co/docs/peft/main/conceptual_guides/lora
  Technical reference; all chapter figures and teaching code are original.
- QLoRA: https://arxiv.org/abs/2305.14314
  Technical reference; all chapter figures and teaching code are original.
- Direct Preference Optimization: https://arxiv.org/abs/2305.18290
  Technical reference; all chapter figures and teaching code are original.
- Training Compute-Optimal Large Language Models: https://arxiv.org/abs/2203.15556
  Technical reference; all chapter figures and teaching code are original.
- Switch Transformers: https://arxiv.org/abs/2101.03961
  Technical reference; all chapter figures and teaching code are original.
- Scaling LLM Test-Time Compute Optimally: https://arxiv.org/abs/2408.03314
  Technical reference; all chapter figures and teaching code are original.
- Hugging Face — Model Cards: https://huggingface.co/docs/hub/model-cards
  Technical reference; all chapter figures and teaching code are original.
