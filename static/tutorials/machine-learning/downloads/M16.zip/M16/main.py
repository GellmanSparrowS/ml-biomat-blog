"""A tiny causal language model, genuine low-rank adaptation, and exact checks."""
import argparse,copy,json,math,time
from pathlib import Path
import numpy as np
import torch
from torch import nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

torch.set_num_threads(2)
WORDS=['<pad>','<bos>','<eos>','the','red','green','blue','fox','dog','cat','runs','sleeps','jumps','.','color','of','?',':']
VOCAB={w:i for i,w in enumerate(WORDS)};D=32
def ids(words):return [VOCAB[w]for w in words]

class Attention(nn.Module):
    def __init__(self):
        super().__init__();self.q=nn.Linear(D,D);self.k=nn.Linear(D,D);self.v=nn.Linear(D,D);self.out=nn.Linear(D,D)
    def forward(self,x):
        b,t,d=x.shape
        q,k,v=[layer(x).reshape(b,t,4,8).transpose(1,2)for layer in [self.q,self.k,self.v]]
        scores=q@k.transpose(-2,-1)/math.sqrt(8);mask=torch.triu(torch.ones(t,t,dtype=torch.bool),diagonal=1);scores=scores.masked_fill(mask,float('-inf'))
        return self.out((scores.softmax(-1)@v).transpose(1,2).reshape(b,t,d))

class TinyLM(nn.Module):
    def __init__(self):
        super().__init__();self.token=nn.Embedding(len(WORDS),D);self.position=nn.Embedding(16,D);self.norm1=nn.LayerNorm(D);self.attn=Attention();self.norm2=nn.LayerNorm(D);self.ff=nn.Sequential(nn.Linear(D,64),nn.GELU(),nn.Linear(64,D));self.final=nn.LayerNorm(D);self.head=nn.Linear(D,len(WORDS))
    def forward(self,tokens):
        x=self.token(tokens)+self.position(torch.arange(tokens.shape[1]))[None];x=x+self.attn(self.norm1(x));x=x+self.ff(self.norm2(x));return self.head(self.final(x))

class LoRALinear(nn.Module):
    def __init__(self,base,rank=4,alpha=8):
        super().__init__();self.base=base;self.A=nn.Parameter(torch.randn(rank,base.in_features)*.02);self.B=nn.Parameter(torch.zeros(base.out_features,rank));self.scale=alpha/rank
        for p in self.base.parameters():p.requires_grad=False
    def forward(self,x):return self.base(x)+(x@self.A.T@self.B.T)*self.scale
    def merged(self):
        layer=copy.deepcopy(self.base)
        with torch.no_grad():layer.weight.add_(self.scale*self.B@self.A)
        return layer

def corpus():
    parts=[[],[],[]];sentences=[[],[],[]]
    for c,color in enumerate(['red','green','blue']):
        for a,animal in enumerate(['fox','dog','cat']):
            for v,verb in enumerate(['runs','sleeps','jumps']):
                residue=(c+2*a+v)%5;split=2 if residue==0 else 1 if residue==1 else 0
                words=['<bos>','the',color,animal,verb,'.','<eos>'];parts[split].append(ids(words));sentences[split].append(' '.join(words))
    return [torch.tensor(p)for p in parts],sentences

def prompts():
    allrows=[];istrain=[]
    for c,color in enumerate(['red','green','blue']):
        for a,animal in enumerate(['fox','dog','cat']):
            allrows.append(ids(['<bos>','color','of','the',color,animal,'?',':',color,'<eos>']));istrain.append(c!=a)
    return torch.tensor(allrows),np.array(istrain)

def lm_loss(model,rows):
    out=model(rows[:,:-1]);return nn.functional.cross_entropy(out.reshape(-1,len(WORDS)),rows[:,1:].reshape(-1))

def generate(model,prompt,steps=8):
    tokens=list(prompt)
    for _ in range(steps):
        with torch.no_grad():n=int(model(torch.tensor([tokens]))[0,-1].argmax())
        tokens.append(n)
        if n==VOCAB['<eos>']:break
    return ' '.join(WORDS[n]for n in tokens)

def run(out,language):
    out.mkdir(parents=True,exist_ok=True);torch.manual_seed(16);rng=np.random.default_rng(16);text=lambda z,e:z if language=='zh' else e
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','axes.unicode_minus':False})
    save=lambda fig,n:(fig.savefig(out/f'{n}-{language}.svg',bbox_inches='tight'),fig.savefig(out/f'{n}-{language}.png',dpi=140,bbox_inches='tight'),plt.close(fig))
    (train,valid,test),sentences=corpus();base=TinyLM();optimizer=torch.optim.Adam(base.parameters(),lr=.003);trace=[];best=float('inf');selected=0;start=time.perf_counter()
    for step in range(1,401):
        batch=train[torch.randint(len(train),(24,))];optimizer.zero_grad();loss=lm_loss(base,batch);loss.backward();optimizer.step()
        if step%10==0:
            with torch.no_grad():vl=lm_loss(base,valid).item()
            trace.append([step,loss.item(),vl])
            if vl<best:best=vl;weights=copy.deepcopy(base.state_dict());selected=step
    elapsed=time.perf_counter()-start;base.load_state_dict(weights);base.eval()
    with torch.no_grad():test_loss=lm_loss(base,test).item()
    rows,adapttrain=prompts();labels=rows[:,1:].clone();labels[:,:7]=-100
    with torch.no_grad():before=base(rows[:,:8])[:,-1].softmax(1).numpy()
    adapted=copy.deepcopy(base)
    for p in adapted.parameters():p.requires_grad=False
    adapted.attn.q=LoRALinear(adapted.attn.q);adapted.attn.v=LoRALinear(adapted.attn.v);adapted.head=LoRALinear(adapted.head)
    with torch.no_grad():initial_error=float((base(rows[:,:8])-adapted(rows[:,:8])).abs().max())
    frozen={n:p.detach().clone()for n,p in adapted.named_parameters()if not p.requires_grad};opt=torch.optim.Adam([p for p in adapted.parameters()if p.requires_grad],lr=.015);atrace=[]
    for step in range(1,401):
        opt.zero_grad();logits=adapted(rows[adapttrain,:-1]);loss=nn.functional.cross_entropy(logits.reshape(-1,len(WORDS)),labels[adapttrain].reshape(-1),ignore_index=-100);loss.backward();opt.step()
        if step%10==0:atrace.append([step,loss.item()])
    with torch.no_grad():after=adapted(rows[:,:8])[:,-1].softmax(1).numpy();adapt_test_loss=nn.functional.cross_entropy(adapted(rows[~adapttrain,:-1]).reshape(-1,len(WORDS)),labels[~adapttrain].reshape(-1),ignore_index=-100).item()
    frozen_error=max(float((p-frozen[n]).abs().max())for n,p in adapted.named_parameters()if n in frozen)
    merged=copy.deepcopy(adapted);merged.attn.q=merged.attn.q.merged();merged.attn.v=merged.attn.v.merged();merged.head=merged.head.merged()
    with torch.no_grad():merge_error=float((merged(rows[:,:8])-adapted(rows[:,:8])).abs().max())
    torch.save(base.state_dict(),out/'base.pt');torch.save(merged.state_dict(),out/'merged.pt')
    metadata={'vocabulary':WORDS,'architecture':{'hidden_dimension':32,'heads':4,'blocks':1,'feedforward_dimension':64,'max_positions':16},'adaptation':{'targets':['attn.q','attn.v','head'],'rank':4,'alpha':8},'selected_pretrain_step':selected}
    (out/'model.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    reloaded=load_model(out/'merged.pt')
    with torch.no_grad():reload_error=float((reloaded(rows[:,:8])-merged(rows[:,:8])).abs().max())
    true=rows[:,8].numpy();pred=after.argmax(1);bpred=before.argmax(1);delta=(adapted.head.scale*adapted.head.B@adapted.head.A).detach().numpy();singular=np.linalg.svd(delta,compute_uv=False)
    w=merged.head.weight.detach();scale=w.abs().amax(1,keepdim=True).clamp_min(1e-8)/127;quant=(w/scale).round().clamp(-127,127).to(torch.int8);recovered=quant.float()*scale;quant_error=float((w-recovered).abs().max())
    # Causal attention should leave a prefix unchanged when only its suffix changes.
    modified=test[:1,:-1].clone();modified[0,-1]=VOCAB['?']
    with torch.no_grad():causal_error=float((base(test[:1,:-1])[:,:-1]-base(modified)[:,:-1]).abs().max())
    dpo_loss=float(nn.functional.softplus(torch.tensor(-.2)));params=sum(p.numel()for p in base.parameters());trainable=sum(p.numel()for p in adapted.parameters()if p.requires_grad)
    summary={'vocabulary_size':len(WORDS),'unique_sentence_splits':[len(train),len(valid),len(test)],'unique_split_overlap':len(set(sentences[0])&set(sentences[2])),'base_parameters':params,'lora_trainable_parameters':trainable,'pretrain_selected_step':selected,'pretrain_test_loss':test_loss,'pretrain_test_perplexity':math.exp(test_loss),'pretrain_seconds':elapsed,'pretrain_tokens_per_second':400*24*6/elapsed,'base_color_accuracy':float(np.mean(bpred==true)),'lora_seen_pair_accuracy':float(np.mean(pred[adapttrain]==true[adapttrain])),'lora_unseen_pair_accuracy':float(np.mean(pred[~adapttrain]==true[~adapttrain])),'adapt_test_response_loss':adapt_test_loss,'lora_initial_output_error':initial_error,'frozen_parameter_max_change':frozen_error,'merged_logits_max_error':merge_error,'causal_prefix_error':causal_error,'lora_head_numerical_rank':int(np.sum(singular>1e-5)),'quant_head_max_weight_error':quant_error,'quant_head_storage_bytes':quant.numel()+scale.numel()*4,'float_head_storage_bytes':w.numel()*4,'dpo_hand_loss':dpo_loss,'base_generated':generate(base,ids(['<bos>'])),'adapted_outputs':[generate(adapted,row[:8].tolist(),3)for row in rows]}
    summary.update({'reloaded_logits_max_error':reload_error,'reloaded_example':generate(reloaded,ids(['<bos>','color','of','the','red','fox','?',':']),3)})
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');np.savez_compressed(out/'data.npz',pretrain_trace=trace,adapt_trace=atrace,before=before,after=after,targets=true,train_mask=adapttrain,head_delta=delta,singular_values=singular)
    (out/'corpus.json').write_text(json.dumps({'train':sentences[0],'validation':sentences[1],'test':sentences[2]},indent=2),encoding='utf-8')
    assert initial_error==0 and frozen_error==0 and causal_error<1e-6 and merge_error<1e-4 and reload_error==0
    fig,axs=plt.subplots(1,2,figsize=(11,4),layout='constrained');tr=np.array(trace);at=np.array(atrace)
    axs[0].plot(tr[:,0],tr[:,1],label=text('训练','Train'),color='#176b91');axs[0].plot(tr[:,0],tr[:,2],label=text('验证：独立句子','Validation: held-out sentences'),color='#bc584d');axs[0].axvline(selected,color='#9a9a9a',ls='--');axs[0].set(xlabel=text('预训练步数','Pretraining step'),ylabel=text('每token交叉熵','Cross entropy per token'));axs[0].legend()
    axs[1].plot(at[:,0],at[:,1],color='#267c6a');axs[1].set(xlabel=text('LoRA步数','LoRA step'),ylabel=text('仅回答token的交叉熵','Cross entropy on answer tokens'));save(fig,'training')
    fig,axs=plt.subplots(1,2,figsize=(11,5),layout='constrained');promptnames=[f'{WORDS[row[4]]} {WORDS[row[5]]}'for row in rows]
    for ax,probs,title in zip(axs,[before,after],[text('适配前','Before adaptation'),text('LoRA之后','After LoRA')]):
        im=ax.imshow(probs[:,4:7],vmin=0,vmax=1,cmap='Blues',aspect='auto');ax.set(xticks=range(3),xticklabels=['red','green','blue'],yticks=range(9),yticklabels=[s+(' *'if not adapttrain[i]else'')for i,s in enumerate(promptnames)],title=title,xlabel=text('颜色token','Color token'))
        for i in range(9):
            for j in range(3):ax.text(j,i,f'{probs[i,4+j]:.2f}',ha='center',va='center',color='white'if probs[i,4+j]>.5 else '#193b50',fontsize=9)
    fig.colorbar(im,ax=axs,label=text('在完整18词表中的概率','Probability in the full 18-token vocabulary'));save(fig,'answers')
    fig,axs=plt.subplots(1,3,figsize=(12,3.5),layout='constrained');lim=max(abs(delta).max(),1e-9);im=axs[0].imshow(delta,cmap='RdBu_r',vmin=-lim,vmax=lim,aspect='auto');axs[0].set(xlabel=text('输入维度','Input dimension'),ylabel=text('输出token','Output token'),title=text('输出层低秩增量','Low-rank output-head update'));fig.colorbar(im,ax=axs[0])
    axs[1].semilogy(np.arange(1,len(singular)+1),np.maximum(singular,1e-9),'o-',color='#176b91');axs[1].axvline(4.5,color='#aaa',ls='--');axs[1].set(xlabel=text('奇异值编号','Singular value index'),ylabel=text('奇异值','Singular value'),title=text('秩4的结构','Rank-four structure'))
    axs[2].bar([text('全模型','Base model'),'LoRA'],[params,trainable],color=['#9babb5','#267c6a']);axs[2].set(ylabel=text('参数个数','Parameter count'),title=text('冻结与训练','Frozen and trainable'));save(fig,'adapters')
    print(json.dumps(summary,indent=2))

def load_model(checkpoint):
    metadata=json.loads(checkpoint.with_name('model.json').read_text(encoding='utf-8'))
    expected={'hidden_dimension':32,'heads':4,'blocks':1,'feedforward_dimension':64,'max_positions':16}
    if metadata['vocabulary']!=WORDS or metadata['architecture']!=expected:raise ValueError('Checkpoint vocabulary or architecture does not match TinyLM.')
    model=TinyLM();model.load_state_dict(torch.load(checkpoint,map_location='cpu',weights_only=True));return model.eval()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('output'));p.add_argument('--language',choices=['zh','en'],default='en');p.add_argument('--load',type=Path);p.add_argument('--prompt',default='<bos> color of the red fox ? :');args=p.parse_args()
    if args.load:print(generate(load_model(args.load),ids(args.prompt.split()),3))
    else:run(args.output,args.language)
