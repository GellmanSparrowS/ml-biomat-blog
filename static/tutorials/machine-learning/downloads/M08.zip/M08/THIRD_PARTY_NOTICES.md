# Public sources and third-party materials

- Neyman (1923; English translation 1990), On the Application of Probability Theory to Agricultural Experiments: https://ics.uci.edu/~sternh/courses/265/neyman_statsci1990.pdf
  Primary reference; no article figure reproduced
- DoWhy — User guide: https://www.pywhy.org/dowhy/main/user_guide/
  MIT project; original graph attributed
- DoWhy repository: https://github.com/py-why/dowhy
  MIT
- EconML — Double Machine Learning: https://econml.azurewebsites.net/spec/estimation/dml.html
  Technical reference
- Causal Inference for the Brave and True — Regression Discontinuity: https://matheusfacure.github.io/python-causality-handbook/16-Regression-Discontinuity-Design.html
  Open tutorial; linked reference
- Final report on the aspirin component of the ongoing Physicians’ Health Study (1989): https://www.urmc.rochester.edu/MediaLibraries/URMCMedia/neurology/documents/PHS.pdf
  Primary paper; aggregate numerical facts, no figure or prose reproduced
