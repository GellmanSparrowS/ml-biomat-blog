"""Causal designs with known synthetic effects and one public aggregate experiment."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.special import expit
from scipy.stats import norm
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors
from threadpoolctl import threadpool_limits
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def ols(X,y):
 b=np.linalg.lstsq(X,y,rcond=None)[0];r=y-X@b;s2=r@r/(len(y)-X.shape[1]);cov=s2*np.linalg.inv(X.T@X);return b,np.sqrt(np.diag(cov))

def crossfit(X,T,Y,seed=8):
 e=np.zeros(len(T));m0=np.zeros(len(T));m1=np.zeros(len(T));m=np.zeros(len(T));fold=np.zeros(len(T),int)
 for k,(train,test) in enumerate(StratifiedKFold(5,shuffle=True,random_state=seed).split(X,T)):
  prop=LogisticRegression(C=10,max_iter=1000).fit(X[train],T[train]);e[test]=prop.predict_proba(X[test])[:,1];fold[test]=k
  for group,dest in [(0,m0),(1,m1)]:
   ind=train[T[train]==group];model=HistGradientBoostingRegressor(max_iter=120,max_leaf_nodes=9,l2_regularization=2,random_state=seed).fit(X[ind],Y[ind]);dest[test]=model.predict(X[test])
  model=HistGradientBoostingRegressor(max_iter=120,max_leaf_nodes=9,l2_regularization=2,random_state=seed).fit(X[train],Y[train]);m[test]=model.predict(X[test])
 return e,m0,m1,m,fold

def n_per_arm(p0,p1,alpha=.05,power=.8):
 p=(p0+p1)/2;return float(((norm.ppf(1-alpha/2)*np.sqrt(2*p*(1-p))+norm.ppf(power)*np.sqrt(p0*(1-p0)+p1*(1-p1)))/(p1-p0))**2)

def main(out,lang):
 out=Path(out);out.mkdir(parents=True,exist_ok=True);zh=lang=='zh';L=lambda z,e:z if zh else e;rng=np.random.default_rng(8)
 plt.rcParams.update({'font.family':'Microsoft YaHei' if zh else 'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','axes.unicode_minus':False})
 def save(fig,name):fig.savefig(out/f'{name}-{lang}.svg',bbox_inches='tight');plt.close(fig)
 n=3000;X=rng.uniform(-2,2,(n,6));true_e=expit(.6*X[:,0]-.4*X[:,1]);T=rng.binomial(1,true_e);tau=1+.5*X[:,0];noise=rng.normal(0,1,n);Y0=2+1.5*X[:,0]+X[:,1]**2+np.sin(X[:,2])+noise;Y1=Y0+tau;Y=np.where(T,Y1,Y0)
 e,m0,m1,m,fold=crossfit(X,T,Y);e=np.clip(e,.001,.999);phi=m1-m0+T*(Y-m1)/e-(1-T)*(Y-m0)/(1-e);aipw=float(phi.mean());aipw_se=float(phi.std(ddof=1)/np.sqrt(n));ipw=float(np.mean(T*Y/e-(1-T)*Y/(1-e)));hajek=float(np.sum(T*Y/e)/np.sum(T/e)-np.sum((1-T)*Y/(1-e))/np.sum((1-T)/(1-e)));naive=float(Y[T==1].mean()-Y[T==0].mean())
 residual_T=T-e;residual_Y=Y-m;design=np.c_[residual_T,residual_T*X[:,0]];dml=np.linalg.lstsq(design,residual_Y,rcond=None)[0];dml_ate=float(dml[0]);cate=dml[0]+dml[1]*X[:,0]
 # Nearest-neighbor matching with replacement estimates ATT for treated records.
 scaled=StandardScaler().fit_transform(X[:,:3]);treated=np.flatnonzero(T==1);controls=np.flatnonzero(T==0);nearest=NearestNeighbors(n_neighbors=1).fit(scaled[controls]).kneighbors(scaled[treated],return_distance=False)[:,0];matched=controls[nearest];att=float(np.mean(Y[treated]-Y[matched]));true_att=float(tau[treated].mean())
 def smd(weights):
  mean1=np.average(X[T==1],axis=0,weights=weights[T==1]);mean0=np.average(X[T==0],axis=0,weights=weights[T==0]);return (mean1-mean0)/np.sqrt((X[T==1].var(0,ddof=1)+X[T==0].var(0,ddof=1))/2)
 w=np.where(T==1,1/e,1/(1-e));before=smd(np.ones(n));after=smd(w)
 fig,axs=plt.subplots(1,3,figsize=(15,4.8),layout='constrained');axs[0].hist(e[T==0],bins=25,alpha=.5,density=True,label=L('未分配券','No coupon'),color='#237b94');axs[0].hist(e[T==1],bins=25,alpha=.5,density=True,label=L('分配券','Coupon'),color='#d87430');axs[0].set(xlabel=L('折外倾向概率','Out-of-fold propensity'),ylabel=L('密度','Density'),title=L('两组的共同支持','Overlap between groups'));axs[0].legend(fontsize=9)
 axs[1].plot(abs(before),range(6),'o-',label=L('调整前','Before'));axs[1].plot(abs(after),range(6),'s-',label=L('IPW调整后','After IPW'));axs[1].axvline(.1,color='#aab7bf',ls=':');axs[1].set(yticks=range(6),yticklabels=[f'x{j}' for j in range(6)],xlabel=L('绝对标准化均值差','Absolute standardized mean difference'),title=L('观测变量的平衡','Balance of observed covariates'));axs[1].legend(fontsize=9)
 names=['Naive','IPW','Hajek','AIPW','DML'];vals=[naive,ipw,hajek,aipw,dml_ate];axs[2].barh(names,vals,color=['#aab7bf']+['#237b94']*4);axs[2].axvline(1,color='#d87430',ls='--',label=L('生成总体ATE=1','Generating population ATE=1'));axs[2].errorbar(aipw,3,xerr=1.96*aipw_se,fmt='none',color='#263744',capsize=4);axs[2].set(xlabel=L('结果单位的平均处理效应','Average treatment effect in outcome units'));axs[2].legend(fontsize=8);save(fig,'adjustment')
 fig,axs=plt.subplots(1,2,figsize=(11,4.4),layout='constrained');xx=np.linspace(-2,2,100);axs[0].plot(xx,1+.5*xx,color='#d87430',label=L('生成效应','Generating effect'));axs[0].plot(xx,dml[0]+dml[1]*xx,'--',color='#237b94',label=L('折外残差DML','Cross-fitted residual DML'));axs[0].set(xlabel='x0',ylabel=L('条件平均处理效应','Conditional average treatment effect'));axs[0].legend();axs[1].bar(['ATE','ATT'],[aipw,att],color=['#237b94','#609b6d']);axs[1].scatter([0,1],[1,true_att],marker='_',s=500,color='#d87430',linewidth=3,label=L('对应真实目标','Corresponding true target'));axs[1].set(ylabel=L('结果单位','Outcome units'),title=L('人群变了，目标也变了','A different population changes the target'));axs[1].legend(fontsize=9);save(fig,'heterogeneity')
 # Three distinct identification designs, each with an explicit known mechanism.
 N=4000;U=rng.normal(size=N);Z=rng.binomial(1,.5,N);eps=rng.normal(size=N);outcome_noise=rng.normal(size=N);iv={}
 for strength in [1.,.05]:
  treatment=(strength*Z+.8*U+eps>0).astype(int);outcome=2*treatment+U+outcome_noise;first=float(treatment[Z==1].mean()-treatment[Z==0].mean());reduced=float(outcome[Z==1].mean()-outcome[Z==0].mean());iv[str(strength)]={'first_stage':first,'reduced_form':reduced,'wald_effect':reduced/first}
 G=np.repeat([0,1],400);time=np.arange(-2,2);panel_noise=rng.normal(0,.5,(800,4));did={};panel={}
 for trend in [0.,.7]:
  yy=10+2*G[:,None]+.8*time[None,:]+3*G[:,None]*(time>=0)[None,:]+trend*G[:,None]*time[None,:]+panel_noise;means=np.array([yy[G==g].mean(0) for g in [0,1]]);effect=float((means[1,2:].mean()-means[1,:2].mean())-(means[0,2:].mean()-means[0,:2].mean()));did[str(trend)]=effect;panel[str(trend)]=means
 running=rng.uniform(-1,1,N);D=(running>=0).astype(int);outcome=1+2*running+1.5*D+rng.normal(0,.4,N);rd={}
 for bandwidth in [.2,.4,.8]:
  use=abs(running)<=bandwidth;rdX=np.c_[np.ones(use.sum()),running[use],D[use],running[use]*D[use]];b,se=ols(rdX,outcome[use]);rd[str(bandwidth)]={'n':int(use.sum()),'jump':float(b[2]),'se':float(se[2])}
 fig,axs=plt.subplots(1,3,figsize=(15,4.7),layout='constrained');axs[0].bar([0,1],[iv['1.0']['first_stage'],iv['0.05']['first_stage']],color=['#237b94','#d87430']);axs[0].set(xticks=[0,1],xticklabels=[L('强鼓励','Strong encouragement'),L('弱鼓励','Weak encouragement')],ylabel=L('第一阶段处理率差','First-stage treatment-rate difference'));axs[0].set_title(L('工具变量先改变处理','Instrument first changes treatment'))
 for tr,style in [('0.0','-'),('0.7','--')]:
  for g,c in [(0,'#83949e'),(1,'#237b94')]:axs[1].plot(time,panel[tr][g],style+'o',color=c,label=(L('对照','Control') if g==0 else L('处理','Treated'))+f' trend={tr}')
 axs[1].axvline(-.5,color='#d87430',ls=':');axs[1].set(xlabel=L('时期','Period'),ylabel=L('平均结果','Mean outcome'),title=L('DiD与平行趋势','DiD and parallel trends'));axs[1].legend(fontsize=7)
 use=abs(running)<=.4;axs[2].scatter(running[use],outcome[use],s=5,c=np.where(D[use],'#d87430','#237b94'),alpha=.25);b,_=ols(np.c_[np.ones(use.sum()),running[use],D[use],running[use]*D[use]],outcome[use]);
 for side,interval in [(0,[-.4,0]),(1,[0,.4])]:
  rx=np.linspace(*interval,100);axs[2].plot(rx,b[0]+b[1]*rx+b[2]*side+b[3]*rx*side,color='#263744')
 axs[2].set(xlabel=L('运行变量距阈值','Running variable relative to cutoff'),ylabel=L('结果','Outcome'),title=L('RD：阈值附近的跳跃','RD: a jump near the cutoff'));save(fig,'designs')
 # Sensitivity demonstration: a generated omitted U is known to the simulator.
 Xs=rng.normal(size=3000);Us=rng.normal(size=3000);Ts=(.8*Xs+Us+rng.normal(size=3000)>0).astype(int);sn=rng.normal(size=3000);sens=[]
 for gamma in [0,.5,1,1.5,2]:
  ys=Ts+2*Xs+gamma*Us+sn;omit,_=ols(np.c_[np.ones(3000),Ts,Xs],ys);full,_=ols(np.c_[np.ones(3000),Ts,Xs,Us],ys);sens.append({'hidden_effect':gamma,'omitted_U':float(omit[1]),'included_U':float(full[1])})
 # Public aggregate facts from the 1989 FINAL PHS report; crude summaries, not its adjusted analysis.
 count1,n1,count0,n0=139,11037,239,11034;p1=count1/n1;p0=count0/n0;rdiff=p1-p0;se=np.sqrt(p1*(1-p1)/n1+p0*(1-p0)/n0);rr=p1/p0
 fig,axs=plt.subplots(1,2,figsize=(11,4.5),layout='constrained');axs[0].plot([v['hidden_effect'] for v in sens],[v['omitted_U'] for v in sens],'o-',label=L('遗漏U','U omitted'),color='#d87430');axs[0].plot([v['hidden_effect'] for v in sens],[v['included_U'] for v in sens],'s-',label=L('调整U','U adjusted'),color='#237b94');axs[0].axhline(1,color='#83949e',ls=':');axs[0].set(xlabel=L('隐藏U对结果的生成系数','Generating outcome coefficient of hidden U'),ylabel=L('处理效应估计','Treatment-effect estimate'),title=L('敏感性情景：改变未测量机制','Sensitivity scenarios: change the omitted mechanism'));axs[0].legend(fontsize=9)
 axs[1].bar([0,1],[1000*p0,1000*p1],color=['#83949e','#237b94']);axs[1].set(xticks=[0,1],xticklabels=[L('安慰剂组','Placebo group'),L('随机分配阿司匹林组','Assigned aspirin group')],ylabel=L('每千名分配者的事件数','Events per 1,000 assigned participants'),title=L('1989报告：原始事件比例','1989 report: crude event fractions'));axs[1].text(0,1000*p0+.4,f'{count0}/{n0}',ha='center');axs[1].text(1,1000*p1+.4,f'{count1}/{n1}',ha='center');axs[1].set_ylim(0,26);save(fig,'sensitivity_trial')
 differences=np.linspace(.005,.05,100);sizes=np.array([n_per_arm(.1,.1+d) for d in differences]);required=int(np.ceil(n_per_arm(.1,.12)));days=int(np.ceil(2*required/1000));recruitment=max(14,int(np.ceil(days/7)*7));fig,axs=plt.subplots(1,2,figsize=(11,4.5),layout='constrained');axs[0].plot(100*differences,sizes,color='#237b94');axs[0].scatter([2],[required],c='#d87430');axs[0].set(yscale='log',xlabel=L('绝对提升（百分点）','Absolute increase (percentage points)'),ylabel=L('每组所需人数','Required participants per arm'),title=L('基线10%，双侧5%，功效80%','Baseline 10%, two-sided 5%, power 80%'));axs[1].broken_barh([(0,recruitment)],(15,8),facecolors='#237b94');axs[1].broken_barh([(recruitment,7)],(15,8),facecolors='#d87430');axs[1].set(xlim=(0,recruitment+8),ylim=(5,32),yticks=[],xlabel=L('天数','Days'),title=L('招募覆盖两周，再等待7天结局','Recruit over two weeks, then mature 7-day outcomes'));axs[1].text(recruitment/2,19,L('招募','Recruit'),ha='center',va='center',color='white');axs[1].text(recruitment+3.5,19,L('结局成熟','Maturation'),ha='center',va='center',color='white',fontsize=9);save(fig,'power_duration')
 summary={'n':n,'treated_n':int(T.sum()),'controls_n':int((1-T).sum()),'true_population_ate':1,'true_sample_ate':float(tau.mean()),'naive_difference':naive,'ipw_ate':ipw,'hajek_ate':hajek,'aipw_ate':aipw,'aipw_se':aipw_se,'aipw_ci95':[aipw-1.96*aipw_se,aipw+1.96*aipw_se],'dml_intercept':float(dml[0]),'dml_slope':float(dml[1]),'matching_att':att,'true_sample_att':true_att,'propensity_min':float(e.min()),'propensity_max':float(e.max()),'absolute_smd_before':abs(before).tolist(),'absolute_smd_after':abs(after).tolist(),'iv':iv,'did':did,'rd':rd,'sensitivity':sens,'trial':{'treated_events':count1,'treated_n':n1,'control_events':count0,'control_n':n0,'total_n':n1+n0,'crude_risk_difference':rdiff,'crude_risk_ratio':rr,'binomial_difference_ci95':[rdiff-1.96*se,rdiff+1.96*se]},'power_per_arm':required,'raw_recruitment_days':days,'planned_recruitment_days':recruitment,'outcome_window_days':7,'planned_complete_day':recruitment+7}
 summary.update({'crossfit_fold_counts':np.bincount(fold).tolist(),'potential_effect_identity_error':float(np.max(abs(Y1-Y0-tau))),'did_trend_bias':did['0.7']-did['0.0']})
 np.savez_compressed(out/'experiment_data.npz',X=X,treatment=T,outcome=Y,potential_y0=Y0,potential_y1=Y1,true_effect=tau,propensity=e,crossfit_fold=fold,aipw_scores=phi,matched_control_indices=matched,rd_running=running,rd_outcome=outcome);(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args()
 with threadpool_limits(limits=1):main(a.output,a.language)
