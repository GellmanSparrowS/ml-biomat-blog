"""Attention retrieval and a CPU selective state-space teaching model.

The selective recurrence follows the mathematical form documented by Gu & Dao
and the state-spaces/mamba reference implementation. This compact implementation
uses ordinary PyTorch operations so each state is inspectable on CPU.
"""
from pathlib import Path
import argparse,copy,json,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import torch
from torch import nn

def retrieval_data(n,seed):
    rng=np.random.default_rng(seed);x=np.zeros((n,5,9),dtype=np.float32);target=np.zeros(n,dtype=np.int64);slots=[]
    for b in range(n):
        keys=rng.permutation(4);values=rng.integers(0,4,4);chosen=int(rng.integers(4))
        for t,(key,value) in enumerate(zip(keys,values)):x[b,t,key]=1;x[b,t,4+value]=1
        x[b,4,keys[chosen]]=1;x[b,4,8]=1;target[b]=values[chosen];slots.append(chosen)
    return torch.tensor(x),torch.tensor(target),np.array(slots)

class AttentionBlock(nn.Module):
    def __init__(self):
        super().__init__();self.norm1=nn.LayerNorm(32);self.attention=nn.MultiheadAttention(32,4,batch_first=True,dropout=0)
        self.norm2=nn.LayerNorm(32);self.ff=nn.Sequential(nn.Linear(32,64),nn.GELU(),nn.Linear(64,32))
    def forward(self,x,mask=None,weights=False):
        z=self.norm1(x);a,w=self.attention(z,z,z,attn_mask=mask,need_weights=weights,average_attn_weights=False)
        x=x+a;return x+self.ff(self.norm2(x)),w

class TinyTransformer(nn.Module):
    def __init__(self):
        super().__init__();self.embed=nn.Linear(9,32);self.position=nn.Parameter(torch.randn(1,5,32)*.02)
        self.blocks=nn.ModuleList([AttentionBlock(),AttentionBlock()]);self.norm=nn.LayerNorm(32);self.head=nn.Linear(32,4)
    def forward(self,x,weights=False):
        x=self.embed(x)+self.position;all_weights=[]
        for block in self.blocks:x,w=block(x,weights=weights);all_weights.append(w)
        logits=self.head(self.norm(x[:,-1]));return (logits,all_weights) if weights else logits

def memory_data(n,seed,length=16):
    rng=np.random.default_rng(seed);values=rng.uniform(-1,1,(n,length));marks=rng.random((n,length))<.2;marks[:,0]=True
    targets=np.zeros_like(values);last=np.zeros(n)
    for t in range(length):last=np.where(marks[:,t],values[:,t],last);targets[:,t]=last
    x=np.stack([values,marks],-1).astype('float32');return torch.tensor(x),torch.tensor(targets,dtype=torch.float32)

class SelectiveMemory(nn.Module):
    def __init__(self,width=24,state_size=4):
        super().__init__();self.width=width;self.state_size=state_size
        self.input=nn.Linear(2,2*width);self.local=nn.Conv1d(width,width,3,padding=2,groups=width)
        self.delta=nn.Linear(width,width);nn.init.constant_(self.delta.bias,-2)
        self.B=nn.Linear(width,state_size,bias=False);self.C=nn.Linear(width,state_size,bias=False)
        self.log_rates=nn.Parameter(torch.log(torch.arange(1,state_size+1,dtype=torch.float32)).repeat(width,1))
        self.direct=nn.Parameter(torch.ones(width));self.readout=nn.Linear(width,1)
    def forward(self,x,trace=False):
        u,z=self.input(x).chunk(2,-1);length=x.shape[1]
        u=nn.functional.silu(self.local(u.transpose(1,2))[...,:length].transpose(1,2))
        dt=nn.functional.softplus(self.delta(u));B=self.B(u);C=self.C(u);A=-torch.exp(self.log_rates)
        h=x.new_zeros(x.shape[0],self.width,self.state_size);outputs=[];states=[]
        for t in range(length):
            decay=torch.exp(dt[:,t,:,None]*A[None])
            write=dt[:,t,:,None]*B[:,t,None,:]*u[:,t,:,None]
            h=decay*h+write
            y=(h*C[:,t,None,:]).sum(-1)+self.direct*u[:,t]
            outputs.append(self.readout(y*nn.functional.silu(z[:,t])).squeeze(-1))
            if trace:states.append(h)
        result=torch.stack(outputs,1)
        return (result,dt,torch.stack(states,1)) if trace else result

def fit(model,train_x,train_y,val_x,val_y,classification,epochs,seed):
    optimizer=torch.optim.Adam(model.parameters(),lr=.003);generator=torch.Generator().manual_seed(seed)
    criterion=nn.CrossEntropyLoss() if classification else nn.MSELoss();history=[];best=float('inf');saved=None;best_epoch=0
    for epoch in range(1,epochs+1):
        model.train()
        for ix in torch.randperm(len(train_x),generator=generator).split(64):
            optimizer.zero_grad(set_to_none=True);loss=criterion(model(train_x[ix]),train_y[ix]);loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(),1.0);optimizer.step()
        model.eval()
        with torch.no_grad():tl=float(criterion(model(train_x),train_y));vl=float(criterion(model(val_x),val_y))
        history.append([epoch,tl,vl])
        if vl<best:best=vl;best_epoch=epoch;saved=copy.deepcopy(model.state_dict())
    model.load_state_dict(saved);model.eval();return np.array(history),best_epoch

def run(output,language):
    output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    zh=language=='zh';tr=lambda z,e:z if zh else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    tx,ty,_=retrieval_data(1000,320);vx,vy,_=retrieval_data(300,321);ex,ey,slots=retrieval_data(400,322)
    torch.manual_seed(323);transformer=TinyTransformer();attention_history,attention_best=fit(transformer,tx,ty,vx,vy,True,50,324)
    with torch.no_grad():logits,weights=transformer(ex,weights=True);accuracy=float((logits.argmax(-1)==ey).float().mean())
    query_blind=ex[:,:4,4:8].sum(1).argmax(-1);baseline=float((query_blind==ey).float().mean())
    mx,my=memory_data(800,325);mv,mvy=memory_data(240,326);me,mey=memory_data(320,327)
    torch.manual_seed(328);selective=SelectiveMemory();memory_history,memory_best=fit(selective,mx,my,mv,mvy,False,70,329)
    with torch.no_grad():memory_pred,dt,states=selective(me,trace=True)
    memory_mse=float(nn.functional.mse_loss(memory_pred,mey));last_mse=float(nn.functional.mse_loss(memory_pred[:,-1],mey[:,-1]))
    torch.save(transformer.state_dict(),output/'transformer.pt');torch.save(selective.state_dict(),output/'selective-memory.pt')
    # Exact QKV example; compare direct calculation with the library operation.
    q=torch.tensor([[1.,0.]],dtype=torch.float64);k=torch.eye(2,dtype=torch.float64);v=torch.tensor([[2.,0.],[0.,4.]],dtype=torch.float64)
    scores=q@k.T/math.sqrt(2);alpha=torch.softmax(scores,dim=-1);manual=alpha@v
    official=nn.functional.scaled_dot_product_attention(q[None,None],k[None,None],v[None,None])[0,0]
    qkv_error=float((manual-official).abs().max());assert qkv_error<1e-12
    # Changing future tokens cannot change earlier outputs under a causal mask.
    torch.manual_seed(330);block=AttentionBlock().eval();sequence=torch.randn(1,6,32);changed=sequence.clone();changed[:,3:]+=10*torch.randn(1,3,32)
    mask=torch.triu(torch.ones(6,6,dtype=torch.bool),diagonal=1)
    with torch.no_grad():a,_=block(sequence,mask);b,_=block(changed,mask);causal_error=float((a[:,:3]-b[:,:3]).abs().max())
    assert causal_error<1e-6
    # A diagonal scan independently evaluated in two equivalent arrangements.
    A=np.array([-.5,-1.]);deltas=np.array([.1,.2,.05]);inputs=np.array([1.,-2.,.3]);B=np.array([.6,-.4]);h=np.zeros(2);trace=[]
    for delta,value in zip(deltas,inputs):h=np.exp(delta*A)*h+delta*B*value;trace.append(h.copy())
    # Expanded closed form: each earlier write is multiplied by later decays.
    expanded=sum(deltas[t]*B*inputs[t]*np.exp(A*deltas[t+1:].sum()) for t in range(3))
    scan_error=float(np.abs(h-expanded).max());assert scan_error<1e-12

    fig=plt.figure(figsize=(12,4.3),layout='constrained');gs=fig.add_gridspec(1,3,width_ratios=[1,1,1.3])
    ax=fig.add_subplot(gs[0,0]);ax.bar([0,1],scores.numpy().ravel(),color=['#0072B2','#D58500']);ax.set(xticks=[0,1],xticklabels=['K1','K2'],ylabel=tr('缩放点积分数','Scaled dot-product score'))
    ax=fig.add_subplot(gs[0,1]);ax.bar([0,1],alpha.numpy().ravel(),color=['#0072B2','#D58500']);ax.set(xticks=[0,1],xticklabels=['K1','K2'],ylim=(0,1),ylabel=tr('归一化读取权重','Normalized reading weight'))
    ax=fig.add_subplot(gs[0,2]);ax.arrow(0,0,2,0,color='#0072B2',width=.025,length_includes_head=True);ax.arrow(0,0,0,4,color='#D58500',width=.025,length_includes_head=True);ax.arrow(0,0,float(manual[0,0]),float(manual[0,1]),color='#008675',width=.035,length_includes_head=True)
    ax.text(2,.2,'V1');ax.text(.1,3.8,'V2');ax.text(float(manual[0,0]),float(manual[0,1])+.15,tr('加权输出','Weighted output'));ax.set(xlim=(-.2,2.8),ylim=(-.2,4.3),xlabel=tr('特征维1','Feature dimension1'),ylabel=tr('特征维2','Feature dimension2'))
    fig.savefig(output/f'qkv-{language}.svg');plt.close(fig)
    # Actual second-layer head maps for the first held-out retrieval example.
    retrieval_sample=next(i for i in range(len(ex)) if len(set(ex[i,:4,4:8].argmax(1).tolist()))==4)
    head_maps=weights[-1][retrieval_sample].numpy();key_ids=ex[retrieval_sample,:4,:4].argmax(1).numpy();value_ids=ex[retrieval_sample,:4,4:8].argmax(1).numpy();query=int(ex[retrieval_sample,4,:4].argmax())
    labels=[f'K{k}:V{v}' for k,v in zip(key_ids,value_ids)]+[f'Q:K{query}']
    fig,axes=plt.subplots(1,4,figsize=(13,3.8),layout='constrained')
    for j,ax in enumerate(axes):
        im=ax.imshow(head_maps[j],vmin=0,vmax=1,cmap='viridis');ax.set(xticks=range(5),xticklabels=labels,yticks=range(5),yticklabels=labels,title=tr(f'头{j}',f'Head{j}'))
        ax.tick_params(axis='x',labelrotation=55);ax.add_patch(plt.Rectangle((-.5,3.5),5,1,fill=False,edgecolor='#D58500',lw=2))
    fig.colorbar(im,ax=list(axes),shrink=.6,label=tr('注意力权重','Attention weight'));fig.savefig(output/f'attention-{language}.svg');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11.5,4.3),layout='constrained')
    for ax,history,title in [(axes[0],attention_history,tr('键值检索：Transformer','Key-value retrieval: Transformer')),(axes[1],memory_history,tr('最近标记值：选择性状态','Last marked value: selective state'))]:
        ax.semilogy(history[:,0],history[:,1],label=tr('训练','Training'),color='#0072B2');ax.semilogy(history[:,0],history[:,2],label=tr('验证','Validation'),color='#D58500');ax.set(title=title,xlabel=tr('训练轮数','Epoch'),ylabel=tr('交叉熵' if ax is axes[0] else '均方误差','Cross entropy' if ax is axes[0] else 'MSE'));ax.legend()
    fig.savefig(output/f'learning-{language}.svg');plt.close(fig)
    # Inspect a learned memory trajectory, not a manually prescribed gate plot.
    sample=0;time=np.arange(1,17);marked=np.flatnonzero(me[sample,:,1].numpy())
    fig=plt.figure(figsize=(12,6.3),layout='constrained');gs=fig.add_gridspec(2,2,width_ratios=[1.6,1])
    ax=fig.add_subplot(gs[0,:]);ax.plot(time,me[sample,:,0],'.-',color='#9aa5ab',label=tr('当前输入值','Current input value'));ax.step(time,mey[sample],where='post',color='#273e47',lw=2,label=tr('最近标记值目标','Last-marked-value target'));ax.plot(time,memory_pred[sample],'o-',color='#0072B2',ms=4,label=tr('模型读出','Model readout'));ax.scatter(time[marked],me[sample,marked,0],s=90,facecolors='none',edgecolors='#D58500',linewidths=2,label=tr('有标记的输入','Marked inputs'));ax.set(xlabel=tr('时间步','Time step'),ylabel=tr('数值（无量纲）','Value (dimensionless)'));ax.legend(ncol=2,fontsize=9)
    ax=fig.add_subplot(gs[1,0]);im=ax.imshow(dt[sample].T,aspect='auto',origin='lower',cmap='magma');ax.set(xlabel=tr('时间索引0–15','Time index0–15'),ylabel=tr('内部通道0–23','Internal channel0–23'));fig.colorbar(im,ax=ax,label=tr('学习得到的步长Δ','Learned step sizeΔ'))
    ax=fig.add_subplot(gs[1,1]);ax.plot(time,states[sample,:,0,:].numpy());ax.set(xlabel=tr('时间步','Time step'),ylabel=tr('通道0的四维状态','Four state coordinates, channel0'));ax.legend([f'n={i}' for i in range(4)],fontsize=8,ncol=2)
    fig.savefig(output/f'memory-{language}.svg');plt.close(fig)
    lengths=np.array([16,32,64,128,256,512,1024,2048]);attention_entries=4*lengths**2;kv_entries=2*32*lengths;state_entries=np.full_like(lengths,24*4)
    fig,axes=plt.subplots(1,2,figsize=(11.5,4.3),layout='constrained')
    axes[0].loglog(lengths,attention_entries,'o-',label=tr('4头注意力分数','Four-head attention scores'),color='#0072B2');axes[0].loglog(lengths,24*4*lengths,'o-',label=tr('选择性状态逐步展开','Unrolled selective states'),color='#D58500');axes[0].set(xlabel=tr('序列长度T','Sequence lengthT'),ylabel=tr('指定数组的标量数','Scalars in the specified array'));axes[0].legend(fontsize=9)
    axes[1].loglog(lengths,kv_entries*4/1024,'o-',label=tr('单层KV缓存，d=32','One-layer KV cache,d=32'),color='#0072B2');axes[1].loglog(lengths,state_entries*4/1024,'o-',label=tr('24×4递推状态','24×4 recurrent state'),color='#D58500');axes[1].set(xlabel=tr('已读长度T','Observed lengthT'),ylabel=tr('float32状态存储（KiB）','float32 state storage(KiB)'));axes[1].legend(fontsize=9)
    fig.savefig(output/f'complexity-{language}.svg');plt.close(fig)
    summary={'retrieval':{'train':1000,'validation':300,'test':400,'accuracy':accuracy,'query_blind_majority_accuracy':baseline,'best_epoch':attention_best,'parameter_count':sum(p.numel() for p in transformer.parameters()),'sample_index':retrieval_sample,'sample_query_key':query,'sample_correct_slot':int(slots[retrieval_sample]),'sample_values':value_ids.tolist(),'sample_prediction':int(logits[retrieval_sample].argmax()),'sample_target':int(ey[retrieval_sample])},'memory':{'train':800,'validation':240,'test':320,'length':16,'test_mse_all_steps':memory_mse,'test_mse_last_step':last_mse,'best_epoch':memory_best,'parameter_count':sum(p.numel() for p in selective.parameters())},'hand_attention':{'weights':alpha.numpy().tolist(),'output':manual.numpy().tolist(),'library_max_error':qkv_error},'causal_prefix_max_error':causal_error,'scan_expansion_max_error':scan_error,'scan_final_state':h.tolist(),'torch_version':torch.__version__}
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');np.savez(output/'experiment.npz',attention_history=attention_history,memory_history=memory_history,head_maps=head_maps,memory_input=me.numpy(),memory_target=mey.numpy(),memory_prediction=memory_pred.numpy(),delta=dt.numpy(),states=states.numpy(),retrieval_test=ex.numpy(),retrieval_target=ey.numpy());print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();run(a.output,a.language)
