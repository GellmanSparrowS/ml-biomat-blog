# Public sources and third-party materials

- Attention Is All You Need: https://arxiv.org/abs/1706.03762
  Primary research link; no paper figure copied
- Dive into Deep Learning — The Transformer Architecture: https://d2l.ai/chapter_attention-mechanisms-and-transformers/transformer.html
  CC BY-SA4.0 text/figures
- Mamba: Linear-Time Sequence Modeling with Selective State Spaces: https://arxiv.org/abs/2312.00752
  Primary research link; no paper figure copied
- state-spaces/mamba — reference implementation: https://github.com/state-spaces/mamba
  Apache2.0 repository code; no GPU extension bundled
- PyTorch — MultiheadAttention: https://docs.pytorch.org/docs/2.15/generated/torch.nn.MultiheadAttention.html
  Technical documentation reference
