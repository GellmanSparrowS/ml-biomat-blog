# Public sources and third-party materials

- Dive into Deep Learning: Working with Sequences: https://d2l.ai/chapter_recurrent-neural-networks/sequence.html
  CC BY-SA 4.0; original image retained unchanged
- Long Short-Term Memory: https://doi.org/10.1162/neco.1997.9.8.1735
  Primary paper; no figure copied
- Long Short-Term Memory — author-hosted full text: https://people.idsia.ch/~juergen/lstm1997-2024head.pdf
  Primary paper; no figure copied
- PyTorch LSTM: https://docs.pytorch.org/docs/stable/generated/torch.nn.LSTM.html
  Official API reference; independent code
- Pixel Recurrent Neural Networks: https://arxiv.org/abs/1601.06759
  Primary paper; no figure copied
- Conditional Image Generation with PixelCNN Decoders: https://arxiv.org/html/1606.05328v2
  Primary paper; no figure copied
- WaveNet: A Generative Model for Raw Audio: https://arxiv.org/html/1609.03499v2
  Primary paper; independently constructed dependency diagram
- The Curious Case of Neural Text Degeneration: https://arxiv.org/abs/1904.09751
  Primary paper; no figure copied
- Dive into Deep Learning: Beam Search: https://d2l.ai/chapter_recurrent-modern/beam-search.html
  CC BY-SA 4.0 reference; independent worked example
- Attention Is All You Need: https://arxiv.org/abs/1706.03762
  Primary paper; no figure copied
- Google Neural Machine Translation: https://arxiv.org/abs/1609.08144
  Primary paper; no figure copied
