"""A character-level LSTM language model trained on a fully specified grammar.
All sequences, split indices, weights, generated strings, and figures are saved.
"""
from pathlib import Path
import argparse, json, math, itertools, copy, platform
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['en','zh'],default='en');args=p.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
def tr(z,e):return z if zh else e
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','svg.fonttype':'none'})
def save(fig,name):fig.savefig(out/f'{name}-{args.language}.svg',bbox_inches='tight');plt.close(fig)
colors=['blue','red','gold','green','pink','white'];agents=['robot','pilot','otter','fox'];verbs=['carries','finds','moves'];objects=['cube','book','ball','key','bag'];places=['river','tower','garden','bridge']
sentences=[f'the {c} {a} {v} the {o} near the {r}.' for c,a,v,o,r in itertools.product(colors,agents,verbs,objects,places)]
vocab=['<pad>','<bos>','<eos>']+sorted(set(''.join(sentences)));stoi={s:i for i,s in enumerate(vocab)};V=len(vocab)
encoded=[[1]+[stoi[c] for c in s]+[2] for s in sentences];length=max(map(len,encoded));data=torch.zeros(len(encoded),length,dtype=torch.long)
for i,row in enumerate(encoded):data[i,:len(row)]=torch.tensor(row)
perm=np.random.default_rng(360).permutation(len(data));train_ids,val_ids,test_ids=perm[:1008],perm[1008:1224],perm[1224:]
class CharacterLSTM(nn.Module):
 def __init__(self):
  super().__init__();self.embedding=nn.Embedding(V,24,padding_idx=0);self.lstm=nn.LSTM(24,64,batch_first=True);self.head=nn.Linear(64,V)
 def forward(self,x,state=None):
  h,state=self.lstm(self.embedding(x),state);return self.head(h),state
torch.manual_seed(361);model=CharacterLSTM();optimizer=torch.optim.Adam(model.parameters(),lr=.004);order_rng=torch.Generator().manual_seed(362)
def evaluation(indices):
 model.eval();total=0.;tokens=0;correct=0
 with torch.no_grad():
  for idx in np.array_split(indices,max(1,math.ceil(len(indices)/128))):
   x=data[idx,:-1];y=data[idx,1:];logits,_=model(x);mask=y!=0;total+=F.cross_entropy(logits.reshape(-1,V),y.reshape(-1),ignore_index=0,reduction='sum').item();tokens+=mask.sum().item();correct+=((logits.argmax(-1)==y)&mask).sum().item()
 return dict(nll=total/tokens,perplexity=math.exp(total/tokens),accuracy=correct/tokens,tokens=tokens)
history=[];best=float('inf');best_epoch=0;best_state=None
for epoch in range(1,81):
 model.train();order=torch.randperm(len(train_ids),generator=order_rng);total=0.;count=0
 for part in order.split(64):
  idx=train_ids[part];x=data[idx,:-1];y=data[idx,1:];logits,_=model(x);loss=F.cross_entropy(logits.reshape(-1,V),y.reshape(-1),ignore_index=0);optimizer.zero_grad();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1);optimizer.step();n=(y!=0).sum().item();total+=loss.item()*n;count+=n
 valid=evaluation(val_ids);history.append([epoch,total/count,valid['nll']])
 if valid['nll']<best:best=valid['nll'];best_epoch=epoch;best_state=copy.deepcopy(model.state_dict())
model.load_state_dict(best_state);model.eval();test_metrics=evaluation(test_ids)
torch.save(dict(model=model.state_dict(),vocab=vocab,epoch=best_epoch),out/'character-lstm.pt')
def distribution(logits,temperature=1.,top_k=0,top_p=1.):
 logits=logits.astype('float64').copy()/temperature;logits[:2]=-np.inf;logits-=np.max(logits);probs=np.exp(logits);probs/=probs.sum();order=np.argsort(-probs,kind='stable');keep=np.ones(len(probs),dtype=bool)
 if top_k>0:keep[:]=False;keep[order[:top_k]]=True
 if top_p<1:
  # Keep the token that first reaches or crosses the requested cumulative mass.
  n=np.searchsorted(np.cumsum(probs[order]),top_p,side='left')+1;nucleus=np.zeros(len(probs),dtype=bool);nucleus[order[:n]]=True;keep&=nucleus
 probs*=keep;return probs/probs.sum()
@torch.no_grad()
def prefix_state(prefix):return model(torch.tensor([[1]+[stoi[c] for c in prefix]]))
@torch.no_grad()
def sample(prefix='',mode='sample',temperature=1.,top_k=0,top_p=1.,seed=0,max_new=80):
 logits,state=prefix_state(prefix);rng=np.random.default_rng(seed);text=prefix;trace=[];ended=False
 for _ in range(max_new):
  raw=logits[0,-1].numpy();prob=distribution(raw,temperature,top_k,top_p);token=int(prob.argmax()) if mode=='greedy' else int(rng.choice(V,p=prob));trace.append(dict(token=vocab[token],probability=float(prob[token])))
  if token==2:ended=True;break
  text+=vocab[token];logits,state=model(torch.tensor([[token]]),state)
 return dict(text=text,ended=ended,trace=trace)
@torch.no_grad()
def beam_search(prefix='',width=4,alpha=.7,max_new=80):
 logits,state=prefix_state(prefix);beams=[dict(text=prefix,score=0.,length=0,ended=False,logits=logits,state=state)]
 def rank(b):return b['score']/(((5+b['length'])/6)**alpha)
 for _ in range(max_new):
  candidates=[]
  for b in beams:
   if b['ended']:candidates.append(b);continue
   # Raw log probabilities retain the model's normalization, including special tokens.
   lp=F.log_softmax(b['logits'][0,-1],dim=-1);lp[:2]=-torch.inf
   for token in torch.topk(lp,width).indices.tolist():
    ended=token==2;new_logits,new_state=(b['logits'],b['state']) if ended else model(torch.tensor([[token]]),b['state'])
    candidates.append(dict(text=b['text']+('' if ended else vocab[token]),score=b['score']+lp[token].item(),length=b['length']+1,ended=ended,logits=new_logits,state=new_state))
  beams=sorted(candidates,key=rank,reverse=True)[:width]
  if all(b['ended'] for b in beams):break
 best=sorted(beams,key=rank,reverse=True)[0];return {k:best[k] for k in ['text','score','length','ended']}|dict(normalized_score=rank(best))
settings={'greedy':dict(mode='greedy'),'T0.7':dict(temperature=.7),'T1.0':dict(temperature=1.),'T1.3':dict(temperature=1.3),'top-k5':dict(top_k=5),'top-p0.9':dict(top_p=.9)}
generation={};metrics={};valid_set=set(sentences);training_set={sentences[i] for i in train_ids}
for name,options in settings.items():
 rows=[sample(seed=363+i,**options) for i in range(100)];generation[name]=rows;strings=[r['text'] for r in rows]
 metrics[name]=dict(valid=sum(s in valid_set for s in strings)/100,unique=len(set(strings)),ended=sum(r['ended'] for r in rows)/100,training_overlap=sum(s in training_set for s in strings)/100)
beam=beam_search();conditioned=[sample(prefix='the blue robot ',seed=463+i,top_p=.9) for i in range(20)]
# A small tree of actual next-character distributions for the browser explorer.
prefixes=['the ','the blue ','the blue robot ','the blue robot carries the ','the blue robot carries the book near the ']
lab_nodes=[]
for prefix in prefixes:
 logits,_=prefix_state(prefix);raw=logits[0,-1].numpy();options=[]
 for token in np.argsort(-distribution(raw))[:5]:
  if token<3:continue
  child,_=prefix_state(prefix+vocab[token]);options.append(dict(token=int(token),prefix=prefix+vocab[token],logits=child[0,-1].numpy().tolist()))
 lab_nodes.append(dict(prefix=prefix,logits=raw.tolist(),children=options))
(out/'decoding.json').write_text(json.dumps(dict(vocab=vocab,nodes=lab_nodes),ensure_ascii=False,separators=(',',':')),encoding='utf-8')
# Compare teacher-forced and cached sequential evaluation of identical known tokens.
with torch.no_grad():
 seq=data[test_ids[:1],:-1];whole,_=model(seq);parts=[];state=None
 for t in range(seq.shape[1]):
  pred,state=model(seq[:,t:t+1],state);parts.append(pred)
 sequential_error=float((whole-torch.cat(parts,1)).abs().max())
 # A causal dilated convolution reads only positions at or before its input index.
 torch.manual_seed(364);signal=torch.randn(1,1,32);altered=signal.clone();altered[:,:,16:]+=10
 def causal(x):
  for dilation in [1,2,4]:x=F.conv1d(F.pad(x,(2*dilation,0)),torch.tensor([[[.2,.3,.5]]]),dilation=dilation)
  return x
 causal_error=float((causal(signal)[:,:,:16]-causal(altered)[:,:,:16]).abs().max())
 mask=torch.ones(1,1,5,5);mask[:,:,3:]=0;mask[:,:,2,2:]=0
 img=torch.arange(49,dtype=torch.float32).reshape(1,1,7,7);changed=img.clone();changed.flatten()[24:]+=100
 pixel_error=float((F.conv2d(img,mask,padding=2)[0,0,3,3]-F.conv2d(changed,mask,padding=2)[0,0,3,3]).abs())
hand_p=np.array([.6,.25,.1,.05]);hand_k=hand_p.copy();hand_k[2:]=0;hand_k/=hand_k.sum();chain=.6*.5*.8
summary=dict(versions=dict(python=platform.python_version(),torch=torch.__version__,numpy=np.__version__),data=dict(sentences=len(sentences),train=len(train_ids),validation=len(val_ids),test=len(test_ids),vocabulary=V,max_padded_length=length,seed=360),training=dict(epochs=80,best_epoch=best_epoch,parameters=sum(p.numel() for p in model.parameters()),embedding=24,hidden=64,lr=.004,batch=64),test=test_metrics,generation=metrics,beam=beam,conditioned=dict(count=20,valid=sum(r['text'] in valid_set for r in conditioned)/20,prefix_preserved=all(r['text'].startswith('the blue robot ') for r in conditioned)),hand=dict(chain_probability=chain,chain_nll=-math.log(chain),chain_perplexity=chain**(-1/3),top_k_first=float(hand_k[0]),top_p_count=int(np.searchsorted(np.cumsum(hand_p),.8)+1),receptive_field=1+2*(1+2+4),sequential_logit_max_error=sequential_error,causal_future_error=causal_error,pixel_future_error=pixel_error))
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');(out/'generations.json').write_text(json.dumps(dict(unconditional=generation,beam=beam,conditioned=conditioned),ensure_ascii=False,indent=2),encoding='utf-8');(out/'corpus.json').write_text(json.dumps(dict(sentences=sentences,vocab=vocab,train_indices=train_ids.tolist(),validation_indices=val_ids.tolist(),test_indices=test_ids.tolist()),indent=2),encoding='utf-8')
np.savez_compressed(out/'experiment.npz',encoded=data.numpy(),train_indices=train_ids,validation_indices=val_ids,test_indices=test_ids,history=history,mask=mask.numpy())
fig,axs=plt.subplots(1,3,figsize=(13,4),layout='constrained');h=np.array(history);axs[0].plot(h[:,0],h[:,1],label=tr('训练','Train'),color='#125f82');axs[0].plot(h[:,0],h[:,2],label=tr('验证','Validation'),color='#bf7139');axs[0].axvline(best_epoch,color='#555',ls=':',lw=1);axs[0].set(xlabel=tr('训练轮数','Epoch'),ylabel=tr('每字符负对数似然 / nats','NLL per character / nats'),title=tr('A  从字符规则到新组合','A  Learning unseen combinations'));axs[0].legend()
names=list(metrics);xs=np.arange(len(names));axs[1].bar(xs,[metrics[n]['valid'] for n in names],color='#125f82');axs[1].set_xticks(xs,names,rotation=35,ha='right');axs[1].set(ylim=(0,1.07),ylabel=tr('合乎语法的生成比例','Grammar-valid fraction'),title=tr('B  每种策略100次生成','B  100 generations per strategy'))
axs[2].bar(xs,[metrics[n]['unique'] for n in names],color='#bf7139');axs[2].set_xticks(xs,names,rotation=35,ha='right');axs[2].set(ylim=(0,105),ylabel=tr('不同完整字符串数','Distinct complete strings'),title=tr('C  同一模型的不同选择','C  Choices from the same model'));save(fig,'learning')
# A teacher-forced probability strip makes uncertain boundaries and certain spelling visible.
chosen='the blue robot carries the book near the river.';ids=torch.tensor([[1]+[stoi[c] for c in chosen]])
with torch.no_grad():prob=model(ids)[0].softmax(-1)[0].numpy().T
fig,ax=plt.subplots(figsize=(14,6),layout='constrained');im=ax.imshow(prob[2:,:],aspect='auto',vmin=0,vmax=1,cmap='YlGnBu');ax.set_yticks(range(V-2),[('EOS' if v=='<eos>' else 'space' if v==' ' else v) for v in vocab[2:]]);ax.set_xticks(np.arange(0,len(chosen)+1,2),['BOS' if i==0 else ('_' if chosen[i-1]==' ' else chosen[i-1]) for i in range(0,len(chosen)+1,2)]);ax.set(xlabel=tr('读入的当前字符（预测下一字符）','Current input character (predicting the following character)'),ylabel=tr('候选下一字符','Candidate next character'),title=tr('真实模型的条件概率：词内集中，选择词语时分散','Actual conditional probabilities: concentrated spelling, uncertain word choices'));fig.colorbar(im,ax=ax,label=tr('预测概率','Predicted probability'));save(fig,'probabilities')
fig,axs=plt.subplots(1,2,figsize=(12,5),layout='constrained');raster=np.arange(49).reshape(7,7);ax=axs[0];state=np.where(raster<24,1,np.where(raster==24,2,0));ax.imshow(state,cmap=matplotlib.colors.ListedColormap(['#e9e4d9','#71a6b8','#bd713f']),vmin=0,vmax=2)
for row in range(7):
 for col in range(7):ax.text(col,row,str(raster[row,col]+1),ha='center',va='center',fontsize=10)
ax.set(title=tr('A  预测第25个像素：只读蓝色历史','A  Predict pixel 25 using only blue history'),xlabel=tr('图像列：从左到右','Column: left to right'),ylabel=tr('图像行：从上到下','Row: top to bottom'))
ax=axs[1];offsets={0}
for row,d in enumerate([4,2,1]):
 new={i-j*d for i in offsets for j in range(3)}
 for i in offsets:
  for j in range(3):ax.plot([i,i-j*d],[3-row,2-row],color='#8ca8b4',lw=1)
 for i in new:ax.scatter(i,2-row,s=30,color='#125f82')
 offsets=new
ax.scatter(0,3,c='#bd713f',s=65);ax.set(xticks=range(-14,1,2),yticks=range(4),yticklabels=[tr('输入','Input'),'d=1','d=2','d=4'],xlabel=tr('相对当前输入的位置','Position relative to current input'),title=tr('B  核3、膨胀1/2/4覆盖15个位置','B  Kernel 3, dilation 1/2/4 spans 15 positions'));save(fig,'causality')
fig,ax=plt.subplots(figsize=(13,7.4));ax.axis('off');lines=[]
for name in ['greedy','T0.7','T1.0','T1.3','top-k5','top-p0.9']:
 lines.append((name,generation[name][0]['text'],generation[name][1]['text']))
for i,(name,a,b) in enumerate(lines):
 y=.96-i*.15;ax.text(0,y,name,color='#125f82',weight='bold',fontsize=13,transform=ax.transAxes);ax.text(.13,y,a,fontsize=11,transform=ax.transAxes);ax.text(.13,y-.05,b,fontsize=11,transform=ax.transAxes)
ax.set_title(tr('每种策略最先生成的两个字符串：保留实际拼写','The first two generated strings per strategy: actual spelling retained'),loc='left',pad=18);save(fig,'samples')
print(json.dumps(summary,indent=2))
