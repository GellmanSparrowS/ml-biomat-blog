# Public sources and third-party materials

- Physics Informed Deep Learning: https://maziarraissi.github.io/PINNs/
  Technical reference; figures independently computed
- Fourier Neural Operator for Parametric PDEs: https://arxiv.org/abs/2010.08895
  Technical reference; figures independently computed
- NeuralOperator: Fourier Neural Operators: https://neuraloperator.github.io/dev/theory_guide/fno.html
  Technical reference; figures independently computed
- Discovering governing equations by sparse identification: https://arxiv.org/abs/1509.03580
  Technical reference; figures independently computed
- PySINDy documentation: https://pysindy.readthedocs.io/en/stable/
  Technical reference; figures independently computed
- SciPy solve_ivp: https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.solve_ivp.html
  Technical reference; figures independently computed
- Hamiltonian Neural Networks: https://arxiv.org/abs/1906.01563
  Technical reference; figures independently computed
- Fourier, Théorie analytique de la chaleur (1822): https://www.e-rara.ch/zut/content/titleinfo/6187666
  Historical work linked; no scanned image reproduced
- Universal Differential Equations for Scientific Machine Learning: https://arxiv.org/abs/2001.04385
  Primary paper
- PySINDy STLSQ: https://pysindy.readthedocs.io/en/latest/generated/pysindy.optimizers.STLSQ.html
  Official documentation
