"""Cooling, a small Fourier neural operator, and sparse equation discovery.

All data are constructed from the equations stated in the chapter.
The program writes only to the selected output directory.
"""
from pathlib import Path
import argparse
import copy
import json

import numpy as np
import torch
from torch import nn
from scipy.integrate import solve_ivp
from scipy.signal import savgol_filter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


torch.set_num_threads(2)
torch.use_deterministic_algorithms(True)
torch.manual_seed(2901)
rng = np.random.default_rng(2901)
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, default=Path('results'))
parser.add_argument('--language', choices=['zh', 'en'], default='en')
args = parser.parse_args()
out = args.output
out.mkdir(parents=True, exist_ok=True)
zh = args.language == 'zh'


def tr(chinese, english):
    return chinese if zh else english


plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Microsoft YaHei', 'Noto Sans CJK SC', 'DejaVu Sans'],
    'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False,
    'svg.fonttype': 'none', 'figure.facecolor': '#faf9f5',
    'axes.facecolor': '#faf9f5',
})


def save(fig, name):
    fig.savefig(out / f'{name}-{args.language}.svg', bbox_inches='tight')
    fig.savefig(out / f'{name}-{args.language}.png', dpi=130, bbox_inches='tight')
    plt.close(fig)


def euler_cooling(k, step, stop=12.0):
    time, temperature = [0.0], [80.0]
    while time[-1] < stop - 1e-12:
        dt = min(step, stop - time[-1])
        temperature.append(temperature[-1] - dt * k * (temperature[-1] - 20))
        time.append(time[-1] + dt)
    return np.array(time), np.array(temperature)


# A forward PINN: tau=t/10, u=(T-20)/60, du/dtau + 3.5*u=0.
net = nn.Sequential(nn.Linear(1, 24), nn.Tanh(), nn.Linear(24, 24),
                    nn.Tanh(), nn.Linear(24, 1)).double()
optimizer = torch.optim.Adam(net.parameters(), lr=.003)
collocation = torch.linspace(0, 1, 64, dtype=torch.float64)[:, None]
trace = []
for iteration in range(1600):
    tau = collocation.clone().requires_grad_(True)
    u = 1 + tau * net(tau)  # The initial condition is exact for any parameters.
    derivative = torch.autograd.grad(u.sum(), tau, create_graph=True)[0]
    residual = derivative + 3.5 * u
    loss = residual.square().mean()
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    if iteration % 40 == 0:
        trace.append([iteration, loss.item()])
grid = torch.linspace(0, 2, 401, dtype=torch.float64)[:, None]
with torch.no_grad():
    pinn = (1 + grid * net(grid)).numpy().ravel()
tau = grid.numpy().ravel()
exact = np.exp(-3.5 * tau)
test_tau = torch.tensor(np.linspace(.0025, .9975, 200)[:, None], requires_grad=True)
test_u = 1 + test_tau * net(test_tau)
test_derivative = torch.autograd.grad(test_u.sum(), test_tau)[0]
pinn_residual = (test_derivative + 3.5 * test_u).detach().numpy().ravel()
torch.save(net.state_dict(), out / 'pinn.pt')

# A differentiable numerical simulator estimates k from noisy observations.
obs_time = np.arange(0, 8.01, 1.0)
obs = 20 + 60 * np.exp(-.35 * obs_time) + rng.normal(0, .4, len(obs_time))
obs[0] = 80  # Initial condition is measured exactly in this constructed example.
dt = .05
obs_indices = torch.tensor(np.rint(obs_time / dt).astype(int))


def simulator(k):
    temperatures = [torch.tensor(80., dtype=torch.float64)]
    for _ in range(int(8 / dt)):
        temperatures.append(temperatures[-1] - dt * k * (temperatures[-1] - 20))
    return torch.stack(temperatures)[obs_indices]


probe_k = torch.tensor(.25, dtype=torch.float64, requires_grad=True)
probe_loss = (simulator(probe_k) - torch.tensor(obs)).square().mean()
automatic_gradient = torch.autograd.grad(probe_loss, probe_k)[0].item()
eps = 1e-5
with torch.no_grad():
    finite_gradient = (((simulator(torch.tensor(.25 + eps, dtype=torch.float64)) - torch.tensor(obs)).square().mean()
                       - (simulator(torch.tensor(.25 - eps, dtype=torch.float64)) - torch.tensor(obs)).square().mean()) / (2 * eps)).item()
raw_k = torch.tensor(-1.5, dtype=torch.float64, requires_grad=True)
inverse_optimizer = torch.optim.Adam([raw_k], lr=.04)
inverse_trace = []
for iteration in range(350):
    k = nn.functional.softplus(raw_k)
    inverse_loss = (simulator(k) - torch.tensor(obs)).square().mean()
    inverse_optimizer.zero_grad()
    inverse_loss.backward()
    inverse_optimizer.step()
    if iteration % 10 == 0:
        inverse_trace.append([iteration, k.item(), inverse_loss.item()])
estimated_k = nn.functional.softplus(raw_k).item()

# A genuine two-block FNO maps an initial periodic field to its field at time1.
nu = .01


def fields(coefficients, resolution, final=False):
    x = np.arange(resolution) / resolution
    result = np.repeat(coefficients[:, :1], resolution, axis=1)
    for mode in range(1, 5):
        amplitude = np.exp(-nu * (2 * np.pi * mode) ** 2) if final else 1.
        result += amplitude * (
            coefficients[:, 2 * mode - 1:2 * mode] * np.cos(2 * np.pi * mode * x)
            + coefficients[:, 2 * mode:2 * mode + 1] * np.sin(2 * np.pi * mode * x))
    return result.astype('float32')


coefficients = rng.normal(0, .45, (144, 9))
coefficients[:, 0] = rng.uniform(-.5, .5, 144)
train_x = torch.tensor(fields(coefficients[:96], 32))[:, None]
train_y = torch.tensor(fields(coefficients[:96], 32, True))[:, None]
valid_x = torch.tensor(fields(coefficients[96:120], 32))[:, None]
valid_y = torch.tensor(fields(coefficients[96:120], 32, True))[:, None]


class SpectralLayer(nn.Module):
    def __init__(self, width, modes):
        super().__init__()
        self.modes = modes
        self.weights = nn.Parameter(torch.randn(width, width, modes, dtype=torch.cfloat) / width)

    def forward(self, values):
        transformed = torch.fft.rfft(values, dim=-1)
        result = torch.zeros(values.shape[0], values.shape[1], transformed.shape[-1],
                             dtype=torch.cfloat, device=values.device)
        result[:, :, :self.modes] = torch.einsum(
            'bik,iok->bok', transformed[:, :, :self.modes], self.weights)
        return torch.fft.irfft(result, n=values.shape[-1], dim=-1)


class SmallFNO(nn.Module):
    def __init__(self):
        super().__init__()
        self.lift = nn.Conv1d(1, 12, 1)
        self.spectral = nn.ModuleList([SpectralLayer(12, 6) for _ in range(2)])
        self.local = nn.ModuleList([nn.Conv1d(12, 12, 1) for _ in range(2)])
        self.readout = nn.Conv1d(12, 1, 1)

    def forward(self, values):
        hidden = self.lift(values)
        for spectral, local in zip(self.spectral, self.local):
            hidden = nn.functional.gelu(spectral(hidden) + local(hidden))
        return self.readout(hidden)


torch.manual_seed(2902)
fno = SmallFNO()
fno_optimizer = torch.optim.Adam(fno.parameters(), lr=.003)
fno_rng = torch.Generator().manual_seed(2903)
best_validation, best_state, best_step = float('inf'), None, None
fno_trace = []
for iteration in range(601):
    indices = torch.randint(96, (32,), generator=fno_rng)
    loss = (fno(train_x[indices]) - train_y[indices]).square().mean()
    fno_optimizer.zero_grad()
    loss.backward()
    fno_optimizer.step()
    if iteration % 20 == 0:
        with torch.no_grad():
            validation = (fno(valid_x) - valid_y).square().mean().item()
        fno_trace.append([iteration, loss.item(), validation])
        if validation < best_validation:
            best_validation = validation
            best_state = copy.deepcopy(fno.state_dict())
            best_step = iteration
fno.load_state_dict(best_state)
torch.save(fno.state_dict(), out / 'fno.pt')
operator_results = {}
operator_arrays = {}
for resolution in [32, 64]:
    inputs = fields(coefficients[120:], resolution)
    targets = fields(coefficients[120:], resolution, True)
    with torch.no_grad():
        prediction = fno(torch.tensor(inputs)[:, None]).numpy()[:, 0]
    conserved = prediction - prediction.mean(1, keepdims=True) + inputs.mean(1, keepdims=True)
    relative = np.linalg.norm(prediction - targets, axis=1) / np.linalg.norm(targets, axis=1)
    operator_results[str(resolution)] = {
        'mean_relative_l2': float(relative.mean()),
        'mse': float(np.mean((prediction - targets) ** 2)),
        'projected_mse': float(np.mean((conserved - targets) ** 2)),
        'mean_conservation_error': float(np.mean(np.abs(prediction.mean(1) - inputs.mean(1)))),
        'projected_conservation_max_error': float(np.max(np.abs(conserved.mean(1) - inputs.mean(1)))),
        'identity_mse': float(np.mean((inputs - targets) ** 2)),
    }
    operator_arrays.update({f'input_{resolution}': inputs, f'target_{resolution}': targets,
                            f'prediction_{resolution}': prediction, f'projected_{resolution}': conserved})

# Sparse identification uses smoothed numerical derivatives, not known derivatives.
time = np.arange(0, 4.001, .02)


def logistic(t, initial):
    capacity = 1.2 / .8
    return capacity / (1 + (capacity / initial - 1) * np.exp(-1.2 * t))


clean = np.array([logistic(time, initial) for initial in [.2, .5, 1.]])
noisy = clean + rng.normal(0, .002, clean.shape)
smooth = savgol_filter(noisy, 21, 3, axis=1)
estimated_derivatives = savgol_filter(noisy, 21, 3, deriv=1, delta=.02, axis=1)
raw_derivatives = np.gradient(noisy, .02, axis=1)
states = smooth[:, 10:-10].ravel()
derivatives = estimated_derivatives[:, 10:-10].ravel()
library = np.stack([np.ones_like(states), states, states**2, states**3], axis=1)
coefficients_sindy = np.linalg.lstsq(library, derivatives, rcond=None)[0]
for _ in range(8):
    active = np.abs(coefficients_sindy) >= .08
    coefficients_sindy[~active] = 0
    coefficients_sindy[active] = np.linalg.lstsq(library[:, active], derivatives, rcond=None)[0]
rollout_time = np.linspace(0, 8, 401)
identified = solve_ivp(lambda t, x: sum(c * x**i for i, c in enumerate(coefficients_sindy)),
                       [0, 8], [.8], t_eval=rollout_time, rtol=1e-9, atol=1e-11).y[0]
true_derivative = 1.2 * clean - .8 * clean**2

# Same oscillator, different integrators: geometry changes long-time energy.
position = {'euler': [1.], 'symplectic': [1.]}
momentum = {'euler': [0.], 'symplectic': [0.]}
for _ in range(400):
    x, v = position['euler'][-1], momentum['euler'][-1]
    position['euler'].append(x + .1 * v)
    momentum['euler'].append(v - .1 * x)
    x, v = position['symplectic'][-1], momentum['symplectic'][-1]
    new_v = v - .1 * x
    momentum['symplectic'].append(new_v)
    position['symplectic'].append(x + .1 * new_v)
energy = {key: .5 * (np.array(position[key])**2 + np.array(momentum[key])**2) for key in position}

fig, axes = plt.subplots(1, 3, figsize=(13.5, 4), layout='constrained')
t = np.linspace(0, 12, 401)
axes[0].plot(t, 20 + 60 * np.exp(-.35 * t), color='#183a4c', label=tr('解析解', 'Analytic'))
for step, color in [(1, '#267b7d'), (6, '#bd653f')]:
    et, ey = euler_cooling(.35, step)
    axes[0].plot(et, ey, 'o--', color=color, label=f'Euler h={step}')
axes[0].axhline(20, color='#aaa', lw=.8)
axes[0].set(xlabel=tr('时间 / min', 'Time / min'), ylabel=tr('温度 / °C', 'Temperature / °C'), title=tr('A  步长改变数值行为', 'A  Step size changes dynamics'))
axes[0].legend(fontsize=8)
axes[1].plot(tau, exact, color='#183a4c', label=tr('解析解', 'Analytic'))
axes[1].plot(tau, pinn, color='#267b7d', label='PINN')
axes[1].axvline(1, color='#bd653f', ls='--')
axes[1].set(xlabel=tr('无量纲时间 τ', 'Dimensionless time τ'), ylabel=tr('无量纲温差 u', 'Dimensionless excess u'), title=tr('B  训练区间与外推', 'B  Training interval and extrapolation'))
axes[1].legend(fontsize=8)
axes[2].semilogy(np.array(trace)[:, 0], np.array(trace)[:, 1], color='#267b7d')
axes[2].set(xlabel=tr('更新次数', 'Updates'), ylabel=tr('残差均方', 'Mean squared residual'), title=tr('C  自动微分形成约束', 'C  Autodifferentiated constraint'))
save(fig, 'cooling')

fig, axes = plt.subplots(1, 3, figsize=(13.5, 4), layout='constrained')
axes[0].errorbar(obs_time, obs, yerr=np.r_[0, np.repeat(.4, len(obs_time)-1)], fmt='o', color='#bd653f', label=tr('观测 ±1σ', 'Observations ±1σ'))
axes[0].plot(t, 20 + 60 * np.exp(-estimated_k * t), color='#267b7d', label=tr('估计参数的连续解', 'Continuous curve at fitted k'))
axes[0].set(xlabel=tr('时间 / min', 'Time / min'), ylabel=tr('温度 / °C', 'Temperature / °C'), title=tr('A  可微求解器识别参数', 'A  Identify a simulator parameter'))
axes[0].legend(fontsize=8)
kk, ambient = np.meshgrid(np.linspace(.15, .6, 101), np.linspace(5, 35, 101))
for ax, stop in zip(axes[1:], [1, 8]):
    sample_t = np.linspace(0, stop, 9)
    target = 20 + 60 * np.exp(-.35 * sample_t)
    predicted = ambient[..., None] + (80 - ambient[..., None]) * np.exp(-kk[..., None] * sample_t)
    rmse = np.sqrt(np.mean((predicted - target)**2, axis=-1))
    contours = ax.contour(kk, ambient, rmse, levels=[.2, .5, 1, 2, 4, 8], cmap='viridis')
    ax.clabel(contours, fontsize=8)
    ax.plot(.35, 20, '*', color='#bd653f', ms=11)
    ax.set(xlabel=tr('冷却率 k / min$^{-1}$', 'Rate k / min$^{-1}$'), ylabel=tr('环境温度 / °C', 'Ambient / °C'), title=tr(f'0–{stop} min：温度RMSE等值线', f'0–{stop} min: temperature-RMSE contours'))
save(fig, 'inverse')

fig, axes = plt.subplots(2, 3, figsize=(13.5, 7), layout='constrained')
error_limit = max(float(np.max(np.abs(operator_arrays[f'prediction_{n}'] - operator_arrays[f'target_{n}']))) for n in [32, 64])
for column, resolution in enumerate([32, 64]):
    x = np.arange(resolution) / resolution
    for values, label, color in [(operator_arrays[f'input_{resolution}'][0], tr('初始', 'Initial'), '#aaa'),
                                 (operator_arrays[f'target_{resolution}'][0], tr('真实终态', 'Exact final'), '#183a4c'),
                                 (operator_arrays[f'prediction_{resolution}'][0], 'FNO', '#bd653f')]:
        axes[0, column].plot(x, values, label=label, color=color)
    axes[0, column].set(xlabel='x / L', ylabel=tr('场值', 'Field value'), title=f'N={resolution}')
    axes[0, column].legend(fontsize=8)
    error = operator_arrays[f'prediction_{resolution}'] - operator_arrays[f'target_{resolution}']
    im = axes[1, column].imshow(error, aspect='auto', extent=[0, 1, 24, 0], cmap='RdBu_r', vmin=-error_limit, vmax=error_limit)
    axes[1, column].set(xlabel='x / L', ylabel=tr('独立函数编号', 'Held-out function'), title=tr('全部24个函数的误差', 'Errors for all 24 held-out functions'))
    fig.colorbar(im, ax=axes[1, column], label=tr('预测−真实', 'Predicted−exact'))
ft = np.array(fno_trace)
axes[0, 2].semilogy(ft[:, 0], ft[:, 1], label=tr('训练批次', 'Training batch'), color='#267b7d')
axes[0, 2].semilogy(ft[:, 0], ft[:, 2], label=tr('验证函数', 'Validation functions'), color='#bd653f')
axes[0, 2].set(xlabel=tr('更新次数', 'Updates'), ylabel='MSE', title=tr('按验证函数选择权重', 'Select by validation functions'))
axes[0, 2].legend(fontsize=8)
modes = np.arange(0, 9)
axes[1, 2].semilogy(modes, np.exp(-nu * (2 * np.pi * modes)**2), 'o-', color='#267b7d')
axes[1, 2].axvspan(.5, 4.5, color='#267b7d', alpha=.1)
axes[1, 2].set(xlabel=tr('Fourier模式 k', 'Fourier mode k'), ylabel=tr('精确衰减因子', 'Exact attenuation'), title=tr('高频更快消退', 'High frequencies decay faster'))
save(fig, 'operator')

fig, axes = plt.subplots(1, 3, figsize=(13.5, 4), layout='constrained')
axes[0].plot(time, true_derivative[0], color='#183a4c', label=tr('真实导数', 'Exact derivative'))
axes[0].plot(time, raw_derivatives[0], color='#bbb', alpha=.6, label=tr('直接差分', 'Finite difference'))
axes[0].plot(time, estimated_derivatives[0], color='#bd653f', label=tr('局部多项式导数', 'Local-polynomial derivative'))
axes[0].set(xlabel=tr('时间 / min', 'Time / min'), ylabel='du/dt / min$^{-1}$', title=tr('A  求导会放大噪声', 'A  Differentiation amplifies noise'))
axes[0].legend(fontsize=8)
axes[1].bar(np.arange(4) - .18, [0, 1.2, -.8, 0], .36, label=tr('真实', 'True'), color='#183a4c')
axes[1].bar(np.arange(4) + .18, coefficients_sindy, .36, label=tr('识别', 'Identified'), color='#bd653f')
axes[1].set(xticks=np.arange(4), xticklabels=['1', 'u', 'u²', 'u³'], ylabel=tr('系数 / min$^{-1}$', 'Coefficient / min$^{-1}$'), title=tr('B  从候选库选择表达式', 'B  Select terms from a library'))
axes[1].legend(fontsize=8)
axes[2].plot(rollout_time, logistic(rollout_time, .8), color='#183a4c', label=tr('真实', 'True'))
axes[2].plot(rollout_time, identified, '--', color='#bd653f', label='SINDy')
axes[2].axvline(4, color='#aaa', ls=':')
axes[2].set(xlabel=tr('时间 / min', 'Time / min'), ylabel=tr('无量纲状态 u', 'Dimensionless state u'), title=tr('C  新初值与更长时间', 'C  New initial state and longer time'))
axes[2].legend(fontsize=8)
save(fig, 'discovery')

fig, axes = plt.subplots(1, 2, figsize=(10, 4), layout='constrained')
for key, color in [('euler', '#bd653f'), ('symplectic', '#267b7d')]:
    label = tr('显式Euler', 'Explicit Euler') if key == 'euler' else tr('辛Euler', 'Symplectic Euler')
    axes[0].plot(position[key], momentum[key], color=color, label=label)
    axes[1].plot(np.arange(401)*.1, energy[key], color=color, label=label)
axes[0].set(xlabel='q', ylabel='p', title=tr('相平面轨迹', 'Phase-space trajectory'))
axes[0].set_aspect('equal')
axes[0].legend(fontsize=8)
axes[1].axhline(.5, color='#aaa', ls='--')
axes[1].set(xlabel=tr('无量纲时间', 'Dimensionless time'), ylabel=tr('能量 H', 'Energy H'), title=tr('离散更新改变长期能量', 'Discrete updates change long-time energy'))
axes[1].legend(fontsize=8)
inset = axes[1].inset_axes([.13, .42, .48, .43])
inset.plot(np.arange(401)*.1, energy['symplectic'], color='#267b7d', lw=.8)
inset.axhline(.5, color='#aaa', ls='--', lw=.7)
inset.set(ylim=(.47, .53), title=tr('辛Euler：能量放大', 'Symplectic energy: zoom'))
inset.tick_params(labelsize=7)
inset.title.set_fontsize(8)
save(fig, 'structure')

summary = {
    'pinn': {'inside_max_abs_error': float(np.max(np.abs(pinn[tau <= 1] - exact[tau <= 1]))),
             'outside_max_abs_error': float(np.max(np.abs(pinn[tau > 1] - exact[tau > 1]))),
             'independent_residual_rmse': float(np.sqrt(np.mean(pinn_residual**2))),
             'initial_condition_error': abs(float(pinn[0])-1), 'updates':1600},
    'inverse': {'true_k':.35, 'estimated_k':estimated_k, 'step':dt,
                'automatic_gradient':automatic_gradient, 'finite_gradient':finite_gradient,
                'gradient_relative_error':abs(automatic_gradient-finite_gradient)/abs(automatic_gradient)},
    'operator': {'train_functions':96, 'validation_functions':24, 'test_functions':24,
                 'selected_step':best_step, 'resolutions':operator_results},
    'sindy': {'coefficients':coefficients_sindy.tolist(), 'active_terms':int(np.count_nonzero(coefficients_sindy)),
              'derivative_rmse_raw':float(np.sqrt(np.mean((raw_derivatives[:,10:-10]-true_derivative[:,10:-10])**2))),
              'derivative_rmse_smooth':float(np.sqrt(np.mean((estimated_derivatives[:,10:-10]-true_derivative[:,10:-10])**2))),
              'heldout_rollout_max_error':float(np.max(np.abs(identified-logistic(rollout_time,.8))))},
    'structure':{'euler_final_energy':float(energy['euler'][-1]),
                 'symplectic_energy_min':float(energy['symplectic'].min()),
                 'symplectic_energy_max':float(energy['symplectic'].max())},
    'hand':{'euler_k05_h2_final':float(euler_cooling(.5,2)[1][-1]),
            'euler_k05_h4_final':float(euler_cooling(.5,4)[1][-1]),
            'heat_mode1_factor':float(np.exp(-.01*(2*np.pi)**2))}
}
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
np.savez_compressed(out/'experiment.npz',tau=tau,pinn=pinn,exact=exact,
                    collocation=collocation.numpy(),pinn_trace=trace,pinn_test_residual=pinn_residual,
                    obs_time=obs_time,observations=obs,inverse_trace=inverse_trace,
                    operator_coefficients=coefficients,fno_trace=fno_trace,
                    sindy_time=time,sindy_clean=clean,sindy_noisy=noisy,
                    sindy_derivatives=estimated_derivatives,sindy_coefficients=coefficients_sindy,
                    rollout_time=rollout_time,identified_rollout=identified,
                    euler_energy=energy['euler'],symplectic_energy=energy['symplectic'],**operator_arrays)
print(json.dumps(summary,indent=2))
