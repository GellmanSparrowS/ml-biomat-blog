# Public sources and third-party materials

- Dive into Deep Learning — Forward Propagation, Backward Propagation, and Computational Graphs: https://d2l.ai/chapter_multilayer-perceptrons/backprop.html
  CC BY-SA 4.0
- PyTorch — Automatic Differentiation with torch.autograd: https://docs.pytorch.org/tutorials/beginner/basics/autogradqs_tutorial.html
  BSD-3-Clause (tutorial repository)
- PyTorch — Datasets & DataLoaders: https://docs.pytorch.org/tutorials/beginner/basics/data_tutorial.html
  BSD-3-Clause (tutorial repository)
- Rumelhart, Hinton & Williams (1986), Learning representations by back-propagating errors: https://www.cs.toronto.edu/~hinton/absps/naturebp.pdf
  Reference
