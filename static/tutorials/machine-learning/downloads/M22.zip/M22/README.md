# M22 · 图神经网络：让关系进入计算

Graph neural networks: learning through relationships

## 运行 / Run

在解压目录打开终端。安装依赖后运行完整示例：
Open a terminal in the extracted directory, install the dependencies, and run the complete example:

```text
python -m pip install -r requirements.txt
python main.py --output output-zh --language zh
python main.py --output output-en --language en
```

输出目录包含计算摘要、数据与图像；summary.json 保存可以复查的数值。
The output directory contains numerical summaries, data, and figures. Inspect summary.json for calculated values.

示例在 Python 3.14.3 下运行核对。requirements.txt 记录本次运行的库版本。
This example was executed with Python 3.14.3. requirements.txt records the tested library versions.

中文图像使用系统中可用的中文字体；可安装 Noto Sans CJK SC 后运行。英文图像不需要中文字体。
Chinese figures use an available CJK font, such as Noto Sans CJK SC. English figures work with the standard font fallback.

公开数据和参考资料列在 THIRD_PARTY_NOTICES.md；教学构造数据在正文及程序中标明。
Public data and references are listed in THIRD_PARTY_NOTICES.md. Constructed teaching datasets are identified in the chapter and code.
