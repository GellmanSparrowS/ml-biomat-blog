"""A transductive graph experiment with reproducible ablations and symmetries."""
import argparse
import copy
import json
from pathlib import Path
import numpy as np
import torch
from torch import nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

torch.set_num_threads(2)


def dataset():
    rng = np.random.default_rng(2026)
    labels = np.repeat(np.arange(2), 60)
    p = np.where(labels[:, None] == labels[None, :], .18, .015)
    upper = np.triu(rng.random((120, 120)) < p, 1)
    adjacency = (upper | upper.T).astype(np.float32)
    features = rng.normal(0, 1, (120, 6)).astype(np.float32)
    features[:, :2] += (2 * labels[:, None] - 1) * .25
    train, valid, test = [], [], []
    for c in range(2):
        order = rng.permutation(np.where(labels == c)[0])
        train.extend(order[:10]); valid.extend(order[10:20]); test.extend(order[20:])
    a = adjacency + np.eye(120, dtype=np.float32)
    inv = 1 / np.sqrt(a.sum(1))
    normalized = inv[:, None] * a * inv[None, :]
    return adjacency, normalized, features, labels, train, valid, test


class NodeModel(nn.Module):
    def __init__(self, graph):
        super().__init__()
        self.graph = graph
        self.first = nn.Linear(6, 16, bias=False)
        self.last = nn.Linear(16, 2, bias=False)

    def forward(self, x, a):
        hidden = torch.relu(self.first(a @ x if self.graph else x))
        hidden = nn.functional.dropout(hidden, .2, self.training)
        return self.last(a @ hidden if self.graph else hidden)


def fit(kind, seed, a, x, y, train, valid, test):
    torch.manual_seed(seed)
    model = NodeModel(kind == 'GCN')
    optimizer = torch.optim.Adam(model.parameters(), lr=.02, weight_decay=5e-4)
    trace, best_loss, best = [], float('inf'), None
    for epoch in range(150):
        model.train(); optimizer.zero_grad()
        logits = model(x, a)
        loss = nn.functional.cross_entropy(logits[train], y[train])
        loss.backward(); optimizer.step()
        model.eval()
        with torch.no_grad():
            logits = model(x, a)
            val = nn.functional.cross_entropy(logits[valid], y[valid]).item()
            trace.append([loss.item(), val])
            if val < best_loss:
                best_loss, best = val, copy.deepcopy(model.state_dict())
    model.load_state_dict(best); model.eval()
    with torch.no_grad():
        logits = model(x, a)
        accuracy = (logits[test].argmax(1) == y[test]).float().mean().item()
    return model, np.asarray(trace), accuracy, logits.detach().numpy()


def vectors(points):
    difference = points[None, :, :] - points[:, None, :]
    weights = np.exp(-np.square(difference).sum(-1))
    return (weights[:, :, None] * difference).sum(1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--language', choices=['zh', 'en'], default='en')
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    zh = args.language == 'zh'
    plt.rcParams.update({'font.family': 'Microsoft YaHei' if zh else 'Arial',
                         'font.size': 11, 'axes.spines.top': False,
                         'axes.spines.right': False, 'svg.fonttype': 'none'})
    def label(ch, en): return ch if zh else en
    def save(fig, name):
        fig.savefig(args.output / f'{name}-{args.language}.svg', bbox_inches='tight')
        fig.savefig(args.output / f'{name}-{args.language}.png', dpi=140, bbox_inches='tight')
        plt.close(fig)
    adjacency, normalized, features, labels, train, valid, test = dataset()
    a, x, y = torch.tensor(normalized), torch.tensor(features), torch.tensor(labels)
    results, traces, scores, models = {}, {}, {}, {}
    for kind in ['MLP', 'GCN']:
        traces[kind], scores[kind] = [], []
        for seed in range(5):
            model, trace, score, logits = fit(kind, seed, a, x, y, train, valid, test)
            traces[kind].append(trace); scores[kind].append(score)
            if seed == 0: models[kind] = (model, logits)
        results[kind] = {'test_accuracy': scores[kind], 'mean_accuracy': float(np.mean(scores[kind]))}
    permutation = torch.tensor(np.random.default_rng(17).permutation(120))
    with torch.no_grad():
        shifted = models['GCN'][0](x[permutation], a[permutation][:, permutation])
        original = models['GCN'][0](x, a)[permutation]
        permutation_error = float((shifted-original).abs().max())
    points = np.array([[0., 0.], [1., .1], [.2, .8], [1.2, 1.]])
    theta = .7
    rotation = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
    rotation_error = float(np.max(np.abs(vectors(points @ rotation.T) - vectors(points) @ rotation.T)))
    assert permutation_error < 2e-6
    assert rotation_error < 1e-12
    results.update({'nodes': 120, 'edges': int(adjacency.sum()/2), 'split_sizes': [20, 20, 80],
                    'permutation_max_error': permutation_error, 'rotation_max_error': rotation_error})
    (args.output/'summary.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    np.savez(args.output/'data.npz', adjacency=adjacency, features=features, labels=labels,
             train=train, valid=valid, test=test, GCN_trace=np.array(traces['GCN']),
             MLP_trace=np.array(traces['MLP']), GCN_scores=scores['GCN'], MLP_scores=scores['MLP'])

    colors = np.array(['#176b91', '#bb554d'])[labels]
    rng = np.random.default_rng(71)
    xy = rng.normal(0, .32, (120, 2)); xy[:, 0] += (labels*2-1)*.8
    fig, axs = plt.subplots(1, 2, figsize=(12, 4.5), gridspec_kw={'width_ratios':[1.25, 1]})
    for i, j in zip(*np.where(np.triu(adjacency, 1))):
        axs[0].plot(xy[[i,j],0], xy[[i,j],1], color='#b4c0c9', lw=.45, alpha=.35, zorder=0)
    axs[0].scatter(*xy.T, c=colors, s=24)
    axs[0].scatter(*xy[train].T, facecolors='none', edgecolors='black', s=85, linewidths=1.2)
    axs[0].set(title=label('关系图：黑圈为20个训练标签', 'Graph: rings mark 20 training labels'), aspect='equal')
    axs[0].axis('off')
    axs[1].scatter(features[:,0], features[:,1], c=colors, s=28, alpha=.7)
    axs[1].set(xlabel=label('节点特征1（无量纲）','Node feature 1 (dimensionless)'),
               ylabel=label('节点特征2（无量纲）','Node feature 2 (dimensionless)'),
               title=label('仅看特征，两个类别重叠','Features alone overlap'))
    fig.tight_layout(); save(fig, 'data')

    fig = plt.figure(figsize=(12, 7)); gs=fig.add_gridspec(2, 2, width_ratios=[1.4, 1])
    ax = fig.add_subplot(gs[:,0])
    for kind, c in [('MLP','#bb554d'), ('GCN','#176b91')]:
        values = np.asarray(traces[kind])[:,:,1]
        ax.plot(np.arange(1,151), np.mean(values,0), color=c, label=kind)
        ax.fill_between(np.arange(1,151), *np.quantile(values,[.25,.75],axis=0), color=c, alpha=.15)
    ax.set(xlabel=label('训练轮数','Epoch'), ylabel=label('验证交叉熵','Validation cross-entropy'),
           title=label('5次初始化：均值与四分位带','5 initializations: mean and interquartile band'))
    ax.legend()
    ax=fig.add_subplot(gs[0,1])
    for k, kind in enumerate(['MLP','GCN']):
        vals=scores[kind];ax.scatter(k+np.linspace(-.12,.12,5),vals,c=['#bb554d','#176b91'][k],s=50)
        ax.hlines(np.mean(vals),k-.25,k+.25,color=['#bb554d','#176b91'][k])
    ax.set(xticks=[0,1],xticklabels=['MLP','GCN'],ylim=(0,1.05),ylabel=label('测试准确率','Test accuracy'))
    ax=fig.add_subplot(gs[1,1]); logits=models['GCN'][1]
    pred=logits.argmax(1); confusion=np.zeros((2,2),int)
    for t in test: confusion[labels[t],pred[t]]+=1
    ax.imshow(confusion,cmap='Blues',vmin=0,vmax=40)
    for i in range(2):
        for j in range(2): ax.text(j,i,str(confusion[i,j]),ha='center',va='center',color='white' if confusion[i,j]>20 else 'black')
    ax.set(xticks=[0,1],yticks=[0,1],xlabel=label('预测类别','Predicted class'),
           ylabel=label('真实类别','True class'),title=label('GCN种子0：80个测试节点','GCN seed 0: 80 test nodes'))
    fig.tight_layout();save(fig,'results')

    n=36; ring=np.eye(n)
    for i in range(n): ring[i,(i-1)%n]=ring[i,(i+1)%n]=1
    ring/=3; signal=np.zeros(n); signal[:6]=1
    sequence=[signal.copy()]
    for _ in range(60): sequence.append(ring@sequence[-1])
    sequence=np.array(sequence)
    fig,axs=plt.subplots(1,3,figsize=(13,4),gridspec_kw={'width_ratios':[1.3,1,.9]})
    im=axs[0].imshow(sequence,aspect='auto',origin='lower',cmap='viridis',vmin=0,vmax=1)
    axs[0].set(xlabel=label('环上节点编号','Node on a ring'),ylabel=label('平均传播次数','Averaging steps'),title=label('扩散信息，也磨平差别','Information spreads; contrast fades'))
    fig.colorbar(im,ax=axs[0],label=label('节点信号（无量纲）','Node signal (dimensionless)'))
    axs[1].semilogy(np.var(sequence,axis=1),color='#176b91')
    axs[1].set(xlabel=label('传播次数','Propagation steps'),ylabel=label('节点间方差','Variance across nodes'))
    v=vectors(points); rotated=points@rotation.T; vr=vectors(rotated)
    axs[2].quiver(*points.T,*v.T,color='#176b91',angles='xy',scale_units='xy',scale=1,label=label('原坐标','Original'))
    axs[2].quiver(*rotated.T,*vr.T,color='#bb554d',angles='xy',scale_units='xy',scale=1,label=label('旋转0.7 rad','Rotated 0.7 rad'))
    axs[2].scatter(*points.T,color='#176b91',s=12);axs[2].scatter(*rotated.T,color='#bb554d',s=12)
    axs[2].set(xlim=(-.7,1.6),ylim=(-.2,1.8),aspect='equal',xlabel='x',ylabel='y',title=label('向量随几何旋转','Vectors rotate with geometry'))
    axs[2].legend(fontsize=8)
    fig.tight_layout();save(fig,'structure')
    print(json.dumps(results,indent=2))


if __name__ == '__main__':
    main()
