# Public sources and third-party materials

- A Gentle Introduction to Graph Neural Networks: https://distill.pub/2021/gnn-intro/
  Original diagrams and text CC BY 4.0; selected original GCN image unmodified.
- Semi-Supervised Classification with Graph Convolutional Networks: https://arxiv.org/abs/1609.02907
  Technical reference; paper figures not reproduced.
- Inductive Representation Learning on Large Graphs: https://arxiv.org/abs/1706.02216
  Technical reference; original teaching calculations.
- Graph Attention Networks: https://arxiv.org/abs/1710.10903
  Technical reference; paper figures not reproduced.
- e3nn: Euclidean Neural Networks: https://arxiv.org/abs/2207.09453
  Technical reference; the numerical vector example is original.
