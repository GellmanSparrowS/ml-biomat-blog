# Public sources and third-party materials

- Dive into Deep Learning — Momentum: https://d2l.ai/chapter_optimization/momentum.html
  Technical/primary research link; chapter figures and examples are original calculations.
- Adam: A Method for Stochastic Optimization: https://arxiv.org/abs/1412.6980
  Technical/primary research link; chapter figures and examples are original calculations.
- Decoupled Weight Decay Regularization: https://arxiv.org/abs/1711.05101
  Technical/primary research link; chapter figures and examples are original calculations.
- PyTorch — AdamW: https://docs.pytorch.org/docs/2.15/generated/torch.optim.AdamW.html
  Technical/primary research link; chapter figures and examples are original calculations.
- Batch Normalization: https://arxiv.org/abs/1502.03167
  Technical/primary research link; chapter figures and examples are original calculations.
- Layer Normalization: https://arxiv.org/abs/1607.06450
  Technical/primary research link; chapter figures and examples are original calculations.
- Random Search for Hyper-Parameter Optimization: https://www.jmlr.org/papers/v13/bergstra12a.html
  Technical/primary research link; chapter figures and examples are original calculations.
- Practical Bayesian Optimization of Machine Learning Algorithms: https://arxiv.org/abs/1206.2944
  Technical/primary research link; chapter figures and examples are original calculations.
- Deep Residual Learning for Image Recognition: https://arxiv.org/abs/1512.03385
  Technical/primary research link; chapter figures and examples are original calculations.
