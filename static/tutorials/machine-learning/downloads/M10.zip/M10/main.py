"""Optimization, activation scale, and normalization experiments on CPU."""
from pathlib import Path
import argparse,copy,json,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import torch
from torch import nn

def data(n,seed):
    rng=np.random.default_rng(seed);x=rng.uniform(-3,3,(n,1)).astype('float32')
    clean=np.sin(1.7*x)+.15*x
    y=clean+rng.normal(0,.2,x.shape).astype('float32')
    return torch.from_numpy(x),torch.from_numpy(y)

def network():return nn.Sequential(nn.Linear(1,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh(),nn.Linear(32,1))

def continuation_check(output, train):
    """An epoch-boundary checkpoint with optimizer, schedule, and two RNG states."""
    def make():
        return nn.Sequential(nn.Linear(1,16),nn.ReLU(),nn.Dropout(.25),nn.Linear(16,1))
    schedule={'base_lr':.01,'total_epochs':5,'minimum_fraction':.1}
    def update(model,opt,batch_rng,epoch,config):
        rate=config['base_lr']*(config['minimum_fraction']+(1-config['minimum_fraction'])*
             (1+math.cos(math.pi*epoch/config['total_epochs']))/2)
        for group in opt.param_groups:group['lr']=rate
        indices=torch.randperm(len(train[0]),generator=batch_rng)
        model.train();losses=[]
        for batch in indices.split(32):
            opt.zero_grad(set_to_none=True)
            loss=nn.functional.mse_loss(model(train[0][batch]),train[1][batch])
            loss.backward();opt.step();losses.append(loss.detach().clone())
        return indices,torch.stack(losses).mean(),rate
    torch.manual_seed(190);model=make();opt=torch.optim.AdamW(model.parameters(),lr=.01,weight_decay=.01)
    batch_rng=torch.Generator().manual_seed(191)
    for epoch in [1,2]:update(model,opt,batch_rng,epoch,schedule)
    torch.save({'model':model.state_dict(),'optimizer':opt.state_dict(),'epoch':2,
                'schedule':schedule,'batch_rng':batch_rng.get_state(),
                'torch_rng':torch.get_rng_state()},output/'continuation.pt')
    original_indices,original_loss,rate=update(model,opt,batch_rng,3,schedule)
    saved=torch.load(output/'continuation.pt',weights_only=True)
    restored=make();restored.load_state_dict(saved['model'])
    restored_opt=torch.optim.AdamW(restored.parameters(),lr=.01,weight_decay=.01)
    restored_opt.load_state_dict(saved['optimizer'])
    restored_rng=torch.Generator();restored_rng.set_state(saved['batch_rng'])
    # Restore global RNG after constructing the new network, before dropout runs.
    torch.set_rng_state(saved['torch_rng'])
    indices,loss,restored_rate=update(restored,restored_opt,restored_rng,saved['epoch']+1,saved['schedule'])
    error=max((p-q).abs().max().item() for p,q in zip(model.parameters(),restored.parameters()))
    result={'saved_epoch':2,'next_epoch':3,'learning_rate':rate,'restored_learning_rate':restored_rate,
            'batch_match':bool(torch.equal(original_indices,indices)),
            'loss_error':abs(original_loss.item()-loss.item()),'parameter_max_error':error,
            'optimizer_step':int(next(iter(restored_opt.state.values()))['step'].item())}
    assert result['batch_match'] and error==0 and result['loss_error']==0
    return result

def fit(kind,lr,decay,train,val,epochs=160):
    torch.manual_seed(101);model=network()
    if kind=='SGD':opt=torch.optim.SGD(model.parameters(),lr=lr)
    elif kind=='Momentum':opt=torch.optim.SGD(model.parameters(),lr=lr,momentum=.9)
    elif kind=='Adam':opt=torch.optim.Adam(model.parameters(),lr=lr,weight_decay=decay)
    else:opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=decay)
    generator=torch.Generator().manual_seed(102);hist=[];best=float('inf');state=None;epoch_best=0
    for epoch in range(1,epochs+1):
        # AdamW alone demonstrates warmup followed by cosine decay.
        scale=min(epoch/5,1)*(0.1+0.9*(1+math.cos(math.pi*max(epoch-5,0)/max(epochs-5,1)))/2) if kind=='AdamW' else 1
        for group in opt.param_groups:group['lr']=lr*scale
        norms=[];model.train()
        for ix in torch.randperm(len(train[0]),generator=generator).split(32):
            opt.zero_grad(set_to_none=True);loss=nn.functional.mse_loss(model(train[0][ix]),train[1][ix]);loss.backward()
            norm=torch.sqrt(sum(p.grad.square().sum() for p in model.parameters())).item();norms.append(norm)
            assert math.isfinite(norm);opt.step()
        model.eval()
        with torch.no_grad():tl=nn.functional.mse_loss(model(train[0]),train[1]).item();vl=nn.functional.mse_loss(model(val[0]),val[1]).item()
        hist.append([epoch,tl,vl,float(np.mean(norms)),lr*scale])
        if vl<best:best=vl;state=copy.deepcopy(model.state_dict());epoch_best=epoch
    model.load_state_dict(state);return model,np.array(hist),best,epoch_best

def run(output,language):
    output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    zh=language=='zh';tr=lambda z,e:z if zh else e
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    train=data(96,103);val=data(240,104);test=data(400,105);grid=torch.linspace(-3,3,400)[:,None]
    configurations={'SGD':(.03,0),'Momentum':(.03,0),'Adam':(.01,0),'AdamW':(.01,.01)}
    models={};histories={};metrics={};colors=['#0072B2','#D58500','#008675','#98558b']
    for name,(lr,decay) in configurations.items():
        model,h,best,epoch=fit(name,lr,decay,train,val);models[name]=model;histories[name]=h
        with torch.no_grad():mse=nn.functional.mse_loss(model(test[0]),test[1]).item()
        metrics[name]={'learning_rate':lr,'weight_decay':decay,'best_epoch':epoch,'validation_mse':best,'test_mse':mse}
        torch.save(model.state_dict(),output/f'{name}.pt')
    fig=plt.figure(figsize=(12,8),layout='constrained');gs=fig.add_gridspec(2,2)
    ax=fig.add_subplot(gs[0,0]);ax.scatter(train[0],train[1],s=12,alpha=.5,color='#89939b',label=tr('训练观测 n=96','Training observations n=96'))
    ax.plot(grid,torch.sin(1.7*grid)+.15*grid,color='#25333d',lw=2,ls='--',label=tr('生成均值','Generating mean'))
    for (name,model),color in zip(models.items(),colors):
        with torch.no_grad():ax.plot(grid,model(grid),color=color,label=name)
    ax.set(xlabel=tr('输入 x（无量纲）','Input x (dimensionless)'),ylabel=tr('目标 y（无量纲）','Target y (dimensionless)'));ax.legend(fontsize=8,ncol=2)
    ax=fig.add_subplot(gs[0,1])
    for (name,h),color in zip(histories.items(),colors):ax.semilogy(h[:,0],h[:,2],color=color,label=name)
    ax.axhline(.2**2,color='#89939b',ls=':',label=tr('噪声方差 0.04','Noise variance 0.04'));ax.set(xlabel=tr('训练轮数','Epoch'),ylabel=tr('验证均方误差','Validation MSE'));ax.legend(fontsize=8)
    ax=fig.add_subplot(gs[1,0])
    for (name,h),color in zip(histories.items(),colors):ax.semilogy(h[:,0],h[:,3],color=color,label=name)
    ax.set(xlabel=tr('训练轮数','Epoch'),ylabel=tr('批梯度范数的轮内平均','Epoch mean of batch gradient norm'))
    ax=fig.add_subplot(gs[1,1])
    for (name,h),color in zip(histories.items(),colors):ax.plot(h[:,0],h[:,4],color=color,label=name)
    ax.set(xlabel=tr('训练轮数','Epoch'),ylabel=tr('学习率','Learning rate'));ax.legend(fontsize=8)
    fig.savefig(output/f'training-{language}.svg');plt.close(fig)

    paths={}
    for name in ['SGD','Momentum','Adam']:
        p=torch.tensor([3.,1.],requires_grad=True)
        opt=torch.optim.SGD([p],lr=.07,momentum=.6 if name=='Momentum' else 0) if name!='Adam' else torch.optim.Adam([p],lr=.15)
        path=[p.detach().numpy().copy()]
        for _ in range(60):opt.zero_grad();(.5*(p[0]**2+25*p[1]**2)).backward();opt.step();path.append(p.detach().numpy().copy())
        paths[name]=np.array(path)
    xx,yy=np.meshgrid(np.linspace(-.5,3.5,180),np.linspace(-1.1,1.2,140));zz=.5*(xx**2+25*yy**2)
    fig,axes=plt.subplots(1,3,figsize=(12,4),layout='constrained')
    for ax,((name,path),color) in zip(axes,zip(paths.items(),colors)):
        ax.contour(xx,yy,zz,levels=[.05,.2,.5,1,2,4,8,16],colors='#ccd4db',linewidths=.8);ax.plot(path[:,0],path[:,1],'-o',color=color,ms=2);ax.scatter([0],[0],marker='*',s=80,color='#263b43')
        ax.set(title=name,xlabel=tr('参数 x','Parameter x'),ylabel=tr('参数 y','Parameter y'),xlim=(-.5,3.5),ylim=(-1.1,1.2))
    fig.savefig(output/f'terrain-{language}.svg');plt.close(fig)

    # Feed the same random vectors through ten untrained ReLU layers.
    torch.manual_seed(106);initial=torch.randn(1024,64);activation={}
    for scheme in ['small','large','kaiming']:
        torch.manual_seed(107);h=initial.clone();stds=[]
        for _ in range(10):
            w=torch.empty(64,64)
            if scheme=='kaiming':nn.init.kaiming_normal_(w,nonlinearity='relu')
            else:nn.init.normal_(w,std=.02 if scheme=='small' else .5)
            h=torch.relu(h@w.T);stds.append(float(h.std()))
        activation[scheme]=stds
    matrix=torch.tensor([[1.,2.,3.],[7.,8.,9.]])
    bn=nn.BatchNorm1d(3,affine=False,track_running_stats=False);ln=nn.LayerNorm(3,elementwise_affine=False)
    bn_values=bn(matrix).detach().numpy();ln_values=ln(matrix).detach().numpy()
    fig=plt.figure(figsize=(12,4.5),layout='constrained');gs=fig.add_gridspec(1,4,width_ratios=[1.8,1,1,1])
    ax=fig.add_subplot(gs[0,0])
    for (name,values),color in zip(activation.items(),colors):ax.semilogy(range(1,11),values,'-o',label=tr({'small':'小权重','large':'大权重','kaiming':'Kaiming'}[name],name),color=color)
    ax.set(xlabel=tr('层数','Layer index'),ylabel=tr('ReLU输出标准差','Standard deviation of ReLU outputs'));ax.legend(fontsize=8)
    for j,(name,a) in enumerate([('Input',matrix.numpy()),('BatchNorm',bn_values),('LayerNorm',ln_values)]):
        ax=fig.add_subplot(gs[0,j+1]);im=ax.imshow(a,cmap='RdBu_r',vmin=-2 if j else 0,vmax=2 if j else 9)
        for r in range(2):
            for c in range(3):ax.text(c,r,f'{a[r,c]:.2f}',ha='center',va='center',color='white' if (j==0 and a[r,c]>6) or (j>0 and abs(a[r,c])>1) else '#182a34',fontsize=10)
        ax.set(title=tr('原始输入',name) if j==0 else name,xticks=[0,1,2],xticklabels=[1,2,3],yticks=[0,1],yticklabels=[1,2],xlabel=tr('特征','Feature'),ylabel=tr('样本','Sample'))
        fig.colorbar(im,ax=ax,shrink=.5)
    fig.savefig(output/f'scale-{language}.svg');plt.close(fig)

    # A transparent, validation-only hyperparameter grid. Test data are untouched.
    rates=[.001,.003,.01];decays=[0,.01,.1];search=np.zeros((3,3))
    for row,decay in enumerate(decays):
        for col,lr in enumerate(rates):_,_,score,_=fit('AdamW',lr,decay,train,val,epochs=60);search[row,col]=score
    fig,ax=plt.subplots(figsize=(7.2,4.8),layout='constrained');im=ax.imshow(search,cmap='viridis_r')
    for r in range(3):
        for c in range(3):ax.text(c,r,f'{search[r,c]:.4f}',ha='center',va='center',color='white' if search[r,c]>.15 else '#152e32')
    ax.set(xticks=range(3),xticklabels=rates,yticks=range(3),yticklabels=decays,xlabel=tr('峰值学习率','Peak learning rate'),ylabel=tr('AdamW权重衰减','AdamW weight decay'))
    fig.colorbar(im,ax=ax,label=tr('最佳验证均方误差（60轮预算）','Best validation MSE (60-epoch budget)'))
    fig.savefig(output/f'search-{language}.svg');plt.close(fig)
    # Reproduce two concrete failures with a separate, matched short budget.
    failure_traces={}
    for rate in [.03,1.0]:
        torch.manual_seed(101);model=network();opt=torch.optim.SGD(model.parameters(),lr=rate);losses=[]
        for step in range(30):
            opt.zero_grad();loss=nn.functional.mse_loss(model(train[0]),train[1]);value=float(loss.detach());losses.append(value)
            if not math.isfinite(value) or value>1e10:break
            loss.backward();opt.step()
        failure_traces[str(rate)]=losses
    rng=np.random.default_rng(109);permutation=rng.permutation(len(train[0]))
    _,_,clean_score,_=fit('Adam',.01,0,train,val,epochs=80)
    _,_,shuffled_score,_=fit('Adam',.01,0,(train[0],train[1][permutation]),val,epochs=80)
    fig,axes=plt.subplots(1,2,figsize=(11,4.1),layout='constrained')
    for rate,losses in failure_traces.items():axes[0].semilogy(np.arange(len(losses)),losses,'-o',ms=3,label=tr('学习率 ','rate ')+rate)
    axes[0].set(xlabel=tr('完整批更新步数','Full-batch update'),ylabel=tr('训练均方误差','Training MSE'));axes[0].legend()
    axes[1].bar([0,1],[clean_score,shuffled_score],color=['#0072B2','#D58500'],width=.55)
    axes[1].set(xticks=[0,1],xticklabels=[tr('对应正确','Aligned targets'),tr('打乱标签','Shuffled targets')],ylabel=tr('最佳验证均方误差','Best validation MSE'))
    for j,v in enumerate([clean_score,shuffled_score]):axes[1].text(j,v,f'{v:.4f}',ha='center',va='bottom')
    fig.savefig(output/f'diagnostics-{language}.svg');plt.close(fig)
    # Deterministic dropout probe: inverted dropout preserves expectation.
    torch.manual_seed(108);drop=nn.Dropout(.25);probe=drop(torch.ones(100000));drop.eval();eval_equal=bool(torch.equal(drop(torch.ones(20)),torch.ones(20)))
    summary={'train_n':96,'validation_n':240,'test_n':400,'noise_std':.2,'epochs':160,'models':metrics,'quadratic_final':{k:float(.5*(v[-1,0]**2+25*v[-1,1]**2)) for k,v in paths.items()},'activation_std':activation,'batchnorm':bn_values.tolist(),'layernorm':ln_values.tolist(),'dropout_training_mean':float(probe.mean()),'dropout_eval_identity':eval_equal,'search_validation_mse':search.tolist(),'failure_traces':failure_traces,'label_diagnostic':{'epochs':80,'aligned_validation_mse':clean_score,'shuffled_validation_mse':shuffled_score},'torch_version':torch.__version__,'numpy_version':np.__version__}
    summary['continuation']=continuation_check(output,train)
    (output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    np.savez(output/'experiment.npz',train_x=train[0].numpy(),train_y=train[1].numpy(),validation_x=val[0].numpy(),validation_y=val[1].numpy(),search=search,**{f'history_{k}':v for k,v in histories.items()},**{f'path_{k}':v for k,v in paths.items()})
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();run(a.output,a.language)
