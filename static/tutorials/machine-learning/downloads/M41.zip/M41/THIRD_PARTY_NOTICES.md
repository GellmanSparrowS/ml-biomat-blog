# Public sources and third-party materials

- Flow Matching for Generative Modeling: https://arxiv.org/html/2210.02747v2
  Primary paper; independent experiment
- Flow Straight and Fast: Learning to Generate and Transfer Data with Rectified Flow: https://arxiv.org/html/2209.03003v1
  Primary paper; independent experiment
- Improving and generalizing flow-based generative models with minibatch optimal transport: https://arxiv.org/abs/2302.00482
  Primary paper; independent experiment
- TorchCFM: https://github.com/atong01/conditional-flow-matching
  MIT Copyright2023AlexanderTong; cropped original frames and license retained
- Flow Matching Guide and Code: https://github.com/facebookresearch/flow_matching
  CC BY-NC repository; linked reference only, no code/figure reuse
- Neural Ordinary Differential Equations: https://arxiv.org/abs/1806.07366
  Primary paper; no copied figures
- Score-Based Generative Modeling through Stochastic Differential Equations: https://arxiv.org/html/2011.13456v2
  Primary paper; no copied figures
