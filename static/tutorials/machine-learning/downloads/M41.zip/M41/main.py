"""Train flow-matching velocity fields and compare actual ODE trajectories.
All data follow the explicit pinwheel rule below. No downloads are required.
"""
from pathlib import Path
import argparse,json,math,copy,platform,time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from scipy.optimize import linear_sum_assignment
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('results'));p.add_argument('--language',choices=['zh','en'],default='en');args=p.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
def tr(z,e):return z if zh else e
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'#faf9f5','axes.facecolor':'#faf9f5','svg.fonttype':'none'})
def save(fig,name):fig.savefig(out/f'{name}-{args.language}.svg',bbox_inches='tight');plt.close(fig)
def pinwheel(n,seed):
 r=np.random.default_rng(seed);labels=np.arange(n)%3;r.shuffle(labels);radius=r.uniform(.4,2,n);angle=labels*2*np.pi/3+.8*radius;points=np.c_[radius*np.cos(angle),radius*np.sin(angle)]+r.normal(0,.07,(n,2));return points.astype('float32'),labels
train,labels=pinwheel(4096,410);valid,valid_labels=pinwheel(1024,411);test,test_labels=pinwheel(1024,412);xt=torch.tensor(train);yt=torch.tensor(labels)
class Velocity(nn.Module):
 def __init__(self,conditional=False):
  super().__init__();self.conditional=conditional;self.net=nn.Sequential(nn.Linear(3+(3 if conditional else 0),96),nn.SiLU(),nn.Linear(96,96),nn.SiLU(),nn.Linear(96,2))
 def forward(self,x,t,c=None):
  if isinstance(t,(float,int)):t=torch.full((len(x),1),float(t))
  else:t=t.reshape(-1,1)
  parts=[x,t]
  if self.conditional:parts.append(F.one_hot(c,3).float())
  return self.net(torch.cat(parts,1))
def couple(a,b,kind):
 if kind!='OT':return b
 cost=torch.cdist(a,b).square().numpy();_,j=linear_sum_assignment(cost);return b[j]
@torch.no_grad()
def integrate(model,initial,steps,method='heun',condition=None,record=False):
 x=initial.clone();h=1/steps;path=[x.numpy().copy()] if record else []
 for i in range(steps):
  t=i*h;k1=model(x,t,condition)
  if method=='euler':x=x+h*k1
  elif method=='heun':x=x+h*(k1+model(x+h*k1,t+h,condition))/2
  else:
   k2=model(x+h*k1/2,t+h/2,condition);k3=model(x+h*k2/2,t+h/2,condition);k4=model(x+h*k3,t+h,condition);x=x+h*(k1+2*k2+2*k3+k4)/6
  if record:path.append(x.numpy().copy())
 return x.numpy(),np.array(path)
histories={};training={};models={}
def fit(name,seed,steps=4000,paired=None):
 conditional=name=='Conditional';torch.manual_seed(seed);m=Velocity(conditional);opt=torch.optim.Adam(m.parameters(),lr=.001);rng=torch.Generator().manual_seed(seed+100);vrng=torch.Generator().manual_seed(seed+200)
 if paired is None:
  va=torch.randn((1024,2),generator=vrng);vb=torch.tensor(valid);vc=torch.tensor(valid_labels)
  if name=='OT':vb=torch.cat([couple(va[i:i+128],vb[i:i+128],name) for i in range(0,1024,128)])
 else:va,vb=paired[2:];vc=None
 vt=torch.rand((len(va),1),generator=vrng);vx=(1-vt)*va+vt*vb;vu=vb-va;best=float('inf');best_state=None;history=[];started=time.perf_counter()
 for step in range(1,steps+1):
  if paired is None:
   idx=torch.randint(len(xt),(128,),generator=rng);a=torch.randn((128,2),generator=rng);b=couple(a,xt[idx],name);c=yt[idx] if conditional else None
  else:
   idx=torch.randint(len(paired[0]),(128,),generator=rng);a,b=paired[0][idx],paired[1][idx];c=None
  t=torch.rand((128,1),generator=rng);x=(1-t)*a+t*b;u=b-a;loss=F.mse_loss(m(x,t,c),u);opt.zero_grad();loss.backward();opt.step()
  if step%200==0:
   with torch.no_grad():vl=F.mse_loss(m(vx,vt,vc),vu).item()
   history.append([step,loss.item(),vl])
   if vl<best:best=vl;best_step=step;best_state=copy.deepcopy(m.state_dict())
 m.load_state_dict(best_state);m.eval();models[name]=m;histories[name]=history;training[name]=dict(parameters=sum(p.numel() for p in m.parameters()),updates=steps,best_step=best_step,validation_velocity_mse=best,seconds=time.perf_counter()-started,seed=seed);torch.save(dict(model=m.state_dict(),conditional=conditional,best_step=best_step),out/f'{name.lower()}.pt');return m
fit('Independent',414);fit('OT',415)
teacher_rng=torch.Generator().manual_seed(416);teacher_train=torch.randn((2048,2),generator=teacher_rng);teacher_valid=torch.randn((512,2),generator=teacher_rng);teacher_b,_=integrate(models['Independent'],teacher_train,64,'heun');teacher_vb,_=integrate(models['Independent'],teacher_valid,64,'heun');fit('Reflow',417,3000,(teacher_train,torch.tensor(teacher_b),teacher_valid,torch.tensor(teacher_vb)));fit('Conditional',418)
evalrng=torch.Generator().manual_seed(413);initial=torch.randn((1024,2),generator=evalrng);requests=torch.arange(1024)%3
rr=np.linspace(.4,2,240);curve=np.concatenate([np.c_[rr*np.cos(c*2*np.pi/3+.8*rr),rr*np.sin(c*2*np.pi/3+.8*rr)] for c in range(3)]);curve_labels=np.repeat(np.arange(3),len(rr));curve_bins=np.tile(np.minimum((np.arange(len(rr))*6/len(rr)).astype(int),5),3)
angles=np.arange(32)*np.pi/32;directions=np.c_[np.cos(angles),np.sin(angles)]
def assess(x):
 distance=((x[:,None]-curve[None])**2).sum(2);nearest=distance.argmin(1);d=np.sqrt(distance[np.arange(len(x)),nearest]);cl=curve_labels[nearest];inside=d<.21;counts=np.bincount((cl*6+curve_bins[nearest])[inside],minlength=18);sw=float(np.abs(np.sort(x@directions.T,axis=0)-np.sort(test@directions.T,axis=0)).mean());return dict(sliced_w1=sw,mean_curve_distance=float(d.mean()),near_curve_fraction=float(inside.mean()),covered_bins=int((counts>=5).sum()),bin_counts=counts.tolist(),arm_counts=np.bincount(cl,minlength=3).tolist())
settings=[('Euler1','euler',1),('Euler4','euler',4),('Euler16','euler',16),('Heun8','heun',8),('RK4x4','rk4',4),('Heun32','heun',32)]
metrics={};outputs={};paths={};replay={};axis=np.linspace(-2.5,2.5,11);gx,gy=np.meshgrid(axis,axis);grid=np.c_[gx.ravel(),gy.ravel()].astype('float32')
for name,m in models.items():
 c=requests if name=='Conditional' else None;reference,reference_path=integrate(m,initial,128,'rk4',c,True);paths[name]=reference_path;outputs[name+'_reference']=reference;metrics[name]={}
 for label,method,n in settings:
  value,_=integrate(m,initial,n,method,c);stat=assess(value);stat.update(endpoint_rmse=float(np.sqrt(np.mean((value-reference)**2))),calls=n*dict(euler=1,heun=2,rk4=4)[method]);metrics[name][label]=stat;outputs[name+'_'+label]=value
 stat=assess(reference);refined,_=integrate(m,initial,256,'rk4',c);stat['refinement_rmse']=float(np.sqrt(np.mean((refined-reference)**2)));stat['calls']=512;chords=np.linalg.norm(reference_path[-1]-reference_path[0],axis=1);lengths=np.linalg.norm(np.diff(reference_path,axis=0),axis=2).sum(0);stat['mean_path_excess']=float(np.mean(lengths-chords));stat['mean_path_length']=float(lengths.mean());stat['mean_chord_length']=float(chords.mean())
 if c is not None:stat['condition_agreement']=float((curve_labels[((reference[:,None]-curve[None])**2).sum(2).argmin(1)]==requests.numpy()).mean())
 metrics[name]['Reference']=stat
 if name!='Conditional':
  time_indices=np.arange(0,129,8);fields=[]
  with torch.no_grad():
   for k in time_indices:fields.append(m(torch.tensor(grid),k/128).numpy().tolist())
  replay[name]=dict(times=(time_indices/128).tolist(),points=reference_path[time_indices,:128].tolist(),velocity=fields,solver='RK4, 128 steps')
# Exact two-by-two assignment, one hand interpolation, and a known ODE isolate calculation.
hand_a=np.array([[-1.,0.],[1.,0.]]);hand_b=np.array([[1.,1.],[-1.,1.]]);cost=((hand_a[:,None]-hand_b[None])**2).sum(2);row,col=linear_sum_assignment(cost);ode=[]
for n in [1,4,16,64]:
 x=1.;h=1/n
 for _ in range(n):x+=h*x
 ode.append(dict(steps=n,value=x,error=abs(x-math.e)))
pairrng=np.random.default_rng(419);pair_a=pairrng.normal(size=(24,2));pair_b=train[:24];_,pair_j=linear_sum_assignment(((pair_a[:,None]-pair_b[None])**2).sum(2));pair_ot=pair_b[pair_j]
summary=dict(versions=dict(python=platform.python_version(),torch=torch.__version__,numpy=np.__version__),data=dict(train=4096,validation=1024,test=1024,seeds=[410,411,412],noise=.07),training=training,metrics=metrics,reflow=dict(train_pairs=2048,validation_pairs=512,teacher='Independent',teacher_solver='Heun64',teacher_calls_per_pair=128),hand=dict(interpolated=[.5,.25],velocity=[2.,1.],independent_cost=float(cost.diagonal().mean()),optimal_cost=float(cost[row,col].mean()),optimal_permutation=col.tolist(),euler_exp=ode),display_pairs=dict(independent_mean_cost=float(np.mean(np.sum((pair_b-pair_a)**2,1))),ot_mean_cost=float(np.mean(np.sum((pair_ot-pair_a)**2,1)))))
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');(out/'replay.json').write_text(json.dumps(dict(models=replay,grid=grid.tolist(),target=test[:400].tolist(),curves=[curve[i*240:(i+1)*240:8].tolist() for i in range(3)]),separators=(',',':')),encoding='utf-8');np.savez_compressed(out/'experiment.npz',train=train,train_labels=labels,validation=valid,validation_labels=valid_labels,test=test,test_labels=test_labels,initial_noise=initial.numpy(),requested_classes=requests.numpy(),teacher_train_start=teacher_train.numpy(),teacher_train_end=teacher_b,teacher_validation_start=teacher_valid.numpy(),teacher_validation_end=teacher_vb,grid=grid,pair_a=pair_a,pair_b=pair_b,pair_ot=pair_ot,**outputs,**{name+'_trajectory':v for name,v in paths.items()},**{name+'_history':np.array(v) for name,v in histories.items()})
colors=['#176b8a','#bd6d3a','#63864b']
fig,axs=plt.subplots(1,3,figsize=(13,4.5),layout='constrained')
for ax,b,title in zip(axs[:2],[pair_b,pair_ot],[tr('A  独立配对','A  Independent pairs'),tr('B  小批次最短平方距离配对','B  Minibatch squared-cost assignment')]):
 for a,z in zip(pair_a,b):ax.plot([a[0],z[0]],[a[1],z[1]],color='#647e87',alpha=.4,lw=.8)
 ax.scatter(*pair_a.T,s=26,facecolors='none',edgecolors='#125f82',label=tr('噪声起点','Noise start'));ax.scatter(*b.T,s=24,c='#bf7139',label=tr('数据终点','Data end'));ax.set_title(title);ax.legend(fontsize=8)
for i in range(24):axs[2].plot(paths['Independent'][:,i,0],paths['Independent'][:,i,1],color=colors[i%3],alpha=.7,lw=1)
axs[2].scatter(*initial[:24].numpy().T,s=20,facecolors='none',edgecolors='#125f82');axs[2].set_title(tr('C  学到的ODE轨迹','C  Learned ODE trajectories'))
for ax in axs:ax.set(xlabel='x1',ylabel='x2',xlim=(-4,4),ylim=(-4,4));ax.set_aspect('equal')
save(fig,'couplings')
fig,axs=plt.subplots(2,3,figsize=(13,8),layout='constrained')
for row,name in enumerate(['Independent','OT']):
 for col,k in enumerate([0,64,128]):
  ax=axs[row,col];pts=paths[name][k];ax.scatter(pts[:500,0],pts[:500,1],s=5,color='#176b8a',alpha=.5);ax.scatter(test[:300,0],test[:300,1],s=3,color='#bf7139',alpha=.15)
  with torch.no_grad():v=models[name](torch.tensor(grid),k/128).numpy()
  ax.quiver(grid[:,0],grid[:,1],v[:,0],v[:,1],angles='xy',scale_units='xy',scale=8,width=.003,color='#314c59');ax.set(xlim=(-3,3),ylim=(-3,3),xlabel='x1',ylabel='x2',title=f'{name}, t={k/128:.1f}');ax.set_aspect('equal')
save(fig,'velocity')
fig,axs=plt.subplots(3,4,figsize=(13,10),layout='constrained')
for row,name in enumerate(['Independent','OT','Reflow']):
 for col,key in enumerate(['Euler1','Euler4','Heun8','reference']):
  v=outputs[name+'_'+key];ax=axs[row,col];ax.scatter(*v[:500].T,s=5,alpha=.55,color='#176b8a');ax.set(xlabel='x1',ylabel='x2',xlim=(-3,3),ylim=(-3,3),title=f'{name} / {key}');ax.set_aspect('equal')
save(fig,'samples')
fig,axs=plt.subplots(1,3,figsize=(13,4.5),layout='constrained')
for j,name in enumerate(['Independent','OT','Reflow']):
 for label,method,n in settings:
  z=metrics[name][label];axs[0].scatter(z['calls'],z['endpoint_rmse'],color=colors[j],marker=dict(euler='o',heun='s',rk4='^')[method]);axs[1].scatter(z['calls'],z['sliced_w1'],color=colors[j],marker=dict(euler='o',heun='s',rk4='^')[method])
 axs[0].plot([],[],color=colors[j],label=name);axs[2].bar(j,metrics[name]['Reference']['mean_path_excess'],color=colors[j])
axs[0].set(xscale='log',yscale='log',xlabel=tr('速度网络调用次数','Velocity-network calls'),ylabel=tr('终点对参考解RMSE','Endpoint RMSE vs reference'),title=tr('A  同一模型的数值误差','A  Numerical error within each model'));axs[0].legend(fontsize=8);axs[1].set(xscale='log',xlabel=tr('速度网络调用次数','Velocity-network calls'),ylabel=tr('32方向投影W1','32-direction sliced W1'),title=tr('B  与独立测试分布比较','B  Difference from held-out distribution'));axs[2].set(xticks=range(3),xticklabels=['Independent','OT','Reflow'],ylabel=tr('平均路径长减弦长','Mean path length minus chord'),title=tr('C  积分路径弯曲程度','C  Curvature of integrated paths'));save(fig,'diagnostics')
fig,axs=plt.subplots(1,3,figsize=(13,4.3),layout='constrained');conditional=outputs['Conditional_reference'];req=requests.numpy()
for c,ax in enumerate(axs):
 ax.scatter(*test[test_labels==c].T,s=7,color='#bf7139',alpha=.4,label=tr('测试目标','Test target'));ax.scatter(*conditional[req==c].T,s=7,color='#176b8a',alpha=.6,label=tr('按类别生成','Conditional samples'));ax.set(xlim=(-2.5,2.5),ylim=(-2.5,2.5),xlabel='x1',ylabel='x2',title=tr('请求叶片 ','Requested arm ')+str(c));ax.set_aspect('equal');ax.legend(fontsize=9)
save(fig,'conditions');print(json.dumps(summary,indent=2))
