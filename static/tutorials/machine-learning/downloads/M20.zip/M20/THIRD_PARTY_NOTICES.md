# Public sources and third-party materials

- librosa — Using display.specshow: https://librosa.org/doc-playground/main/auto_examples/plot_display.html
  Technical reference; figures, synthetic recordings, and teaching implementation are original.
- SciPy STFT documentation: https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.stft.html
  Technical reference; figures, synthetic recordings, and teaching implementation are original.
- Connectionist Temporal Classification: https://www.cs.toronto.edu/~graves/icml_2006.pdf
  Technical reference; figures, synthetic recordings, and teaching implementation are original.
- Sequence Modeling With CTC: https://distill.pub/2017/ctc/
  Technical reference; figures, synthetic recordings, and teaching implementation are original.
- SpeechBrain — Speech Recognition From Scratch: https://speechbrain.readthedocs.io/en/latest/tutorials/tasks/speech-recognition-from-scratch.html
  Technical reference; figures, synthetic recordings, and teaching implementation are original.
- Robust Speech Recognition via Large-Scale Weak Supervision: https://arxiv.org/abs/2212.04356
  Technical reference; figures, synthetic recordings, and teaching implementation are original.
- Natural TTS Synthesis by Conditioning WaveNet on Mel Spectrogram Predictions: https://arxiv.org/abs/1712.05884
  Technical reference; figures, synthetic recordings, and teaching implementation are original.
- HiFi-GAN: https://arxiv.org/abs/2010.05646
  Technical reference; figures, synthetic recordings, and teaching implementation are original.
- wav2vec 2.0: https://arxiv.org/abs/2006.11477
  Technical reference; figures, synthetic recordings, and teaching implementation are original.
