"""Generated audio: time-frequency analysis, classification, masks, and exact CTC."""
import argparse,copy,itertools,json
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import confusion_matrix
import torch
from torch import nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

torch.set_num_threads(2)
FS=8000;NFFT=256;HOP=64;DURATION=.6

def stft(x,nfft=NFFT,hop=HOP):
    window=np.hanning(nfft+1)[:-1]
    padded=np.pad(x,(nfft//2,nfft//2+(-len(x))%hop))
    frames=np.lib.stride_tricks.sliding_window_view(padded,nfft)[::hop]
    return np.fft.rfft(frames*window,axis=1).T/window.sum()

def istft(z,length,nfft=NFFT,hop=HOP):
    window=np.hanning(nfft+1)[:-1];frames=np.fft.irfft(z.T,n=nfft,axis=1)*window.sum()
    out=np.zeros((len(frames)-1)*hop+nfft);weight=np.zeros_like(out)
    for i,frame in enumerate(frames):
        out[i*hop:i*hop+nfft]+=frame*window;weight[i*hop:i*hop+nfft]+=window**2
    out=np.divide(out,weight,out=np.zeros_like(out),where=weight>1e-12)
    return out[nfft//2:nfft//2+length]

def mel_filters(count=32):
    hz=np.fft.rfftfreq(NFFT,1/FS)
    mel=lambda x:2595*np.log10(1+x/700)
    points=700*(10**(np.linspace(mel(0),mel(FS/2),count+2)/2595)-1)
    filters=[]
    for left,mid,right in zip(points[:-2],points[1:-1],points[2:]):
        filters.append(np.maximum(0,np.minimum((hz-left)/(mid-left),(right-hz)/(right-mid))))
    return np.array(filters),points[1:-1]

BANK,CENTERS=mel_filters()
def feature(x):return np.log(np.maximum(BANK@abs(stft(x))**2,1e-8)).astype(np.float32)

def dataset(groups,snr=None):
    signals=[];labels=[];groupids=[]
    time=np.arange(int(FS*DURATION))/FS
    for group in groups:
        profile=np.random.default_rng(2000+group);echo=profile.uniform(-.25,.25);gain=profile.uniform(.7,1.3)
        for label in range(3):
            for repeat in range(4):
                rng=np.random.default_rng(10000+group*100+label*10+repeat)
                low=rng.uniform(300,600);high=rng.uniform(1200,1700);phase=rng.uniform(0,2*np.pi)
                if label==0:f0=f1=rng.uniform(650,950)
                elif label==1:f0,f1=low,high
                else:f0,f1=high,low
                phase_t=2*np.pi*(f0*time+(f1-f0)/(2*DURATION)*time**2)+phase
                clean=np.sin(phase_t)*np.sin(np.pi*time/DURATION)**2
                clean=gain*(clean+echo*np.r_[0,clean[:-1]])
                level=rng.uniform(5,25) if snr is None else snr
                noise=np.random.default_rng(90000+group*100+label*10+repeat).normal(size=len(clean))
                noise*=np.sqrt(np.mean(clean**2)/(10**(level/10)*np.mean(noise**2)))
                signals.append(clean+noise);labels.append(label);groupids.append(group)
    return np.array(signals),np.array(labels),np.array(groupids)

class AudioCNN(nn.Module):
    def __init__(self):
        super().__init__();self.net=nn.Sequential(nn.Conv2d(1,8,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),nn.Conv2d(8,16,3,padding=1),nn.ReLU(),nn.AdaptiveAvgPool2d((4,4)),nn.Flatten(),nn.Linear(256,3))
    def forward(self,x):return self.net(x)

def collapse(path):
    return ''.join(c for i,c in enumerate(path) if c!='_' and (i==0 or c!=path[i-1]))

def edit_distance(ref,hyp):
    d=np.zeros((len(ref)+1,len(hyp)+1),int);d[:,0]=np.arange(len(ref)+1);d[0,:]=np.arange(len(hyp)+1)
    for i in range(1,len(ref)+1):
        for j in range(1,len(hyp)+1):d[i,j]=min(d[i-1,j]+1,d[i,j-1]+1,d[i-1,j-1]+(ref[i-1]!=hyp[j-1]))
    return int(d[-1,-1])

def run(out,language):
    out.mkdir(parents=True,exist_ok=True);zh=language=='zh';text=lambda z,e:z if zh else e
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','DejaVu Sans'],'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','axes.unicode_minus':False})
    save=lambda fig,name:(fig.savefig(out/f'{name}-{language}.svg',bbox_inches='tight'),fig.savefig(out/f'{name}-{language}.png',dpi=140,bbox_inches='tight'),plt.close(fig))
    waves,y,g=dataset(range(17));features=np.array([feature(w) for w in waves]);train=g<10;valid=(g>=10)&(g<13);test=g>=13
    mean=features[train].mean();std=features[train].std();inputs=torch.tensor((features-mean)/std)[:,None];targets=torch.tensor(y)
    torch.manual_seed(20);model=AudioCNN();optimizer=torch.optim.Adam(model.parameters(),lr=.002);trace=[];best=float('inf');selected=0
    trainids=np.flatnonzero(train)
    for epoch in range(35):
        model.train();order=torch.randperm(len(trainids));total=0
        for ids in order.split(24):
            ix=trainids[ids.numpy()];optimizer.zero_grad();loss=nn.functional.cross_entropy(model(inputs[ix]),targets[ix]);loss.backward();optimizer.step();total+=loss.item()*len(ix)
        model.eval()
        with torch.no_grad():vl=nn.functional.cross_entropy(model(inputs[valid]),targets[valid]).item()
        trace.append((total/train.sum(),vl))
        if vl<best:best=vl;weights=copy.deepcopy(model.state_dict());selected=epoch+1
    model.load_state_dict(weights);model.eval()
    torch.save({'model':model.state_dict(),'mean':float(mean),'std':float(std)},out/'audio-model.pt')
    (out/'model.json').write_text(json.dumps({'class':'AudioCNN','classes':['steady','rising','falling'],'sample_rate_hz':FS,'window_samples':NFFT,'hop_samples':HOP,'mel_filters':32,'selected_epoch':selected,'mean':float(mean),'std':float(std)},indent=2),encoding='utf-8')
    saved=torch.load(out/'audio-model.pt',weights_only=True);reloaded=AudioCNN();reloaded.load_state_dict(saved['model']);reloaded.eval()
    restored_inputs=torch.tensor((features[test]-saved['mean'])/saved['std'])[:,None]
    with torch.no_grad():reload_error=float((model(inputs[test])-reloaded(restored_inputs)).abs().max())
    with torch.no_grad():prob=model(inputs[test]).softmax(1).numpy()
    pred=prob.argmax(1);cm=confusion_matrix(y[test],pred,labels=range(3))
    baseline=make_pipeline(StandardScaler(),LogisticRegression(max_iter=1000));baseline.fit(features[train].mean(2),y[train]);baseline_accuracy=float(baseline.score(features[test].mean(2),y[test]))
    levels=[20,5,-5];noise_acc=[]
    for level in levels:
        ww,yy,_=dataset(range(13,17),level);ff=np.array([feature(w) for w in ww]);xx=torch.tensor((ff-mean)/std)[:,None]
        with torch.no_grad():pp=model(xx).argmax(1).numpy()
        noise_acc.append(float(np.mean(pp==yy)))
    t=np.arange(2*FS)/FS;envelope=np.sin(np.pi*t/2)**2
    clean=envelope*(.65*np.sin(2*np.pi*440*t)+.2*np.sin(2*np.pi*880*t));interference=.65*envelope*np.sin(2*np.pi*(1300*t+250*t*t))
    noise=np.random.default_rng(77).normal(0,.12,len(t));mixture=clean+interference+noise
    z=stft(mixture);freq=np.fft.rfftfreq(NFFT,1/FS);mask=(freq<=1000).astype(float)[:,None]
    estimate=istft(z*mask,len(t));reconstructed=istft(z,len(t));reconstruction_error=float(abs(reconstructed-mixture).max())
    snr=lambda estimate:float(10*np.log10(np.sum(clean**2)/np.sum((estimate-clean)**2)))
    shared_gain=.85/max(np.max(abs(x)) for x in [clean,mixture,estimate])
    for name,w in [('clean',clean),('mixture',mixture),('filtered',estimate)]:wavfile.write(out/(name+'.wav'),FS,np.int16(np.clip(w*shared_gain,-1,1)*32767))
    ctc_prob=np.array([[.4,.6],[.5,.5],[.3,.7]]);sequences={}
    for path in itertools.product(range(2),repeat=3):
        output=collapse(''.join('_A'[k] for k in path));p=float(np.prod([ctc_prob[i,k] for i,k in enumerate(path)]));sequences[output]=sequences.get(output,0)+p
    greedy=collapse(''.join('_A'[k] for k in ctc_prob.argmax(1)))
    ref='turn left at next street'.split();hyp='turn right at the next street'.split();ed=edit_distance(ref,hyp)
    summary={'sample_rate_hz':FS,'window_samples':NFFT,'hop_samples':HOP,'frequency_bin_hz':FS/NFFT,'split_clips':[int(train.sum()),int(valid.sum()),int(test.sum())],'group_overlap':len(set(g[train])&set(g[test])),'selected_epoch':selected,'cnn_test_accuracy':float(np.mean(pred==y[test])),'time_averaged_baseline_accuracy':baseline_accuracy,'confusion_matrix':cm.tolist(),'noise_levels_db':levels,'noise_accuracy':noise_acc,'stft_reconstruction_max_error':reconstruction_error,'input_snr_db':snr(mixture),'filtered_snr_db':snr(estimate),'ctc_sequence_probabilities':sequences,'ctc_greedy_output':greedy,'wer_edit_distance':ed,'wer_reference_words':len(ref),'wer':ed/len(ref),'audio_duration_seconds':len(t)/FS,'audio_shared_gain':float(shared_gain)}
    summary['reload_logits_error']=reload_error
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    np.savez_compressed(out/'data.npz',waveforms=waves,labels=y,groups=g,features=features,probabilities=prob,trace=trace,clean=clean,mixture=mixture,estimate=estimate,ctc_prob=ctc_prob)
    assert reconstruction_error<1e-10;assert abs(sum(sequences.values())-1)<1e-12;assert abs(sequences['AA']-.21)<1e-12;assert ed==2
    names=[text('恒定音调','Steady tone'),text('上升扫频','Rising sweep'),text('下降扫频','Falling sweep')]
    fig,axs=plt.subplots(2,3,figsize=(12,5.6),gridspec_kw={'height_ratios':[.7,1.4]},layout='constrained')
    for c in range(3):
        idx=np.flatnonzero((y==c)&test)[0];wave=waves[idx];spec=stft(wave);db=20*np.log10(np.maximum(abs(spec),1e-8)/np.max(abs(spec)))
        axs[0,c].plot(np.arange(len(wave))/FS,wave,lw=.35,color='#4d6575');axs[0,c].set(title=names[c],xlabel=text('时间 / s','Time / s'),ylabel=text('振幅','Amplitude'))
        im=axs[1,c].pcolormesh(np.arange(spec.shape[1])*HOP/FS,freq,db,cmap='magma',vmin=-65,vmax=0,shading='auto',rasterized=True);axs[1,c].set(ylim=(0,2500),xlabel=text('时间 / s','Time / s'),ylabel=text('频率 / Hz','Frequency / Hz'))
    fig.colorbar(im,ax=axs[1,:],label=text('相对峰值 / dB','Relative to each peak / dB'));save(fig,'representations')
    fig,axs=plt.subplots(1,3,figsize=(12,3.7),layout='constrained');tr=np.array(trace)
    axs[0].plot(np.arange(1,36),tr[:,0],label=text('训练','Train'),color='#176b91');axs[0].plot(np.arange(1,36),tr[:,1],label=text('验证','Validation'),color='#bc5549');axs[0].set(xlabel=text('轮数','Epoch'),ylabel=text('交叉熵','Cross entropy'));axs[0].legend()
    im=axs[1].imshow(cm,cmap='Blues',vmin=0,vmax=16);axs[1].set(xticks=range(3),yticks=range(3),xticklabels=names,yticklabels=names,xlabel=text('预测类别','Predicted'),ylabel=text('实际类别','True'));axs[1].tick_params(axis='x',labelrotation=25)
    for i in range(3):
        for j in range(3):axs[1].text(j,i,str(cm[i,j]),ha='center',va='center',color='white' if cm[i,j]>8 else '#18384d')
    axs[2].plot(levels,noise_acc,'o-',color='#176b91');axs[2].axhline(1/3,color='#8e9ba3',ls='--',label=text('随机机会 1/3','Chance 1/3'));axs[2].set(xticks=levels,ylim=(0,1.05),xlabel=text('输入信噪比 / dB','Input SNR / dB'),ylabel=text('正确率','Accuracy'));axs[2].legend();save(fig,'classification')
    fig,axs=plt.subplots(2,3,figsize=(12,5.8),layout='constrained');refamp=max(abs(stft(w)).max() for w in [clean,mixture,estimate])
    for j,(name,w)in enumerate([(text('目标声','Target'),clean),(text('混合声','Mixture'),mixture),(text('频带估计','Band estimate'),estimate)]):
        segment=(t>=.8)&(t<.84)
        axs[0,j].plot(t[segment],w[segment],lw=.8,color=['#176b91','#8c6e99','#2b897a'][j]);axs[0,j].set(title=name,xlabel=text('时间 / s','Time / s'),ylabel=text('振幅','Amplitude'),ylim=(-1.5,1.5))
        zz=stft(w);im=axs[1,j].pcolormesh(np.arange(zz.shape[1])*HOP/FS,freq,20*np.log10(np.maximum(abs(zz),1e-8)/refamp),vmin=-65,vmax=0,cmap='magma',shading='auto',rasterized=True);axs[1,j].set(xlabel=text('时间 / s','Time / s'),ylabel=text('频率 / Hz','Frequency / Hz'),ylim=(0,2500))
    fig.colorbar(im,ax=axs[1,:],label=text('共享参考 / dB','Shared reference / dB'));save(fig,'separation')
    fig,axs=plt.subplots(1,2,figsize=(10,3.2),layout='constrained');im=axs[0].imshow(ctc_prob.T,cmap='Blues',vmin=0,vmax=1,aspect='auto')
    axs[0].set(xticks=range(3),xticklabels=[1,2,3],yticks=[0,1],yticklabels=[text('空白','Blank'),'A'],xlabel=text('声学帧','Acoustic frame'),title=text('每帧输出概率','Frame probabilities'))
    for i in range(3):
        for j in range(2):axs[0].text(i,j,f'{ctc_prob[i,j]:.1f}',ha='center',va='center',color='white' if ctc_prob[i,j]>.55 else '#18384d')
    axs[1].bar([text('空序列','Empty'),'A','AA'],[sequences[''],sequences['A'],sequences['AA']],color=['#9daab1','#176b91','#bf7444']);axs[1].set(ylim=(0,1),ylabel=text('所有路径求和后的概率','Probability summed over paths'),title=text('最可能的路径不等于最可能的转写','Best path differs from best transcript'));save(fig,'ctc')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('output'));p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args();run(a.output,a.language)
