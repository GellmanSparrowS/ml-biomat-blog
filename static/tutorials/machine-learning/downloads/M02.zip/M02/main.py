"""Small, reproducible experiments in geometry, approximation and optimization."""
from pathlib import Path
import argparse, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.special import logsumexp, xlogy

def main(output, language):
    output=Path(output);output.mkdir(parents=True,exist_ok=True);zh=language=='zh'
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
    def t(a,b):return a if zh else b
    def save(fig,name):fig.savefig(output/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
    # A complete two-dimensional SVD: rotation/reflection, stretch, rotation.
    A=np.array([[2.,1.],[0.,1.]])
    U,s,Vt=np.linalg.svd(A);theta=np.linspace(0,2*np.pi,401);circle=np.array([np.cos(theta),np.sin(theta)])
    fig,axes=plt.subplots(1,4,figsize=(12,3.2),layout='constrained')
    arrays=[circle,Vt@circle,np.diag(s)@Vt@circle,A@circle]
    titles=[t('单位圆','Unit circle'),'Vᵀ x','Σ Vᵀ x','U Σ Vᵀ x = A x']
    for ax,points,title in zip(axes,arrays,titles):
        ax.plot(*points,color='#167d87',lw=2);ax.scatter(*points[:,0],color='#d48745',s=30,zorder=3)
        ax.axhline(0,color='#b8c7ce',lw=.7);ax.axvline(0,color='#b8c7ce',lw=.7)
        ax.set(xlim=(-2.8,2.8),ylim=(-2.8,2.8),aspect='equal',title=title,xlabel='x₁',ylabel='x₂')
    save(fig,'geometry')
    # Original analytic image, with structure known exactly; no downloaded image.
    x=np.linspace(-1,1,96);xx,yy=np.meshgrid(x,x)
    img=np.exp(-((xx+.35)**2+(yy-.2)**2)/.11)+.6*np.exp(-((xx-.35)**2+(yy+.3)**2)/.09)+.22*np.cos(11*(xx+yy))*np.exp(-xx**2-yy**2)
    u,sv,vt=np.linalg.svd(img,full_matrices=False);ranks=[1,2,4,12];errs=[]
    fig=plt.figure(figsize=(13,6.0),layout='constrained');gs=fig.add_gridspec(2,5,height_ratios=[1,1.1]);field_axes=[]
    for j,(rank,title) in enumerate([(96,t('原始场','Original field'))]+[(r,f'r={r}') for r in ranks]):
        approx=img if rank==96 else (u[:,:rank]*sv[:rank])@vt[:rank]
        ax=fig.add_subplot(gs[0,j]);field_axes.append(ax);field_image=ax.imshow(approx,cmap='magma',vmin=img.min(),vmax=img.max(),origin='lower',extent=[-1,1,-1,1]);ax.set(title=title);ax.set_xticks([-1,0,1]);ax.set_yticks([-1,0,1])
        if rank!=96:errs.append(float(np.linalg.norm(img-approx)/np.linalg.norm(img)))
    fig.colorbar(field_image,ax=field_axes,location='right',shrink=.85,pad=.025,label=t('场幅值（无量纲）','Field amplitude (dimensionless)'))
    ax=fig.add_subplot(gs[1,:3]);ax.semilogy(np.arange(1,21),sv[:20],'o-',color='#167d87');ax.set(xlabel=t('奇异值序号','Singular-value index'),ylabel=t('奇异值（场幅值单位）','Singular value (field units)'));ax.grid(alpha=.2)
    ax=fig.add_subplot(gs[1,3:]);ax.bar([str(r) for r in ranks],errs,color='#d48745');ax.set(xlabel=t('保留秩 r','Retained rank r'),ylabel=t('相对重建误差','Relative reconstruction error'));save(fig,'svd')
    H=np.diag([1.,8.]);start=np.array([2.,2.]);trajectories={}
    fig,(ax,lossax)=plt.subplots(1,2,figsize=(11,4.4),layout='constrained');g=np.linspace(-2.4,2.4,200);gx,gy=np.meshgrid(g,g);ax.contour(gx,gy,.5*(gx**2+8*gy**2),levels=[.1,.5,1,2,4,8,16],colors='#cad8de')
    for eta,col in [(.05,'#167d87'),(.22,'#d48745'),(.3,'#8b557c')]:
        w=start.copy();path=[w.copy()]
        for _ in range(25):w=w-eta*(H@w);path.append(w.copy())
        path=np.array(path);loss=.5*np.sum(path*(path@H),axis=1);trajectories[str(eta)]={'path':path.tolist(),'loss':loss.tolist()}
        ax.plot(*path.T,'o-',ms=2,color=col,label=f'η={eta}');lossax.semilogy(loss,color=col,label=f'η={eta}')
    ax.set(xlim=(-2.4,2.4),ylim=(-2.4,2.4),xlabel='w₁',ylabel='w₂',title=t('同一碗形目标，三种步长','One quadratic objective, three step sizes'));ax.legend()
    lossax.set(xlabel=t('更新次数','Update'),ylabel=t('目标函数（无量纲）','Objective (dimensionless)'));lossax.grid(alpha=.2);lossax.legend();save(fig,'gradients')
    q=np.linspace(.001,.999,500);p=.7;entropy=-(xlogy(q,q)+xlogy(1-q,1-q));ce=-(p*np.log(q)+(1-p)*np.log1p(-q));loglike=7*np.log(q)+3*np.log1p(-q)
    fig,axes=plt.subplots(1,3,figsize=(12,3.7),layout='constrained')
    axes[0].plot(q,loglike-loglike.max(),color='#167d87');axes[0].axvline(.7,color='#d48745',ls='--');axes[0].set(xlabel=t('候选正面概率 q','Candidate success probability q'),ylabel=t('相对对数似然','Relative log likelihood'),title=t('10次中7次正面','Seven successes in ten trials'))
    axes[1].plot(q,entropy,color='#167d87');axes[1].set(xlabel='q',ylabel=t('熵（nat）','Entropy (nats)'),title=t('不确定性在中间最大','Uncertainty peaks in the middle'))
    axes[2].plot(q,ce,label=t('交叉熵','Cross entropy'),color='#167d87');hp=-(p*np.log(p)+(1-p)*np.log1p(-p));axes[2].axhline(hp,color='#d48745',label='H(p)');axes[2].set(xlabel=t('报告概率 q','Reported probability q'),ylabel='nat',title=t('真实比例 p=0.7','True proportion p=0.7'));axes[2].legend();save(fig,'probability')
    f=lambda v:.5*v@H@v;eps=1e-6;fd=np.array([(f(start+eps*np.eye(2)[i])-f(start-eps*np.eye(2)[i]))/(2*eps) for i in range(2)])
    logits=np.array([1000.,1001.,999.]);probs=np.exp(logits-logsumexp(logits))
    summary={'matrix_reconstruction_error':float(np.linalg.norm(A-U@np.diag(s)@Vt)),'singular_values':s.tolist(),'image_rank_errors':dict(zip(map(str,ranks),errs)),'analytic_gradient':(H@start).tolist(),'finite_difference_gradient':fd.tolist(),'gradient_max_error':float(np.max(np.abs(fd-H@start))),'one_step_eta_0_1':(start-.1*H@start).tolist(),'one_step_loss':f(start-.1*H@start),'stable_probabilities':probs.tolist(),'stable_probability_sum':float(probs.sum()),'entropy_p_0_7_nats':hp,'trajectories':trajectories}
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');np.savez(output/'experiment_data.npz',A=A,image=img,singular_values=sv,q=q,cross_entropy=ce)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--language',choices=['zh','en'],default='en');a=ap.parse_args();main(a.output,a.language)
