# Public sources and third-party materials

- Dive into Deep Learning — Linear Algebra: https://d2l.ai/chapter_preliminaries/linear-algebra.html
  CC BY-SA 4.0
- Dive into Deep Learning — Calculus: https://d2l.ai/chapter_preliminaries/calculus.html
  CC BY-SA 4.0
- NumPy — Singular Value Decomposition: https://numpy.org/doc/stable/reference/generated/numpy.linalg.svd.html
  NumPy documentation
- SciPy — logsumexp: https://docs.scipy.org/doc/scipy/reference/generated/scipy.special.logsumexp.html
  SciPy documentation
- Shannon (1948), A Mathematical Theory of Communication: https://people.math.harvard.edu/~ctm/home/text/others/shannon/entropy/entropy.pdf
  Reference
