# Public sources and third-party materials

- Christoph Molnar — Interpretable Machine Learning: https://christophm.github.io/interpretable-ml-book/
  CC BY-NC-SA book; linked, no figure copied
- Ribeiro et al. (2016), Why Should I Trust You?: https://arxiv.org/abs/1602.04938
  Primary reference
- SHAP — Beeswarm example and TreeExplainer: https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/beeswarm.html
  MIT, unmodified figure
- SHAP — TreeExplainer output scale: https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html
  MIT documentation
- Sundararajan et al. (2017), Axiomatic Attribution for Deep Networks: https://proceedings.mlr.press/v70/sundararajan17a.html
  Primary reference
- Captum — Integrated Gradients: https://captum.ai/docs/extension/integrated_gradients
  Official technical reference
- Selvaraju et al., Grad-CAM: https://arxiv.org/abs/1610.02391
  Primary reference
- Kim et al. (2018), TCAV: https://proceedings.mlr.press/v80/kim18d.html
  Primary reference
- Olah, Mordvintsev & Schubert (2017), Feature Visualization: https://distill.pub/2017/feature-visualization/
  CC BY4.0, unmodified figure
- Adebayo et al., Sanity Checks for Saliency Maps: https://arxiv.org/abs/1810.03292
  Primary reference
- UCI — Optical Recognition of Handwritten Digits: https://archive.ics.uci.edu/dataset/80/optical+recognition+of+handwritten+digits
  CC BY4.0
