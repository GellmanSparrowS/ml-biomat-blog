"""Explain actual fitted models through complementary, inspectable calculations."""
from pathlib import Path
import argparse,json,itertools,math
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor,HistGradientBoostingRegressor
from sklearn.linear_model import LinearRegression,Ridge,LogisticRegression
from sklearn.preprocessing import SplineTransformer
from sklearn.pipeline import make_pipeline
from sklearn.tree import DecisionTreeRegressor
from threadpoolctl import threadpool_limits
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def exact_shap(model,x,background):
 p=len(x);values={}
 for mask in range(1<<p):
  X=background.copy()
  for j in range(p):
   if mask&(1<<j):X[:,j]=x[j]
  values[mask]=float(model.predict(X).mean())
 phi=np.zeros(p)
 for j in range(p):
  for mask in range(1<<p):
   if mask&(1<<j):continue
   k=mask.bit_count();weight=math.factorial(k)*math.factorial(p-k-1)/math.factorial(p);phi[j]+=weight*(values[mask|(1<<j)]-values[mask])
 return phi,values[0],values[(1<<p)-1]
class CNN(nn.Module):
 def __init__(self):super().__init__();self.c1=nn.Conv2d(1,8,3,padding=1);self.c2=nn.Conv2d(8,12,3,padding=1);self.fc=nn.Linear(12*64,10)
 def from_first(self,a):b=F.relu(self.c2(a));return self.fc(b.flatten(1)),b
 def forward(self,x):a=F.relu(self.c1(x));o,b=self.from_first(a);return o,a,b
def ig(model,x,base,target,steps=128):
 # Midpoint quadrature, explicitly retaining the chosen baseline and target logit.
 alphas=(torch.arange(steps,dtype=x.dtype)+.5)/steps;path=(base+alphas[:,None,None,None]*(x-base)).requires_grad_(True);logit=model(path)[0][:,target];g=torch.autograd.grad(logit.sum(),path)[0];return (x-base)*g.mean(0,keepdim=True)
def main(output,language):
 out=Path(output);out.mkdir(parents=True,exist_ok=True);z=language=='zh';L=lambda a,b:a if z else b;rng=np.random.default_rng(25);torch.manual_seed(25);torch.set_num_threads(1)
 plt.rcParams.update({'font.family':'Microsoft YaHei' if z else 'DejaVu Sans','font.size':11,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
 def save(fig,name):fig.savefig(out/f'{name}-{language}.svg',bbox_inches='tight');plt.close(fig)
 X=rng.uniform(-1.5,1.5,(800,3));X[:,2]=X[:,0]+rng.normal(0,.08,800);y=2*X[:,0]+X[:,1]**2+.8*X[:,0]*X[:,1]+rng.normal(0,.15,800);tr,te=train_test_split(np.arange(800),test_size=.25,random_state=25);xt,yt=X[tr],y[tr];xe,ye=X[te],y[te]
 models={'Linear':LinearRegression(),'Tree':DecisionTreeRegressor(max_depth=3,random_state=25),'GAM':make_pipeline(SplineTransformer(n_knots=6,degree=3),Ridge(alpha=1)),'Monotonic':HistGradientBoostingRegressor(max_iter=150,max_leaf_nodes=9,monotonic_cst=[1,0,0],random_state=25),'Forest':RandomForestRegressor(n_estimators=120,max_depth=7,min_samples_leaf=4,n_jobs=1,random_state=25)}
 rmse={}
 for k,m in models.items():m.fit(xt,yt);rmse[k]=float(np.sqrt(np.mean((m.predict(xe)-ye)**2)))
 rf=models['Forest'];base_mse=np.mean((rf.predict(xe)-ye)**2);perm=[]
 for cols in [[0],[1],[2],[0,2]]:
  reps=[]
  for _ in range(12):xx=xe.copy();order=rng.permutation(len(xx));xx[:,cols]=xx[order][:,cols];reps.append(float(np.mean((rf.predict(xx)-ye)**2)-base_mse))
  perm.append({'features':cols,'mean':float(np.mean(reps)),'std':float(np.std(reps,ddof=1))})
 grid=np.linspace(-1.4,1.4,60);ice=[]
 for row in xe[:30]:xx=np.tile(row,(60,1));xx[:,0]=grid;ice.append(rf.predict(xx))
 pdp=np.array([rf.predict(np.c_[np.full(len(xe),v),xe[:,1:]]).mean() for v in grid]);edges=np.quantile(xt[:,0],np.linspace(0,1,11));delta=[];counts=[]
 for lo,hi in zip(edges[:-1],edges[1:]):
  sel=(xt[:,0]>=lo)&(xt[:,0]<(hi if hi<edges[-1] else hi+1e-9));low=xt[sel].copy();high=low.copy();low[:,0]=lo;high[:,0]=hi;delta.append(float(np.mean(rf.predict(high)-rf.predict(low))));counts.append(int(sel.sum()))
 ale=np.cumsum(delta)-np.array(delta)/2;ale-=np.average(ale,weights=counts)
 fig,axs=plt.subplots(1,3,figsize=(15,4.8),layout='constrained');axs[0].scatter(xt[:,0],xt[:,2],s=7,alpha=.25,color='#247b94');axs[0].plot([-1.3,1.3],[1,1],'o--',color='#d97b36');axs[0].set(xlabel='x0',ylabel='x2',title=L('相关特征与人工替换','Correlated features and replacement'));axs[1].barh(['x0','x1','x2','x0+x2'],[v['mean'] for v in perm],xerr=[v['std'] for v in perm],color='#247b94');axs[1].set(xlabel=L('置换后的MSE增加','MSE increase after permutation'),title=L('12次置换的均值与标准差','Mean and SD over 12 permutations'));axs[2].barh(list(rmse),list(rmse.values()),color='#d97b36');axs[2].set(xlabel='RMSE',title=L('同一200点测试集','Same 200-record test set'));save(fig,'global_models')
 fig,axs=plt.subplots(1,2,figsize=(11,4.7),layout='constrained');axs[0].plot(grid,np.array(ice).T,color='#9abac5',alpha=.45,linewidth=.7);axs[0].plot(grid,pdp,color='#d97b36',lw=3,label='PDP');axs[0].set(xlabel='x0',ylabel=L('预测结果','Predicted outcome'),title=L('30条ICE与200点PDP','30 ICE curves and 200-record PDP'));axs[0].legend();axs[1].plot(grid,pdp-pdp.mean(),label=L('PDP减去网格均值','PDP minus grid mean'));axs[1].plot((edges[1:]+edges[:-1])/2,ale,'o-',label=L('ALE按样本数居中','ALE centered by bin counts'));axs[1].set(xlabel='x0',ylabel=L('居中后的模型效应','Centered model effect'),title=L('替换全体，或只做局部差分','Global replacement or local differences'));axs[1].legend(fontsize=8);save(fig,'dependence')
 bg=xt[:80];shaps=np.array([exact_shap(rf,row,bg)[0] for row in xe[:30]]);x=xe[0];phi,base,pred=exact_shap(rf,x,bg);altphi,altbase,_=exact_shap(rf,x,xt[xt[:,0]>0][:80]);lime=[]
 for width in [.2,.8]:
  for seed in range(5):
   rg=np.random.default_rng(seed);near=x+rg.normal(size=(600,3))*width;dist=np.sum(((near-x)/width)**2,axis=1);weights=np.exp(-dist/2);lm=Ridge(alpha=.01).fit(near,rf.predict(near),sample_weight=weights);approx=lm.predict(near);target=rf.predict(near);r2=1-np.sum(weights*(target-approx)**2)/np.sum(weights*(target-np.average(target,weights=weights))**2);lime.append({'width':width,'seed':seed,'coefficients':lm.coef_.tolist(),'point_prediction':float(lm.predict(x[None])[0]),'weighted_r2':float(r2)})
 fig,axs=plt.subplots(1,3,figsize=(15,4.6),layout='constrained');vals=[base,*phi];bottom=0
 for i,v in enumerate(vals):axs[0].bar(i,v,bottom=bottom,color='#247b94' if v>=0 else '#d97b36');bottom+=v
 axs[0].axhline(pred,color='#20394a',ls='--');axs[0].set(xticks=range(4),xticklabels=['Base','x0','x1','x2'],ylabel=L('模型结果单位','Model outcome units'),title=L('精确三特征Shapley求和','Exact three-feature Shapley sum'))
 for j in range(3):axs[1].scatter(shaps[:,j],j+rng.uniform(-.14,.14,30),c=xe[:30,j],cmap='coolwarm',vmin=-1.5,vmax=1.5,s=24)
 axs[1].axvline(0,color='#b6c5cc');axs[1].set(yticks=range(3),yticklabels=['x0','x1','x2'],xlabel=L('Shapley贡献','Shapley contribution'),title=L('30个测试对象；颜色为特征值','30 test records; color is feature value'));fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(-1.5,1.5),cmap='coolwarm'),ax=axs[1],label=L('特征值','Feature value'),shrink=.65)
 for w,c in [(.2,'#247b94'),(.8,'#d97b36')]:cs=np.array([a['coefficients'] for a in lime if a['width']==w]);axs[2].errorbar(range(3),cs.mean(0),yerr=cs.std(0,ddof=1),fmt='o-',color=c,label=f'width={w}')
 axs[2].set(xticks=range(3),xticklabels=['x0','x1','x2'],ylabel=L('局部线性斜率','Local linear slope'),title=L('5个邻域种子的均值与标准差','Mean and SD over 5 neighborhood seeds'));axs[2].legend();save(fig,'local_attribution')
 digits=load_digits();images=digits.images[:,None]/16;labels=digits.target;it,ie=train_test_split(np.arange(len(labels)),test_size=.3,stratify=labels,random_state=25);trainx=torch.tensor(images[it],dtype=torch.float32);trainy=torch.tensor(labels[it]);testx=torch.tensor(images[ie],dtype=torch.float32);model=CNN();optimizer=torch.optim.Adam(model.parameters(),lr=.003);trace=[]
 for epoch in range(35):
  order=torch.randperm(len(it));total=0
  for idx in order.split(128):logits=model(trainx[idx])[0];loss=F.cross_entropy(logits,trainy[idx]);optimizer.zero_grad();loss.backward();optimizer.step();total+=float(loss.detach())*len(idx)
  trace.append(total/len(it))
 model.eval();predicted=model(testx)[0].argmax(1).detach().numpy();acc=float(np.mean(predicted==labels[ie]));selected=int(np.flatnonzero((labels[ie]==3)&(predicted==3))[0]);image=testx[selected:selected+1].clone();target=3;xin=image.clone().requires_grad_(True);logits,a,b=model(xin);grad=torch.autograd.grad(logits[0,target],xin,retain_graph=True)[0];bggrad=torch.autograd.grad(logits[0,target],b)[0];cam_signed=(bggrad.mean((2,3),keepdim=True)*b).sum(1).detach().numpy()[0];cam=np.maximum(cam_signed,0);cam/=max(cam.max(),1e-12);zero=torch.zeros_like(image);meanbase=trainx.mean(0,keepdim=True);attr=ig(model,image,zero,target);attrmean=ig(model,image,meanbase,target);logit=float(model(image)[0][0,target].detach());base_logit=float(model(zero)[0][0,target].detach());igerr=float(attr.sum().detach())-(logit-base_logit)
 # Compare attribution-ranked deletion with a fixed random deletion schedule.
 order_ig=np.argsort(-np.abs(attr.detach().numpy().ravel()));order_random=np.random.default_rng(250).permutation(64);delete={}
 for name,order in [('IG',order_ig),('Random',order_random)]:
  vals=[]
  for n in range(0,65,4):xx=image.clone();xx.view(-1)[torch.tensor(order[:n].copy())]=0;vals.append(float(model(xx)[0][0,target].detach()))
  delete[name]=vals
 fig,axs=plt.subplots(2,3,figsize=(11,7.4),layout='constrained');maps=[image.numpy()[0,0],abs(grad.detach().numpy()[0,0]),attr.detach().numpy()[0,0],attrmean.detach().numpy()[0,0],cam_signed,cam];titles=[L('真实输入：3','Observed input: 3'),'|Saliency|',L('IG：黑色基线','IG: black baseline'),L('IG：均值基线','IG: mean baseline'),L('Grad-CAM：取正部之前','Grad-CAM: before positive-part step'),L('Grad-CAM：取正部之后','Grad-CAM: after positive-part step')]
 for j,(ax,arr,title) in enumerate(zip(axs.flat,maps,titles)):
  vmax=1 if j==5 else max(max(abs(maps[2]).max(),abs(maps[3]).max()) if j in [2,3] else abs(arr).max(),1e-8);im=ax.imshow(arr,cmap='coolwarm' if j in [2,3,4] else 'gray' if j==0 else 'magma',vmin=-vmax if j in [2,3,4] else 0,vmax=vmax);ax.set_title(title,fontsize=11);ax.set_xticks([]);ax.set_yticks([]);fig.colorbar(im,ax=ax,shrink=.6)
 save(fig,'image_attribution')
 # A controlled concept direction: synthetic central vertical versus horizontal strokes.
 concept=[];cl=[]
 for c in [0,1]:
  for _ in range(60):
   xx=rng.uniform(0,.1,(8,8));pos=int(rng.integers(2,6));xx[:,pos]=.9 if c else xx[:,pos]
   if c==0:xx[pos,:]=.9
   concept.append(xx);cl.append(c)
 concept=torch.tensor(np.array(concept)[:,None],dtype=torch.float32);activation=model(concept)[1].detach().flatten(1).numpy();ct,ce=train_test_split(np.arange(120),test_size=.25,stratify=cl,random_state=25);probe=LogisticRegression(C=1,max_iter=2000).fit(activation[ct],np.array(cl)[ct]);cav=probe.coef_[0];cav/=np.linalg.norm(cav);probeacc=float(probe.score(activation[ce],np.array(cl)[ce]));tcav={}
 for k in [1,3,7]:
  sub=testx[labels[ie]==k];first=model(sub)[1].detach().requires_grad_(True);score=model.from_first(first)[0][:,k];direction=(torch.autograd.grad(score.sum(),first)[0].flatten(1).detach().numpy()*cav).sum(1);tcav[str(k)]={'n':len(sub),'positive_fraction':float(np.mean(direction>0)),'mean_directional_derivative':float(direction.mean())}
 # Input optimization maximizes one learned channel with L2 and total-variation regularization.
 vis=torch.tensor(rng.uniform(.2,.8,(1,1,8,8)),dtype=torch.float32,requires_grad=True);vo=torch.optim.Adam([vis],lr=.04);channel=2
 for _ in range(100):
  acts=model(vis)[1];tv=(vis[:,:,:,1:]-vis[:,:,:,:-1]).square().mean()+(vis[:,:,1:]-vis[:,:,:-1]).square().mean();loss=-acts[:,channel].mean()+.03*vis.square().mean()+.1*tv;vo.zero_grad();loss.backward();vo.step()
  with torch.no_grad():vis.clamp_(0,1)
 # Intervention on a trained internal channel: zero channel2 in conv1 before the rest of the network.
 first=model(testx)[1].detach();ablated=first.clone();ablated[:,channel]=0;ablacc=float(np.mean(model.from_first(ablated)[0].argmax(1).detach().numpy()==labels[ie]));activation_drop=float((model.from_first(first)[0][:,3]-model.from_first(ablated)[0][:,3]).mean().detach())
 fig,axs=plt.subplots(1,3,figsize=(13,4.3),layout='constrained')
 for name,vals in delete.items():axs[0].plot(range(0,65,4),vals,'o-',label=name)
 axs[0].set(xlabel=L('归零像素数','Pixels set to zero'),ylabel=L('数字3的logit','Digit-3 logit'),title=L('同一图像、同一黑色替换','Same image and black replacement'));axs[0].legend();vim=axs[1].imshow(vis.detach().numpy()[0,0],cmap='gray',vmin=0,vmax=1);axs[1].set_title(L('通道2偏好的亮度模式','Channel-2 brightness preference'));axs[1].set_xticks([]);axs[1].set_yticks([])
 for spine in axs[1].spines.values():spine.set_visible(True);spine.set_color('#8fa5b1')
 fig.colorbar(vim,ax=axs[1],shrink=.6,label=L('归一化强度','Normalized intensity'));axs[2].bar(list(tcav),[v['positive_fraction'] for v in tcav.values()],color='#247b94');axs[2].set(ylim=(0,1.05),xlabel=L('测试真实类别','True test class'),ylabel=L('概念方向导数为正的比例','Fraction with positive concept derivative'),title=L('竖线相对横线的方向','Vertical-versus-horizontal direction'));save(fig,'interventions_concepts')
 train_acts=model(trainx)[1][:,channel].mean((1,2)).detach().numpy();top6=np.argsort(-train_acts)[:6];fig,axs=plt.subplots(2,6,figsize=(12,4.8),layout='constrained')
 for j,k in enumerate([60,61,62,0,1,2]):axs[0,j].imshow(concept[k,0],cmap='gray',vmin=0,vmax=1);axs[0,j].set_title(L('竖线','Vertical') if k>=60 else L('横线','Horizontal'))
 for j,k in enumerate(top6):axs[1,j].imshow(trainx[k,0],cmap='gray',vmin=0,vmax=1);axs[1,j].set_title(f'label={int(trainy[k])}, a={train_acts[k]:.2f}',fontsize=9)
 for ax in axs.flat:ax.set_xticks([]);ax.set_yticks([])
 fig.suptitle(L('上：合成概念样本；下：通道2平均激活最高的训练图','Top: synthetic concept examples; bottom: training images with highest channel-2 mean activation'));save(fig,'concept_examples')
 # Transparent feasible counterfactual for a two-feature score, with x1 immutable.
 original=np.array([1.,1.]);threshold=5.;changed=original.copy();changed[1]=(threshold-original[0])/2;cf_score=float(changed[0]+2*changed[1])
 summary={'tabular_train_n':len(tr),'tabular_test_n':len(te),'feature_correlation':float(np.corrcoef(X[:,0],X[:,2])[0,1]),'rmse':rmse,'permutation':perm,'shap_point':x.tolist(),'shap_values':phi.tolist(),'shap_base':base,'shap_prediction':pred,'shap_additivity_error':float(base+phi.sum()-pred),'shap_alternative_values':altphi.tolist(),'shap_alternative_base':altbase,'lime':lime,'digits_train_n':len(it),'digits_test_n':len(ie),'digits_accuracy':acc,'selected_test_index':selected,'selected_original_index':int(ie[selected]),'target_logit':logit,'black_baseline_logit':base_logit,'ig_sum':float(attr.sum().detach()),'ig_completeness_error':igerr,'concept_probe_accuracy':probeacc,'concept_direction':tcav,'ablated_channel':channel,'ablated_accuracy':ablacc,'class3_mean_logit_drop_after_ablation':activation_drop,'counterfactual_original_score':3.,'counterfactual_new_score':cf_score,'counterfactual_immutable_error':float(changed[0]-original[0]),'deletion':delete}
 constrained_x=np.tile(x,(60,1));constrained_x[:,0]=grid;summary['monotonic_violation']=float(max(0,-np.min(np.diff(models['Monotonic'].predict(constrained_x)))));summary['ale_weighted_mean']=float(np.average(ale,weights=counts));summary['gradcam_signed_range']=[float(cam_signed.min()),float(cam_signed.max())];summary['gradcam_positive_max']=float(cam.max());summary['channel2_brightness_correlation']=float(np.corrcoef(trainx.mean((1,2,3)).numpy(),train_acts)[0,1])
 torch.save(model.state_dict(),out/'digits-cnn.pt');np.savez_compressed(out/'experiment_data.npz',X=X,y=y,train_indices=tr,test_indices=te,pdp_grid=grid,pdp=pdp,ale_edges=edges,ale=ale,shap=shaps,digits_train_indices=it,digits_test_indices=ie,image=image.numpy(),gradient=grad.detach().numpy(),ig=attr.detach().numpy(),ig_mean=attrmean.detach().numpy(),gradcam=cam,concept_images=concept.numpy(),concept_labels=np.array(cl),cav=cav,optimized_stimulus=vis.detach().numpy(),loss_trace=trace);(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--language',choices=['zh','en'],default='en');a=p.parse_args()
 with threadpool_limits(limits=1):main(a.output,a.language)
