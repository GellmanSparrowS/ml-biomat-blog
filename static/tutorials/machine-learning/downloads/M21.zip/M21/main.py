"""Chronological forecasts, rolling horizons, and held-out interval calibration."""
import argparse
import copy
import json
from pathlib import Path
import numpy as np
import torch
from torch import nn
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

torch.set_num_threads(2)
HORIZON=7


def seasonal_naive(history, horizon=7, period=7):
    return np.asarray([history[-period+(h%period)] for h in range(horizon)])


def generate():
    rng=np.random.default_rng(21);t=np.arange(900);noise=np.zeros(900)
    for i in range(1,900):noise[i]=.6*noise[i-1]+rng.normal(0,1.5)
    trend=40+.018*t;season=5*np.sin(2*np.pi*t/7)+3*np.sin(2*np.pi*t/365)
    shift=6*(t>=820)
    return trend+season+noise+shift,trend,season,noise


def features(history,t):
    return np.r_[history[-28:],t/900,np.sin(2*np.pi*t/7),np.cos(2*np.pi*t/7),
                 np.sin(2*np.pi*t/365),np.cos(2*np.pi*t/365)]


def holt_winters(history,horizon=7):
    alpha,beta,gamma=.25,.03,.2;m=7
    level=np.mean(history[:m]);trend=(np.mean(history[m:2*m])-level)/m
    season=history[:m]-level
    for t in range(m,len(history)):
        old_level=level;slot=t%m;old_season=season[slot]
        level=alpha*(history[t]-old_season)+(1-alpha)*(level+trend)
        trend=beta*(level-old_level)+(1-beta)*trend
        season[slot]=gamma*(history[t]-level)+(1-gamma)*old_season
    return np.array([level+h*trend+season[(len(history)+h-1)%m] for h in range(1,horizon+1)])


def arima110(history,horizon=7):
    differenced=np.diff(history)
    # Conditional least squares for an AR(1) model of first differences.
    design=np.column_stack([np.ones(len(differenced)-1),differenced[:-1]])
    constant,phi=np.linalg.lstsq(design,differenced[1:],rcond=None)[0]
    value=history[-1];delta=differenced[-1];out=[]
    for _ in range(horizon):
        delta=constant+phi*delta;value+=delta;out.append(value)
    return np.asarray(out)


class DirectGRU(nn.Module):
    def __init__(self):
        super().__init__();self.recurrent=nn.GRU(1,16,batch_first=True);self.output=nn.Linear(16,7)
    def forward(self,x):
        _,hidden=self.recurrent(x);return self.output(hidden[-1])


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=['zh','en'],default='en');args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True);zh=args.language=='zh'
    def text(ch,en):return ch if zh else en
    plt.rcParams.update({'font.family':'Microsoft YaHei' if zh else 'Arial','font.size':10,
                         'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    def save(fig,name):
        fig.savefig(args.output/f'{name}-{args.language}.svg',bbox_inches='tight')
        fig.savefig(args.output/f'{name}-{args.language}.png',dpi=140,bbox_inches='tight');plt.close(fig)
    y,trend,season,noise=generate();torch.manual_seed(21)
    train_end,selection_end,calibration_end=500,600,700
    train_ids=np.arange(28,train_end)
    xx=np.array([features(y[:i],i) for i in train_ids]);yy=y[train_ids]
    scaler=StandardScaler().fit(xx);ridge=Ridge(alpha=10).fit(scaler.transform(xx),yy)
    mean,std=y[:train_end].mean(),y[:train_end].std()
    def windows(origins):
        a=np.array([(y[o-28:o]-mean)/std for o in origins],dtype=np.float32)[:,:,None]
        b=np.array([(y[o:o+7]-mean)/std for o in origins],dtype=np.float32)
        return torch.tensor(a),torch.tensor(b)
    train_origins=np.arange(28,train_end-6);select_origins=np.arange(train_end,selection_end-6,7)
    tx,ty=windows(train_origins);vx,vy=windows(select_origins)
    model=DirectGRU();optimizer=torch.optim.Adam(model.parameters(),lr=.005)
    trace=[];best=float('inf')
    for epoch in range(45):
        model.train();losses=[]
        for ids in torch.randperm(len(tx)).split(64):
            optimizer.zero_grad();loss=nn.functional.mse_loss(model(tx[ids]),ty[ids]);loss.backward();optimizer.step();losses.append(loss.item())
        model.eval()
        with torch.no_grad():val=nn.functional.mse_loss(model(vx),vy).item()
        trace.append([float(np.mean(losses)),val])
        if val<best:best=val;checkpoint=copy.deepcopy(model.state_dict())
    model.load_state_dict(checkpoint);model.eval()
    methods=['Naive','Seasonal naive','Holt-Winters','ARIMA(1,1,0)','Ridge','GRU']
    def forecast(origin,method):
        history=y[:origin].copy()
        if method=='Naive':return np.full(7,history[-1])
        if method=='Seasonal naive':return seasonal_naive(history)
        if method=='Holt-Winters':return holt_winters(history)
        if method=='ARIMA(1,1,0)':return arima110(history)
        if method=='Ridge':
            out=[]
            for t in range(origin,origin+7):
                prediction=float(ridge.predict(scaler.transform(features(history,t)[None]))[0]);out.append(prediction);history=np.r_[history,prediction]
            return np.array(out)
        with torch.no_grad():return model(torch.tensor(((history[-28:]-mean)/std).astype(np.float32))[None,:,None]).numpy()[0]*std+mean
    calibration_origins=np.arange(selection_end,calibration_end-6,7)
    test_origins=np.arange(calibration_end,len(y)-6,7)
    target=np.array([y[o:o+7] for o in test_origins]);predictions={m:np.array([forecast(o,m) for o in test_origins]) for m in methods}
    calibration_error=np.abs(np.array([forecast(o,'Ridge')-y[o:o+7] for o in calibration_origins])).ravel()
    rank=min(len(calibration_error),int(np.ceil((len(calibration_error)+1)*.9)))
    radius=float(np.sort(calibration_error)[rank-1])
    lower=predictions['Ridge']-radius;upper=predictions['Ridge']+radius
    covered=(target>=lower)&(target<=upper)
    times=test_origins[:,None]+np.arange(7)[None]
    before=times<820;after=~before
    summary={'test_origins':len(test_origins),'forecast_horizon':7,'test_forecasts':target.size,
             'mae':{m:float(np.mean(np.abs(predictions[m]-target))) for m in methods},
             'mae_by_horizon':{m:np.mean(np.abs(predictions[m]-target),axis=0).tolist() for m in methods},
             'ridge_interval_radius':radius,'coverage':float(covered.mean()),
             'coverage_before_shift':float(covered[before].mean()),'coverage_after_shift':float(covered[after].mean()),
             'gru_selected_epoch':int(np.argmin(np.array(trace)[:,1])+1),
             'latest_training_target':int(train_origins[-1]+6),'first_selection_origin':int(select_origins[0]),
             'latest_calibration_target':int(calibration_origins[-1]+6),'first_test_origin':int(test_origins[0]),
             'seasonal_hand_forecast':seasonal_naive(np.tile(np.arange(1,8),3)).tolist(),
             'arima_constant_increment_forecast':arima110(np.arange(30,dtype=float)).tolist()}
    assert summary['latest_training_target']<summary['first_selection_origin']
    assert summary['latest_calibration_target']<summary['first_test_origin']
    assert np.allclose(arima110(np.arange(30,dtype=float)),np.arange(30,37))
    assert np.array_equal(forecast(700,'Seasonal naive'),y[693:700])
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    np.savez(args.output/'data.npz',series=y,trend=trend,season=season,noise=noise,
             train_trace=trace,test_origins=test_origins,targets=target,interval_lower=lower,
             interval_upper=upper,calibration_errors=calibration_error,**{m.replace(' ','_'):p for m,p in predictions.items()})
    colors=['#8c9196','#b38b31','#328679','#8d64a6','#176b91','#bd554c']
    fig=plt.figure(figsize=(12,6));gs=fig.add_gridspec(2,1,height_ratios=[2,1]);ax=fig.add_subplot(gs[0])
    ax.plot(y,color='#476170',lw=.8)
    for a,b,c,l in [(0,500,'#d9e9ef',text('训练','Train')),(500,600,'#f6e9ca',text('模型选择','Selection')),(600,700,'#e3dfed',text('区间校准','Calibration')),(700,900,'#e0eadc',text('测试','Test'))]:
        ax.axvspan(a,b,color=c,alpha=.5);ax.text((a+b)/2,75,l,ha='center')
    ax.axvline(820,color='#bd554c',ls='--');ax.set(xlabel=text('日索引','Day index'),ylabel=text('需求 / 量单位','Demand / quantity units'),ylim=(25,80))
    ax=fig.add_subplot(gs[1]);start=80;ax.plot(np.arange(start,start+56),y[start:start+56]-trend[start:start+56],color='#176b91',label=text('去已知趋势的观测','Observation minus known trend'))
    ax.plot(np.arange(start,start+56),season[start:start+56],color='#bd554c',label=text('生成的季节分量','Generated seasonal component'))
    ax.set(xlabel=text('日索引','Day index'),ylabel=text('偏离 / 量单位','Deviation / quantity units'));ax.legend(ncol=2,fontsize=9)
    fig.tight_layout();save(fig,'timeline')
    fig=plt.figure(figsize=(12,6));gs=fig.add_gridspec(2,2,width_ratios=[1.5,1])
    ax=fig.add_subplot(gs[0,0]);ax.plot(times.ravel(),target.ravel(),color='#333',lw=1,label=text('真实观测','Observed'))
    ax.plot(times.ravel(),predictions['Ridge'].ravel(),color='#176b91',lw=1,label='Ridge')
    ax.fill_between(times.ravel(),lower.ravel(),upper.ravel(),color='#176b91',alpha=.15,label=text('校准区间','Calibrated interval'))
    ax.axvline(820,color='#bd554c',ls='--');ax.set(xlabel=text('日索引','Day index'),ylabel=text('需求','Demand'));ax.legend(ncol=3,fontsize=8)
    ax=fig.add_subplot(gs[1,0]);errors=np.abs(predictions['Ridge']-target)
    im=ax.imshow(errors.T,aspect='auto',origin='lower',cmap='magma',extent=[test_origins[0]-3.5,test_origins[-1]+3.5,.5,7.5])
    ax.set(xlabel=text('滚动预测起点（日）','Rolling origin (day)'),ylabel=text('预测步长（日）','Horizon (days)'),yticks=range(1,8));fig.colorbar(im,ax=ax,label=text('绝对误差','Absolute error'))
    ax=fig.add_subplot(gs[:,1]);
    method_labels={'Naive':text('朴素','Naive'),'Seasonal naive':text('季节朴素','Seasonal naive')}
    for m,c in zip(methods,colors):ax.plot(range(1,8),summary['mae_by_horizon'][m],'o-',label=method_labels.get(m,m),color=c,ms=4)
    ax.set(xlabel=text('预测步长（日）','Horizon (days)'),ylabel=text('MAE / 量单位','MAE / quantity units'),xticks=range(1,8));ax.legend(fontsize=9)
    fig.tight_layout();save(fig,'backtest')
    fig,axs=plt.subplots(1,3,figsize=(12,3.8),gridspec_kw={'width_ratios':[1.2,1,1]})
    trace=np.array(trace);axs[0].plot(range(1,46),trace[:,0],label=text('训练','Train'),color='#176b91');axs[0].plot(range(1,46),trace[:,1],label=text('选择窗口','Selection window'),color='#bd554c')
    axs[0].set(xlabel=text('轮数','Epoch'),ylabel=text('标准化均方误差','Standardized MSE'),title='GRU');axs[0].legend()
    axs[1].hist(calibration_error,bins=15,color='#176b91',alpha=.8);axs[1].axvline(radius,color='#bd554c',ls='--')
    axs[1].set(xlabel=text('校准绝对残差','Calibration absolute residual'),ylabel=text('预测数','Forecast count'),title=text(f'区间半宽 {radius:.2f}',f'Interval radius {radius:.2f}'))
    vals=[summary['coverage_before_shift'],summary['coverage_after_shift']]
    axs[2].bar([0,1],vals,color=['#176b91','#bd554c']);axs[2].axhline(.9,color='#888',ls='--')
    axs[2].set(xticks=[0,1],xticklabels=[text('变化前','Before shift'),text('变化后','After shift')],ylim=(0,1),ylabel=text('区间覆盖率','Interval coverage'))
    fig.tight_layout();save(fig,'uncertainty')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
