# Public sources and third-party materials

- Forecasting: Principles and Practice — forecasting tools: https://otexts.com/fpp3/toolbox.html
  Technical reference; all experiment figures are original.
- Forecasting: Principles and Practice — exponential smoothing: https://otexts.com/fpp3/exponential-smoothing.html
  Technical reference; all experiment figures are original.
- Forecasting: Principles and Practice — ARIMA: https://otexts.com/fpp3/arima.html
  Technical reference; all experiment figures are original.
- Chronos: Learning the Language of Time Series: https://arxiv.org/abs/2403.07815
  Technical reference; all experiment figures are original.
- A decoder-only foundation model for time-series forecasting: https://arxiv.org/abs/2310.10688
  Technical reference; all experiment figures are original.
